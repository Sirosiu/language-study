# Russian

Professional ambition - C1-oriented study

Everything for this language is in this note. Open a rule, read its examples and follow its practice link. Answers stay in this same note.

[[Start Here|All languages]] · [[Sources and licenses|Sources]]

## Start reading

### алфавит / азбука

| Written form | Name / reading | Related forms |
|---|---|---|
| А а | а  |  ·  ·  |
| Б б | бэ  |  ·  ·  |
| В в | вэ  |  ·  ·  |
| Г г | гэ  |  ·  ·  |
| Д д | дэ  |  ·  ·  |
| Е е | е  |  ·  ·  |
| Ё ё | ё  |  ·  ·  |
| Ж ж | жэ  |  ·  ·  |
| З з | зэ  |  ·  ·  |
| И и | и  |  ·  ·  |
| Й й | и краткое  |  ·  ·  |
| К к | ка  |  ·  ·  |
| Л л | эль  |  ·  ·  |
| М м | эм  |  ·  ·  |
| Н н | эн  |  ·  ·  |
| О о | о  |  ·  ·  |
| П п | пэ  |  ·  ·  |
| Р р | эр  |  ·  ·  |
| С с | эс  |  ·  ·  |
| Т т | тэ  |  ·  ·  |
| У у | у  |  ·  ·  |
| Ф ф | эф  |  ·  ·  |
| Х х | ха  |  ·  ·  |
| Ц ц | цэ  |  ·  ·  |
| Ч ч | че  |  ·  ·  |
| Ш ш | ша  |  ·  ·  |
| Щ щ | ща  |  ·  ·  |
| Ъ ъ | твёрдый знак  |  ·  ·  |
| Ы ы | ы  |  ·  ·  |
| Ь ь | мягкий знак  |  ·  ·  |
| Э э | э  |  ·  ·  |
| Ю ю | ю  |  ·  ·  |
| Я я | я  |  ·  ·  |

![[Resources/Audio/ru/Script and first phrases.mp3]]

The player above is synthetic speech. Word tracks below work offline.

### All 33 letters

Several Cyrillic letters look Latin but have different values: В is /v/, Н /n/, Р /r/, С /s/, У /u/, Х /x/. Ъ and Ь have no independent vowel sound. Practise recognising them inside words, not only reciting the order.

### Stress and softness

Stress is lexical and can move under inflection. Mark it while learning: вода́, во́ды. Unstressed vowels reduce in ordinary speech. Many consonants contrast hard and soft; following е/ё/и/ю/я or ь often signals softness. ы is a separate vowel requiring listening practice.

### Spelling and reading

ё is often printed as е, but its pronunciation and stress must still be learned. Word-final voiced obstruents generally devoice. Use a dictionary recording for a new word and its inflected forms.

### Change the noun ending

книга → книги → книгу = book → of a book → a book as a direct object. Endings express case and number; they are not interchangeable suffix decorations.

### Build an aspect pair

читать → прочитать = read as an activity → read through / finish reading. Prefixes can change aspect and lexical meaning, so record the pair with an example.

### Build a sentence

Я читаю книгу. = I am reading a book. Я не читаю книгу. = I am not reading a book. Russian generally has no present-tense copula in a simple identity sentence: Это книга. = This is a book.

**Здравствуйте.**

Hello (polite).

**Я изучаю русский язык.**

I study Russian.

**Повторите, пожалуйста.**

Repeat, please.

**Что означает это слово?**

What does this word mean?

### Grammar terms in plain English

**Noun** — A word naming a person, thing or idea: student, book, freedom.

**Verb** — A word describing an action or state: read, know, be.

**Subject** — The participant linked to the main verb’s subject pattern. In The student reads a book, the student is the subject.

**Object** — A participant selected by a verb. In The student reads a book, a book is the direct object.

**Agreement** — One word changes to match another, for example an adjective matching a noun’s gender and number.

**Case** — A noun/pronoun form marking its relationship in a sentence. Cases can mark subjects, objects, possession or relations usually expressed by English prepositions.

**Gender** — A grammatical noun class. It does not always describe the sex of a person or any physical property.

**Tense** — A verb system that relates a situation to a time, often past or non-past.

**Aspect** — How a situation is viewed: unfolding, completed, habitual, experienced or in a resulting state.

**Infinitive** — A non-finite verb form often used for a dictionary entry or a complement. It does not by itself give the ordinary person/tense pattern.

**Participle** — A verb-derived form used in compound predicates or as a modifier; its exact function depends on the language and construction.

**Clause** — A unit organised around a predicate. One sentence can contain several clauses.

**Register** — Language choices suited to a situation: casual conversation, polite requests, academic writing or another context.

## Grammar, examples and practice

### Cases, agreement and prepositions

Russian has six main cases. Nominative marks many subjects, genitive possession and quantities, dative recipients, accusative many objects, instrumental means or roles, and prepositional certain governed complements. Animate masculine/plural accusative often resembles genitive. Adjectives and pronouns agree in gender, number and case. Learn prepositions with their meanings and case: в + accusative can mark destination; в + prepositional location. Many verbs govern a case independently of English structure.

**Я читаю новую книгу.**

I am reading a new book. Feminine accusative agreement.

**Я работаю в университете.**

I work at a university. Location with в and prepositional case.

#### Subject pronouns

Subject pronouns distinguish person and number. Вы can address one person politely or multiple people. Russian often omits the present copula in identity and classification statements.

**Ты должен сделать своих родителей счастливыми.**

You must make your parents happy.

**Вы расскажете Тому?**

Will you tell Tom?

![[Resources/Audio/ru/Rule 01.mp3]]

[[Russian#^ru-Q0001|Practise this rule (50 questions)]]

#### Object and oblique pronouns

Pronouns have case-specific forms, and several cases share a surface form. Identify the governing verb/preposition and intended relationship rather than translating by word order alone.

**Тебя, по идее, здесь быть не должно.**

You're not supposed to be here.

**Нам нужно её протестировать.**

We need to test it.

![[Resources/Audio/ru/Rule 02.mp3]]

[[Russian#^ru-Q0051|Practise this rule (50 questions)]]

#### Dative pronouns

Dative often marks a recipient or experiencer. Impersonal constructions such as Мне холодно use dative where English uses a subject plus be.

**Тебе не кажется, что это слишком далеко зашло?**

Don't you think this has gone far enough?

**Мне в целом нравится китайская еда.**

I like Chinese food in general.

![[Resources/Audio/ru/Rule 03.mp3]]

[[Russian#^ru-Q0101|Practise this rule (50 questions)]]

#### Possessive forms

Possessive adjectives agree with the possessed noun in case, gender and number. The possessor’s sex does not choose мой versus моя.

**Моя мама красивая.**

My mother is beautiful.

**Ваша жена ещё в Америке?**

Is your wife still in America?

![[Resources/Audio/ru/Rule 04.mp3]]

[[Russian#^ru-Q0151|Practise this rule (50 questions)]]

#### Locative prepositions

Prepositions govern case. В/на commonly distinguish destination with accusative and location with prepositional. У + genitive is frequent in possession; с has more than one case/meaning pattern.

**Пойди поговори с ними.**

Go talk to them.

**Никто из них не занят.**

None of them are busy.

![[Resources/Audio/ru/Rule 05.mp3]]

[[Russian#^ru-Q0201|Practise this rule (50 questions)]]

#### Adjective agreement

Adjectives agree with the noun in gender, number and case. Short and long adjective forms have distinct distributions and meanings. Learn a full phrase, not an isolated ending.

**Шторм нанёс большой урон урожаю.**

The storm did great harm to the crop.

**У Тома уже новая девушка.**

Tom already has a new girlfriend.

![[Resources/Audio/ru/Rule 06.mp3]]

[[Russian#^ru-Q0251|Practise this rule (50 questions)]]

#### Quantity and comparison

Numerals govern distinctive noun forms, with patterns for 1, 2–4 and other numbers. Gender can affect два/две. Comparatives such as лучше can be invariant in relevant uses.

**Она оказалась меньше, чем я себе её представлял.**

She turned out to be smaller than I'd thought she was.

**Том и Мария больше не любят друг друга.**

Tom and Mary don't love each other anymore.

![[Resources/Audio/ru/Rule 19.mp3]]

[[Russian#^ru-Q0901|Practise this rule (50 questions)]]

<details><summary>Distinguish в Москву and в Москве.</summary>

To Moscow is a destination; in Moscow is a location. The case expresses the relation.

</details>

<details><summary>What belongs on a noun card?</summary>

Gender, stress, plural and difficult case forms, with an example.

</details>

### Aspect and temporal perspective

Imperfective often presents an activity, habit or process; perfective presents a bounded whole or achieved result. These are perspectives rather than a simple finished/unfinished test. Читать and прочитать form a useful reading contrast. Perfective nonpast forms normally express future meaning; imperfective has present and a compound future with быть. Past forms agree in gender and number, not person: читал, читала, читали. Negation, repetition and expectation affect aspect choice.

**Я читал статью.**

I was reading/read an article. Imperfective foregrounds activity in context.

**Я прочитал статью.**

I read the article through. Perfective presents a bounded reading event.

#### Past forms of быть

Russian past tense generally agrees in gender and number rather than person. Был/была/было/были are forms of be and can establish a past state or accompany another construction.

**Том был напуган до смерти.**

Tom was scared to death.

**Том тоже был сильно голоден.**

Tom also was very hungry.

![[Resources/Audio/ru/Rule 07.mp3]]

[[Russian#^ru-Q0301|Practise this rule (50 questions)]]

#### Common present verbs

Present forms agree with person and number. Ordinary present-time activity uses an imperfective verb. Perfective forms with similar endings normally refer to future events.

**Думаю, когда-нибудь это произойдёт.**

I think that'll happen someday.

**Том мало что знает.**

Tom doesn't know much.

![[Resources/Audio/ru/Rule 08.mp3]]

[[Russian#^ru-Q0351|Practise this rule (50 questions)]]

#### Bounded past and aspect

These common perfective past forms present a bounded event in suitable contexts. Aspect is lexical and interacts with negation and discourse; a prefix is not always a simple completion switch.

**Она сказала, что не будет ждать.**

She said she wouldn't wait.

**Даже Том такого бы не сделал.**

Even Tom wouldn't do that.

![[Resources/Audio/ru/Rule 09.mp3]]

[[Russian#^ru-Q0401|Practise this rule (50 questions)]]

#### Future constructions

Буду plus an imperfective infinitive expresses future activity. A perfective verb can form its future without буду. Буду alone can also mean will be.

**Буду держать кулачки.**

I'll keep my fingers crossed.

**"На пикнике будет живая музыка". - "Что за музыка?"**

"There will be live music at the picnic." "What kind of music?"

![[Resources/Audio/ru/Rule 10.mp3]]

[[Russian#^ru-Q0451|Practise this rule (50 questions)]]

#### Hypothetical бы

Бы combines with a past-form verb to express a conditional/subjunctive meaning. Past morphology here does not always locate the situation in the past. Если introduces an if condition.

**Она бы вам понравилась.**

You would've liked her.

**Вот бы мне мозги Тома.**

I wish I had Tom's brains.

![[Resources/Audio/ru/Rule 17.mp3]]

[[Russian#^ru-Q0801|Practise this rule (50 questions)]]

<details><summary>Can every English past tense be translated with perfective?</summary>

No. Perspective, repetition and context determine aspect.

</details>

<details><summary>How does a female speaker say I was reading?</summary>

Я читала. The past form marks feminine gender.

</details>

### Motion, modality and impersonal sentences

Russian distinguishes unidirectional and multidirectional or habitual motion in pairs such as идти/ходить and ехать/ездить. Transport and walking also differ. Prefixes add direction and often change aspectual relationships; learn the complete pair in context. Мне нужно ... and мне нравится ... use dative experiencers. Modal expressions may be impersonal, so an English subject does not always become Russian nominative.

**Я иду в библиотеку.**

I am going to the library on foot. A current directed movement.

**Мне нужно проверить данные.**

I need to check the data. Dative experiencer with an impersonal necessity expression.

#### Motion forms

Motion verbs distinguish travel on foot/vehicle and directed versus multidirectional/habitual patterns. Prefixes add direction and other meanings. The English verb go hides distinctions Russian expresses.

**Он пошёл домой через три часа.**

He went home three hours later.

**Я ехал домой.**

I was on my way home.

![[Resources/Audio/ru/Rule 11.mp3]]

[[Russian#^ru-Q0501|Practise this rule (50 questions)]]

#### Negation

Не negates a predicate or constituent; нет states absence/existence negation and commonly governs genitive. Negative pronouns can participate in negative concord. Нельзя can express prohibition or impossibility.

**Рыбы не любят солнечный свет.**

Fish don't like sunlight.

**Тому не пришлось ничего объяснять.**

Tom didn't have to explain anything.

![[Resources/Audio/ru/Rule 12.mp3]]

[[Russian#^ru-Q0551|Practise this rule (50 questions)]]

#### Modal and impersonal words

Modality can be expressed with verbs or impersonal predicates. Нужно/надо often combine with a dative experiencer and infinitive. Может can also be a verb meaning can; context distinguishes inference.

**Тому нужно внимание.**

Tom needs attention.

**Тому нужно, чтобы Мэри кто-нибудь помог.**

Tom needs somebody to help Mary.

![[Resources/Audio/ru/Rule 13.mp3]]

[[Russian#^ru-Q0601|Practise this rule (50 questions)]]

#### Questions

Где asks location, куда destination, откуда source. Question words can inflect for case. Word order and intonation help mark a question without an English do auxiliary.

**Когда мы можем пойти купаться?**

When can we go swimming?

**Том, вероятно, думал, что я счастлив.**

Tom probably thought I was happy.

![[Resources/Audio/ru/Rule 14.mp3]]

[[Russian#^ru-Q0651|Practise this rule (50 questions)]]

<details><summary>Contrast я иду and я хожу in a suitable context.</summary>

Иду can be one directed current journey; хожу can describe a habitual activity or non-unidirectional motion.

</details>

<details><summary>Translate I like this method.</summary>

Мне нравится этот метод. Метод is the grammatical subject.

</details>

### Participles, clauses and academic compression

Russian formal prose uses participles to modify nouns and adverbial participles to relate actions. Agreement identifies the noun modified; the implied agent of an adverbial participle normally matches the relevant clause subject. A literal English dangling construction can produce a Russian error too. Relative который agrees with the antecedent in gender and number, while its case follows its role within the relative clause.

**данные, полученные в ходе исследования**

data obtained during the study Passive past participle agrees with данные.

**метод, который мы используем**

the method we use Relative pronoun is the object within its clause.

#### Content clauses

Что can introduce reported content, while чтобы often marks purpose or a desired event. Ли helps form indirect yes/no questions. Identical words may have interrogative or relative roles elsewhere.

**Том приехал сюда, чтобы учить французский.**

Tom came here to study French.

**Том использовал лом, чтобы открыть крышку ящика.**

Tom used a crowbar to pry open the lid of the crate.

![[Resources/Audio/ru/Rule 15.mp3]]

[[Russian#^ru-Q0701|Practise this rule (50 questions)]]

#### Relative forms

Который agrees with its antecedent for gender/number but takes case from its role inside the relative clause. Do not copy the antecedent’s case automatically.

**Первым предметом, который он приобрёл, стал будильник.**

The first item he bought was an alarm clock.

**Есть математическое понятие, которого я не понимаю. Не могли бы вы мне его объяснить?**

There's a mathematical concept that I don't understand. Could you explain it to me?

![[Resources/Audio/ru/Rule 16.mp3]]

[[Russian#^ru-Q0751|Practise this rule (50 questions)]]

#### Logical connectors

Distinguish cause, concession and result. Поэтому presents a consequence, not its cause. Несмотря often belongs to a prepositional concessive construction requiring its own complement.

**Есть только одна религия, хотя у неё сотня вариаций.**

There is only one religion, though there are a hundred versions of it.

**Он не извинился, хотя и был неправ.**

Although he was wrong, he didn't say he was sorry.

![[Resources/Audio/ru/Rule 18.mp3]]

[[Russian#^ru-Q0851|Practise this rule (50 questions)]]

<details><summary>What should you identify before translating a participial phrase?</summary>

The head noun, agreement, agent, time relation and any governed complements.

</details>

<details><summary>Expand данные, полученные вчера.</summary>

Данные, которые были получены вчера. A finite relative makes the passive event explicit.

</details>

### Professional register and reading

Use Вы for polite address, with conventions determined by relationship and medium. Не могли бы Вы ... is a standard courteous request. Distinguish возможно, вероятно and несомненно rather than translating all as probably.
Teaching passage: Результаты исследования указывают на связь между двумя факторами. Однако они не доказывают, что один фактор вызывает другой. Для более точного вывода необходимо учитывать условия исследования.
Translation: The study results indicate an association between two factors. However, they do not prove that one causes the other. A more precise conclusion requires considering the study conditions.

**Не могли бы Вы уточнить этот пункт?**

Could you clarify this point? Courteous conditional request.

**Однако это не доказывает причинную связь.**

However, this does not prove a causal relationship. Contrast and an explicit limit on inference.

#### Professional stance and courtesy

Пожалуйста supports courteous requests. Возможно/вероятно limit certainty; следует/необходимо express recommendations or necessity. Distinguish a documented claim from a possibility.

**Оставь его, пожалуйста, в покое.**

Leave him alone, please.

**Приходи ещё, пожалуйста.**

Please come again.

![[Resources/Audio/ru/Rule 20.mp3]]

[[Russian#^ru-Q0951|Practise this rule (50 questions)]]

<details><summary>Summarise the passage without strengthening the claim.</summary>

It reports an association but not proof of causation, and requires attention to conditions.

</details>

<details><summary>Write a 100-word clarification request.</summary>

Use accurate cases, appropriate Вы address, a precise question and a practical next step.

</details>

## Word bank and recordings

1,000 study entries, based on dictionary selections and authored teaching glosses. Learn a word in a phrase; consult the linked entry for additional senses.

<details><summary>Words 1–50</summary>

![[Resources/Audio/ru/Words 0001-0050.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [произношение](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%BE%D0%B8%D0%B7%D0%BD%D0%BE%D1%88%D0%B5%D0%BD%D0%B8%D0%B5) | pronunciation |  · noun |
| [в](https://en.wiktionary.org/wiki/%D0%B2#Russian) | in (location + prepositional); into (direction + accusative) | v · prep |
| [грамматика](https://en.wiktionary.org/wiki/%D0%B3%D1%80%D0%B0%D0%BC%D0%BC%D0%B0%D1%82%D0%B8%D0%BA%D0%B0) | grammar |  · noun |
| [и](https://en.wiktionary.org/wiki/%D0%B8#Russian) | and; also in some contexts | i · conj |
| [на](https://en.wiktionary.org/wiki/%D0%BD%D0%B0#Russian) | onto, on | na · prep |
| [не](https://en.wiktionary.org/wiki/%D0%BD%D0%B5#Russian) | not, no, -n't, without | ne · particle |
| [с](https://en.wiktionary.org/wiki/%D1%81#Russian) | with | [s] · prep |
| [что](https://en.wiktionary.org/wiki/%D1%87%D1%82%D0%BE#Russian) | what; that (introducing a clause) | što · pron |
| [я](https://en.wiktionary.org/wiki/%D1%8F#Russian) | I | ja · pron |
| [по](https://en.wiktionary.org/wiki/%D0%BF%D0%BE#Russian) | used broadly to indicate action, typically involving movement, across a surface or across several things in a generally flat plane; across, on, along, down, up, all over, (all) around | po · prep |
| [упражнение](https://en.wiktionary.org/wiki/%D1%83%D0%BF%D1%80%D0%B0%D0%B6%D0%BD%D0%B5%D0%BD%D0%B8%D0%B5) | exercise; practice task |  · noun |
| [а](https://en.wiktionary.org/wiki/%D0%B0#Russian) | and; but (contrasting or shifting the topic) | a · conj |
| [как](https://en.wiktionary.org/wiki/%D0%BA%D0%B0%D0%BA#Russian) | how (in what way, in what manner) (translated as "what" with some verbs) | kak · adv |
| [из](https://en.wiktionary.org/wiki/%D0%B8%D0%B7#Russian) | from | iz · prep |
| [это](https://en.wiktionary.org/wiki/%D1%8D%D1%82%D0%BE#Russian) | Generic demonstrative pronoun. Translated as "this" or "that" (or their plural forms, "these" or "those"), depending on the context. | éto · pron |
| [за](https://en.wiktionary.org/wiki/%D0%B7%D0%B0#Russian) | to | za · prep |
| [для](https://en.wiktionary.org/wiki/%D0%B4%D0%BB%D1%8F#Russian) | for | dlja · prep |
| [о](https://en.wiktionary.org/wiki/%D0%BE#Russian) | about (+ prepositional); an exclamation in another use | o · prep |
| [о.](https://en.wiktionary.org/wiki/%D0%BE.#Russian) | order | [ˈordʲɪr] · noun |
| [тетрадь](https://en.wiktionary.org/wiki/%D1%82%D0%B5%D1%82%D1%80%D0%B0%D0%B4%D1%8C) | notebook |  · noun |
| [к](https://en.wiktionary.org/wiki/%D0%BA#Russian) | to, toward | [k] · prep |
| [-то](https://en.wiktionary.org/wiki/-%D1%82%D0%BE#Russian) | particle used to give intonational emphasis to a part of speech | -to · particle |
| [но](https://en.wiktionary.org/wiki/%D0%BD%D0%BE#Russian) | but, yet | no · conj |
| [то](https://en.wiktionary.org/wiki/%D1%82%D0%BE#Russian) | Used in various collocations to refer to the content of a sentence or clause just mentioned by the speaker. | to · pron |
| [у](https://en.wiktionary.org/wiki/%D1%83#Russian) | at/by; possession in у меня есть | u · prep |
| [его](https://en.wiktionary.org/wiki/%D0%B5%D0%B3%D0%BE#Russian) | his | jevó · pron |
| [он](https://en.wiktionary.org/wiki/%D0%BE%D0%BD#Russian) | third-person masculine singular pronoun: he, it. | on · pron |
| [от](https://en.wiktionary.org/wiki/%D0%BE%D1%82#Russian) | to denote the starting point of the movement of something | ot · prep |
| [что за](https://en.wiktionary.org/wiki/%D1%87%D1%82%D0%BE%20%D0%B7%D0%B0#Russian) | what, what kind of, what sort of | štó za · adv |
| [что-то](https://en.wiktionary.org/wiki/%D1%87%D1%82%D0%BE-%D1%82%D0%BE#Russian) | something (implies that one has a certain thing in mind, but does not know exactly what) | štó-to · pron |
| [так](https://en.wiktionary.org/wiki/%D1%82%D0%B0%D0%BA#Russian) | like that, like this (in that/this way, in that/this manner) (translated as "that" or "this" with some verbs) | tak · adv |
| [из-за](https://en.wiktionary.org/wiki/%D0%B8%D0%B7-%D0%B7%D0%B0#Russian) | from (behind) | íz-za · prep |
| [же](https://en.wiktionary.org/wiki/%D0%B6%D0%B5#Russian) | and, but | že · conj |
| [мы](https://en.wiktionary.org/wiki/%D0%BC%D1%8B#Russian) | we | my · pron |
| [до](https://en.wiktionary.org/wiki/%D0%B4%D0%BE#Russian) | before | do · prep |
| [только](https://en.wiktionary.org/wiki/%D1%82%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE#Russian) | only, but | tólʹko · adv |
| [если](https://en.wiktionary.org/wiki/%D0%B5%D1%81%D0%BB%D0%B8#Russian) | if, in case | jésli · conj |
| [когда](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0#Russian) | when | kogdá · adv |
| [то-то](https://en.wiktionary.org/wiki/%D1%82%D0%BE-%D1%82%D0%BE#Russian) | Aha!, That's it!, There we go! What did I tell you? | tó-to · intj |
| [было](https://en.wiktionary.org/wiki/%D0%B1%D1%8B%D0%BB%D0%BE#Russian) | nearly, on the point of, just about | býlo · particle |
| [так как](https://en.wiktionary.org/wiki/%D1%82%D0%B0%D0%BA%20%D0%BA%D0%B0%D0%BA#Russian) | as, since, because, inasmuch as | ták kak · conj |
| [уже](https://en.wiktionary.org/wiki/%D1%83%D0%B6%D0%B5#Russian) | already; carries the sense of the perfect continuous tenses in English. | užé · adv |
| [бы](https://en.wiktionary.org/wiki/%D0%B1%D1%8B#Russian) | A verbal particle used to render conditional and subjunctive mood | by · particle |
| [или](https://en.wiktionary.org/wiki/%D0%B8%D0%BB%D0%B8#Russian) | or | íli · conj |
| [их](https://en.wiktionary.org/wiki/%D0%B8%D1%85#Russian) | their | ix · pron |
| [они](https://en.wiktionary.org/wiki/%D0%BE%D0%BD%D0%B8#Russian) | they | oní · pron |
| [при](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%B8#Russian) | with; when; during (in the time and/or presence (of)) | pri · prep |
| [время](https://en.wiktionary.org/wiki/%D0%B2%D1%80%D0%B5%D0%BC%D1%8F#Russian) | time | vrémja · noun |
| [кто](https://en.wiktionary.org/wiki/%D0%BA%D1%82%D0%BE#Russian) | who | kto · pron |
| [чтобы](https://en.wiktionary.org/wiki/%D1%87%D1%82%D0%BE%D0%B1%D1%8B#Russian) | that...should (indicates the subjunctive) | štóby · conj |

</details>

<details><summary>Words 51–100</summary>

![[Resources/Audio/ru/Words 0051-0100.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [есть](https://en.wiktionary.org/wiki/%D0%B5%D1%81%D1%82%D1%8C#Russian) | to eat | jestʹ · verb |
| [она](https://en.wiktionary.org/wiki/%D0%BE%D0%BD%D0%B0#Russian) | she, it (third-person feminine singular pronoun) | oná · pron |
| [вы](https://en.wiktionary.org/wiki/%D0%B2%D1%8B#Russian) | you (plural or formal singular) | vy · pron |
| [после](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D1%81%D0%BB%D0%B5#Russian) | after (in time) | pósle · prep |
| [нет](https://en.wiktionary.org/wiki/%D0%BD%D0%B5%D1%82#Russian) | no | net · intj |
| [очень](https://en.wiktionary.org/wiki/%D0%BE%D1%87%D0%B5%D0%BD%D1%8C#Russian) | very, really, much, very much | óčenʹ · adv |
| [вот](https://en.wiktionary.org/wiki/%D0%B2%D0%BE%D1%82#Russian) | Used in place of a pronoun to direct attention towards something; this (is), here (is), that (is), there (is) | vot · particle |
| [чем](https://en.wiktionary.org/wiki/%D1%87%D0%B5%D0%BC#Russian) | than | čem · conj |
| [быть](https://en.wiktionary.org/wiki/%D0%B1%D1%8B%D1%82%D1%8C#Russian) | to be | bytʹ · verb |
| [где](https://en.wiktionary.org/wiki/%D0%B3%D0%B4%D0%B5#Russian) | where | gde · adv |
| [под](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%B4#Russian) | under, below, beneath (movement to beneath a location) | pod · prep |
| [кто-то](https://en.wiktionary.org/wiki/%D0%BA%D1%82%D0%BE-%D1%82%D0%BE#Russian) | somebody, someone (implies that one has a certain person in mind, but does not know exactly who) | kto-to · pron |
| [то есть](https://en.wiktionary.org/wiki/%D1%82%D0%BE%20%D0%B5%D1%81%D1%82%D1%8C#Russian) | that is, in other words, i.e. | tó jestʹ · adv |
| [да](https://en.wiktionary.org/wiki/%D0%B4%D0%B0#Russian) | yes | da · adv |
| [даже](https://en.wiktionary.org/wiki/%D0%B4%D0%B0%D0%B6%D0%B5#Russian) | even | dáže · adv |
| [можно](https://en.wiktionary.org/wiki/%D0%BC%D0%BE%D0%B6%D0%BD%D0%BE#Russian) | one can, one may | móžno · adj |
| [просто](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%BE%D1%81%D1%82%D0%BE#Russian) | simply, plainly, just | prósto · adv |
| [больше](https://en.wiktionary.org/wiki/%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5#Russian) | any more | bólʹše · adv |
| [из-под](https://en.wiktionary.org/wiki/%D0%B8%D0%B7-%D0%BF%D0%BE%D0%B4#Russian) | from under | íz-pod · prep |
| [сейчас](https://en.wiktionary.org/wiki/%D1%81%D0%B5%D0%B9%D1%87%D0%B0%D1%81#Russian) | now (presently, at present, at the moment) | sejčás · adv |
| [более](https://en.wiktionary.org/wiki/%D0%B1%D0%BE%D0%BB%D0%B5%D0%B5#Russian) | more | bóleje · adv |
| [ну](https://en.wiktionary.org/wiki/%D0%BD%D1%83#Russian) | well | nu · intj |
| [без](https://en.wiktionary.org/wiki/%D0%B1%D0%B5%D0%B7#Russian) | without, aside from, except, minus, free of/from (signifying absence) | bez · prep |
| [ни](https://en.wiktionary.org/wiki/%D0%BD%D0%B8#Russian) | neither, nor | ni · conj |
| [об](https://en.wiktionary.org/wiki/%D0%BE%D0%B1#Russian) | about (variant of о before some sounds) | ob · prep |
| [там](https://en.wiktionary.org/wiki/%D1%82%D0%B0%D0%BC#Russian) | there | tam · adv |
| [человек](https://en.wiktionary.org/wiki/%D1%87%D0%B5%D0%BB%D0%BE%D0%B2%D0%B5%D0%BA#Russian) | person, human being, man | čelovék · noun |
| [себя](https://en.wiktionary.org/wiki/%D1%81%D0%B5%D0%B1%D1%8F#Russian) | myself, yourself, himself, herself, itself, ourselves, yourselves, themselves (no nominative case) | sebjá · pron |
| [этот](https://en.wiktionary.org/wiki/%D1%8D%D1%82%D0%BE%D1%82#Russian) | Mostly proximal demonstrative determiner. Usually translated as "this"/"these", but can occasionally be translated as "that"/"those" and, in some cases, the English definite article, "the". | étot · det |
| [а сейчас](https://en.wiktionary.org/wiki/%D0%B0%20%D1%81%D0%B5%D0%B9%D1%87%D0%B0%D1%81#Russian) | now, and now, but now (beginning a sentence or phrase to indicate a change or contrast from the foregoing) | [ɐ‿sʲɪˈt͡ɕas] · adv |
| [который](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%8B%D0%B9#Russian) | what, which (among a specific series) | kotóryj · pron |
| [ли](https://en.wiktionary.org/wiki/%D0%BB%D0%B8#Russian) | Do/does/did...? Is/are/was/were...? | li · particle |
| [раз](https://en.wiktionary.org/wiki/%D1%80%D0%B0%D0%B7#Russian) | time (an instance or occurrence) | raz · noun |
| [один](https://en.wiktionary.org/wiki/%D0%BE%D0%B4%D0%B8%D0%BD#Russian) | one (1) | odín · num |
| [теперь](https://en.wiktionary.org/wiki/%D1%82%D0%B5%D0%BF%D0%B5%D1%80%D1%8C#Russian) | now, at present | tepérʹ · adv |
| [сегодня](https://en.wiktionary.org/wiki/%D1%81%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F#Russian) | today | sevódnja · adv |
| [надо](https://en.wiktionary.org/wiki/%D0%BD%D0%B0%D0%B4%D0%BE#Russian) | must, (it is) necessary | nádo · adj |
| [через](https://en.wiktionary.org/wiki/%D1%87%D0%B5%D1%80%D0%B5%D0%B7#Russian) | through | čérez · prep |
| [если бы только](https://en.wiktionary.org/wiki/%D0%B5%D1%81%D0%BB%D0%B8%20%D0%B1%D1%8B%20%D1%82%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE#Russian) | if only | jésli by tólʹko · phrase |
| [почему](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D1%87%D0%B5%D0%BC%D1%83#Russian) | why (due to what, on what grounds) | počemú · adv |
| [день](https://en.wiktionary.org/wiki/%D0%B4%D0%B5%D0%BD%D1%8C#Russian) | day, daytime | denʹ · noun |
| [пока](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%BA%D0%B0#Russian) | for the present, for the time being | poká · adv |
| [там же](https://en.wiktionary.org/wiki/%D1%82%D0%B0%D0%BC%20%D0%B6%D0%B5#Russian) | in the same place | tám že · adv |
| [может быть](https://en.wiktionary.org/wiki/%D0%BC%D0%BE%D0%B6%D0%B5%D1%82%20%D0%B1%D1%8B%D1%82%D1%8C#Russian) | maybe, perhaps, possibly | móžet bytʹ · adv |
| [им.](https://en.wiktionary.org/wiki/%D0%B8%D0%BC.#Russian) | named after (usually not translated, see и́мя (ímja)) | im. · prep |
| [пока не](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%BA%D0%B0%20%D0%BD%D0%B5#Russian) | unless, until | poká ne · conj |
| [вот-вот](https://en.wiktionary.org/wiki/%D0%B2%D0%BE%D1%82-%D0%B2%D0%BE%D1%82#Russian) | just about to; on the point of | vot-vót · adv |
| [всегда](https://en.wiktionary.org/wiki/%D0%B2%D1%81%D0%B5%D0%B3%D0%B4%D0%B0#Russian) | always | vsegdá · adv |
| [между](https://en.wiktionary.org/wiki/%D0%BC%D0%B5%D0%B6%D0%B4%D1%83#Russian) | between, among | méždu · prep |
| [здесь](https://en.wiktionary.org/wiki/%D0%B7%D0%B4%D0%B5%D1%81%D1%8C#Russian) | here | zdesʹ · adv |

</details>

<details><summary>Words 101–150</summary>

![[Resources/Audio/ru/Words 0101-0150.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [потому](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D1%82%D0%BE%D0%BC%D1%83#Russian) | therefore, because of that, consequently | potomú · adv |
| [почему-то](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D1%87%D0%B5%D0%BC%D1%83-%D1%82%D0%BE#Russian) | for some reason, somewhy | počemú-to · adv |
| [такой](https://en.wiktionary.org/wiki/%D1%82%D0%B0%D0%BA%D0%BE%D0%B9#Russian) | such (a), such (used to indicate a sufficient degree of something, such that the following clause is true) | takój · det |
| [год](https://en.wiktionary.org/wiki/%D0%B3%D0%BE%D0%B4#Russian) | year | god · noun |
| [два](https://en.wiktionary.org/wiki/%D0%B4%D0%B2%D0%B0#Russian) | two (2) | dva · num |
| [потому что](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE#Russian) | because | potomú što · conj |
| [люди](https://en.wiktionary.org/wiki/%D0%BB%D1%8E%D0%B4%D0%B8#Russian) | people, humans | ljúdi · noun |
| [много](https://en.wiktionary.org/wiki/%D0%BC%D0%BD%D0%BE%D0%B3%D0%BE#Russian) | much | mnógo · adv |
| [тут](https://en.wiktionary.org/wiki/%D1%82%D1%83%D1%82#Russian) | here | tut · adv |
| [всё](https://en.wiktionary.org/wiki/%D0%B2%D1%81%D1%91#Russian) | everything | vsjo · pron |
| [её](https://en.wiktionary.org/wiki/%D0%B5%D1%91#Russian) | her, its | jejó · pron |
| [несколько](https://en.wiktionary.org/wiki/%D0%BD%D0%B5%D1%81%D0%BA%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE#Russian) | somewhat, slightly, rather; some | néskolʹko · adv |
| [тогда](https://en.wiktionary.org/wiki/%D1%82%D0%BE%D0%B3%D0%B4%D0%B0#Russian) | then (at that time) | togdá · adv |
| [мой](https://en.wiktionary.org/wiki/%D0%BC%D0%BE%D0%B9#Russian) | my, mine | moj · pron |
| [ещё](https://en.wiktionary.org/wiki/%D0%B5%D1%89%D1%91#Russian) | yet, more | ješčó · adv |
| [место](https://en.wiktionary.org/wiki/%D0%BC%D0%B5%D1%81%D1%82%D0%BE#Russian) | place, spot | mésto · noun |
| [потом](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D1%82%D0%BE%D0%BC#Russian) | afterwards, afterward, after that | potóm · adv |
| [против](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%BE%D1%82%D0%B8%D0%B2#Russian) | against | prótiv · prep |
| [хорошо](https://en.wiktionary.org/wiki/%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%BE#Russian) | well, right | xorošó · adv |
| [лишь](https://en.wiktionary.org/wiki/%D0%BB%D0%B8%D1%88%D1%8C#Russian) | only, merely, just | lišʹ · adv |
| [дело](https://en.wiktionary.org/wiki/%D0%B4%D0%B5%D0%BB%D0%BE#Russian) | affair, matter, concern | délo · noun |
| [над](https://en.wiktionary.org/wiki/%D0%BD%D0%B0%D0%B4#Russian) | above, over | nad · prep |
| [какой](https://en.wiktionary.org/wiki/%D0%BA%D0%B0%D0%BA%D0%BE%D0%B9#Russian) | what | kakój · det |
| [тот](https://en.wiktionary.org/wiki/%D1%82%D0%BE%D1%82#Russian) | that, those (distal to an observer) | tot · det |
| [перед](https://en.wiktionary.org/wiki/%D0%BF%D0%B5%D1%80%D0%B5%D0%B4#Russian) | in front of, before | péred · prep |
| [поэтому](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D1%8D%D1%82%D0%BE%D0%BC%D1%83#Russian) | so, therefore, that's why | poétomu · adv |
| [сделать](https://en.wiktionary.org/wiki/%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C#Russian) | to make, to do | sdélatʹ · verb |
| [три](https://en.wiktionary.org/wiki/%D1%82%D1%80%D0%B8#Russian) | three (3) | tri · num |
| [стал](https://en.wiktionary.org/wiki/%D1%81%D1%82%D0%B0%D0%BB#Russian) | began to | stal · verb |
| [первый](https://en.wiktionary.org/wiki/%D0%BF%D0%B5%D1%80%D0%B2%D1%8B%D0%B9#Russian) | first | pérvyj · adj |
| [хотя](https://en.wiktionary.org/wiki/%D1%85%D0%BE%D1%82%D1%8F#Russian) | although, though (contrasting two clauses) | xotjá · conj |
| [ведь](https://en.wiktionary.org/wiki/%D0%B2%D0%B5%D0%B4%D1%8C#Russian) | after all | vedʹ · intj |
| [дома](https://en.wiktionary.org/wiki/%D0%B4%D0%BE%D0%BC%D0%B0#Russian) | at home | dóma · adv |
| [спасибо](https://en.wiktionary.org/wiki/%D1%81%D0%BF%D0%B0%D1%81%D0%B8%D0%B1%D0%BE#Russian) | thank you, thanks | spasíbo · intj |
| [учебник](https://en.wiktionary.org/wiki/%D1%83%D1%87%D0%B5%D0%B1%D0%BD%D0%B8%D0%BA) | textbook |  · noun |
| [сам](https://en.wiktionary.org/wiki/%D1%81%D0%B0%D0%BC#Russian) | self, -self | sam · pron |
| [деньги](https://en.wiktionary.org/wiki/%D0%B4%D0%B5%D0%BD%D1%8C%D0%B3%D0%B8#Russian) | money | dénʹgi · noun |
| [новый](https://en.wiktionary.org/wiki/%D0%BD%D0%BE%D0%B2%D1%8B%D0%B9#Russian) | new | nóvyj · adj |
| [около](https://en.wiktionary.org/wiki/%D0%BE%D0%BA%D0%BE%D0%BB%D0%BE#Russian) | near, around, about, by | ókolo · prep |
| [почти](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D1%87%D1%82%D0%B8#Russian) | almost, nearly | počtí · adv |
| [свой](https://en.wiktionary.org/wiki/%D1%81%D0%B2%D0%BE%D0%B9#Russian) | one's own; my, his, her, its, our, your, their (always refers to the subject of the clause) | svoj · pron |
| [часть](https://en.wiktionary.org/wiki/%D1%87%D0%B0%D1%81%D1%82%D1%8C#Russian) | part | častʹ · noun |
| [делать](https://en.wiktionary.org/wiki/%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C#Russian) | to make, to do | délatʹ · verb |
| [кроме](https://en.wiktionary.org/wiki/%D0%BA%D1%80%D0%BE%D0%BC%D0%B5#Russian) | except, besides | króme · prep |
| [каждый](https://en.wiktionary.org/wiki/%D0%BA%D0%B0%D0%B6%D0%B4%D1%8B%D0%B9#Russian) | every, each | káždyj · pron |
| [среди](https://en.wiktionary.org/wiki/%D1%81%D1%80%D0%B5%D0%B4%D0%B8#Russian) | among, in the midst of | sredí · prep |
| [понимать](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%BD%D0%B8%D0%BC%D0%B0%D1%82%D1%8C) | to understand |  · verb |
| [повторять](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%B2%D1%82%D0%BE%D1%80%D1%8F%D1%82%D1%8C) | to repeat |  · verb |
| [что-нибудь](https://en.wiktionary.org/wiki/%D1%87%D1%82%D0%BE-%D0%BD%D0%B8%D0%B1%D1%83%D0%B4%D1%8C#Russian) | anything, something (implies one does not care what, or does not have any particular thing in mind) | štó-nibudʹ · pron |
| [дом](https://en.wiktionary.org/wiki/%D0%B4%D0%BE%D0%BC#Russian) | house, building (a residential building) | dom · noun |

</details>

<details><summary>Words 151–200</summary>

![[Resources/Audio/ru/Words 0151-0200.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [ещё раз](https://en.wiktionary.org/wiki/%D0%B5%D1%89%D1%91%20%D1%80%D0%B0%D0%B7#Russian) | once again | ješčó raz · adv |
| [либо](https://en.wiktionary.org/wiki/%D0%BB%D0%B8%D0%B1%D0%BE#Russian) | either ... or | líbo · conj |
| [сколько](https://en.wiktionary.org/wiki/%D1%81%D0%BA%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE#Russian) | how much, how many | skólʹko · pron |
| [что-либо](https://en.wiktionary.org/wiki/%D1%87%D1%82%D0%BE-%D0%BB%D0%B8%D0%B1%D0%BE#Russian) | anything, something (implies one does not care what, or does not have any particular thing in mind) | štó-libo · pron |
| [сказать](https://en.wiktionary.org/wiki/%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C#Russian) | to say, to tell | skazátʹ · verb |
| [друг](https://en.wiktionary.org/wiki/%D0%B4%D1%80%D1%83%D0%B3#Russian) | close friend | drug · noun |
| [затем](https://en.wiktionary.org/wiki/%D0%B7%D0%B0%D1%82%D0%B5%D0%BC#Russian) | then, thereupon, after that | zatém · adv |
| [оно](https://en.wiktionary.org/wiki/%D0%BE%D0%BD%D0%BE#Russian) | it (third-person neuter singular pronoun) | onó · pron |
| [про](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%BE#Russian) | about, concerning | pro · prep |
| [см](https://en.wiktionary.org/wiki/%D1%81%D0%BC#Russian) | cm, centimeter | sm · noun |
| [см.](https://en.wiktionary.org/wiki/%D1%81%D0%BC.#Russian) | cf., v., q.v., refer to, compare with | sm. · verb |
| [сразу](https://en.wiktionary.org/wiki/%D1%81%D1%80%D0%B0%D0%B7%D1%83#Russian) | at once, simultaneously | srázu · adv |
| [второй](https://en.wiktionary.org/wiki/%D0%B2%D1%82%D0%BE%D1%80%D0%BE%D0%B9#Russian) | second | vtorój · adj |
| [другой](https://en.wiktionary.org/wiki/%D0%B4%D1%80%D1%83%D0%B3%D0%BE%D0%B9#Russian) | other, another, different, next, else, second (representing a different instance or of a different type/nature) | drugój · det |
| [кто-нибудь](https://en.wiktionary.org/wiki/%D0%BA%D1%82%D0%BE-%D0%BD%D0%B8%D0%B1%D1%83%D0%B4%D1%8C#Russian) | anybody, anyone, somebody or someone (implies one does not care who, or does not have any particular person in mind) | któ-nibudʹ · pron |
| [нельзя](https://en.wiktionary.org/wiki/%D0%BD%D0%B5%D0%BB%D1%8C%D0%B7%D1%8F#Russian) | it is impossible (perfective aspect), one cannot, you can't | nelʹzjá · adj |
| [совсем](https://en.wiktionary.org/wiki/%D1%81%D0%BE%D0%B2%D1%81%D0%B5%D0%BC#Russian) | quite, entirely, totally | sovsém · adv |
| [когда-либо](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0-%D0%BB%D0%B8%D0%B1%D0%BE#Russian) | (at) some time or other, one day; ever (legalese, as intensifier) | kogdá-libo · adv |
| [куда](https://en.wiktionary.org/wiki/%D0%BA%D1%83%D0%B4%D0%B0#Russian) | where? | kudá · adv |
| [т](https://en.wiktionary.org/wiki/%D1%82#Russian) | ton | t · noun |
| [кто-либо](https://en.wiktionary.org/wiki/%D0%BA%D1%82%D0%BE-%D0%BB%D0%B8%D0%B1%D0%BE#Russian) | anybody, anyone, somebody, someone (implies one does not care who, or does not have any particular person in mind) | któ-libo · pron |
| [большой](https://en.wiktionary.org/wiki/%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%BE%D0%B9#Russian) | big, large, great | bolʹšój · adj |
| [весь](https://en.wiktionary.org/wiki/%D0%B2%D0%B5%D1%81%D1%8C#Russian) | all, the whole, all of, the whole of, the entire, the entirety of | vesʹ · det |
| [как дела](https://en.wiktionary.org/wiki/%D0%BA%D0%B0%D0%BA%20%D0%B4%D0%B5%D0%BB%D0%B0#Russian) | how are you?; how is it going? | kak delá? · phrase |
| [мир](https://en.wiktionary.org/wiki/%D0%BC%D0%B8%D1%80#Russian) | peace | mir · noun |
| [найти](https://en.wiktionary.org/wiki/%D0%BD%D0%B0%D0%B9%D1%82%D0%B8#Russian) | to find | najtí · verb |
| [иногда](https://en.wiktionary.org/wiki/%D0%B8%D0%BD%D0%BE%D0%B3%D0%B4%D0%B0#Russian) | sometimes, at times | inogdá · adv |
| [совсем нет](https://en.wiktionary.org/wiki/%D1%81%D0%BE%D0%B2%D1%81%D0%B5%D0%BC%20%D0%BD%D0%B5%D1%82#Russian) | not at all | sovsém nét · adv |
| [фильм](https://en.wiktionary.org/wiki/%D1%84%D0%B8%D0%BB%D1%8C%D0%BC#Russian) | film, movie | filʹm · noun |
| [город](https://en.wiktionary.org/wiki/%D0%B3%D0%BE%D1%80%D0%BE%D0%B4#Russian) | city, town | górod · noun |
| [зачем](https://en.wiktionary.org/wiki/%D0%B7%D0%B0%D1%87%D0%B5%D0%BC#Russian) | why, what for (for what purpose, to what end, with what goal) | začém · adv |
| [часто](https://en.wiktionary.org/wiki/%D1%87%D0%B0%D1%81%D1%82%D0%BE#Russian) | frequently, often | částo · adv |
| [быстро](https://en.wiktionary.org/wiki/%D0%B1%D1%8B%D1%81%D1%82%D1%80%D0%BE#Russian) | fast, quickly, rapidly | býstro · adv |
| [многие](https://en.wiktionary.org/wiki/%D0%BC%D0%BD%D0%BE%D0%B3%D0%B8%D0%B5#Russian) | many (people) | mnógije · pron |
| [работа](https://en.wiktionary.org/wiki/%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B0#Russian) | work | rabóta · noun |
| [говорить](https://en.wiktionary.org/wiki/%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D1%8C#Russian) | to speak, to talk (perfective поговорить) | govorítʹ · verb |
| [вчера](https://en.wiktionary.org/wiki/%D0%B2%D1%87%D0%B5%D1%80%D0%B0#Russian) | yesterday | včerá · adv |
| [завтра](https://en.wiktionary.org/wiki/%D0%B7%D0%B0%D0%B2%D1%82%D1%80%D0%B0#Russian) | tomorrow | závtra · adv |
| [имя](https://en.wiktionary.org/wiki/%D0%B8%D0%BC%D1%8F#Russian) | personal name, first name, Christian name, given name (for inanimate things, see назва́ние (nazvánije)) | ímja · noun |
| [немного](https://en.wiktionary.org/wiki/%D0%BD%D0%B5%D0%BC%D0%BD%D0%BE%D0%B3%D0%BE#Russian) | a little, some | nemnógo · adv |
| [ночь](https://en.wiktionary.org/wiki/%D0%BD%D0%BE%D1%87%D1%8C#Russian) | night, nighttime (period of time from sundown to sunup) | nočʹ · noun |
| [стать](https://en.wiktionary.org/wiki/%D1%81%D1%82%D0%B0%D1%82%D1%8C#Russian) | to stand (in a certain location or near someone or something) | statʹ · verb |
| [жить](https://en.wiktionary.org/wiki/%D0%B6%D0%B8%D1%82%D1%8C#Russian) | to live | žitʹ · verb |
| [пять](https://en.wiktionary.org/wiki/%D0%BF%D1%8F%D1%82%D1%8C#Russian) | five (5) | pjatʹ · num |
| [р.](https://en.wiktionary.org/wiki/%D1%80.#Russian) | river |  · noun |
| [наш](https://en.wiktionary.org/wiki/%D0%BD%D0%B0%D1%88#Russian) | our, ours | naš · pron |
| [история](https://en.wiktionary.org/wiki/%D0%B8%D1%81%D1%82%D0%BE%D1%80%D0%B8%D1%8F#Russian) | history | istórija · noun |
| [и т. п.](https://en.wiktionary.org/wiki/%D0%B8%20%D1%82.%20%D0%BF.#Russian) | etc., and so forth, and so on | [i tɛ ˈpɛ] · adv |
| [опять](https://en.wiktionary.org/wiki/%D0%BE%D0%BF%D1%8F%D1%82%D1%8C#Russian) | again (occurring another time) | opjátʹ · adv |
| [работать](https://en.wiktionary.org/wiki/%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B0%D1%82%D1%8C#Russian) | to work | rabótatʹ · verb |

</details>

<details><summary>Words 201–250</summary>

![[Resources/Audio/ru/Words 0201-0250.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [скоро](https://en.wiktionary.org/wiki/%D1%81%D0%BA%D0%BE%D1%80%D0%BE#Russian) | soon | skóro · adv |
| [на помощь](https://en.wiktionary.org/wiki/%D0%BD%D0%B0%20%D0%BF%D0%BE%D0%BC%D0%BE%D1%89%D1%8C#Russian) | help! | na pómoščʹ · intj |
| [обычно](https://en.wiktionary.org/wiki/%D0%BE%D0%B1%D1%8B%D1%87%D0%BD%D0%BE#Russian) | usually, habitually, customarily | obýčno · adv |
| [поскольку](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D1%81%D0%BA%D0%BE%D0%BB%D1%8C%D0%BA%D1%83#Russian) | inasmuch as, as | poskólʹku · conj |
| [я вас люблю](https://en.wiktionary.org/wiki/%D1%8F%20%D0%B2%D0%B0%D1%81%20%D0%BB%D1%8E%D0%B1%D0%BB%D1%8E#Russian) | I love you | ja vas ljubljú · phrase |
| [дальше](https://en.wiktionary.org/wiki/%D0%B4%D0%B0%D0%BB%D1%8C%D1%88%D0%B5#Russian) | furthermore | dálʹše · adv |
| [самый](https://en.wiktionary.org/wiki/%D1%81%D0%B0%D0%BC%D1%8B%D0%B9#Russian) | the very | sámyj · pron |
| [четыре](https://en.wiktionary.org/wiki/%D1%87%D0%B5%D1%82%D1%8B%D1%80%D0%B5#Russian) | four (4) | četýre · num |
| [число](https://en.wiktionary.org/wiki/%D1%87%D0%B8%D1%81%D0%BB%D0%BE#Russian) | number (cardinal) | čisló · noun |
| [женщина](https://en.wiktionary.org/wiki/%D0%B6%D0%B5%D0%BD%D1%89%D0%B8%D0%BD%D0%B0#Russian) | woman | žénščina · noun |
| [последний](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D1%81%D0%BB%D0%B5%D0%B4%D0%BD%D0%B8%D0%B9#Russian) | last, latest, recent | poslédnij · adj |
| [сын](https://en.wiktionary.org/wiki/%D1%81%D1%8B%D0%BD#Russian) | son | syn · noun |
| [мама](https://en.wiktionary.org/wiki/%D0%BC%D0%B0%D0%BC%D0%B0#Russian) | mama, mummy, mommy, mum, mom (mother) | máma · noun |
| [право](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%B0%D0%B2%D0%BE#Russian) | right; claim | právo · noun |
| [я тебя люблю](https://en.wiktionary.org/wiki/%D1%8F%20%D1%82%D0%B5%D0%B1%D1%8F%20%D0%BB%D1%8E%D0%B1%D0%BB%D1%8E#Russian) | I love you | ja tebjá ljubljú · phrase |
| [имени](https://en.wiktionary.org/wiki/%D0%B8%D0%BC%D0%B5%D0%BD%D0%B8#Russian) | named after (usually not translated, see и́мя (ímja)) | ímeni · prep |
| [прежде](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%B5%D0%B6%D0%B4%D0%B5#Russian) | previously, before, formerly | préžde · adv |
| [слово](https://en.wiktionary.org/wiki/%D1%81%D0%BB%D0%BE%D0%B2%D0%BE#Russian) | word, term | slóvo · noun |
| [вместо](https://en.wiktionary.org/wiki/%D0%B2%D0%BC%D0%B5%D1%81%D1%82%D0%BE#Russian) | instead of | vmésto · prep |
| [отец](https://en.wiktionary.org/wiki/%D0%BE%D1%82%D0%B5%D1%86#Russian) | father | otéc · noun |
| [российский](https://en.wiktionary.org/wiki/%D1%80%D0%BE%D1%81%D1%81%D0%B8%D0%B9%D1%81%D0%BA%D0%B8%D0%B9#Russian) | Russian (concerning the country, nationality) | rossíjskij · adj |
| [вокруг](https://en.wiktionary.org/wiki/%D0%B2%D0%BE%D0%BA%D1%80%D1%83%D0%B3#Russian) | round, around, about | vokrúg · prep |
| [домой](https://en.wiktionary.org/wiki/%D0%B4%D0%BE%D0%BC%D0%BE%D0%B9#Russian) | home, homewards, to the house | domój · adv |
| [настоящее](https://en.wiktionary.org/wiki/%D0%BD%D0%B0%D1%81%D1%82%D0%BE%D1%8F%D1%89%D0%B5%D0%B5#Russian) | the present | nastojáščeje · noun |
| [система](https://en.wiktionary.org/wiki/%D1%81%D0%B8%D1%81%D1%82%D0%B5%D0%BC%D0%B0#Russian) | system | sistéma · noun |
| [всё равно](https://en.wiktionary.org/wiki/%D0%B2%D1%81%D1%91%20%D1%80%D0%B0%D0%B2%D0%BD%D0%BE#Russian) | it’s all the same; it doesn’t matter | vsjo ravnó · adv |
| [мать](https://en.wiktionary.org/wiki/%D0%BC%D0%B0%D1%82%D1%8C#Russian) | mother | matʹ · noun |
| [сердце](https://en.wiktionary.org/wiki/%D1%81%D0%B5%D1%80%D0%B4%D1%86%D0%B5#Russian) | heart | sérdce · noun |
| [столько](https://en.wiktionary.org/wiki/%D1%81%D1%82%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE#Russian) | this much, this long | stólʹko · adv |
| [таким образом](https://en.wiktionary.org/wiki/%D1%82%D0%B0%D0%BA%D0%B8%D0%BC%20%D0%BE%D0%B1%D1%80%D0%B0%D0%B7%D0%BE%D0%BC#Russian) | thus, therefore, in this way | takím óbrazom · adv |
| [улучшать](https://en.wiktionary.org/wiki/%D1%83%D0%BB%D1%83%D1%87%D1%88%D0%B0%D1%82%D1%8C) | to improve |  · verb |
| [кстати](https://en.wiktionary.org/wiki/%D0%BA%D1%81%D1%82%D0%B0%D1%82%D0%B8#Russian) | by the way | kstáti · adv |
| [лицо](https://en.wiktionary.org/wiki/%D0%BB%D0%B8%D1%86%D0%BE#Russian) | face | licó · noun |
| [компания](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D0%BC%D0%BF%D0%B0%D0%BD%D0%B8%D1%8F#Russian) | company (a group of acquaintances) | kompánija · noun |
| [настоящее время](https://en.wiktionary.org/wiki/%D0%BD%D0%B0%D1%81%D1%82%D0%BE%D1%8F%D1%89%D0%B5%D0%B5%20%D0%B2%D1%80%D0%B5%D0%BC%D1%8F#Russian) | present tense | nastojáščeje vrémja · noun |
| [туда](https://en.wiktionary.org/wiki/%D1%82%D1%83%D0%B4%D0%B0#Russian) | there, that way, thither | tudá · adv |
| [час](https://en.wiktionary.org/wiki/%D1%87%D0%B0%D1%81#Russian) | hour, o'clock, time, time of day | čas · noun |
| [автор](https://en.wiktionary.org/wiki/%D0%B0%D0%B2%D1%82%D0%BE%D1%80#Russian) | author | ávtor · noun |
| [вид](https://en.wiktionary.org/wiki/%D0%B2%D0%B8%D0%B4#Russian) | look, looks, appearance, air | vid · noun |
| [играть](https://en.wiktionary.org/wiki/%D0%B8%D0%B3%D1%80%D0%B0%D1%82%D1%8C#Russian) | to play | igrátʹ · verb |
| [привет](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%B8%D0%B2%D0%B5%D1%82#Russian) | hello, hi | privét · intj |
| [путь](https://en.wiktionary.org/wiki/%D0%BF%D1%83%D1%82%D1%8C#Russian) | way, path, road | putʹ · noun |
| [руб.](https://en.wiktionary.org/wiki/%D1%80%D1%83%D0%B1.#Russian) | rouble (singular or plural) | rub. · noun |
| [утром](https://en.wiktionary.org/wiki/%D1%83%D1%82%D1%80%D0%BE%D0%BC#Russian) | in the morning | útrom · adv |
| [пожалуйста](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0#Russian) | please | požálujsta · intj |
| [русский](https://en.wiktionary.org/wiki/%D1%80%D1%83%D1%81%D1%81%D0%BA%D0%B8%D0%B9#Russian) | Russian, related to Russian ethnicity, language, or culture | rússkij · adj |
| [вдруг](https://en.wiktionary.org/wiki/%D0%B2%D0%B4%D1%80%D1%83%D0%B3#Russian) | suddenly, all of a sudden | vdrug · adv |
| [вечером](https://en.wiktionary.org/wiki/%D0%B2%D0%B5%D1%87%D0%B5%D1%80%D0%BE%D0%BC#Russian) | in the evening | véčerom · adv |
| [игра](https://en.wiktionary.org/wiki/%D0%B8%D0%B3%D1%80%D0%B0#Russian) | game | igrá · noun |
| [использовать](https://en.wiktionary.org/wiki/%D0%B8%D1%81%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D1%82%D1%8C#Russian) | to use, to apply | ispólʹzovatʹ · verb |

</details>

<details><summary>Words 251–300</summary>

![[Resources/Audio/ru/Words 0251-0300.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [тому назад](https://en.wiktionary.org/wiki/%D1%82%D0%BE%D0%BC%D1%83%20%D0%BD%D0%B0%D0%B7%D0%B0%D0%B4#Russian) | ago | tomú nazád · adv |
| [кино](https://en.wiktionary.org/wiki/%D0%BA%D0%B8%D0%BD%D0%BE#Russian) | movie, motion picture, film | kinó · noun |
| [и т. д.](https://en.wiktionary.org/wiki/%D0%B8%20%D1%82.%20%D0%B4.#Russian) | etc., and so forth, and so on | i t. d. · phrase |
| [поле](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%BB%D0%B5#Russian) | field, ground | póle · noun |
| [суд](https://en.wiktionary.org/wiki/%D1%81%D1%83%D0%B4#Russian) | court | sud · noun |
| [честь](https://en.wiktionary.org/wiki/%D1%87%D0%B5%D1%81%D1%82%D1%8C#Russian) | honor | čestʹ · noun |
| [взять](https://en.wiktionary.org/wiki/%D0%B2%D0%B7%D1%8F%D1%82%D1%8C#Russian) | to take | vzjatʹ · verb |
| [всё-таки](https://en.wiktionary.org/wiki/%D0%B2%D1%81%D1%91-%D1%82%D0%B0%D0%BA%D0%B8#Russian) | still, all the same, nevertheless, for all that (with a tone of regret) | vsjo-taki · particle |
| [девушка](https://en.wiktionary.org/wiki/%D0%B4%D0%B5%D0%B2%D1%83%D1%88%D0%BA%D0%B0#Russian) | girl, lass (from the age of puberty to womanhood) | dévuška · noun |
| [идти](https://en.wiktionary.org/wiki/%D0%B8%D0%B4%D1%82%D0%B8#Russian) | to go | idtí · verb |
| [интересно](https://en.wiktionary.org/wiki/%D0%B8%D0%BD%D1%82%D0%B5%D1%80%D0%B5%D1%81%D0%BD%D0%BE#Russian) | interestingly, in an interesting manner | interésno · adv |
| [км](https://en.wiktionary.org/wiki/%D0%BA%D0%BC#Russian) | km, kilometer | km · noun |
| [месяц](https://en.wiktionary.org/wiki/%D0%BC%D0%B5%D1%81%D1%8F%D1%86#Russian) | month | mésjac · noun |
| [мужчина](https://en.wiktionary.org/wiki/%D0%BC%D1%83%D0%B6%D1%87%D0%B8%D0%BD%D0%B0#Russian) | man (male person) | mužčína · noun |
| [ночью](https://en.wiktionary.org/wiki/%D0%BD%D0%BE%D1%87%D1%8C%D1%8E#Russian) | at night, by night | nóčʹju · adv |
| [область](https://en.wiktionary.org/wiki/%D0%BE%D0%B1%D0%BB%D0%B0%D1%81%D1%82%D1%8C#Russian) | region, oblast, province | óblastʹ · noun |
| [тот же самый](https://en.wiktionary.org/wiki/%D1%82%D0%BE%D1%82%20%D0%B6%D0%B5%20%D1%81%D0%B0%D0%BC%D1%8B%D0%B9#Russian) | the same | tót že sámyj · det |
| [большинство](https://en.wiktionary.org/wiki/%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B8%D0%BD%D1%81%D1%82%D0%B2%D0%BE#Russian) | majority, most | bolʹšinstvó · noun |
| [знать](https://en.wiktionary.org/wiki/%D0%B7%D0%BD%D0%B0%D1%82%D1%8C#Russian) | to know: to be familiar with or accustomed to a person, place, or thing | znatʹ · verb |
| [и др.](https://en.wiktionary.org/wiki/%D0%B8%20%D0%B4%D1%80.#Russian) | et alii, etc. | i dr. · phrase |
| [клуб](https://en.wiktionary.org/wiki/%D0%BA%D0%BB%D1%83%D0%B1#Russian) | cloud, puff (of smoke, etc.) | klub · noun |
| [речь](https://en.wiktionary.org/wiki/%D1%80%D0%B5%D1%87%D1%8C#Russian) | speech, language (spoken) | rečʹ · noun |
| [язык](https://en.wiktionary.org/wiki/%D1%8F%D0%B7%D1%8B%D0%BA#Russian) | tongue | jazýk · noun |
| [дать](https://en.wiktionary.org/wiki/%D0%B4%D0%B0%D1%82%D1%8C#Russian) | to give | datʹ · verb |
| [дочь](https://en.wiktionary.org/wiki/%D0%B4%D0%BE%D1%87%D1%8C#Russian) | daughter | dočʹ · noun |
| [и-го-го](https://en.wiktionary.org/wiki/%D0%B8-%D0%B3%D0%BE-%D0%B3%D0%BE#Russian) | whinny, neigh (sound a horse makes) | ihohó · intj |
| [совет](https://en.wiktionary.org/wiki/%D1%81%D0%BE%D0%B2%D0%B5%D1%82#Russian) | advice | sovét · noun |
| [запоминать](https://en.wiktionary.org/wiki/%D0%B7%D0%B0%D0%BF%D0%BE%D0%BC%D0%B8%D0%BD%D0%B0%D1%82%D1%8C) | to memorise |  · verb |
| [внутри](https://en.wiktionary.org/wiki/%D0%B2%D0%BD%D1%83%D1%82%D1%80%D0%B8#Russian) | in or into the interior; inside | vnutrí · adv |
| [книга](https://en.wiktionary.org/wiki/%D0%BA%D0%BD%D0%B8%D0%B3%D0%B0#Russian) | book | kníga · noun |
| [производство](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%BE%D0%B8%D0%B7%D0%B2%D0%BE%D0%B4%D1%81%D1%82%D0%B2%D0%BE#Russian) | production, manufacture | proizvódstvo · noun |
| [ради](https://en.wiktionary.org/wiki/%D1%80%D0%B0%D0%B4%D0%B8#Russian) | for the sake of | rádi · prep |
| [семья](https://en.wiktionary.org/wiki/%D1%81%D0%B5%D0%BC%D1%8C%D1%8F#Russian) | family | semʹjá · noun |
| [твой](https://en.wiktionary.org/wiki/%D1%82%D0%B2%D0%BE%D0%B9#Russian) | your, yours, thy, thine (2nd-person familiar, singular only) | tvoj · pron |
| [узнать](https://en.wiktionary.org/wiki/%D1%83%D0%B7%D0%BD%D0%B0%D1%82%D1%8C#Russian) | to recognize | uznátʹ · verb |
| [ч](https://en.wiktionary.org/wiki/%D1%87#Russian) | h, hour | č · noun |
| [голос](https://en.wiktionary.org/wiki/%D0%B3%D0%BE%D0%BB%D0%BE%D1%81#Russian) | voice | gólos · noun |
| [откуда](https://en.wiktionary.org/wiki/%D0%BE%D1%82%D0%BA%D1%83%D0%B4%D0%B0#Russian) | whence, from where | otkúda · adv |
| [свет](https://en.wiktionary.org/wiki/%D1%81%D0%B2%D0%B5%D1%82#Russian) | light | svet · noun |
| [сюда](https://en.wiktionary.org/wiki/%D1%81%D1%8E%D0%B4%D0%B0#Russian) | here, hither | sjudá · adv |
| [хороший](https://en.wiktionary.org/wiki/%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B8%D0%B9#Russian) | good, nice, fine | xoróšij · adj |
| [большое спасибо](https://en.wiktionary.org/wiki/%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%BE%D0%B5%20%D1%81%D0%BF%D0%B0%D1%81%D0%B8%D0%B1%D0%BE#Russian) | many thanks, thank you very much | bolʹšóje spasíbo · intj |
| [д-р](https://en.wiktionary.org/wiki/%D0%B4-%D1%80#Russian) | Dr., doctor (PhD or MD) | d-r · noun |
| [мм](https://en.wiktionary.org/wiki/%D0%BC%D0%BC#Russian) | mm, millimeter | mm · noun |
| [народ](https://en.wiktionary.org/wiki/%D0%BD%D0%B0%D1%80%D0%BE%D0%B4#Russian) | people | naród · noun |
| [день рождения](https://en.wiktionary.org/wiki/%D0%B4%D0%B5%D0%BD%D1%8C%20%D1%80%D0%BE%D0%B6%D0%B4%D0%B5%D0%BD%D0%B8%D1%8F#Russian) | birthday | denʹ roždénija · noun |
| [друг друга](https://en.wiktionary.org/wiki/%D0%B4%D1%80%D1%83%D0%B3%20%D0%B4%D1%80%D1%83%D0%B3%D0%B0#Russian) | one another, each other | drug drúga · pron |
| [друг на друга](https://en.wiktionary.org/wiki/%D0%B4%D1%80%D1%83%D0%B3%20%D0%BD%D0%B0%20%D0%B4%D1%80%D1%83%D0%B3%D0%B0#Russian) | against one another, against each other | drúg na drúga · adv |
| [оба](https://en.wiktionary.org/wiki/%D0%BE%D0%B1%D0%B0#Russian) | both | óba · num |
| [положение](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%BB%D0%BE%D0%B6%D0%B5%D0%BD%D0%B8%D0%B5#Russian) | position, location | položénije · noun |

</details>

<details><summary>Words 301–350</summary>

![[Resources/Audio/ru/Words 0301-0350.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [помочь](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%BC%D0%BE%D1%87%D1%8C#Russian) | to help | pomóčʹ · verb |
| [шесть](https://en.wiktionary.org/wiki/%D1%88%D0%B5%D1%81%D1%82%D1%8C#Russian) | six (6) | šestʹ · num |
| [брат](https://en.wiktionary.org/wiki/%D0%B1%D1%80%D0%B0%D1%82#Russian) | brother | brat · noun |
| [вечер](https://en.wiktionary.org/wiki/%D0%B2%D0%B5%D1%87%D0%B5%D1%80#Russian) | evening (after 8 PM) | véčer · noun |
| [друг от друга](https://en.wiktionary.org/wiki/%D0%B4%D1%80%D1%83%D0%B3%20%D0%BE%D1%82%20%D0%B4%D1%80%D1%83%D0%B3%D0%B0#Russian) | one from another | drúg ot drúga · adv |
| [друг у друга](https://en.wiktionary.org/wiki/%D0%B4%D1%80%D1%83%D0%B3%20%D1%83%20%D0%B4%D1%80%D1%83%D0%B3%D0%B0#Russian) | at one another | drúg u drúga · adv |
| [море](https://en.wiktionary.org/wiki/%D0%BC%D0%BE%D1%80%D0%B5#Russian) | sea | móre · noun |
| [следующий](https://en.wiktionary.org/wiki/%D1%81%D0%BB%D0%B5%D0%B4%D1%83%D1%8E%D1%89%D0%B8%D0%B9#Russian) | following | slédujuščij · adj |
| [бог](https://en.wiktionary.org/wiki/%D0%B1%D0%BE%D0%B3#Russian) | God | box · noun |
| [ваш](https://en.wiktionary.org/wiki/%D0%B2%D0%B0%D1%88#Russian) | your, yours (2nd-person singular formal or 2nd-person plural) | vaš · pron |
| [видеть](https://en.wiktionary.org/wiki/%D0%B2%D0%B8%D0%B4%D0%B5%D1%82%D1%8C#Russian) | to see (perceive by eyesight) | vídetʹ · verb |
| [доктор](https://en.wiktionary.org/wiki/%D0%B4%D0%BE%D0%BA%D1%82%D0%BE%D1%80#Russian) | doctor (PhD or MD) | dóktor · noun |
| [пора](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D1%80%D0%B0#Russian) | time | porá · noun |
| [ребята](https://en.wiktionary.org/wiki/%D1%80%D0%B5%D0%B1%D1%8F%D1%82%D0%B0#Russian) | young men, boys, friends, comrades | rebjáta · noun |
| [утро](https://en.wiktionary.org/wiki/%D1%83%D1%82%D1%80%D0%BE#Russian) | morning | útro · noun |
| [война](https://en.wiktionary.org/wiki/%D0%B2%D0%BE%D0%B9%D0%BD%D0%B0#Russian) | war, warfare | vojná · noun |
| [господин](https://en.wiktionary.org/wiki/%D0%B3%D0%BE%D1%81%D0%BF%D0%BE%D0%B4%D0%B8%D0%BD#Russian) | gentleman (a man of a high rank or position) | gospodín · noun |
| [мнение](https://en.wiktionary.org/wiki/%D0%BC%D0%BD%D0%B5%D0%BD%D0%B8%D0%B5#Russian) | opinion (person's) | mnénije · noun |
| [номер](https://en.wiktionary.org/wiki/%D0%BD%D0%BE%D0%BC%D0%B5%D1%80#Russian) | nominal number | nómer · noun |
| [оружие](https://en.wiktionary.org/wiki/%D0%BE%D1%80%D1%83%D0%B6%D0%B8%D0%B5#Russian) | weapon(s), weaponry, arm(s) | orúžije · noun |
| [парень](https://en.wiktionary.org/wiki/%D0%BF%D0%B0%D1%80%D0%B5%D0%BD%D1%8C#Russian) | fellow, lad, chap, guy, bloke, boy | párenʹ · noun |
| [случай](https://en.wiktionary.org/wiki/%D1%81%D0%BB%D1%83%D1%87%D0%B0%D0%B9#Russian) | case | slúčaj · noun |
| [десять](https://en.wiktionary.org/wiki/%D0%B4%D0%B5%D1%81%D1%8F%D1%82%D1%8C#Russian) | ten (10) | désjatʹ · num |
| [кг](https://en.wiktionary.org/wiki/%D0%BA%D0%B3#Russian) | kg, kilogram | kg · noun |
| [телефон](https://en.wiktionary.org/wiki/%D1%82%D0%B5%D0%BB%D0%B5%D1%84%D0%BE%D0%BD#Russian) | telephone | telefón · noun |
| [журнал](https://en.wiktionary.org/wiki/%D0%B6%D1%83%D1%80%D0%BD%D0%B0%D0%BB#Russian) | magazine, periodical, journal | žurnál · noun |
| [однажды](https://en.wiktionary.org/wiki/%D0%BE%D0%B4%D0%BD%D0%B0%D0%B6%D0%B4%D1%8B#Russian) | once, one day, once upon a time | odnáždy · adv |
| [песня](https://en.wiktionary.org/wiki/%D0%BF%D0%B5%D1%81%D0%BD%D1%8F#Russian) | song | pésnja · noun |
| [пол](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%BB#Russian) | floor (bottom part of a room) | pol · noun |
| [председатель](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%B5%D0%B4%D1%81%D0%B5%D0%B4%D0%B0%D1%82%D0%B5%D0%BB%D1%8C#Russian) | chairman, president | predsedátelʹ · noun |
| [создать](https://en.wiktionary.org/wiki/%D1%81%D0%BE%D0%B7%D0%B4%D0%B0%D1%82%D1%8C#Russian) | to create | sozdátʹ · verb |
| [третий](https://en.wiktionary.org/wiki/%D1%82%D1%80%D0%B5%D1%82%D0%B8%D0%B9#Russian) | third | trétij · adj |
| [друг против друга](https://en.wiktionary.org/wiki/%D0%B4%D1%80%D1%83%D0%B3%20%D0%BF%D1%80%D0%BE%D1%82%D0%B8%D0%B2%20%D0%B4%D1%80%D1%83%D0%B3%D0%B0#Russian) | face to face; vis-à-vis | drúg prótiv drúga · adv |
| [общество](https://en.wiktionary.org/wiki/%D0%BE%D0%B1%D1%89%D0%B5%D1%81%D1%82%D0%B2%D0%BE#Russian) | society, public | óbščestvo · noun |
| [сан](https://en.wiktionary.org/wiki/%D1%81%D0%B0%D0%BD#Russian) | religious title/order/rank, dignity | san · noun |
| [семь](https://en.wiktionary.org/wiki/%D1%81%D0%B5%D0%BC%D1%8C#Russian) | seven (7) | semʹ · num |
| [огонь](https://en.wiktionary.org/wiki/%D0%BE%D0%B3%D0%BE%D0%BD%D1%8C#Russian) | fire (also figurative) | ogónʹ · noun |
| [письмо](https://en.wiktionary.org/wiki/%D0%BF%D0%B8%D1%81%D1%8C%D0%BC%D0%BE#Russian) | letter (written communication) | pisʹmó · noun |
| [увидеть](https://en.wiktionary.org/wiki/%D1%83%D0%B2%D0%B8%D0%B4%D0%B5%D1%82%D1%8C#Russian) | to see, to catch sight of, to notice | uvídetʹ · verb |
| [в т. ч.](https://en.wiktionary.org/wiki/%D0%B2%20%D1%82.%20%D1%87.#Russian) | including | v t. č. · prep |
| [и так далее](https://en.wiktionary.org/wiki/%D0%B8%20%D1%82%D0%B0%D0%BA%20%D0%B4%D0%B0%D0%BB%D0%B5%D0%B5#Russian) | et cetera, and so forth, and so on | i tak dáleje · adv |
| [кофе](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D1%84%D0%B5#Russian) | coffee (in the form of a beverage) | kófe · noun |
| [муж](https://en.wiktionary.org/wiki/%D0%BC%D1%83%D0%B6#Russian) | husband | muž · noun |
| [союз](https://en.wiktionary.org/wiki/%D1%81%D0%BE%D1%8E%D0%B7#Russian) | union | sojúz · noun |
| [спать](https://en.wiktionary.org/wiki/%D1%81%D0%BF%D0%B0%D1%82%D1%8C#Russian) | to sleep | spatʹ · verb |
| [генерал](https://en.wiktionary.org/wiki/%D0%B3%D0%B5%D0%BD%D0%B5%D1%80%D0%B0%D0%BB#Russian) | general | generál · noun |
| [глаз](https://en.wiktionary.org/wiki/%D0%B3%D0%BB%D0%B0%D0%B7#Russian) | eye | glaz · noun |
| [друг с другом](https://en.wiktionary.org/wiki/%D0%B4%D1%80%D1%83%D0%B3%20%D1%81%20%D0%B4%D1%80%D1%83%D0%B3%D0%BE%D0%BC#Russian) | with one another, with each other | drúg s drúgom · adv |
| [евро](https://en.wiktionary.org/wiki/%D0%B5%D0%B2%D1%80%D0%BE#Russian) | euro (€, currency) | jévro · noun |
| [будущее время](https://en.wiktionary.org/wiki/%D0%B1%D1%83%D0%B4%D1%83%D1%89%D0%B5%D0%B5%20%D0%B2%D1%80%D0%B5%D0%BC%D1%8F#Russian) | future tense | búduščeje vrémja · noun |

</details>

<details><summary>Words 351–400</summary>

![[Resources/Audio/ru/Words 0351-0400.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [дверь](https://en.wiktionary.org/wiki/%D0%B4%D0%B2%D0%B5%D1%80%D1%8C#Russian) | door | dverʹ · noun |
| [друг за другом](https://en.wiktionary.org/wiki/%D0%B4%D1%80%D1%83%D0%B3%20%D0%B7%D0%B0%20%D0%B4%D1%80%D1%83%D0%B3%D0%BE%D0%BC#Russian) | one after another | drúg za drúgom · adv |
| [организация](https://en.wiktionary.org/wiki/%D0%BE%D1%80%D0%B3%D0%B0%D0%BD%D0%B8%D0%B7%D0%B0%D1%86%D0%B8%D1%8F#Russian) | organization, arrangement | organizácija · noun |
| [политика](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%BB%D0%B8%D1%82%D0%B8%D0%BA%D0%B0#Russian) | politics | polítika · noun |
| [рано](https://en.wiktionary.org/wiki/%D1%80%D0%B0%D0%BD%D0%BE#Russian) | early | ráno · adv |
| [тип](https://en.wiktionary.org/wiki/%D1%82%D0%B8%D0%BF#Russian) | type, model | tip · noun |
| [цена](https://en.wiktionary.org/wiki/%D1%86%D0%B5%D0%BD%D0%B0#Russian) | price, cost | cená · noun |
| [государство](https://en.wiktionary.org/wiki/%D0%B3%D0%BE%D1%81%D1%83%D0%B4%D0%B0%D1%80%D1%81%D1%82%D0%B2%D0%BE#Russian) | State | gosudárstvo · noun |
| [настоящий](https://en.wiktionary.org/wiki/%D0%BD%D0%B0%D1%81%D1%82%D0%BE%D1%8F%D1%89%D0%B8%D0%B9#Russian) | present | nastojáščij · adj |
| [ок.](https://en.wiktionary.org/wiki/%D0%BE%D0%BA.#Russian) | near, about | ok. · prep |
| [роман](https://en.wiktionary.org/wiki/%D1%80%D0%BE%D0%BC%D0%B0%D0%BD#Russian) | novel (work of prose fiction) | román · noun |
| [возле](https://en.wiktionary.org/wiki/%D0%B2%D0%BE%D0%B7%D0%BB%D0%B5#Russian) | beside, by, near | vózle · prep |
| [девочка](https://en.wiktionary.org/wiki/%D0%B4%D0%B5%D0%B2%D0%BE%D1%87%D0%BA%D0%B0#Russian) | girl, little girl (before the age of puberty) | dévočka · noun |
| [метро](https://en.wiktionary.org/wiki/%D0%BC%D0%B5%D1%82%D1%80%D0%BE#Russian) | subway, underground | metró · noun |
| [папа](https://en.wiktionary.org/wiki/%D0%BF%D0%B0%D0%BF%D0%B0#Russian) | dad, daddy | pápa · noun |
| [церковь](https://en.wiktionary.org/wiki/%D1%86%D0%B5%D1%80%D0%BA%D0%BE%D0%B2%D1%8C#Russian) | church (religious group) | cérkovʹ · noun |
| [школа](https://en.wiktionary.org/wiki/%D1%88%D0%BA%D0%BE%D0%BB%D0%B0#Russian) | school | škóla · noun |
| [вода](https://en.wiktionary.org/wiki/%D0%B2%D0%BE%D0%B4%D0%B0#Russian) | water | vodá · noun |
| [молодой](https://en.wiktionary.org/wiki/%D0%BC%D0%BE%D0%BB%D0%BE%D0%B4%D0%BE%D0%B9#Russian) | young | molodój · adj |
| [использование](https://en.wiktionary.org/wiki/%D0%B8%D1%81%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5#Russian) | use, usage | ispólʹzovanije · noun |
| [первое лицо](https://en.wiktionary.org/wiki/%D0%BF%D0%B5%D1%80%D0%B2%D0%BE%D0%B5%20%D0%BB%D0%B8%D1%86%D0%BE#Russian) | first person | pérvoje licó · noun |
| [площадь](https://en.wiktionary.org/wiki/%D0%BF%D0%BB%D0%BE%D1%89%D0%B0%D0%B4%D1%8C#Russian) | square (open area in a town or city) | plóščadʹ · noun |
| [солдат](https://en.wiktionary.org/wiki/%D1%81%D0%BE%D0%BB%D0%B4%D0%B0%D1%82#Russian) | soldier (male or female) | soldát · noun |
| [адрес](https://en.wiktionary.org/wiki/%D0%B0%D0%B4%D1%80%D0%B5%D1%81#Russian) | address (the location of a property) | ádres · noun |
| [активно](https://en.wiktionary.org/wiki/%D0%B0%D0%BA%D1%82%D0%B8%D0%B2%D0%BD%D0%BE#Russian) | actively | aktívno · adv |
| [городской](https://en.wiktionary.org/wiki/%D0%B3%D0%BE%D1%80%D0%BE%D0%B4%D1%81%D0%BA%D0%BE%D0%B9#Russian) | town, city; urban, municipal | gorodskój · adj |
| [класс](https://en.wiktionary.org/wiki/%D0%BA%D0%BB%D0%B0%D1%81%D1%81#Russian) | class | klass · noun |
| [км/час](https://en.wiktionary.org/wiki/%D0%BA%D0%BC/%D1%87%D0%B0%D1%81#Russian) | km/h, kilometers per hour | km/čas · noun |
| [контроль](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C#Russian) | control | kontrólʹ · noun |
| [король](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D1%80%D0%BE%D0%BB%D1%8C#Russian) | king | korólʹ · noun |
| [отсюда](https://en.wiktionary.org/wiki/%D0%BE%D1%82%D1%81%D1%8E%D0%B4%D0%B0#Russian) | from here, hence | otsjúda · adv |
| [страна](https://en.wiktionary.org/wiki/%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B0#Russian) | country | straná · noun |
| [образ](https://en.wiktionary.org/wiki/%D0%BE%D0%B1%D1%80%D0%B0%D0%B7#Russian) | shape, form | óbraz · noun |
| [остров](https://en.wiktionary.org/wiki/%D0%BE%D1%81%D1%82%D1%80%D0%BE%D0%B2#Russian) | island | óstrov · noun |
| [пойти](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%B9%D1%82%D0%B8#Russian) | to go | pojtí · verb |
| [восемь](https://en.wiktionary.org/wiki/%D0%B2%D0%BE%D1%81%D0%B5%D0%BC%D1%8C#Russian) | eight (8) | vósemʹ · num |
| [ж-ж-ж](https://en.wiktionary.org/wiki/%D0%B6-%D0%B6-%D0%B6#Russian) | buzz, bzz (sound a bee or fly makes) | ž-ž-ž · intj |
| [завод](https://en.wiktionary.org/wiki/%D0%B7%D0%B0%D0%B2%D0%BE%D0%B4#Russian) | factory, plant | zavód · noun |
| [многое](https://en.wiktionary.org/wiki/%D0%BC%D0%BD%D0%BE%D0%B3%D0%BE%D0%B5#Russian) | many things, many a thing, much | mnógoje · pron |
| [перевод](https://en.wiktionary.org/wiki/%D0%BF%D0%B5%D1%80%D0%B5%D0%B2%D0%BE%D0%B4#Russian) | transfer, transference | perevód · noun |
| [сон](https://en.wiktionary.org/wiki/%D1%81%D0%BE%D0%BD#Russian) | sleep | son · noun |
| [банк](https://en.wiktionary.org/wiki/%D0%B1%D0%B0%D0%BD%D0%BA#Russian) | bank (financial institution) | bank · noun |
| [вне](https://en.wiktionary.org/wiki/%D0%B2%D0%BD%D0%B5#Russian) | out of, outside | vne · prep |
| [голова](https://en.wiktionary.org/wiki/%D0%B3%D0%BE%D0%BB%D0%BE%D0%B2%D0%B0#Russian) | head | golová · noun |
| [мальчик](https://en.wiktionary.org/wiki/%D0%BC%D0%B0%D0%BB%D1%8C%D1%87%D0%B8%D0%BA#Russian) | boy | málʹčik · noun |
| [район](https://en.wiktionary.org/wiki/%D1%80%D0%B0%D0%B9%D0%BE%D0%BD#Russian) | district | rajón · noun |
| [скорость](https://en.wiktionary.org/wiki/%D1%81%D0%BA%D0%BE%D1%80%D0%BE%D1%81%D1%82%D1%8C#Russian) | speed | skórostʹ · noun |
| [стол](https://en.wiktionary.org/wiki/%D1%81%D1%82%D0%BE%D0%BB#Russian) | table | stol · noun |
| [земля](https://en.wiktionary.org/wiki/%D0%B7%D0%B5%D0%BC%D0%BB%D1%8F#Russian) | earth | zemljá · noun |
| [отношение](https://en.wiktionary.org/wiki/%D0%BE%D1%82%D0%BD%D0%BE%D1%88%D0%B5%D0%BD%D0%B8%D0%B5#Russian) | attitude | otnošénije · noun |

</details>

<details><summary>Words 401–450</summary>

![[Resources/Audio/ru/Words 0401-0450.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [пара](https://en.wiktionary.org/wiki/%D0%BF%D0%B0%D1%80%D0%B0#Russian) | pair, couple | pára · noun |
| [солнце](https://en.wiktionary.org/wiki/%D1%81%D0%BE%D0%BB%D0%BD%D1%86%D0%B5#Russian) | sun | sólnce · noun |
| [часы](https://en.wiktionary.org/wiki/%D1%87%D0%B0%D1%81%D1%8B#Russian) | clock, watch | časý · noun |
| [-ка](https://en.wiktionary.org/wiki/-%D0%BA%D0%B0#Russian) | just, (now) would you? (appended to an imperative verb to soften the command somewhat) |  · particle |
| [ка](https://en.wiktionary.org/wiki/%D0%BA%D0%B0#Russian) | the Cyrillic letter К, к | ka · noun |
| [комитет](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D0%BC%D0%B8%D1%82%D0%B5%D1%82#Russian) | committee | komitét · noun |
| [нечего](https://en.wiktionary.org/wiki/%D0%BD%D0%B5%D1%87%D0%B5%D0%B3%D0%BE#Russian) | there is nothing | néčevo · adj |
| [убийство](https://en.wiktionary.org/wiki/%D1%83%D0%B1%D0%B8%D0%B9%D1%81%D1%82%D0%B2%D0%BE#Russian) | murder, homicide (the action of killing someone) | ubíjstvo · noun |
| [больно](https://en.wiktionary.org/wiki/%D0%B1%D0%BE%D0%BB%D1%8C%D0%BD%D0%BE#Russian) | bad, badly | bólʹno · adv |
| [сто](https://en.wiktionary.org/wiki/%D1%81%D1%82%D0%BE#Russian) | hundred (100) | sto · num |
| [театр](https://en.wiktionary.org/wiki/%D1%82%D0%B5%D0%B0%D1%82%D1%80#Russian) | theatre/theater | teátr · noun |
| [армия](https://en.wiktionary.org/wiki/%D0%B0%D1%80%D0%BC%D0%B8%D1%8F#Russian) | army, armed forces (the complete military organization of a nation, including land, sea and air forces) | ármija · noun |
| [белый](https://en.wiktionary.org/wiki/%D0%B1%D0%B5%D0%BB%D1%8B%D0%B9#Russian) | white | bélyj · adj |
| [газета](https://en.wiktionary.org/wiki/%D0%B3%D0%B0%D0%B7%D0%B5%D1%82%D0%B0#Russian) | newspaper | gazéta · noun |
| [интерес](https://en.wiktionary.org/wiki/%D0%B8%D0%BD%D1%82%D0%B5%D1%80%D0%B5%D1%81#Russian) | interest | interés · noun |
| [кровь](https://en.wiktionary.org/wiki/%D0%BA%D1%80%D0%BE%D0%B2%D1%8C#Russian) | blood | krovʹ · noun |
| [мимо](https://en.wiktionary.org/wiki/%D0%BC%D0%B8%D0%BC%D0%BE#Russian) | past, by | mímo · prep |
| [писать](https://en.wiktionary.org/wiki/%D0%BF%D0%B8%D1%81%D0%B0%D1%82%D1%8C#Russian) | to write | pisátʹ · verb |
| [сутки](https://en.wiktionary.org/wiki/%D1%81%D1%83%D1%82%D0%BA%D0%B8#Russian) | 24 hours (of the clock), day, day and night, nychthemeron | sútki · noun |
| [ул.](https://en.wiktionary.org/wiki/%D1%83%D0%BB.#Russian) | St., street | ul. · noun |
| [цвет](https://en.wiktionary.org/wiki/%D1%86%D0%B2%D0%B5%D1%82#Russian) | color/colour | cvet · noun |
| [великий](https://en.wiktionary.org/wiki/%D0%B2%D0%B5%D0%BB%D0%B8%D0%BA%D0%B8%D0%B9#Russian) | large, big | velíkij · adj |
| [знак](https://en.wiktionary.org/wiki/%D0%B7%D0%BD%D0%B0%D0%BA#Russian) | sign, mark | znak · noun |
| [золото](https://en.wiktionary.org/wiki/%D0%B7%D0%BE%D0%BB%D0%BE%D1%82%D0%BE#Russian) | gold (metal) | zóloto · noun |
| [общий](https://en.wiktionary.org/wiki/%D0%BE%D0%B1%D1%89%D0%B8%D0%B9#Russian) | common | óbščij · adj |
| [советский](https://en.wiktionary.org/wiki/%D1%81%D0%BE%D0%B2%D0%B5%D1%82%D1%81%D0%BA%D0%B8%D0%B9#Russian) | Soviet | sovétskij · adj |
| [футбол](https://en.wiktionary.org/wiki/%D1%84%D1%83%D1%82%D0%B1%D0%BE%D0%BB#Russian) | football (the game, UK English), soccer (US English) | futból · noun |
| [герой](https://en.wiktionary.org/wiki/%D0%B3%D0%B5%D1%80%D0%BE%D0%B9#Russian) | hero | gerój · noun |
| [друг другу](https://en.wiktionary.org/wiki/%D0%B4%D1%80%D1%83%D0%B3%20%D0%B4%D1%80%D1%83%D0%B3%D1%83#Russian) | to one another, to each other | drug drúgu · adv |
| [корабль](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D1%80%D0%B0%D0%B1%D0%BB%D1%8C#Russian) | ship, liner | koráblʹ · noun |
| [круто](https://en.wiktionary.org/wiki/%D0%BA%D1%80%D1%83%D1%82%D0%BE#Russian) | steeply | krúto · adv |
| [банка](https://en.wiktionary.org/wiki/%D0%B1%D0%B0%D0%BD%D0%BA%D0%B0#Russian) | jar, pot | bánka · noun |
| [дорога](https://en.wiktionary.org/wiki/%D0%B4%D0%BE%D1%80%D0%BE%D0%B3%D0%B0#Russian) | road | doróga · noun |
| [форма](https://en.wiktionary.org/wiki/%D1%84%D0%BE%D1%80%D0%BC%D0%B0#Russian) | form, shape | fórma · noun |
| [ходить](https://en.wiktionary.org/wiki/%D1%85%D0%BE%D0%B4%D0%B8%D1%82%D1%8C#Russian) | to go, to walk | xodítʹ · verb |
| [маленький](https://en.wiktionary.org/wiki/%D0%BC%D0%B0%D0%BB%D0%B5%D0%BD%D1%8C%D0%BA%D0%B8%D0%B9#Russian) | little, small | málenʹkij · adj |
| [сидеть](https://en.wiktionary.org/wiki/%D1%81%D0%B8%D0%B4%D0%B5%D1%82%D1%8C#Russian) | to sit | sidétʹ · verb |
| [слава](https://en.wiktionary.org/wiki/%D1%81%D0%BB%D0%B0%D0%B2%D0%B0#Russian) | glory | sláva · noun |
| [ветер](https://en.wiktionary.org/wiki/%D0%B2%D0%B5%D1%82%D0%B5%D1%80#Russian) | wind | véter · noun |
| [красный](https://en.wiktionary.org/wiki/%D0%BA%D1%80%D0%B0%D1%81%D0%BD%D1%8B%D0%B9#Russian) | red | krásnyj · adj |
| [магазин](https://en.wiktionary.org/wiki/%D0%BC%D0%B0%D0%B3%D0%B0%D0%B7%D0%B8%D0%BD#Russian) | shop, store (establishment that sells goods) | magazín · noun |
| [читать](https://en.wiktionary.org/wiki/%D1%87%D0%B8%D1%82%D0%B0%D1%82%D1%8C#Russian) | to read | čitátʹ · verb |
| [везде](https://en.wiktionary.org/wiki/%D0%B2%D0%B5%D0%B7%D0%B4%D0%B5#Russian) | everywhere | vezdé · adv |
| [врач](https://en.wiktionary.org/wiki/%D0%B2%D1%80%D0%B0%D1%87#Russian) | therapist, not surgeon, not hospital nurse | vrač · noun |
| [двадцать](https://en.wiktionary.org/wiki/%D0%B4%D0%B2%D0%B0%D0%B4%D1%86%D0%B0%D1%82%D1%8C#Russian) | twenty (20) | dvádcatʹ · num |
| [делать большие глаза](https://en.wiktionary.org/wiki/%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B8%D0%B5%20%D0%B3%D0%BB%D0%B0%D0%B7%D0%B0#Russian) | to look (as if) surprised or puzzled. (Lit., "to make large eyes".) | délatʹ bolʹšíje glazá · verb |
| [запад](https://en.wiktionary.org/wiki/%D0%B7%D0%B0%D0%BF%D0%B0%D0%B4#Russian) | west | západ · noun |
| [описание](https://en.wiktionary.org/wiki/%D0%BE%D0%BF%D0%B8%D1%81%D0%B0%D0%BD%D0%B8%D0%B5#Russian) | description | opisánije · noun |
| [помогите](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%BC%D0%BE%D0%B3%D0%B8%D1%82%D0%B5#Russian) | help! | pomogíte · intj |
| [понедельник](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%BD%D0%B5%D0%B4%D0%B5%D0%BB%D1%8C%D0%BD%D0%B8%D0%BA#Russian) | Monday | ponedélʹnik · noun |

</details>

<details><summary>Words 451–500</summary>

![[Resources/Audio/ru/Words 0451-0500.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [рот](https://en.wiktionary.org/wiki/%D1%80%D0%BE%D1%82#Russian) | mouth | rot · noun |
| [воскресенье](https://en.wiktionary.org/wiki/%D0%B2%D0%BE%D1%81%D0%BA%D1%80%D0%B5%D1%81%D0%B5%D0%BD%D1%8C%D0%B5#Russian) | Sunday | voskresénʹje · noun |
| [восток](https://en.wiktionary.org/wiki/%D0%B2%D0%BE%D1%81%D1%82%D0%BE%D0%BA#Russian) | east | vostók · noun |
| [государственный](https://en.wiktionary.org/wiki/%D0%B3%D0%BE%D1%81%D1%83%D0%B4%D0%B0%D1%80%D1%81%D1%82%D0%B2%D0%B5%D0%BD%D0%BD%D1%8B%D0%B9#Russian) | state | gosudárstvennyj · adj |
| [звезда](https://en.wiktionary.org/wiki/%D0%B7%D0%B2%D0%B5%D0%B7%D0%B4%D0%B0#Russian) | star (celestial body) | zvezdá · noun |
| [неожиданно](https://en.wiktionary.org/wiki/%D0%BD%D0%B5%D0%BE%D0%B6%D0%B8%D0%B4%D0%B0%D0%BD%D0%BD%D0%BE#Russian) | suddenly, unexpectedly | neožídanno · adv |
| [ред.](https://en.wiktionary.org/wiki/%D1%80%D0%B5%D0%B4.#Russian) | editorial office | red. · noun |
| [тема](https://en.wiktionary.org/wiki/%D1%82%D0%B5%D0%BC%D0%B0#Russian) | theme, subject, topic | téma · noun |
| [автомобиль](https://en.wiktionary.org/wiki/%D0%B0%D0%B2%D1%82%D0%BE%D0%BC%D0%BE%D0%B1%D0%B8%D0%BB%D1%8C#Russian) | car, automobile, motorcar | avtomobílʹ · noun |
| [брать](https://en.wiktionary.org/wiki/%D0%B1%D1%80%D0%B0%D1%82%D1%8C#Russian) | to take | bratʹ · verb |
| [двадцать один](https://en.wiktionary.org/wiki/%D0%B4%D0%B2%D0%B0%D0%B4%D1%86%D0%B0%D1%82%D1%8C%20%D0%BE%D0%B4%D0%B8%D0%BD#Russian) | twenty-one (21) | dvádcatʹ odín · num |
| [немедленно](https://en.wiktionary.org/wiki/%D0%BD%D0%B5%D0%BC%D0%B5%D0%B4%D0%BB%D0%B5%D0%BD%D0%BD%D0%BE#Russian) | immediately, at once, forthwith | nemédlenno · adv |
| [окно](https://en.wiktionary.org/wiki/%D0%BE%D0%BA%D0%BD%D0%BE#Russian) | window | oknó · noun |
| [пить](https://en.wiktionary.org/wiki/%D0%BF%D0%B8%D1%82%D1%8C#Russian) | to drink | pitʹ · verb |
| [анализ](https://en.wiktionary.org/wiki/%D0%B0%D0%BD%D0%B0%D0%BB%D0%B8%D0%B7#Russian) | analysis | análiz · noun |
| [английский](https://en.wiktionary.org/wiki/%D0%B0%D0%BD%D0%B3%D0%BB%D0%B8%D0%B9%D1%81%D0%BA%D0%B8%D0%B9#Russian) | English | anglíjskij · adj |
| [воздух](https://en.wiktionary.org/wiki/%D0%B2%D0%BE%D0%B7%D0%B4%D1%83%D1%85#Russian) | air | vózdux · noun |
| [давать](https://en.wiktionary.org/wiki/%D0%B4%D0%B0%D0%B2%D0%B0%D1%82%D1%8C#Russian) | to give | davátʹ · verb |
| [двадцать два](https://en.wiktionary.org/wiki/%D0%B4%D0%B2%D0%B0%D0%B4%D1%86%D0%B0%D1%82%D1%8C%20%D0%B4%D0%B2%D0%B0#Russian) | twenty-two (22) | dvádcatʹ dvá · num |
| [музей](https://en.wiktionary.org/wiki/%D0%BC%D1%83%D0%B7%D0%B5%D0%B9#Russian) | museum | muzéj · noun |
| [американский](https://en.wiktionary.org/wiki/%D0%B0%D0%BC%D0%B5%D1%80%D0%B8%D0%BA%D0%B0%D0%BD%D1%81%D0%BA%D0%B8%D0%B9#Russian) | American | amerikánskij · adj |
| [вдоль](https://en.wiktionary.org/wiki/%D0%B2%D0%B4%D0%BE%D0%BB%D1%8C#Russian) | along | vdolʹ · prep |
| [второе лицо](https://en.wiktionary.org/wiki/%D0%B2%D1%82%D0%BE%D1%80%D0%BE%D0%B5%20%D0%BB%D0%B8%D1%86%D0%BE#Russian) | second person | vtoróje licó · noun |
| [двадцать три](https://en.wiktionary.org/wiki/%D0%B4%D0%B2%D0%B0%D0%B4%D1%86%D0%B0%D1%82%D1%8C%20%D1%82%D1%80%D0%B8#Russian) | twenty-three (23) | dvádcatʹ trí · num |
| [девять](https://en.wiktionary.org/wiki/%D0%B4%D0%B5%D0%B2%D1%8F%D1%82%D1%8C#Russian) | nine (9) | dévjatʹ · num |
| [дождь](https://en.wiktionary.org/wiki/%D0%B4%D0%BE%D0%B6%D0%B4%D1%8C#Russian) | rain | doždʹ · noun |
| [проводить](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%BE%D0%B2%D0%BE%D0%B4%D0%B8%D1%82%D1%8C#Russian) | to spend (time), to pass | provodítʹ · verb |
| [рабочий](https://en.wiktionary.org/wiki/%D1%80%D0%B0%D0%B1%D0%BE%D1%87%D0%B8%D0%B9#Russian) | worker; worker's (relating to people who perform physical labor for hire, especially in industry, construction, etc.) | rabóčij · adj |
| [борьба](https://en.wiktionary.org/wiki/%D0%B1%D0%BE%D1%80%D1%8C%D0%B1%D0%B0#Russian) | struggle, fight, conflict, combat | borʹbá · noun |
| [мужик](https://en.wiktionary.org/wiki/%D0%BC%D1%83%D0%B6%D0%B8%D0%BA#Russian) | man (male person); (UK) bloke, (US) dude, fella, guy | mužík · noun |
| [наука](https://en.wiktionary.org/wiki/%D0%BD%D0%B0%D1%83%D0%BA%D0%B0#Russian) | science | naúka · noun |
| [платье](https://en.wiktionary.org/wiki/%D0%BF%D0%BB%D0%B0%D1%82%D1%8C%D0%B5#Russian) | dress, gown, frock | plátʹje · noun |
| [теория](https://en.wiktionary.org/wiki/%D1%82%D0%B5%D0%BE%D1%80%D0%B8%D1%8F#Russian) | theory | teórija · noun |
| [тур](https://en.wiktionary.org/wiki/%D1%82%D1%83%D1%80#Russian) | round | tur · noun |
| [душа](https://en.wiktionary.org/wiki/%D0%B4%D1%83%D1%88%D0%B0#Russian) | soul | dušá · noun |
| [труд](https://en.wiktionary.org/wiki/%D1%82%D1%80%D1%83%D0%B4#Russian) | work, labor/labour | trud · noun |
| [аэропорт](https://en.wiktionary.org/wiki/%D0%B0%D1%8D%D1%80%D0%BE%D0%BF%D0%BE%D1%80%D1%82#Russian) | airport | aeropórt · noun |
| [камень](https://en.wiktionary.org/wiki/%D0%BA%D0%B0%D0%BC%D0%B5%D0%BD%D1%8C#Russian) | stone, rock | kámenʹ · noun |
| [ми](https://en.wiktionary.org/wiki/%D0%BC%D0%B8#Russian) | E, mi (note) | mi · noun |
| [мин](https://en.wiktionary.org/wiki/%D0%BC%D0%B8%D0%BD#Russian) | min., minute | min · noun |
| [напротив](https://en.wiktionary.org/wiki/%D0%BD%D0%B0%D0%BF%D1%80%D0%BE%D1%82%D0%B8%D0%B2#Russian) | (no,) quite the opposite; no, in fact... | naprótiv · adv |
| [открытие](https://en.wiktionary.org/wiki/%D0%BE%D1%82%D0%BA%D1%80%D1%8B%D1%82%D0%B8%D0%B5#Russian) | opening | otkrýtije · noun |
| [слушать](https://en.wiktionary.org/wiki/%D1%81%D0%BB%D1%83%D1%88%D0%B0%D1%82%D1%8C#Russian) | to listen, to listen to (someone/something) | slúšatʹ · verb |
| [храм](https://en.wiktionary.org/wiki/%D1%85%D1%80%D0%B0%D0%BC#Russian) | temple, shrine | xram · noun |
| [вера](https://en.wiktionary.org/wiki/%D0%B2%D0%B5%D1%80%D0%B0#Russian) | belief, faith | véra · noun |
| [открыть](https://en.wiktionary.org/wiki/%D0%BE%D1%82%D0%BA%D1%80%D1%8B%D1%82%D1%8C#Russian) | to open | otkrýtʹ · verb |
| [оттуда](https://en.wiktionary.org/wiki/%D0%BE%D1%82%D1%82%D1%83%D0%B4%D0%B0#Russian) | thence, from there | ottúda · adv |
| [собрание](https://en.wiktionary.org/wiki/%D1%81%D0%BE%D0%B1%D1%80%D0%B0%D0%BD%D0%B8%D0%B5#Russian) | meeting, gathering | sobránije · noun |
| [стиль](https://en.wiktionary.org/wiki/%D1%81%D1%82%D0%B8%D0%BB%D1%8C#Russian) | style | stilʹ · noun |
| [ТВ](https://en.wiktionary.org/wiki/%D0%A2%D0%92#Russian) | TV, television | [tɛ ˈvɛ] · noun |

</details>

<details><summary>Words 501–550</summary>

![[Resources/Audio/ru/Words 0501-0550.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [высокий](https://en.wiktionary.org/wiki/%D0%B2%D1%8B%D1%81%D0%BE%D0%BA%D0%B8%D0%B9#Russian) | tall | vysókij · adj |
| [морской](https://en.wiktionary.org/wiki/%D0%BC%D0%BE%D1%80%D1%81%D0%BA%D0%BE%D0%B9#Russian) | sea | morskój · adj |
| [написать](https://en.wiktionary.org/wiki/%D0%BD%D0%B0%D0%BF%D0%B8%D1%81%D0%B0%D1%82%D1%8C#Russian) | to write | napisátʹ · verb |
| [рассказать](https://en.wiktionary.org/wiki/%D1%80%D0%B0%D1%81%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C#Russian) | to tell | rasskazátʹ · verb |
| [служба](https://en.wiktionary.org/wiki/%D1%81%D0%BB%D1%83%D0%B6%D0%B1%D0%B0#Russian) | service | slúžba · noun |
| [вина](https://en.wiktionary.org/wiki/%D0%B2%D0%B8%D0%BD%D0%B0#Russian) | guilt, fault; blame | viná · noun |
| [двадцать пять](https://en.wiktionary.org/wiki/%D0%B4%D0%B2%D0%B0%D0%B4%D1%86%D0%B0%D1%82%D1%8C%20%D0%BF%D1%8F%D1%82%D1%8C#Russian) | twenty-five (25) | dvádcatʹ pjátʹ · num |
| [держать](https://en.wiktionary.org/wiki/%D0%B4%D0%B5%D1%80%D0%B6%D0%B0%D1%82%D1%8C#Russian) | to hold, to keep, to support | deržátʹ · verb |
| [детский](https://en.wiktionary.org/wiki/%D0%B4%D0%B5%D1%82%D1%81%D0%BA%D0%B8%D0%B9#Russian) | child; child's, children's | détskij · adj |
| [звук](https://en.wiktionary.org/wiki/%D0%B7%D0%B2%D1%83%D0%BA#Russian) | sound | zvuk · noun |
| [лес](https://en.wiktionary.org/wiki/%D0%BB%D0%B5%D1%81#Russian) | forest, woods | les · noun |
| [секс](https://en.wiktionary.org/wiki/%D1%81%D0%B5%D0%BA%D1%81#Russian) | sex (sexual intercourse) | sɛks · noun |
| [учитель](https://en.wiktionary.org/wiki/%D1%83%D1%87%D0%B8%D1%82%D0%B5%D0%BB%D1%8C#Russian) | teacher, instructor | učítelʹ · noun |
| [га](https://en.wiktionary.org/wiki/%D0%B3%D0%B0#Russian) | ha, hectare | ga · noun |
| [двадцать четыре](https://en.wiktionary.org/wiki/%D0%B4%D0%B2%D0%B0%D0%B4%D1%86%D0%B0%D1%82%D1%8C%20%D1%87%D0%B5%D1%82%D1%8B%D1%80%D0%B5#Russian) | twenty-four (24) | dvádcatʹ četýre · num |
| [любить](https://en.wiktionary.org/wiki/%D0%BB%D1%8E%D0%B1%D0%B8%D1%82%D1%8C#Russian) | to love, to like, to be fond of, to grow fond of (more intensely than нра́виться (nrávitʹsja)) | ljubítʹ · verb |
| [народный](https://en.wiktionary.org/wiki/%D0%BD%D0%B0%D1%80%D0%BE%D0%B4%D0%BD%D1%8B%D0%B9#Russian) | people's | naródnyj · adj |
| [страх](https://en.wiktionary.org/wiki/%D1%81%D1%82%D1%80%D0%B0%D1%85#Russian) | fear | strax · noun |
| [век](https://en.wiktionary.org/wiki/%D0%B2%D0%B5%D0%BA#Russian) | century | vek · noun |
| [отделение](https://en.wiktionary.org/wiki/%D0%BE%D1%82%D0%B4%D0%B5%D0%BB%D0%B5%D0%BD%D0%B8%D0%B5#Russian) | department, division, branch | otdelénije · noun |
| [средний](https://en.wiktionary.org/wiki/%D1%81%D1%80%D0%B5%D0%B4%D0%BD%D0%B8%D0%B9#Russian) | middle | srédnij · adj |
| [чай](https://en.wiktionary.org/wiki/%D1%87%D0%B0%D0%B9#Russian) | tea (in all senses: the drink, the plant, the dried leaves, or tea-drinking) | čaj · noun |
| [леса](https://en.wiktionary.org/wiki/%D0%BB%D0%B5%D1%81%D0%B0#Russian) | fishing line | lesá · noun |
| [объект](https://en.wiktionary.org/wiki/%D0%BE%D0%B1%D1%8A%D0%B5%D0%BA%D1%82#Russian) | object (general sense) | obʺjékt · noun |
| [сад](https://en.wiktionary.org/wiki/%D1%81%D0%B0%D0%B4#Russian) | garden, orchard | sad · noun |
| [автобус](https://en.wiktionary.org/wiki/%D0%B0%D0%B2%D1%82%D0%BE%D0%B1%D1%83%D1%81#Russian) | bus, motorbus | avtóbus · noun |
| [бабушка](https://en.wiktionary.org/wiki/%D0%B1%D0%B0%D0%B1%D1%83%D1%88%D0%BA%D0%B0#Russian) | grandmother, grandma, granny | bábuška · noun |
| [брак](https://en.wiktionary.org/wiki/%D0%B1%D1%80%D0%B0%D0%BA#Russian) | marriage, matrimony | brak · noun |
| [дух](https://en.wiktionary.org/wiki/%D0%B4%D1%83%D1%85#Russian) | spirit | dux · noun |
| [мозг](https://en.wiktionary.org/wiki/%D0%BC%D0%BE%D0%B7%D0%B3#Russian) | brain; marrow | mozg · noun |
| [поезд](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%B5%D0%B7%D0%B4#Russian) | train, a line of connected railway cars | pójezd · noun |
| [поэт](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D1%8D%D1%82#Russian) | poet | poét · noun |
| [тура](https://en.wiktionary.org/wiki/%D1%82%D1%83%D1%80%D0%B0#Russian) | rook, castle | turá · noun |
| [университет](https://en.wiktionary.org/wiki/%D1%83%D0%BD%D0%B8%D0%B2%D0%B5%D1%80%D1%81%D0%B8%D1%82%D0%B5%D1%82#Russian) | university | universitét · noun |
| [учиться](https://en.wiktionary.org/wiki/%D1%83%D1%87%D0%B8%D1%82%D1%8C%D1%81%D1%8F#Russian) | to learn (to receive knowledge or skills or to gain useful experience) | učítʹsja · verb |
| [ад](https://en.wiktionary.org/wiki/%D0%B0%D0%B4#Russian) | hell, Hades (the abode of the damned) | ad · noun |
| [зря](https://en.wiktionary.org/wiki/%D0%B7%D1%80%D1%8F#Russian) | in vain, to no avail, for nothing | zrja · adv |
| [лев](https://en.wiktionary.org/wiki/%D0%BB%D0%B5%D0%B2#Russian) | lion | lev · noun |
| [мост](https://en.wiktionary.org/wiki/%D0%BC%D0%BE%D1%81%D1%82#Russian) | bridge | most · noun |
| [снег](https://en.wiktionary.org/wiki/%D1%81%D0%BD%D0%B5%D0%B3#Russian) | snow | sneg · noun |
| [лето](https://en.wiktionary.org/wiki/%D0%BB%D0%B5%D1%82%D0%BE#Russian) | summer | léto · noun |
| [набор](https://en.wiktionary.org/wiki/%D0%BD%D0%B0%D0%B1%D0%BE%D1%80#Russian) | set, kit, outfit, collection (collection of various objects for a particular purpose, such as a set of tools) | nabór · noun |
| [обед](https://en.wiktionary.org/wiki/%D0%BE%D0%B1%D0%B5%D0%B4#Russian) | lunch, dinner (the main meal of the day, which is served between noon and 3 p.m.) | obéd · noun |
| [прекрасный](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%B5%D0%BA%D1%80%D0%B0%D1%81%D0%BD%D1%8B%D0%B9#Russian) | beautiful | prekrásnyj · adj |
| [следующим образом](https://en.wiktionary.org/wiki/%D1%81%D0%BB%D0%B5%D0%B4%D1%83%D1%8E%D1%89%D0%B8%D0%BC%20%D0%BE%D0%B1%D1%80%D0%B0%D0%B7%D0%BE%D0%BC#Russian) | as follows, thuswise, this way, in the following way | slédujuščim óbrazom · adv |
| [бесплатно](https://en.wiktionary.org/wiki/%D0%B1%D0%B5%D1%81%D0%BF%D0%BB%D0%B0%D1%82%D0%BD%D0%BE#Russian) | gratis, free of charge | besplátno · adv |
| [дерево](https://en.wiktionary.org/wiki/%D0%B4%D0%B5%D1%80%D0%B5%D0%B2%D0%BE#Russian) | tree | dérevo · noun |
| [задание](https://en.wiktionary.org/wiki/%D0%B7%D0%B0%D0%B4%D0%B0%D0%BD%D0%B8%D0%B5#Russian) | assignment, task | zadánije · noun |
| [замок](https://en.wiktionary.org/wiki/%D0%B7%D0%B0%D0%BC%D0%BE%D0%BA#Russian) | castle | zámok · noun |
| [нос](https://en.wiktionary.org/wiki/%D0%BD%D0%BE%D1%81#Russian) | nose | nos · noun |

</details>

<details><summary>Words 551–600</summary>

![[Resources/Audio/ru/Words 0551-0600.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [ум](https://en.wiktionary.org/wiki/%D1%83%D0%BC#Russian) | mind | um · noun |
| [чудо](https://en.wiktionary.org/wiki/%D1%87%D1%83%D0%B4%D0%BE#Russian) | miracle, marvel | čúdo · noun |
| [болезнь](https://en.wiktionary.org/wiki/%D0%B1%D0%BE%D0%BB%D0%B5%D0%B7%D0%BD%D1%8C#Russian) | disease, sickness, illness | boléznʹ · noun |
| [вон](https://en.wiktionary.org/wiki/%D0%B2%D0%BE%D0%BD#Russian) | there | von · adv |
| [мэр](https://en.wiktionary.org/wiki/%D0%BC%D1%8D%D1%80#Russian) | mayor | mɛr · noun |
| [мясо](https://en.wiktionary.org/wiki/%D0%BC%D1%8F%D1%81%D0%BE#Russian) | meat | mjáso · noun |
| [рука](https://en.wiktionary.org/wiki/%D1%80%D1%83%D0%BA%D0%B0#Russian) | hand | ruká · noun |
| [сквозь](https://en.wiktionary.org/wiki/%D1%81%D0%BA%D0%B2%D0%BE%D0%B7%D1%8C#Russian) | through | skvozʹ · prep |
| [собака](https://en.wiktionary.org/wiki/%D1%81%D0%BE%D0%B1%D0%B0%D0%BA%D0%B0#Russian) | dog | sobáka · noun |
| [единственное число](https://en.wiktionary.org/wiki/%D0%B5%D0%B4%D0%B8%D0%BD%D1%81%D1%82%D0%B2%D0%B5%D0%BD%D0%BD%D0%BE%D0%B5%20%D1%87%D0%B8%D1%81%D0%BB%D0%BE#Russian) | singular | jedínstvennoje čisló · noun |
| [нефть](https://en.wiktionary.org/wiki/%D0%BD%D0%B5%D1%84%D1%82%D1%8C#Russian) | oil, petroleum, mineral oil | neftʹ · noun |
| [офицер](https://en.wiktionary.org/wiki/%D0%BE%D1%84%D0%B8%D1%86%D0%B5%D1%80#Russian) | officer | oficér · noun |
| [поговорить](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D1%8C#Russian) | to have a conversation, to talk, to chat (used with с кем (s kem)) | pogovorítʹ · verb |
| [поток](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D1%82%D0%BE%D0%BA#Russian) | stream | potók · noun |
| [хлеб](https://en.wiktionary.org/wiki/%D1%85%D0%BB%D0%B5%D0%B1#Russian) | bread | xleb · noun |
| [царь](https://en.wiktionary.org/wiki/%D1%86%D0%B0%D1%80%D1%8C#Russian) | tsar, Russian emperor | carʹ · noun |
| [дон](https://en.wiktionary.org/wiki/%D0%B4%D0%BE%D0%BD#Russian) | don (Spanish or Italian title) | don · noun |
| [кв](https://en.wiktionary.org/wiki/%D0%BA%D0%B2#Russian) | kV, kilovolt | kv · noun |
| [кв.](https://en.wiktionary.org/wiki/%D0%BA%D0%B2.#Russian) | apartment, flat | kv. · noun |
| [немецкий](https://en.wiktionary.org/wiki/%D0%BD%D0%B5%D0%BC%D0%B5%D1%86%D0%BA%D0%B8%D0%B9#Russian) | German | neméckij · adj |
| [ошибка](https://en.wiktionary.org/wiki/%D0%BE%D1%88%D0%B8%D0%B1%D0%BA%D0%B0#Russian) | mistake, error, fault | ošíbka · noun |
| [республика](https://en.wiktionary.org/wiki/%D1%80%D0%B5%D1%81%D0%BF%D1%83%D0%B1%D0%BB%D0%B8%D0%BA%D0%B0#Russian) | republic | respúblika · noun |
| [супер](https://en.wiktionary.org/wiki/%D1%81%D1%83%D0%BF%D0%B5%D1%80#Russian) | great! super! cool! | súper · intj |
| [такси](https://en.wiktionary.org/wiki/%D1%82%D0%B0%D0%BA%D1%81%D0%B8#Russian) | taxi; cab | taksí · noun |
| [вследствие](https://en.wiktionary.org/wiki/%D0%B2%D1%81%D0%BB%D0%B5%D0%B4%D1%81%D1%82%D0%B2%D0%B8%D0%B5#Russian) | as a consequence of | vslédstvije · prep |
| [кости](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D1%81%D1%82%D0%B8#Russian) | gambling game that uses dice | kósti · noun |
| [плохой](https://en.wiktionary.org/wiki/%D0%BF%D0%BB%D0%BE%D1%85%D0%BE%D0%B9#Russian) | bad (not good) | ploxój · adj |
| [си](https://en.wiktionary.org/wiki/%D1%81%D0%B8#Russian) | B (musical note) | si · noun |
| [указ](https://en.wiktionary.org/wiki/%D1%83%D0%BA%D0%B0%D0%B7#Russian) | enactment, ordinance, decree, edict, ukase | ukáz · noun |
| [безусловно](https://en.wiktionary.org/wiki/%D0%B1%D0%B5%D0%B7%D1%83%D1%81%D0%BB%D0%BE%D0%B2%D0%BD%D0%BE#Russian) | certainly, undoubtedly, absolutely | bezuslóvno · adv |
| [вино](https://en.wiktionary.org/wiki/%D0%B2%D0%B8%D0%BD%D0%BE#Russian) | wine | vinó · noun |
| [возвращение](https://en.wiktionary.org/wiki/%D0%B2%D0%BE%D0%B7%D0%B2%D1%80%D0%B0%D1%89%D0%B5%D0%BD%D0%B8%D0%B5#Russian) | return | vozvraščénije · noun |
| [улица](https://en.wiktionary.org/wiki/%D1%83%D0%BB%D0%B8%D1%86%D0%B0#Russian) | street | úlica · noun |
| [дядя](https://en.wiktionary.org/wiki/%D0%B4%D1%8F%D0%B4%D1%8F#Russian) | uncle | djádja · noun |
| [аппарат](https://en.wiktionary.org/wiki/%D0%B0%D0%BF%D0%BF%D0%B0%D1%80%D0%B0%D1%82#Russian) | apparatus, instrument, device | apparát · noun |
| [важный](https://en.wiktionary.org/wiki/%D0%B2%D0%B0%D0%B6%D0%BD%D1%8B%D0%B9#Russian) | important | vážnyj · adj |
| [и тому подобное](https://en.wiktionary.org/wiki/%D0%B8%20%D1%82%D0%BE%D0%BC%D1%83%20%D0%BF%D0%BE%D0%B4%D0%BE%D0%B1%D0%BD%D0%BE%D0%B5#Russian) | and so on, and the like, and that kind of thing | i tomú podóbnoje · phrase |
| [королева](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D1%80%D0%BE%D0%BB%D0%B5%D0%B2%D0%B0#Russian) | queen (Russian abbreviation: Ф) | koroléva · noun |
| [помогать](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%BC%D0%BE%D0%B3%D0%B0%D1%82%D1%8C#Russian) | to help | pomogátʹ · verb |
| [предмет](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%B5%D0%B4%D0%BC%D0%B5%D1%82#Russian) | object | predmét · noun |
| [четверг](https://en.wiktionary.org/wiki/%D1%87%D0%B5%D1%82%D0%B2%D0%B5%D1%80%D0%B3#Russian) | Thursday | četvérg · noun |
| [горе](https://en.wiktionary.org/wiki/%D0%B3%D0%BE%D1%80%D0%B5#Russian) | grief, distress, sadness | góre · noun |
| [и т.д.](https://en.wiktionary.org/wiki/%D0%B8%20%D1%82.%D0%B4.#Russian) | etc., and so forth, and so on | i t.d. · phrase |
| [каждому своё](https://en.wiktionary.org/wiki/%D0%BA%D0%B0%D0%B6%D0%B4%D0%BE%D0%BC%D1%83%20%D1%81%D0%B2%D0%BE%D1%91#Russian) | to each his own | káždomu svojó · phrase |
| [тридцать](https://en.wiktionary.org/wiki/%D1%82%D1%80%D0%B8%D0%B4%D1%86%D0%B0%D1%82%D1%8C#Russian) | thirty (30) | trídcatʹ · num |
| [компьютер](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D0%BC%D0%BF%D1%8C%D1%8E%D1%82%D0%B5%D1%80#Russian) | computer | kompʹjútɛr · noun |
| [погода](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%B3%D0%BE%D0%B4%D0%B0#Russian) | weather | pogóda · noun |
| [рубль](https://en.wiktionary.org/wiki/%D1%80%D1%83%D0%B1%D0%BB%D1%8C#Russian) | ruble, rouble (a monetary unit of Russia and Belarus equal to 100 kopecks) | rublʹ · noun |
| [урок](https://en.wiktionary.org/wiki/%D1%83%D1%80%D0%BE%D0%BA#Russian) | lesson | urók · noun |
| [чувствовать](https://en.wiktionary.org/wiki/%D1%87%D1%83%D0%B2%D1%81%D1%82%D0%B2%D0%BE%D0%B2%D0%B0%D1%82%D1%8C#Russian) | to feel (something) | čúvstvovatʹ · verb |

</details>

<details><summary>Words 601–650</summary>

![[Resources/Audio/ru/Words 0601-0650.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [безопасность](https://en.wiktionary.org/wiki/%D0%B1%D0%B5%D0%B7%D0%BE%D0%BF%D0%B0%D1%81%D0%BD%D0%BE%D1%81%D1%82%D1%8C#Russian) | safety | bezopásnostʹ · noun |
| [политический](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%BB%D0%B8%D1%82%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B8%D0%B9#Russian) | political | politíčeskij · adj |
| [род](https://en.wiktionary.org/wiki/%D1%80%D0%BE%D0%B4#Russian) | generation, birth, origin, stock, family, race, tribe, lineage | rod · noun |
| [создавать](https://en.wiktionary.org/wiki/%D1%81%D0%BE%D0%B7%D0%B4%D0%B0%D0%B2%D0%B0%D1%82%D1%8C#Russian) | to create | sozdavátʹ · verb |
| [дед](https://en.wiktionary.org/wiki/%D0%B4%D0%B5%D0%B4#Russian) | grandfather | ded · noun |
| [мужской](https://en.wiktionary.org/wiki/%D0%BC%D1%83%D0%B6%D1%81%D0%BA%D0%BE%D0%B9#Russian) | male | mužskój · adj |
| [лист](https://en.wiktionary.org/wiki/%D0%BB%D0%B8%D1%81%D1%82#Russian) | leaf (flat green organ of a plant) | list · noun |
| [масло](https://en.wiktionary.org/wiki/%D0%BC%D0%B0%D1%81%D0%BB%D0%BE#Russian) | butter | máslo · noun |
| [пиво](https://en.wiktionary.org/wiki/%D0%BF%D0%B8%D0%B2%D0%BE#Russian) | beer (verbal noun of пить (pitʹ) (nomen obiecti)) | pívo · noun |
| [участник](https://en.wiktionary.org/wiki/%D1%83%D1%87%D0%B0%D1%81%D1%82%D0%BD%D0%B8%D0%BA#Russian) | participant, participator | učástnik · noun |
| [берег](https://en.wiktionary.org/wiki/%D0%B1%D0%B5%D1%80%D0%B5%D0%B3#Russian) | bank, shore, coast, beach | béreg · noun |
| [враг](https://en.wiktionary.org/wiki/%D0%B2%D1%80%D0%B0%D0%B3#Russian) | enemy, foe | vrag · noun |
| [двигатель](https://en.wiktionary.org/wiki/%D0%B4%D0%B2%D0%B8%D0%B3%D0%B0%D1%82%D0%B5%D0%BB%D1%8C#Russian) | engine, motor | dvígatelʹ · noun |
| [еда](https://en.wiktionary.org/wiki/%D0%B5%D0%B4%D0%B0#Russian) | food | jedá · noun |
| [комната](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D0%BC%D0%BD%D0%B0%D1%82%D0%B0#Russian) | room | kómnata · noun |
| [май](https://en.wiktionary.org/wiki/%D0%BC%D0%B0%D0%B9#Russian) | May | maj · noun |
| [мечта](https://en.wiktionary.org/wiki/%D0%BC%D0%B5%D1%87%D1%82%D0%B0#Russian) | fantasy, daydream | mečtá · noun |
| [молоко](https://en.wiktionary.org/wiki/%D0%BC%D0%BE%D0%BB%D0%BE%D0%BA%D0%BE#Russian) | milk | molokó · noun |
| [рассказывать](https://en.wiktionary.org/wiki/%D1%80%D0%B0%D1%81%D1%81%D0%BA%D0%B0%D0%B7%D1%8B%D0%B2%D0%B0%D1%82%D1%8C#Russian) | to tell | rasskázyvatʹ · verb |
| [с Новым годом](https://en.wiktionary.org/wiki/%D1%81%20%D0%9D%D0%BE%D0%B2%D1%8B%D0%BC%20%D0%B3%D0%BE%D0%B4%D0%BE%D0%BC#Russian) | Happy New Year | s Nóvym gódom · intj |
| [вторник](https://en.wiktionary.org/wiki/%D0%B2%D1%82%D0%BE%D1%80%D0%BD%D0%B8%D0%BA#Russian) | Tuesday | vtórnik · noun |
| [гей](https://en.wiktionary.org/wiki/%D0%B3%D0%B5%D0%B9#Russian) | hey! | gej · intj |
| [достичь](https://en.wiktionary.org/wiki/%D0%B4%D0%BE%D1%81%D1%82%D0%B8%D1%87%D1%8C#Russian) | to reach, to arrive at | dostíčʹ · verb |
| [кладбище](https://en.wiktionary.org/wiki/%D0%BA%D0%BB%D0%B0%D0%B4%D0%B1%D0%B8%D1%89%D0%B5#Russian) | cemetery, graveyard | kládbišče · noun |
| [март](https://en.wiktionary.org/wiki/%D0%BC%D0%B0%D1%80%D1%82#Russian) | March | mart · noun |
| [поехать](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%B5%D1%85%D0%B0%D1%82%D1%8C#Russian) | to go (in a conveyance or on horseback) | pojéxatʹ · verb |
| [штат](https://en.wiktionary.org/wiki/%D1%88%D1%82%D0%B0%D1%82#Russian) | state (a political division, e.g. a US state) | štat · noun |
| [реальность](https://en.wiktionary.org/wiki/%D1%80%D0%B5%D0%B0%D0%BB%D1%8C%D0%BD%D0%BE%D1%81%D1%82%D1%8C#Russian) | reality | reálʹnostʹ · noun |
| [север](https://en.wiktionary.org/wiki/%D1%81%D0%B5%D0%B2%D0%B5%D1%80#Russian) | north | séver · noun |
| [соль](https://en.wiktionary.org/wiki/%D1%81%D0%BE%D0%BB%D1%8C#Russian) | salt | solʹ · noun |
| [выпить](https://en.wiktionary.org/wiki/%D0%B2%D1%8B%D0%BF%D0%B8%D1%82%D1%8C#Russian) | to drink, to drink up | výpitʹ · verb |
| [кот](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D1%82#Russian) | tomcat | kot · noun |
| [красивый](https://en.wiktionary.org/wiki/%D0%BA%D1%80%D0%B0%D1%81%D0%B8%D0%B2%D1%8B%D0%B9#Russian) | beautiful, handsome | krasívyj · adj |
| [слава богу](https://en.wiktionary.org/wiki/%D1%81%D0%BB%D0%B0%D0%B2%D0%B0%20%D0%B1%D0%BE%D0%B3%D1%83#Russian) | thank God!; thank goodness! | sláva bógu · intj |
| [третье лицо](https://en.wiktionary.org/wiki/%D1%82%D1%80%D0%B5%D1%82%D1%8C%D0%B5%20%D0%BB%D0%B8%D1%86%D0%BE#Russian) | third person | trétʹje licó · noun |
| [южный](https://en.wiktionary.org/wiki/%D1%8E%D0%B6%D0%BD%D1%8B%D0%B9#Russian) | south, southern | júžnyj · adj |
| [волна](https://en.wiktionary.org/wiki/%D0%B2%D0%BE%D0%BB%D0%BD%D0%B0#Russian) | wave | volná · noun |
| [пер.](https://en.wiktionary.org/wiki/%D0%BF%D0%B5%D1%80.#Russian) | lane, by-street | per. · noun |
| [птица](https://en.wiktionary.org/wiki/%D0%BF%D1%82%D0%B8%D1%86%D0%B0#Russian) | bird | ptíca · noun |
| [сука](https://en.wiktionary.org/wiki/%D1%81%D1%83%D0%BA%D0%B0#Russian) | bitch (female dog) | súka · noun |
| [апрель](https://en.wiktionary.org/wiki/%D0%B0%D0%BF%D1%80%D0%B5%D0%BB%D1%8C#Russian) | April | aprélʹ · noun |
| [кровать](https://en.wiktionary.org/wiki/%D0%BA%D1%80%D0%BE%D0%B2%D0%B0%D1%82%D1%8C#Russian) | bed | krovátʹ · noun |
| [правый](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%B0%D0%B2%D1%8B%D0%B9#Russian) | right, right-hand | právyj · adj |
| [промышленность](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%BE%D0%BC%D1%8B%D1%88%D0%BB%D0%B5%D0%BD%D0%BD%D0%BE%D1%81%D1%82%D1%8C#Russian) | industry | promýšlennostʹ · noun |
| [сорок](https://en.wiktionary.org/wiki/%D1%81%D0%BE%D1%80%D0%BE%D0%BA#Russian) | forty (40) | sórok · num |
| [товарищ](https://en.wiktionary.org/wiki/%D1%82%D0%BE%D0%B2%D0%B0%D1%80%D0%B8%D1%89#Russian) | comrade, friend (male or female) | továrišč · noun |
| [МиГ](https://en.wiktionary.org/wiki/%D0%9C%D0%B8%D0%93#Russian) | MiG, mig (fighter jet) | MiG · noun |
| [Миг](https://en.wiktionary.org/wiki/%D0%9C%D0%B8%D0%B3#Russian) | MiG, mig (a series of fighter jets designed by Mikoyán and Gurévich ... А. И. Микоян и М. И. Гуревич) | Mig · noun |
| [веб](https://en.wiktionary.org/wiki/%D0%B2%D0%B5%D0%B1#Russian) | web (the World Wide Web) | vɛb · noun |
| [выражение](https://en.wiktionary.org/wiki/%D0%B2%D1%8B%D1%80%D0%B0%D0%B6%D0%B5%D0%BD%D0%B8%D0%B5#Russian) | act of expressing something, mostly one's feelings or thoughts | vyražénije · noun |

</details>

<details><summary>Words 651–700</summary>

![[Resources/Audio/ru/Words 0651-0700.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [кусок](https://en.wiktionary.org/wiki/%D0%BA%D1%83%D1%81%D0%BE%D0%BA#Russian) | piece | kusók · noun |
| [меч](https://en.wiktionary.org/wiki/%D0%BC%D0%B5%D1%87#Russian) | sword (usually with a straight blade) | meč · noun |
| [миг](https://en.wiktionary.org/wiki/%D0%BC%D0%B8%D0%B3#Russian) | moment, instant | mig · noun |
| [приблизительно](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%B8%D0%B1%D0%BB%D0%B8%D0%B7%D0%B8%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE#Russian) | approximate, approximately, roughly | priblizítelʹno · adv |
| [ресторан](https://en.wiktionary.org/wiki/%D1%80%D0%B5%D1%81%D1%82%D0%BE%D1%80%D0%B0%D0%BD#Russian) | restaurant | restorán · noun |
| [серебро](https://en.wiktionary.org/wiki/%D1%81%D0%B5%D1%80%D0%B5%D0%B1%D1%80%D0%BE#Russian) | silver | serebró · noun |
| [тень](https://en.wiktionary.org/wiki/%D1%82%D0%B5%D0%BD%D1%8C#Russian) | shade | tenʹ · noun |
| [эй](https://en.wiktionary.org/wiki/%D1%8D%D0%B9#Russian) | hey! (you, there!) | ej · intj |
| [юг](https://en.wiktionary.org/wiki/%D1%8E%D0%B3#Russian) | south | jug · noun |
| [январь](https://en.wiktionary.org/wiki/%D1%8F%D0%BD%D0%B2%D0%B0%D1%80%D1%8C#Russian) | January | janvárʹ · noun |
| [ай](https://en.wiktionary.org/wiki/%D0%B0%D0%B9#Russian) | ouch! (it hurts!) | aj · intj |
| [беда](https://en.wiktionary.org/wiki/%D0%B1%D0%B5%D0%B4%D0%B0#Russian) | misfortune, trouble, disaster, mischief | bedá · noun |
| [днём](https://en.wiktionary.org/wiki/%D0%B4%D0%BD%D1%91%D0%BC#Russian) | by day, during the day | dnjom · adv |
| [камера](https://en.wiktionary.org/wiki/%D0%BA%D0%B0%D0%BC%D0%B5%D1%80%D0%B0#Russian) | camera | kámera · noun |
| [объединение](https://en.wiktionary.org/wiki/%D0%BE%D0%B1%D1%8A%D0%B5%D0%B4%D0%B8%D0%BD%D0%B5%D0%BD%D0%B8%D0%B5#Russian) | association, union | obʺjedinénije · noun |
| [прошлый](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%BE%D1%88%D0%BB%D1%8B%D0%B9#Russian) | last, past | próšlyj · adj |
| [вв](https://en.wiktionary.org/wiki/%D0%B2%D0%B2#Russian) | centuries | vv · noun |
| [дар](https://en.wiktionary.org/wiki/%D0%B4%D0%B0%D1%80#Russian) | gift, present | dar · noun |
| [дурак](https://en.wiktionary.org/wiki/%D0%B4%D1%83%D1%80%D0%B0%D0%BA#Russian) | durak (a simple card game in which the last player holding cards in their hand is the loser) | durák · noun |
| [китайский](https://en.wiktionary.org/wiki/%D0%BA%D0%B8%D1%82%D0%B0%D0%B9%D1%81%D0%BA%D0%B8%D0%B9#Russian) | Chinese | kitájskij · adj |
| [луна](https://en.wiktionary.org/wiki/%D0%BB%D1%83%D0%BD%D0%B0#Russian) | moon (the Moon, the satellite of planet Earth) | luná · noun |
| [позади](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%B7%D0%B0%D0%B4%D0%B8#Russian) | behind | pozadí · adv |
| [рак](https://en.wiktionary.org/wiki/%D1%80%D0%B0%D0%BA#Russian) | crawfish, crayfish | rak · noun |
| [сентябрь](https://en.wiktionary.org/wiki/%D1%81%D0%B5%D0%BD%D1%82%D1%8F%D0%B1%D1%80%D1%8C#Russian) | September | sentjábrʹ · noun |
| [телевизор](https://en.wiktionary.org/wiki/%D1%82%D0%B5%D0%BB%D0%B5%D0%B2%D0%B8%D0%B7%D0%BE%D1%80#Russian) | television set | televízor · noun |
| [шутка](https://en.wiktionary.org/wiki/%D1%88%D1%83%D1%82%D0%BA%D0%B0#Russian) | joke | šútka · noun |
| [бить](https://en.wiktionary.org/wiki/%D0%B1%D0%B8%D1%82%D1%8C#Russian) | to beat | bitʹ · verb |
| [вопреки](https://en.wiktionary.org/wiki/%D0%B2%D0%BE%D0%BF%D1%80%D0%B5%D0%BA%D0%B8#Russian) | in spite of, contrary to | voprekí · prep |
| [голосование](https://en.wiktionary.org/wiki/%D0%B3%D0%BE%D0%BB%D0%BE%D1%81%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5#Russian) | voting, poll, polling | golosovánije · noun |
| [лошадь](https://en.wiktionary.org/wiki/%D0%BB%D0%BE%D1%88%D0%B0%D0%B4%D1%8C#Russian) | horse | lóšadʹ · noun |
| [мак](https://en.wiktionary.org/wiki/%D0%BC%D0%B0%D0%BA#Russian) | poppy | mak · noun |
| [нож](https://en.wiktionary.org/wiki/%D0%BD%D0%BE%D0%B6#Russian) | knife | nož · noun |
| [озеро](https://en.wiktionary.org/wiki/%D0%BE%D0%B7%D0%B5%D1%80%D0%BE#Russian) | lake | ózero · noun |
| [рыба](https://en.wiktionary.org/wiki/%D1%80%D1%8B%D0%B1%D0%B0#Russian) | fish (as a living animal) | rýba · noun |
| [чей](https://en.wiktionary.org/wiki/%D1%87%D0%B5%D0%B9#Russian) | whose | čej · pron |
| [август](https://en.wiktionary.org/wiki/%D0%B0%D0%B2%D0%B3%D1%83%D1%81%D1%82#Russian) | August | ávgust · noun |
| [ездить](https://en.wiktionary.org/wiki/%D0%B5%D0%B7%D0%B4%D0%B8%D1%82%D1%8C#Russian) | to go (by horse or vehicle), to ride, to drive | jézditʹ · verb |
| [марш](https://en.wiktionary.org/wiki/%D0%BC%D0%B0%D1%80%D1%88#Russian) | march | marš · noun |
| [мозги](https://en.wiktionary.org/wiki/%D0%BC%D0%BE%D0%B7%D0%B3%D0%B8#Russian) | brains (food) | mozgí · noun |
| [сесть](https://en.wiktionary.org/wiki/%D1%81%D0%B5%D1%81%D1%82%D1%8C#Russian) | to sit down | sestʹ · verb |
| [февраль](https://en.wiktionary.org/wiki/%D1%84%D0%B5%D0%B2%D1%80%D0%B0%D0%BB%D1%8C#Russian) | February | fevrálʹ · noun |
| [фотография](https://en.wiktionary.org/wiki/%D1%84%D0%BE%D1%82%D0%BE%D0%B3%D1%80%D0%B0%D1%84%D0%B8%D1%8F#Russian) | photograph | fotográfija · noun |
| [этаж](https://en.wiktionary.org/wiki/%D1%8D%D1%82%D0%B0%D0%B6#Russian) | floor, storey | etáž · noun |
| [ангел](https://en.wiktionary.org/wiki/%D0%B0%D0%BD%D0%B3%D0%B5%D0%BB#Russian) | angel | ángel · noun |
| [бар](https://en.wiktionary.org/wiki/%D0%B1%D0%B0%D1%80#Russian) | saloon, bar, snack bar | bar · noun |
| [дыхание](https://en.wiktionary.org/wiki/%D0%B4%D1%8B%D1%85%D0%B0%D0%BD%D0%B8%D0%B5#Russian) | breath | dyxánije · noun |
| [океан](https://en.wiktionary.org/wiki/%D0%BE%D0%BA%D0%B5%D0%B0%D0%BD#Russian) | ocean | okeán · noun |
| [пятьдесят](https://en.wiktionary.org/wiki/%D0%BF%D1%8F%D1%82%D1%8C%D0%B4%D0%B5%D1%81%D1%8F%D1%82#Russian) | fifty (50) | pjatʹdesját · num |
| [сок](https://en.wiktionary.org/wiki/%D1%81%D0%BE%D0%BA#Russian) | juice | sok · noun |
| [спас](https://en.wiktionary.org/wiki/%D1%81%D0%BF%D0%B0%D1%81#Russian) | rescue, salvation | spas · noun |

</details>

<details><summary>Words 701–750</summary>

![[Resources/Audio/ru/Words 0701-0750.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [широкий](https://en.wiktionary.org/wiki/%D1%88%D0%B8%D1%80%D0%BE%D0%BA%D0%B8%D0%B9#Russian) | wide, broad | širókij · adj |
| [больной](https://en.wiktionary.org/wiki/%D0%B1%D0%BE%D0%BB%D1%8C%D0%BD%D0%BE%D0%B9#Russian) | sick, ill | bolʹnój · adj |
| [держать за яйца](https://en.wiktionary.org/wiki/%D0%B4%D0%B5%D1%80%D0%B6%D0%B0%D1%82%D1%8C%20%D0%B7%D0%B0%20%D1%8F%D0%B9%D1%86%D0%B0#Russian) | to get by the balls | deržátʹ za jájca · verb |
| [женский](https://en.wiktionary.org/wiki/%D0%B6%D0%B5%D0%BD%D1%81%D0%BA%D0%B8%D0%B9#Russian) | female | žénskij · adj |
| [морской лев](https://en.wiktionary.org/wiki/%D0%BC%D0%BE%D1%80%D1%81%D0%BA%D0%BE%D0%B9%20%D0%BB%D0%B5%D0%B2#Russian) | sea lion | morskój lév · noun |
| [неделя](https://en.wiktionary.org/wiki/%D0%BD%D0%B5%D0%B4%D0%B5%D0%BB%D1%8F#Russian) | week | nedélja · noun |
| [следовательно](https://en.wiktionary.org/wiki/%D1%81%D0%BB%D0%B5%D0%B4%D0%BE%D0%B2%D0%B0%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE#Russian) | consequently; therefore | slédovatelʹno · adv |
| [торговля](https://en.wiktionary.org/wiki/%D1%82%D0%BE%D1%80%D0%B3%D0%BE%D0%B2%D0%BB%D1%8F#Russian) | trade, commerce, sale, business | torgóvlja · noun |
| [артист](https://en.wiktionary.org/wiki/%D0%B0%D1%80%D1%82%D0%B8%D1%81%D1%82#Russian) | artist, actor, performer | artíst · noun |
| [библиотека](https://en.wiktionary.org/wiki/%D0%B1%D0%B8%D0%B1%D0%BB%D0%B8%D0%BE%D1%82%D0%B5%D0%BA%D0%B0#Russian) | library (in all senses) | bibliotéka · noun |
| [дно](https://en.wiktionary.org/wiki/%D0%B4%D0%BD%D0%BE#Russian) | floor, bed (hard surface at the bottom of a body of water) | dno · noun |
| [живот](https://en.wiktionary.org/wiki/%D0%B6%D0%B8%D0%B2%D0%BE%D1%82#Russian) | belly, stomach | živót · noun |
| [октябрь](https://en.wiktionary.org/wiki/%D0%BE%D0%BA%D1%82%D1%8F%D0%B1%D1%80%D1%8C#Russian) | October | oktjábrʹ · noun |
| [планета](https://en.wiktionary.org/wiki/%D0%BF%D0%BB%D0%B0%D0%BD%D0%B5%D1%82%D0%B0#Russian) | planet | planéta · noun |
| [родина](https://en.wiktionary.org/wiki/%D1%80%D0%BE%D0%B4%D0%B8%D0%BD%D0%B0#Russian) | homeland, motherland, native land | ródina · noun |
| [стекло](https://en.wiktionary.org/wiki/%D1%81%D1%82%D0%B5%D0%BA%D0%BB%D0%BE#Russian) | glass | stekló · noun |
| [существо](https://en.wiktionary.org/wiki/%D1%81%D1%83%D1%89%D0%B5%D1%81%D1%82%D0%B2%D0%BE#Russian) | creature, being | suščestvó · noun |
| [формула](https://en.wiktionary.org/wiki/%D1%84%D0%BE%D1%80%D0%BC%D1%83%D0%BB%D0%B0#Russian) | formula | fórmula · noun |
| [хвост](https://en.wiktionary.org/wiki/%D1%85%D0%B2%D0%BE%D1%81%D1%82#Russian) | tail | xvost · noun |
| [близ](https://en.wiktionary.org/wiki/%D0%B1%D0%BB%D0%B8%D0%B7#Russian) | near, in the vicinity of | bliz · prep |
| [горло](https://en.wiktionary.org/wiki/%D0%B3%D0%BE%D1%80%D0%BB%D0%BE#Russian) | throat | górlo · noun |
| [детская](https://en.wiktionary.org/wiki/%D0%B4%D0%B5%D1%82%D1%81%D0%BA%D0%B0%D1%8F#Russian) | child's room, children's room | détskaja · noun |
| [общий род](https://en.wiktionary.org/wiki/%D0%BE%D0%B1%D1%89%D0%B8%D0%B9%20%D1%80%D0%BE%D0%B4#Russian) | common gender (refers to nouns that are both masculine and feminine) | óbščij rod · noun |
| [пальто](https://en.wiktionary.org/wiki/%D0%BF%D0%B0%D0%BB%D1%8C%D1%82%D0%BE#Russian) | overcoat, greatcoat, carrick | palʹtó · noun |
| [ребёнок](https://en.wiktionary.org/wiki/%D1%80%D0%B5%D0%B1%D1%91%D0%BD%D0%BE%D0%BA#Russian) | child, kid, baby: children, kids, babies | rebjónok · noun |
| [с днём рождения](https://en.wiktionary.org/wiki/%D1%81%20%D0%B4%D0%BD%D1%91%D0%BC%20%D1%80%D0%BE%D0%B6%D0%B4%D0%B5%D0%BD%D0%B8%D1%8F#Russian) | happy birthday | s dnjom roždénija · intj |
| [федеральный](https://en.wiktionary.org/wiki/%D1%84%D0%B5%D0%B4%D0%B5%D1%80%D0%B0%D0%BB%D1%8C%D0%BD%D1%8B%D0%B9#Russian) | federal | federálʹnyj · adj |
| [декабрь](https://en.wiktionary.org/wiki/%D0%B4%D0%B5%D0%BA%D0%B0%D0%B1%D1%80%D1%8C#Russian) | December | dekábrʹ · noun |
| [зима](https://en.wiktionary.org/wiki/%D0%B7%D0%B8%D0%BC%D0%B0#Russian) | winter | zimá · noun |
| [марка](https://en.wiktionary.org/wiki/%D0%BC%D0%B0%D1%80%D0%BA%D0%B0#Russian) | stamp (small, adhesive paper document) | márka · noun |
| [ноябрь](https://en.wiktionary.org/wiki/%D0%BD%D0%BE%D1%8F%D0%B1%D1%80%D1%8C#Russian) | November | nojábrʹ · noun |
| [река](https://en.wiktionary.org/wiki/%D1%80%D0%B5%D0%BA%D0%B0#Russian) | river, stream | reká · noun |
| [учить](https://en.wiktionary.org/wiki/%D1%83%D1%87%D0%B8%D1%82%D1%8C#Russian) | to teach, to instruct (often not in an academic setting) | učítʹ · verb |
| [флот](https://en.wiktionary.org/wiki/%D1%84%D0%BB%D0%BE%D1%82#Russian) | fleet, naval fleet | flot · noun |
| [чёрный](https://en.wiktionary.org/wiki/%D1%87%D1%91%D1%80%D0%BD%D1%8B%D0%B9#Russian) | black | čórnyj · adj |
| [элемент](https://en.wiktionary.org/wiki/%D1%8D%D0%BB%D0%B5%D0%BC%D0%B5%D0%BD%D1%82#Russian) | element, component | elemént · noun |
| [голубой](https://en.wiktionary.org/wiki/%D0%B3%D0%BE%D0%BB%D1%83%D0%B1%D0%BE%D0%B9#Russian) | light blue, sky blue, azure (contrasts with си́ний (sínij, “dark blue, indigo”)) | golubój · adj |
| [почта](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D1%87%D1%82%D0%B0#Russian) | mail (U.S.), post (GB) | póčta · noun |
| [произойти](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%BE%D0%B8%D0%B7%D0%BE%D0%B9%D1%82%D0%B8#Russian) | to take place, to happen, to occur | proizojtí · verb |
| [синий](https://en.wiktionary.org/wiki/%D1%81%D0%B8%D0%BD%D0%B8%D0%B9#Russian) | deep blue | sínij · adj |
| [фу](https://en.wiktionary.org/wiki/%D1%84%D1%83#Russian) | pew!, ew!, yuck! (expresses disgust) | fu · intj |
| [академия](https://en.wiktionary.org/wiki/%D0%B0%D0%BA%D0%B0%D0%B4%D0%B5%D0%BC%D0%B8%D1%8F#Russian) | academy | akadémija · noun |
| [британский](https://en.wiktionary.org/wiki/%D0%B1%D1%80%D0%B8%D1%82%D0%B0%D0%BD%D1%81%D0%BA%D0%B8%D0%B9#Russian) | British | británskij · adj |
| [кожа](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D0%B6%D0%B0#Russian) | skin | kóža · noun |
| [му](https://en.wiktionary.org/wiki/%D0%BC%D1%83#Russian) | moo (sound a cow makes) | mu · intj |
| [палец](https://en.wiktionary.org/wiki/%D0%BF%D0%B0%D0%BB%D0%B5%D1%86#Russian) | finger or toe | pálec · noun |
| [федерация](https://en.wiktionary.org/wiki/%D1%84%D0%B5%D0%B4%D0%B5%D1%80%D0%B0%D1%86%D0%B8%D1%8F#Russian) | federation | federácija · noun |
| [длинный](https://en.wiktionary.org/wiki/%D0%B4%D0%BB%D0%B8%D0%BD%D0%BD%D1%8B%D0%B9#Russian) | long | dlínnyj · adj |
| [крутой](https://en.wiktionary.org/wiki/%D0%BA%D1%80%D1%83%D1%82%D0%BE%D0%B9#Russian) | steep | krutój · adj |
| [лесной](https://en.wiktionary.org/wiki/%D0%BB%D0%B5%D1%81%D0%BD%D0%BE%D0%B9#Russian) | forest, wood | lesnój · adj |

</details>

<details><summary>Words 751–800</summary>

![[Resources/Audio/ru/Words 0751-0800.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [некогда](https://en.wiktionary.org/wiki/%D0%BD%D0%B5%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0#Russian) | there is no time | nékogda · adj |
| [некуда](https://en.wiktionary.org/wiki/%D0%BD%D0%B5%D0%BA%D1%83%D0%B4%D0%B0#Russian) | there is nowhere | nékuda · adj |
| [нету](https://en.wiktionary.org/wiki/%D0%BD%D0%B5%D1%82%D1%83#Russian) | there is no, there are no | nétu · particle |
| [осень](https://en.wiktionary.org/wiki/%D0%BE%D1%81%D0%B5%D0%BD%D1%8C#Russian) | autumn, fall | ósenʹ · noun |
| [послушать](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D1%81%D0%BB%D1%83%D1%88%D0%B0%D1%82%D1%8C#Russian) | to listen, to listen to (someone/something) | poslúšatʹ · verb |
| [прочитать](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%BE%D1%87%D0%B8%D1%82%D0%B0%D1%82%D1%8C#Russian) | to read, to read through | pročitátʹ · verb |
| [словарь](https://en.wiktionary.org/wiki/%D1%81%D0%BB%D0%BE%D0%B2%D0%B0%D1%80%D1%8C#Russian) | dictionary, wordbook | slovárʹ · noun |
| [студент](https://en.wiktionary.org/wiki/%D1%81%D1%82%D1%83%D0%B4%D0%B5%D0%BD%D1%82#Russian) | student (in a university or college), undergraduate | studént · noun |
| [согласный](https://en.wiktionary.org/wiki/%D1%81%D0%BE%D0%B3%D0%BB%D0%B0%D1%81%D0%BD%D1%8B%D0%B9) | consonant; also agreeing in another use |  · noun |
| [быстрый](https://en.wiktionary.org/wiki/%D0%B1%D1%8B%D1%81%D1%82%D1%80%D1%8B%D0%B9#Russian) | fast, quick, speedy, rapid | býstryj · adj |
| [волк](https://en.wiktionary.org/wiki/%D0%B2%D0%BE%D0%BB%D0%BA#Russian) | wolf | volk · noun |
| [кремль](https://en.wiktionary.org/wiki/%D0%BA%D1%80%D0%B5%D0%BC%D0%BB%D1%8C#Russian) | kremlin (a central fortress in medieval Russian cities) | kremlʹ · noun |
| [кругом](https://en.wiktionary.org/wiki/%D0%BA%D1%80%D1%83%D0%B3%D0%BE%D0%BC#Russian) | around, round | krugóm · adv |
| [пояс](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D1%8F%D1%81#Russian) | belt, girdle, band, waistband, cummerbund | pójas · noun |
| [северный](https://en.wiktionary.org/wiki/%D1%81%D0%B5%D0%B2%D0%B5%D1%80%D0%BD%D1%8B%D0%B9#Russian) | north, northern | sévernyj · adj |
| [среда](https://en.wiktionary.org/wiki/%D1%81%D1%80%D0%B5%D0%B4%D0%B0#Russian) | Wednesday | sredá · noun |
| [убийца](https://en.wiktionary.org/wiki/%D1%83%D0%B1%D0%B8%D0%B9%D1%86%D0%B0#Russian) | murderer | ubíjca · noun |
| [воспитание](https://en.wiktionary.org/wiki/%D0%B2%D0%BE%D1%81%D0%BF%D0%B8%D1%82%D0%B0%D0%BD%D0%B8%D0%B5#Russian) | education, upbringing | vospitánije · noun |
| [дама](https://en.wiktionary.org/wiki/%D0%B4%D0%B0%D0%BC%D0%B0#Russian) | lady | dáma · noun |
| [интересный](https://en.wiktionary.org/wiki/%D0%B8%D0%BD%D1%82%D0%B5%D1%80%D0%B5%D1%81%D0%BD%D1%8B%D0%B9#Russian) | interesting | interésnyj · adj |
| [средний род](https://en.wiktionary.org/wiki/%D1%81%D1%80%D0%B5%D0%B4%D0%BD%D0%B8%D0%B9%20%D1%80%D0%BE%D0%B4#Russian) | neuter gender | srédnij rod · noun |
| [так называемый](https://en.wiktionary.org/wiki/%D1%82%D0%B0%D0%BA%20%D0%BD%D0%B0%D0%B7%D1%8B%D0%B2%D0%B0%D0%B5%D0%BC%D1%8B%D0%B9#Russian) | so-called (with or without any connotation) | [tak nəzɨˈva(j)ɪmɨj] · adj |
| [училище](https://en.wiktionary.org/wiki/%D1%83%D1%87%D0%B8%D0%BB%D0%B8%D1%89%D0%B5#Russian) | specialized school, college | učílišče · noun |
| [фигура](https://en.wiktionary.org/wiki/%D1%84%D0%B8%D0%B3%D1%83%D1%80%D0%B0#Russian) | figure | figúra · noun |
| [будущий](https://en.wiktionary.org/wiki/%D0%B1%D1%83%D0%B4%D1%83%D1%89%D0%B8%D0%B9#Russian) | future | búduščij · adj |
| [грех](https://en.wiktionary.org/wiki/%D0%B3%D1%80%D0%B5%D1%85#Russian) | sin | grex · noun |
| [дым](https://en.wiktionary.org/wiki/%D0%B4%D1%8B%D0%BC#Russian) | smoke | dym · noun |
| [комиссар](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D0%BC%D0%B8%D1%81%D1%81%D0%B0%D1%80#Russian) | commissioner | komissár · noun |
| [ноль](https://en.wiktionary.org/wiki/%D0%BD%D0%BE%D0%BB%D1%8C#Russian) | zero (0) | nolʹ · noun |
| [обувь](https://en.wiktionary.org/wiki/%D0%BE%D0%B1%D1%83%D0%B2%D1%8C#Russian) | footwear, shoes | óbuvʹ · noun |
| [округ](https://en.wiktionary.org/wiki/%D0%BE%D0%BA%D1%80%D1%83%D0%B3#Russian) | district | ókrug · noun |
| [плата](https://en.wiktionary.org/wiki/%D0%BF%D0%BB%D0%B0%D1%82%D0%B0#Russian) | fee, pay, salary, wages, fare, rent | pláta · noun |
| [сухой](https://en.wiktionary.org/wiki/%D1%81%D1%83%D1%85%D0%BE%D0%B9#Russian) | dry | suxój · adj |
| [шт.](https://en.wiktionary.org/wiki/%D1%88%D1%82.#Russian) | state | št. · noun |
| [лука](https://en.wiktionary.org/wiki/%D0%BB%D1%83%D0%BA%D0%B0#Russian) | bend (in a river or road) | luká · noun |
| [медведь](https://en.wiktionary.org/wiki/%D0%BC%D0%B5%D0%B4%D0%B2%D0%B5%D0%B4%D1%8C#Russian) | bear | medvédʹ · noun |
| [посреди](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D1%81%D1%80%D0%B5%D0%B4%D0%B8#Russian) | in the middle of, in the midst of | posredí · prep |
| [происхождение](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%BE%D0%B8%D1%81%D1%85%D0%BE%D0%B6%D0%B4%D0%B5%D0%BD%D0%B8%D0%B5#Russian) | origin | proisxoždénije · noun |
| [гора](https://en.wiktionary.org/wiki/%D0%B3%D0%BE%D1%80%D0%B0#Russian) | mountain | gorá · noun |
| [двенадцать](https://en.wiktionary.org/wiki/%D0%B4%D0%B2%D0%B5%D0%BD%D0%B0%D0%B4%D1%86%D0%B0%D1%82%D1%8C#Russian) | twelve (12) | dvenádcatʹ · num |
| [курить](https://en.wiktionary.org/wiki/%D0%BA%D1%83%D1%80%D0%B8%D1%82%D1%8C#Russian) | to smoke (tobacco etc.) | kurítʹ · verb |
| [самолёт](https://en.wiktionary.org/wiki/%D1%81%D0%B0%D0%BC%D0%BE%D0%BB%D1%91%D1%82#Russian) | airplane, aircraft | samoljót · noun |
| [страница](https://en.wiktionary.org/wiki/%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0#Russian) | page | straníca · noun |
| [через мой труп](https://en.wiktionary.org/wiki/%D1%87%D0%B5%D1%80%D0%B5%D0%B7%20%D0%BC%D0%BE%D0%B9%20%D1%82%D1%80%D1%83%D0%BF#Russian) | over my dead body | čérez moj trup · phrase |
| [открывать](https://en.wiktionary.org/wiki/%D0%BE%D1%82%D0%BA%D1%80%D1%8B%D0%B2%D0%B0%D1%82%D1%8C#Russian) | to open | otkryvátʹ · verb |
| [па](https://en.wiktionary.org/wiki/%D0%BF%D0%B0#Russian) | pas, step | pa · noun |
| [приходить](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%B8%D1%85%D0%BE%D0%B4%D0%B8%D1%82%D1%8C#Russian) | to come (to), to arrive (at) (place, conclusion, state of abandonment, anger, insanity) | prixodítʹ · verb |
| [стена](https://en.wiktionary.org/wiki/%D1%81%D1%82%D0%B5%D0%BD%D0%B0#Russian) | wall | stená · noun |
| [туалет](https://en.wiktionary.org/wiki/%D1%82%D1%83%D0%B0%D0%BB%D0%B5%D1%82#Russian) | toilet, WC, restroom, lavatory | tualét · noun |
| [ухо](https://en.wiktionary.org/wiki/%D1%83%D1%85%D0%BE#Russian) | ear | úxo · noun |

</details>

<details><summary>Words 801–850</summary>

![[Resources/Audio/ru/Words 0801-0850.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [где туалет](https://en.wiktionary.org/wiki/%D0%B3%D0%B4%D0%B5%20%D1%82%D1%83%D0%B0%D0%BB%D0%B5%D1%82#Russian) | where is the toilet? | gde tualét? · phrase |
| [космический](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D1%81%D0%BC%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B8%D0%B9#Russian) | space, cosmos; cosmic | kosmíčeskij · adj |
| [ля](https://en.wiktionary.org/wiki/%D0%BB%D1%8F#Russian) | look (interjection to attract attention) | lja · intj |
| [склад](https://en.wiktionary.org/wiki/%D1%81%D0%BA%D0%BB%D0%B0%D0%B4#Russian) | supply, stock | sklad · noun |
| [царство](https://en.wiktionary.org/wiki/%D1%86%D0%B0%D1%80%D1%81%D1%82%D0%B2%D0%BE#Russian) | empire, kingdom; tsardom | cárstvo · noun |
| [виски](https://en.wiktionary.org/wiki/%D0%B2%D0%B8%D1%81%D0%BA%D0%B8#Russian) | whiskey/whisky | víski · noun |
| [гость](https://en.wiktionary.org/wiki/%D0%B3%D0%BE%D1%81%D1%82%D1%8C#Russian) | guest, visitor | gostʹ · noun |
| [июнь](https://en.wiktionary.org/wiki/%D0%B8%D1%8E%D0%BD%D1%8C#Russian) | June | ijúnʹ · noun |
| [кит](https://en.wiktionary.org/wiki/%D0%BA%D0%B8%D1%82#Russian) | whale | kit · noun |
| [плечо](https://en.wiktionary.org/wiki/%D0%BF%D0%BB%D0%B5%D1%87%D0%BE#Russian) | shoulder | plečó · noun |
| [почувствовать](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D1%87%D1%83%D0%B2%D1%81%D1%82%D0%B2%D0%BE%D0%B2%D0%B0%D1%82%D1%8C#Russian) | to feel (something) | počúvstvovatʹ · verb |
| [седьмой](https://en.wiktionary.org/wiki/%D1%81%D0%B5%D0%B4%D1%8C%D0%BC%D0%BE%D0%B9#Russian) | seventh | sedʹmój · adj |
| [спутник](https://en.wiktionary.org/wiki/%D1%81%D0%BF%D1%83%D1%82%D0%BD%D0%B8%D0%BA#Russian) | a fellow traveller; companion | spútnik · noun |
| [сыр](https://en.wiktionary.org/wiki/%D1%81%D1%8B%D1%80#Russian) | cheese | syr · noun |
| [цветок](https://en.wiktionary.org/wiki/%D1%86%D0%B2%D0%B5%D1%82%D0%BE%D0%BA#Russian) | flower (plant that bears flowers) | cvetók · noun |
| [авария](https://en.wiktionary.org/wiki/%D0%B0%D0%B2%D0%B0%D1%80%D0%B8%D1%8F#Russian) | damage, breakdown, fault, failure, crash (rarely) | avárija · noun |
| [больница](https://en.wiktionary.org/wiki/%D0%B1%D0%BE%D0%BB%D1%8C%D0%BD%D0%B8%D1%86%D0%B0#Russian) | hospital | bolʹníca · noun |
| [дедушка](https://en.wiktionary.org/wiki/%D0%B4%D0%B5%D0%B4%D1%83%D1%88%D0%BA%D0%B0#Russian) | grandfather | déduška · noun |
| [зелёный](https://en.wiktionary.org/wiki/%D0%B7%D0%B5%D0%BB%D1%91%D0%BD%D1%8B%D0%B9#Russian) | green | zeljónyj · adj |
| [июль](https://en.wiktionary.org/wiki/%D0%B8%D1%8E%D0%BB%D1%8C#Russian) | July | ijúlʹ · noun |
| [кухня](https://en.wiktionary.org/wiki/%D0%BA%D1%83%D1%85%D0%BD%D1%8F#Russian) | kitchen | kúxnja · noun |
| [мороз](https://en.wiktionary.org/wiki/%D0%BC%D0%BE%D1%80%D0%BE%D0%B7#Russian) | freezing weather, frost | moróz · noun |
| [постель](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D1%81%D1%82%D0%B5%D0%BB%D1%8C#Russian) | bed (a piece of furniture to sleep on) | postélʹ · noun |
| [сосед](https://en.wiktionary.org/wiki/%D1%81%D0%BE%D1%81%D0%B5%D0%B4#Russian) | neighbour | soséd · noun |
| [теория великого объединения](https://en.wiktionary.org/wiki/%D1%82%D0%B5%D0%BE%D1%80%D0%B8%D1%8F%20%D0%B2%D0%B5%D0%BB%D0%B8%D0%BA%D0%BE%D0%B3%D0%BE%20%D0%BE%D0%B1%D1%8A%D0%B5%D0%B4%D0%B8%D0%BD%D0%B5%D0%BD%D0%B8%D1%8F#Russian) | grand unification theory | teórija velíkovo obʺjedinénija · noun |
| [улыбка](https://en.wiktionary.org/wiki/%D1%83%D0%BB%D1%8B%D0%B1%D0%BA%D0%B0#Russian) | smile | ulýbka · noun |
| [баба](https://en.wiktionary.org/wiki/%D0%B1%D0%B0%D0%B1%D0%B0#Russian) | grandma, granny (short for ба́бушка (bábuška)) | bába · noun |
| [богатый](https://en.wiktionary.org/wiki/%D0%B1%D0%BE%D0%B3%D0%B0%D1%82%D1%8B%D0%B9#Russian) | rich, wealthy | bogátyj · adj |
| [дан](https://en.wiktionary.org/wiki/%D0%B4%D0%B0%D0%BD#Russian) | dan | dan · noun |
| [мужской род](https://en.wiktionary.org/wiki/%D0%BC%D1%83%D0%B6%D1%81%D0%BA%D0%BE%D0%B9%20%D1%80%D0%BE%D0%B4#Russian) | masculine gender | mužskój rod · noun |
| [боец](https://en.wiktionary.org/wiki/%D0%B1%D0%BE%D0%B5%D1%86#Russian) | warrior | bojéc · noun |
| [вокзал](https://en.wiktionary.org/wiki/%D0%B2%D0%BE%D0%BA%D0%B7%D0%B0%D0%BB#Russian) | station, terminal (with a building for passenger facilities) | vokzál · noun |
| [га-га-га](https://en.wiktionary.org/wiki/%D0%B3%D0%B0-%D0%B3%D0%B0-%D0%B3%D0%B0#Russian) | honk (sound a goose makes) | ga-ga-gá · intj |
| [лук](https://en.wiktionary.org/wiki/%D0%BB%D1%83%D0%BA#Russian) | onion, onions | luk · noun |
| [скучать](https://en.wiktionary.org/wiki/%D1%81%D0%BA%D1%83%D1%87%D0%B0%D1%82%D1%8C#Russian) | to be bored | skučátʹ · verb |
| [блюдо](https://en.wiktionary.org/wiki/%D0%B1%D0%BB%D1%8E%D0%B4%D0%BE#Russian) | dish, plate | bljúdo · noun |
| [ом](https://en.wiktionary.org/wiki/%D0%BE%D0%BC#Russian) | ohm (Ω) | om · noun |
| [поэзия](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D1%8D%D0%B7%D0%B8%D1%8F#Russian) | poetry | poézija · noun |
| [свидание](https://en.wiktionary.org/wiki/%D1%81%D0%B2%D0%B8%D0%B4%D0%B0%D0%BD%D0%B8%D0%B5#Russian) | appointment; date | svidánije · noun |
| [серый](https://en.wiktionary.org/wiki/%D1%81%D0%B5%D1%80%D1%8B%D0%B9#Russian) | grey, gray | séryj · adj |
| [гений](https://en.wiktionary.org/wiki/%D0%B3%D0%B5%D0%BD%D0%B8%D0%B9#Russian) | a genius (someone possessing extraordinary mental capacity) | génij · noun |
| [дура](https://en.wiktionary.org/wiki/%D0%B4%D1%83%D1%80%D0%B0#Russian) | imbecile, fool, simpleton, idiot (stupid woman with poor judgment) | dúra · noun |
| [знамя](https://en.wiktionary.org/wiki/%D0%B7%D0%BD%D0%B0%D0%BC%D1%8F#Russian) | standard, banner, flag, colors, ensign | známja · noun |
| [кошка](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D1%88%D0%BA%D0%B0#Russian) | cat | kóška · noun |
| [по-русски](https://en.wiktionary.org/wiki/%D0%BF%D0%BE-%D1%80%D1%83%D1%81%D1%81%D0%BA%D0%B8#Russian) | in Russian | po-rússki · adv |
| [поздравляю с днём рождения](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%B7%D0%B4%D1%80%D0%B0%D0%B2%D0%BB%D1%8F%D1%8E%20%D1%81%20%D0%B4%D0%BD%D1%91%D0%BC%20%D1%80%D0%BE%D0%B6%D0%B4%D0%B5%D0%BD%D0%B8%D1%8F#Russian) | happy birthday | pozdravljáju s dnjom roždénija · intj |
| [сравнение](https://en.wiktionary.org/wiki/%D1%81%D1%80%D0%B0%D0%B2%D0%BD%D0%B5%D0%BD%D0%B8%D0%B5#Russian) | comparison | sravnénije · noun |
| [тысяча](https://en.wiktionary.org/wiki/%D1%82%D1%8B%D1%81%D1%8F%D1%87%D0%B0#Russian) | thousand (1000) | týsjača · num |
| [бомба](https://en.wiktionary.org/wiki/%D0%B1%D0%BE%D0%BC%D0%B1%D0%B0#Russian) | bomb | bómba · noun |
| [гнев](https://en.wiktionary.org/wiki/%D0%B3%D0%BD%D0%B5%D0%B2#Russian) | anger; wrath | gnev · noun |

</details>

<details><summary>Words 851–900</summary>

![[Resources/Audio/ru/Words 0851-0900.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [до свидания](https://en.wiktionary.org/wiki/%D0%B4%D0%BE%20%D1%81%D0%B2%D0%B8%D0%B4%D0%B0%D0%BD%D0%B8%D1%8F#Russian) | goodbye, see you later | do svidánija · intj |
| [каникулы](https://en.wiktionary.org/wiki/%D0%BA%D0%B0%D0%BD%D0%B8%D0%BA%D1%83%D0%BB%D1%8B#Russian) | vacation (U.S.), holiday (UK) | kaníkuly · noun |
| [на славу](https://en.wiktionary.org/wiki/%D0%BD%D0%B0%20%D1%81%D0%BB%D0%B0%D0%B2%D1%83#Russian) | A-1, first rate, excellent | na slávu · adj |
| [пятнадцать](https://en.wiktionary.org/wiki/%D0%BF%D1%8F%D1%82%D0%BD%D0%B0%D0%B4%D1%86%D0%B0%D1%82%D1%8C#Russian) | fifteen (15) | pjatnádcatʹ · num |
| [религия](https://en.wiktionary.org/wiki/%D1%80%D0%B5%D0%BB%D0%B8%D0%B3%D0%B8%D1%8F#Russian) | religion | relígija · noun |
| [тихий](https://en.wiktionary.org/wiki/%D1%82%D0%B8%D1%85%D0%B8%D0%B9#Russian) | quiet, still | tíxij · adj |
| [тон](https://en.wiktionary.org/wiki/%D1%82%D0%BE%D0%BD#Russian) | tone, plural: то́ны (tóny) | ton · noun |
| [штраф](https://en.wiktionary.org/wiki/%D1%88%D1%82%D1%80%D0%B0%D1%84#Russian) | fine, penalty, citation | štraf · noun |
| [бумага](https://en.wiktionary.org/wiki/%D0%B1%D1%83%D0%BC%D0%B0%D0%B3%D0%B0#Russian) | paper | bumága · noun |
| [добро пожаловать](https://en.wiktionary.org/wiki/%D0%B4%D0%BE%D0%B1%D1%80%D0%BE%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D0%BE%D0%B2%D0%B0%D1%82%D1%8C#Russian) | welcome! | dobró požálovatʹ! · intj |
| [испанский](https://en.wiktionary.org/wiki/%D0%B8%D1%81%D0%BF%D0%B0%D0%BD%D1%81%D0%BA%D0%B8%D0%B9#Russian) | Spanish | ispánskij · adj |
| [конь](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D0%BD%D1%8C#Russian) | horse; male horse | konʹ · noun |
| [левый](https://en.wiktionary.org/wiki/%D0%BB%D0%B5%D0%B2%D1%8B%D0%B9#Russian) | left, left-hand | lévyj · adj |
| [лоб](https://en.wiktionary.org/wiki/%D0%BB%D0%BE%D0%B1#Russian) | forehead | lob · noun |
| [нога](https://en.wiktionary.org/wiki/%D0%BD%D0%BE%D0%B3%D0%B0#Russian) | leg | nogá · noun |
| [переводчик](https://en.wiktionary.org/wiki/%D0%BF%D0%B5%D1%80%D0%B5%D0%B2%D0%BE%D0%B4%D1%87%D0%B8%D0%BA#Russian) | translator | perevódčik · noun |
| [слабый](https://en.wiktionary.org/wiki/%D1%81%D0%BB%D0%B0%D0%B1%D1%8B%D0%B9#Russian) | weak, feeble | slábyj · adj |
| [электронный](https://en.wiktionary.org/wiki/%D1%8D%D0%BB%D0%B5%D0%BA%D1%82%D1%80%D0%BE%D0%BD%D0%BD%D1%8B%D0%B9#Russian) | electron, electronic | elektrónnyj · adj |
| [минута](https://en.wiktionary.org/wiki/%D0%BC%D0%B8%D0%BD%D1%83%D1%82%D0%B0#Russian) | minute | minúta · noun |
| [пламя](https://en.wiktionary.org/wiki/%D0%BF%D0%BB%D0%B0%D0%BC%D1%8F#Russian) | flame | plámja · noun |
| [подросток](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%B4%D1%80%D0%BE%D1%81%D1%82%D0%BE%D0%BA#Russian) | teenager, juvenile, youth, adolescent | podróstok · noun |
| [учение](https://en.wiktionary.org/wiki/%D1%83%D1%87%D0%B5%D0%BD%D0%B8%D0%B5#Russian) | learning, instruction, training, drill, exercising | učénije · noun |
| [Вселенная](https://en.wiktionary.org/wiki/%D0%92%D1%81%D0%B5%D0%BB%D0%B5%D0%BD%D0%BD%D0%B0%D1%8F#Russian) | the Universe (the specific universe in which we all live) | Vselénnaja · noun |
| [вселенная](https://en.wiktionary.org/wiki/%D0%B2%D1%81%D0%B5%D0%BB%D0%B5%D0%BD%D0%BD%D0%B0%D1%8F#Russian) | universe, the world | vselénnaja · noun |
| [двести](https://en.wiktionary.org/wiki/%D0%B4%D0%B2%D0%B5%D1%81%D1%82%D0%B8#Russian) | two hundred (200) | dvésti · num |
| [женский род](https://en.wiktionary.org/wiki/%D0%B6%D0%B5%D0%BD%D1%81%D0%BA%D0%B8%D0%B9%20%D1%80%D0%BE%D0%B4#Russian) | feminine gender | žénskij rod · noun |
| [космический корабль](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D1%81%D0%BC%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B8%D0%B9%20%D0%BA%D0%BE%D1%80%D0%B0%D0%B1%D0%BB%D1%8C#Russian) | spacecraft, spaceship, space vehicle | kosmíčeskij koráblʹ · noun |
| [крыша](https://en.wiktionary.org/wiki/%D0%BA%D1%80%D1%8B%D1%88%D0%B0#Russian) | roof | krýša · noun |
| [отчего](https://en.wiktionary.org/wiki/%D0%BE%D1%82%D1%87%D0%B5%D0%B3%D0%BE#Russian) | why? (from what cause) | otčevó · adv |
| [призрак](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%B8%D0%B7%D1%80%D0%B0%D0%BA#Russian) | ghost, spectre | prízrak · noun |
| [приём](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%B8%D1%91%D0%BC#Russian) | reception | prijóm · noun |
| [энциклопедия](https://en.wiktionary.org/wiki/%D1%8D%D0%BD%D1%86%D0%B8%D0%BA%D0%BB%D0%BE%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F#Russian) | encyclopaedia/encyclopedia | enciklopédija · noun |
| [американец](https://en.wiktionary.org/wiki/%D0%B0%D0%BC%D0%B5%D1%80%D0%B8%D0%BA%D0%B0%D0%BD%D0%B5%D1%86#Russian) | male American (citizen, resident) | amerikánec · noun |
| [ведение](https://en.wiktionary.org/wiki/%D0%B2%D0%B5%D0%B4%D0%B5%D0%BD%D0%B8%D0%B5#Russian) | knowledge, lore | védenije · noun |
| [нравиться](https://en.wiktionary.org/wiki/%D0%BD%D1%80%D0%B0%D0%B2%D0%B8%D1%82%D1%8C%D1%81%D1%8F#Russian) | to please [with dative ‘someone’] (idiomatically translated with English like with the dative object as the subject) | nrávitʹsja · verb |
| [происходить](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%BE%D0%B8%D1%81%D1%85%D0%BE%D0%B4%D0%B8%D1%82%D1%8C#Russian) | to take place, to happen, to occur | proisxodítʹ · verb |
| [сомнение](https://en.wiktionary.org/wiki/%D1%81%D0%BE%D0%BC%D0%BD%D0%B5%D0%BD%D0%B8%D0%B5#Russian) | doubt | somnénije · noun |
| [туман](https://en.wiktionary.org/wiki/%D1%82%D1%83%D0%BC%D0%B0%D0%BD#Russian) | fog | tumán · noun |
| [яблоко](https://en.wiktionary.org/wiki/%D1%8F%D0%B1%D0%BB%D0%BE%D0%BA%D0%BE#Russian) | apple | jábloko · noun |
| [яйцо](https://en.wiktionary.org/wiki/%D1%8F%D0%B9%D1%86%D0%BE#Russian) | egg | jajcó · noun |
| [авторитет](https://en.wiktionary.org/wiki/%D0%B0%D0%B2%D1%82%D0%BE%D1%80%D0%B8%D1%82%D0%B5%D1%82#Russian) | authority, prestige | avtoritét · noun |
| [вагон](https://en.wiktionary.org/wiki/%D0%B2%D0%B0%D0%B3%D0%BE%D0%BD#Russian) | railway car, coach, railway carriage | vagón · noun |
| [сек](https://en.wiktionary.org/wiki/%D1%81%D0%B5%D0%BA#Russian) | sec, second | sek · noun |
| [синдром](https://en.wiktionary.org/wiki/%D1%81%D0%B8%D0%BD%D0%B4%D1%80%D0%BE%D0%BC#Russian) | syndrome (complex of symptoms) | sindróm · noun |
| [хор](https://en.wiktionary.org/wiki/%D1%85%D0%BE%D1%80#Russian) | chorus, choir | xor · noun |
| [бок](https://en.wiktionary.org/wiki/%D0%B1%D0%BE%D0%BA#Russian) | side (various senses) | bok · noun |
| [дракон](https://en.wiktionary.org/wiki/%D0%B4%D1%80%D0%B0%D0%BA%D0%BE%D0%BD#Russian) | dragon (mythical creature) | drakón · noun |
| [и т.п.](https://en.wiktionary.org/wiki/%D0%B8%20%D1%82.%D0%BF.#Russian) | etc., and so forth, and so on | [i tɛ ˈpɛ] · adv |
| [мг](https://en.wiktionary.org/wiki/%D0%BC%D0%B3#Russian) | mg, milligram | mg · noun |
| [блог](https://en.wiktionary.org/wiki/%D0%B1%D0%BB%D0%BE%D0%B3#Russian) | blog | blog · noun |

</details>

<details><summary>Words 901–950</summary>

![[Resources/Audio/ru/Words 0901-0950.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [марс](https://en.wiktionary.org/wiki/%D0%BC%D0%B0%D1%80%D1%81#Russian) | top (on sailing vessels, a platform around the head of a lower mast) | mars · noun |
| [находить](https://en.wiktionary.org/wiki/%D0%BD%D0%B0%D1%85%D0%BE%D0%B4%D0%B8%D1%82%D1%8C#Russian) | to find | naxodítʹ · verb |
| [см/сек](https://en.wiktionary.org/wiki/%D1%81%D0%BC/%D1%81%D0%B5%D0%BA#Russian) | cm/s, centimeters per second | sm/sek · noun |
| [текущего года](https://en.wiktionary.org/wiki/%D1%82%D0%B5%D0%BA%D1%83%D1%89%D0%B5%D0%B3%D0%BE%20%D0%B3%D0%BE%D0%B4%D0%B0#Russian) | of the current year | tekúščevo góda · adv |
| [теннис](https://en.wiktionary.org/wiki/%D1%82%D0%B5%D0%BD%D0%BD%D0%B8%D1%81#Russian) | tennis | tɛ́nnis · noun |
| [шлюха](https://en.wiktionary.org/wiki/%D1%88%D0%BB%D1%8E%D1%85%D0%B0#Russian) | slut, whore, trollop, strumpet, streetwalker | šljúxa · noun |
| [ядро](https://en.wiktionary.org/wiki/%D1%8F%D0%B4%D1%80%D0%BE#Russian) | seed, stone (of a fruit) | jadró · noun |
| [град](https://en.wiktionary.org/wiki/%D0%B3%D1%80%D0%B0%D0%B4#Russian) | hail | grad · noun |
| [девочка-подросток](https://en.wiktionary.org/wiki/%D0%B4%D0%B5%D0%B2%D0%BE%D1%87%D0%BA%D0%B0-%D0%BF%D0%BE%D0%B4%D1%80%D0%BE%D1%81%D1%82%D0%BE%D0%BA#Russian) | girl, teenage girl (at the age of puberty) | dévočka-podróstok · noun |
| [империя](https://en.wiktionary.org/wiki/%D0%B8%D0%BC%D0%BF%D0%B5%D1%80%D0%B8%D1%8F#Russian) | empire | impérija · noun |
| [коридор](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D1%80%D0%B8%D0%B4%D0%BE%D1%80#Russian) | corridor, hallway | koridór · noun |
| [мат](https://en.wiktionary.org/wiki/%D0%BC%D0%B0%D1%82#Russian) | checkmate, mate (Russian notation: ×) | mat · noun |
| [оружие массового поражения](https://en.wiktionary.org/wiki/%D0%BE%D1%80%D1%83%D0%B6%D0%B8%D0%B5%20%D0%BC%D0%B0%D1%81%D1%81%D0%BE%D0%B2%D0%BE%D0%B3%D0%BE%20%D0%BF%D0%BE%D1%80%D0%B0%D0%B6%D0%B5%D0%BD%D0%B8%D1%8F#Russian) | weapon(s) of mass destruction | orúžije mássovovo poražénija · noun |
| [приятный](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%B8%D1%8F%D1%82%D0%BD%D1%8B%D0%B9#Russian) | pleasant, pleasing, agreeable | prijátnyj · adj |
| [часовой](https://en.wiktionary.org/wiki/%D1%87%D0%B0%D1%81%D0%BE%D0%B2%D0%BE%D0%B9#Russian) | hour | časovój · adj |
| [человеческий](https://en.wiktionary.org/wiki/%D1%87%D0%B5%D0%BB%D0%BE%D0%B2%D0%B5%D1%87%D0%B5%D1%81%D0%BA%D0%B8%D0%B9#Russian) | human | čelovéčeskij · adj |
| [авиация](https://en.wiktionary.org/wiki/%D0%B0%D0%B2%D0%B8%D0%B0%D1%86%D0%B8%D1%8F#Russian) | aviation | aviácija · noun |
| [место жительства](https://en.wiktionary.org/wiki/%D0%BC%D0%B5%D1%81%D1%82%D0%BE%20%D0%B6%D0%B8%D1%82%D0%B5%D0%BB%D1%8C%D1%81%D1%82%D0%B2%D0%B0#Russian) | residence | mésto žítelʹstva · noun |
| [напиток](https://en.wiktionary.org/wiki/%D0%BD%D0%B0%D0%BF%D0%B8%D1%82%D0%BE%D0%BA#Russian) | drink (verbal noun of пить (pitʹ) (nomen obiecti)) | napítok · noun |
| [печь](https://en.wiktionary.org/wiki/%D0%BF%D0%B5%D1%87%D1%8C#Russian) | to bake | pečʹ · verb |
| [духи](https://en.wiktionary.org/wiki/%D0%B4%D1%83%D1%85%D0%B8#Russian) | perfume | duxí · noun |
| [корпорация](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D1%80%D0%BF%D0%BE%D1%80%D0%B0%D1%86%D0%B8%D1%8F#Russian) | corporation, company | korporácija · noun |
| [кость](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D1%81%D1%82%D1%8C#Russian) | bone | kostʹ · noun |
| [крыло](https://en.wiktionary.org/wiki/%D0%BA%D1%80%D1%8B%D0%BB%D0%BE#Russian) | wing | kryló · noun |
| [одиннадцать](https://en.wiktionary.org/wiki/%D0%BE%D0%B4%D0%B8%D0%BD%D0%BD%D0%B0%D0%B4%D1%86%D0%B0%D1%82%D1%8C#Russian) | eleven (11) | odínnadcatʹ · num |
| [прочесть](https://en.wiktionary.org/wiki/%D0%BF%D1%80%D0%BE%D1%87%D0%B5%D1%81%D1%82%D1%8C#Russian) | to finish reading, to read through | pročéstʹ · verb |
| [яд](https://en.wiktionary.org/wiki/%D1%8F%D0%B4#Russian) | poison, venom | jad · noun |
| [алло](https://en.wiktionary.org/wiki/%D0%B0%D0%BB%D0%BB%D0%BE#Russian) | hello! | alló · intj |
| [брюки](https://en.wiktionary.org/wiki/%D0%B1%D1%80%D1%8E%D0%BA%D0%B8#Russian) | pants, trousers | brjúki · noun |
| [доска](https://en.wiktionary.org/wiki/%D0%B4%D0%BE%D1%81%D0%BA%D0%B0#Russian) | board, plank | doská · noun |
| [ислам](https://en.wiktionary.org/wiki/%D0%B8%D1%81%D0%BB%D0%B0%D0%BC#Russian) | Islam | islám · noun |
| [кон](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D0%BD#Russian) | gambling bank, kitty | kon · noun |
| [пас](https://en.wiktionary.org/wiki/%D0%BF%D0%B0%D1%81#Russian) | set | pas · noun |
| [роды](https://en.wiktionary.org/wiki/%D1%80%D0%BE%D0%B4%D1%8B#Russian) | delivery, childbirth | ródy · noun |
| [сталь](https://en.wiktionary.org/wiki/%D1%81%D1%82%D0%B0%D0%BB%D1%8C#Russian) | steel | stalʹ · noun |
| [воз](https://en.wiktionary.org/wiki/%D0%B2%D0%BE%D0%B7#Russian) | cart | voz · noun |
| [мышь](https://en.wiktionary.org/wiki/%D0%BC%D1%8B%D1%88%D1%8C#Russian) | mouse (animal) | myšʹ · noun |
| [плод](https://en.wiktionary.org/wiki/%D0%BF%D0%BB%D0%BE%D0%B4#Russian) | fruit (also figurative) | plod · noun |
| [пятница](https://en.wiktionary.org/wiki/%D0%BF%D1%8F%D1%82%D0%BD%D0%B8%D1%86%D0%B0#Russian) | Friday | pjátnica · noun |
| [расскажи это кому-нибудь другому](https://en.wiktionary.org/wiki/%D1%80%D0%B0%D1%81%D1%81%D0%BA%D0%B0%D0%B6%D0%B8%20%D1%8D%D1%82%D0%BE%20%D0%BA%D0%BE%D0%BC%D1%83-%D0%BD%D0%B8%D0%B1%D1%83%D0%B4%D1%8C%20%D0%B4%D1%80%D1%83%D0%B3%D0%BE%D0%BC%D1%83#Russian) | tell it to Sweeney; tell it to the marines | rasskaží éto komú-nibudʹ drugómu · phrase |
| [трава](https://en.wiktionary.org/wiki/%D1%82%D1%80%D0%B0%D0%B2%D0%B0#Russian) | grass | travá · noun |
| [врать](https://en.wiktionary.org/wiki/%D0%B2%D1%80%D0%B0%D1%82%D1%8C#Russian) | to lie | vratʹ · verb |
| [королевство](https://en.wiktionary.org/wiki/%D0%BA%D0%BE%D1%80%D0%BE%D0%BB%D0%B5%D0%B2%D1%81%D1%82%D0%B2%D0%BE#Russian) | kingdom | korolévstvo · noun |
| [хаос](https://en.wiktionary.org/wiki/%D1%85%D0%B0%D0%BE%D1%81#Russian) | chaos | xáos · noun |
| [цифра](https://en.wiktionary.org/wiki/%D1%86%D0%B8%D1%84%D1%80%D0%B0#Russian) | figure, digit, cipher, numeral (a symbol representing a number) | cífra · noun |
| [чёрт](https://en.wiktionary.org/wiki/%D1%87%D1%91%D1%80%D1%82#Russian) | devil, demon | čort · noun |
| [карман](https://en.wiktionary.org/wiki/%D0%BA%D0%B0%D1%80%D0%BC%D0%B0%D0%BD#Russian) | pocket | karmán · noun |
| [морская звезда](https://en.wiktionary.org/wiki/%D0%BC%D0%BE%D1%80%D1%81%D0%BA%D0%B0%D1%8F%20%D0%B7%D0%B2%D0%B5%D0%B7%D0%B4%D0%B0#Russian) | starfish | morskája zvezdá · noun |
| [мур](https://en.wiktionary.org/wiki/%D0%BC%D1%83%D1%80#Russian) | purr (sound a contented cat makes) | mur · intj |
| [пл.](https://en.wiktionary.org/wiki/%D0%BF%D0%BB.#Russian) | square, plaza | [ˈpɫoɕːɪtʲ] · noun |

</details>

<details><summary>Words 951–1000</summary>

![[Resources/Audio/ru/Words 0951-1000.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [фу-фу](https://en.wiktionary.org/wiki/%D1%84%D1%83-%D1%84%D1%83#Russian) | pew!, P U!, pee-you! (it stinks!) | fu-fú! · intj |
| [велосипед](https://en.wiktionary.org/wiki/%D0%B2%D0%B5%D0%BB%D0%BE%D1%81%D0%B8%D0%BF%D0%B5%D0%B4#Russian) | bicycle, bike | velosipéd · noun |
| [дева](https://en.wiktionary.org/wiki/%D0%B4%D0%B5%D0%B2%D0%B0#Russian) | maiden, maid, virgin | déva · noun |
| [еврей](https://en.wiktionary.org/wiki/%D0%B5%D0%B2%D1%80%D0%B5%D0%B9#Russian) | Jew, Hebrew | jevréj · noun |
| [железо](https://en.wiktionary.org/wiki/%D0%B6%D0%B5%D0%BB%D0%B5%D0%B7%D0%BE#Russian) | iron | želézo · noun |
| [забор](https://en.wiktionary.org/wiki/%D0%B7%D0%B0%D0%B1%D0%BE%D1%80#Russian) | fence | zabór · noun |
| [зуб](https://en.wiktionary.org/wiki/%D0%B7%D1%83%D0%B1#Russian) | tooth | zub · noun |
| [острый](https://en.wiktionary.org/wiki/%D0%BE%D1%81%D1%82%D1%80%D1%8B%D0%B9#Russian) | sharp, pointed | óstryj · adj |
| [ср.](https://en.wiktionary.org/wiki/%D1%81%D1%80.#Russian) | compare, cf. | sr. · verb |
| [стих](https://en.wiktionary.org/wiki/%D1%81%D1%82%D0%B8%D1%85#Russian) | line of poetry | stix · noun |
| [шоколад](https://en.wiktionary.org/wiki/%D1%88%D0%BE%D0%BA%D0%BE%D0%BB%D0%B0%D0%B4#Russian) | chocolate | šokolád · noun |
| [административный](https://en.wiktionary.org/wiki/%D0%B0%D0%B4%D0%BC%D0%B8%D0%BD%D0%B8%D1%81%D1%82%D1%80%D0%B0%D1%82%D0%B8%D0%B2%D0%BD%D1%8B%D0%B9#Russian) | administrative | administratívnyj · adj |
| [бал](https://en.wiktionary.org/wiki/%D0%B1%D0%B0%D0%BB#Russian) | ball, dance | bal · noun |
| [будь здоров](https://en.wiktionary.org/wiki/%D0%B1%D1%83%D0%B4%D1%8C%20%D0%B7%D0%B4%D0%BE%D1%80%D0%BE%D0%B2#Russian) | bless you, (US) gesundheit | budʹ zdoróv · intj |
| [лететь](https://en.wiktionary.org/wiki/%D0%BB%D0%B5%D1%82%D0%B5%D1%82%D1%8C#Russian) | to fly, to be flying | letétʹ · verb |
| [ре](https://en.wiktionary.org/wiki/%D1%80%D0%B5#Russian) | D (musical note) | rɛ · noun |
| [стрелка](https://en.wiktionary.org/wiki/%D1%81%D1%82%D1%80%D0%B5%D0%BB%D0%BA%D0%B0#Russian) | hand (on a clock or watch) | strélka · noun |
| [ткань](https://en.wiktionary.org/wiki/%D1%82%D0%BA%D0%B0%D0%BD%D1%8C#Russian) | fabric, cloth | tkanʹ · noun |
| [Кр](https://en.wiktionary.org/wiki/%D0%9A%D1%80#Russian) | K (king) | Kr · noun |
| [архитектура](https://en.wiktionary.org/wiki/%D0%B0%D1%80%D1%85%D0%B8%D1%82%D0%B5%D0%BA%D1%82%D1%83%D1%80%D0%B0#Russian) | architecture | arxitektúra · noun |
| [биология](https://en.wiktionary.org/wiki/%D0%B1%D0%B8%D0%BE%D0%BB%D0%BE%D0%B3%D0%B8%D1%8F#Russian) | biology | biológija · noun |
| [буря](https://en.wiktionary.org/wiki/%D0%B1%D1%83%D1%80%D1%8F#Russian) | storm, tempest (also figuratively) | búrja · noun |
| [деревянный](https://en.wiktionary.org/wiki/%D0%B4%D0%B5%D1%80%D0%B5%D0%B2%D1%8F%D0%BD%D0%BD%D1%8B%D0%B9#Russian) | wood; wooden | derevjánnyj · adj |
| [задний](https://en.wiktionary.org/wiki/%D0%B7%D0%B0%D0%B4%D0%BD%D0%B8%D0%B9#Russian) | rear, back, hind | zádnij · adj |
| [иностранный](https://en.wiktionary.org/wiki/%D0%B8%D0%BD%D0%BE%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%BD%D1%8B%D0%B9#Russian) | foreign | inostránnyj · adj |
| [полночь](https://en.wiktionary.org/wiki/%D0%BF%D0%BE%D0%BB%D0%BD%D0%BE%D1%87%D1%8C#Russian) | midnight | pólnočʹ · noun |
| [шахматы](https://en.wiktionary.org/wiki/%D1%88%D0%B0%D1%85%D0%BC%D0%B0%D1%82%D1%8B#Russian) | chess (two-player board game) | šáxmaty · noun |
| [шестьдесят](https://en.wiktionary.org/wiki/%D1%88%D0%B5%D1%81%D1%82%D1%8C%D0%B4%D0%B5%D1%81%D1%8F%D1%82#Russian) | sixty (60) | šestʹdesját · num |
| [гром](https://en.wiktionary.org/wiki/%D0%B3%D1%80%D0%BE%D0%BC#Russian) | thunder, thunderbolt | grom · noun |
| [краткий](https://en.wiktionary.org/wiki/%D0%BA%D1%80%D0%B0%D1%82%D0%BA%D0%B8%D0%B9#Russian) | brief | krátkij · adj |
| [скот](https://en.wiktionary.org/wiki/%D1%81%D0%BA%D0%BE%D1%82#Russian) | cattle, livestock | skot · noun |
| [слуга](https://en.wiktionary.org/wiki/%D1%81%D0%BB%D1%83%D0%B3%D0%B0#Russian) | servant | slugá · noun |
| [внук](https://en.wiktionary.org/wiki/%D0%B2%D0%BD%D1%83%D0%BA#Russian) | grandson | vnuk · noun |
| [семь чудес света](https://en.wiktionary.org/wiki/%D1%81%D0%B5%D0%BC%D1%8C%20%D1%87%D1%83%D0%B4%D0%B5%D1%81%20%D1%81%D0%B2%D0%B5%D1%82%D0%B0#Russian) | Seven Wonders of the World | semʹ čudés svéta · noun |
| [тс-с-с](https://en.wiktionary.org/wiki/%D1%82%D1%81-%D1%81-%D1%81#Russian) | psst! (listen to this!) | ts-s-s · intj |
| [тьма](https://en.wiktionary.org/wiki/%D1%82%D1%8C%D0%BC%D0%B0#Russian) | dark, darkness | tʹma · noun |
| [балет](https://en.wiktionary.org/wiki/%D0%B1%D0%B0%D0%BB%D0%B5%D1%82#Russian) | ballet | balét · noun |
| [домашнее задание](https://en.wiktionary.org/wiki/%D0%B4%D0%BE%D0%BC%D0%B0%D1%88%D0%BD%D0%B5%D0%B5%20%D0%B7%D0%B0%D0%B4%D0%B0%D0%BD%D0%B8%D0%B5#Russian) | homework | domášneje zadánije · noun |
| [племянник](https://en.wiktionary.org/wiki/%D0%BF%D0%BB%D0%B5%D0%BC%D1%8F%D0%BD%D0%BD%D0%B8%D0%BA#Russian) | nephew | plemjánnik · noun |
| [триста](https://en.wiktionary.org/wiki/%D1%82%D1%80%D0%B8%D1%81%D1%82%D0%B0#Russian) | three hundred (300) | trísta · num |
| [буква](https://en.wiktionary.org/wiki/%D0%B1%D1%83%D0%BA%D0%B2%D0%B0#Russian) | letter (a symbol in an alphabet) | búkva · noun |
| [вал](https://en.wiktionary.org/wiki/%D0%B2%D0%B0%D0%BB#Russian) | billow, roller, large wave (also figuratively) | val · noun |
| [временами](https://en.wiktionary.org/wiki/%D0%B2%D1%80%D0%B5%D0%BC%D0%B5%D0%BD%D0%B0%D0%BC%D0%B8#Russian) | at times, from time to time, now and then, every now and then, now and again, sometimes | vremenámi · adv |
| [вулкан](https://en.wiktionary.org/wiki/%D0%B2%D1%83%D0%BB%D0%BA%D0%B0%D0%BD#Russian) | volcano | vulkán · noun |
| [до нашей эры](https://en.wiktionary.org/wiki/%D0%B4%D0%BE%20%D0%BD%D0%B0%D1%88%D0%B5%D0%B9%20%D1%8D%D1%80%D1%8B#Russian) | Before the Common Era (BCE), before Christ (BC) | do nášej éry · adv |
| [нашей эры](https://en.wiktionary.org/wiki/%D0%BD%D0%B0%D1%88%D0%B5%D0%B9%20%D1%8D%D1%80%D1%8B#Russian) | anno Domini, Common Era, A.D. | nášej éry · adv |
| [пп](https://en.wiktionary.org/wiki/%D0%BF%D0%BF#Russian) | P (pawn, plural form of п² (p²)) | pp · noun |
| [работать как папа Карло](https://en.wiktionary.org/wiki/%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B0%D1%82%D1%8C%20%D0%BA%D0%B0%D0%BA%20%D0%BF%D0%B0%D0%BF%D0%B0%20%D0%9A%D0%B0%D1%80%D0%BB%D0%BE#Russian) | to work hard, to work like a dog | rabótatʹ kak pápa Kárlo · verb |
| [бутылка](https://en.wiktionary.org/wiki/%D0%B1%D1%83%D1%82%D1%8B%D0%BB%D0%BA%D0%B0#Russian) | bottle | butýlka · noun |
| [загадка](https://en.wiktionary.org/wiki/%D0%B7%D0%B0%D0%B3%D0%B0%D0%B4%D0%BA%D0%B0#Russian) | riddle, conundrum, puzzle | zagádka · noun |

</details>

## Question bank

Try before opening the answers. Different tasks use the same sentence to practise complementary skills. Open translation and explanation tasks can have valid alternatives.

### Subject pronouns · 50 questions

**ru-Q0001 · Fill the gap**

____ должен сделать своих родителей счастливыми.

You must make your parents happy.

[[Russian#^ru-Q0001-answer|Compare the answer]]
^ru-Q0001

**ru-Q0002 · Choose the form**

____ должен сделать своих родителей счастливыми.

You must make your parents happy.

Choices: он / Ты / я / она

[[Russian#^ru-Q0002-answer|Compare the answer]]
^ru-Q0002

**ru-Q0003 · Edit the changed sentence**

【я】 расскажете Тому?

Will you tell Tom?

[[Russian#^ru-Q0003-answer|Compare the answer]]
^ru-Q0003

**ru-Q0004 · Build the sentence**

Arrange: расскажете / Тому? / Вы

Will you tell Tom?

[[Russian#^ru-Q0004-answer|Compare the answer]]
^ru-Q0004

**ru-Q0005 · Write a translation**

Write this in Russian: I want to execute the plan by all means.

[[Russian#^ru-Q0005-answer|Compare the answer]]
^ru-Q0005

**ru-Q0006 · Explain the grammar**

【Я】 хочу выполнить план любой ценой.

I want to execute the plan by all means.

[[Russian#^ru-Q0006-answer|Compare the answer]]
^ru-Q0006

**ru-Q0007 · Fill the gap**

____ должен приготовить ей завтрак.

I must cook breakfast for her.

[[Russian#^ru-Q0007-answer|Compare the answer]]
^ru-Q0007

**ru-Q0008 · Choose the form**

____ должен приготовить ей завтрак.

I must cook breakfast for her.

Choices: она / Я / он / ты

[[Russian#^ru-Q0008-answer|Compare the answer]]
^ru-Q0008

**ru-Q0009 · Edit the changed sentence**

【ты】 бы сказал тебе, если бы мог.

I would tell you if I could.

[[Russian#^ru-Q0009-answer|Compare the answer]]
^ru-Q0009

**ru-Q0010 · Build the sentence**

Arrange: тебе, / мог. / Я / бы / бы / сказал / если

I would tell you if I could.

[[Russian#^ru-Q0010-answer|Compare the answer]]
^ru-Q0010

**ru-Q0011 · Write a translation**

Write this in Russian: How are you going to fix that?

[[Russian#^ru-Q0011-answer|Compare the answer]]
^ru-Q0011

**ru-Q0012 · Explain the grammar**

Как 【ты】 собираешься это чинить?

How are you going to fix that?

[[Russian#^ru-Q0012-answer|Compare the answer]]
^ru-Q0012

**ru-Q0013 · Fill the gap**

____ самая высокая в классе.

She's the tallest in her class.

[[Russian#^ru-Q0013-answer|Compare the answer]]
^ru-Q0013

**ru-Q0014 · Choose the form**

____ самая высокая в классе.

She's the tallest in her class.

Choices: он / ты / я / Она

[[Russian#^ru-Q0014-answer|Compare the answer]]
^ru-Q0014

**ru-Q0015 · Edit the changed sentence**

【ты】 никогда не разрешаю кому-нибудь другому кормить свою собаку.

I never let anyone else feed my dog.

[[Russian#^ru-Q0015-answer|Compare the answer]]
^ru-Q0015

**ru-Q0016 · Build the sentence**

Arrange: разрешаю / не / никогда / кому-нибудь / Я / другому / свою / собаку. / кормить

I never let anyone else feed my dog.

[[Russian#^ru-Q0016-answer|Compare the answer]]
^ru-Q0016

**ru-Q0017 · Write a translation**

Write this in Russian: Why do I have to talk to her?

[[Russian#^ru-Q0017-answer|Compare the answer]]
^ru-Q0017

**ru-Q0018 · Explain the grammar**

Почему 【я】 должен с ней разговаривать?

Why do I have to talk to her?

[[Russian#^ru-Q0018-answer|Compare the answer]]
^ru-Q0018

**ru-Q0019 · Fill the gap**

____ знал, что мне не стоило этого делать.

I knew I shouldn't have done that.

[[Russian#^ru-Q0019-answer|Compare the answer]]
^ru-Q0019

**ru-Q0020 · Choose the form**

____ знал, что мне не стоило этого делать.

I knew I shouldn't have done that.

Choices: Я / ты / он / она

[[Russian#^ru-Q0020-answer|Compare the answer]]
^ru-Q0020

**ru-Q0021 · Edit the changed sentence**

【я】 учит друзей английскому.

He teaches English to his friends.

[[Russian#^ru-Q0021-answer|Compare the answer]]
^ru-Q0021

**ru-Q0022 · Build the sentence**

Arrange: друзей / Он / учит / английскому.

He teaches English to his friends.

[[Russian#^ru-Q0022-answer|Compare the answer]]
^ru-Q0022

**ru-Q0023 · Write a translation**

Write this in Russian: We work together.

[[Russian#^ru-Q0023-answer|Compare the answer]]
^ru-Q0023

**ru-Q0024 · Explain the grammar**

【Мы】 вместе работаем.

We work together.

[[Russian#^ru-Q0024-answer|Compare the answer]]
^ru-Q0024

**ru-Q0025 · Fill the gap**

____ ему нравлюсь.

He likes me.

[[Russian#^ru-Q0025-answer|Compare the answer]]
^ru-Q0025

**ru-Q0026 · Choose the form**

____ ему нравлюсь.

He likes me.

Choices: Я / он / ты / она

[[Russian#^ru-Q0026-answer|Compare the answer]]
^ru-Q0026

**ru-Q0027 · Edit the changed sentence**

【я】 же шутила.

She was just kidding.

[[Russian#^ru-Q0027-answer|Compare the answer]]
^ru-Q0027

**ru-Q0028 · Build the sentence**

Arrange: шутила. / Она / же

She was just kidding.

[[Russian#^ru-Q0028-answer|Compare the answer]]
^ru-Q0028

**ru-Q0029 · Write a translation**

Write this in Russian: I was very tired.

[[Russian#^ru-Q0029-answer|Compare the answer]]
^ru-Q0029

**ru-Q0030 · Explain the grammar**

【Я】 был очень уставшим.

I was very tired.

[[Russian#^ru-Q0030-answer|Compare the answer]]
^ru-Q0030

**ru-Q0031 · Fill the gap**

____ погиб за свою страну.

He died for his country.

[[Russian#^ru-Q0031-answer|Compare the answer]]
^ru-Q0031

**ru-Q0032 · Choose the form**

____ погиб за свою страну.

He died for his country.

Choices: она / ты / Он / я

[[Russian#^ru-Q0032-answer|Compare the answer]]
^ru-Q0032

**ru-Q0033 · Edit the changed sentence**

【я】 были очень заняты.

They were very busy.

[[Russian#^ru-Q0033-answer|Compare the answer]]
^ru-Q0033

**ru-Q0034 · Build the sentence**

Arrange: заняты. / были / Они / очень

They were very busy.

[[Russian#^ru-Q0034-answer|Compare the answer]]
^ru-Q0034

**ru-Q0035 · Write a translation**

Write this in Russian: Can I come over to your place today?

[[Russian#^ru-Q0035-answer|Compare the answer]]
^ru-Q0035

**ru-Q0036 · Explain the grammar**

Можно 【я】 сегодня к вам зайду?

Can I come over to your place today?

[[Russian#^ru-Q0036-answer|Compare the answer]]
^ru-Q0036

**ru-Q0037 · Fill the gap**

Что ____ теперь скажу Тому?

What am I going to tell Tom now?

[[Russian#^ru-Q0037-answer|Compare the answer]]
^ru-Q0037

**ru-Q0038 · Choose the form**

Что ____ теперь скажу Тому?

What am I going to tell Tom now?

Choices: он / она / я / ты

[[Russian#^ru-Q0038-answer|Compare the answer]]
^ru-Q0038

**ru-Q0039 · Edit the changed sentence**

【я】 знали, что на этой горе живёт несколько лис?

Did you know that some foxes lived on this mountain?

[[Russian#^ru-Q0039-answer|Compare the answer]]
^ru-Q0039

**ru-Q0040 · Build the sentence**

Arrange: живёт / Вы / лис? / на / знали, / горе / что / этой / несколько

Did you know that some foxes lived on this mountain?

[[Russian#^ru-Q0040-answer|Compare the answer]]
^ru-Q0040

**ru-Q0041 · Write a translation**

Write this in Russian: Arkhangelsk is the farthest of the farthest places you can imagine.

[[Russian#^ru-Q0041-answer|Compare the answer]]
^ru-Q0041

**ru-Q0042 · Explain the grammar**

Архангельск дальше, чем самое дальнее место, какое 【вы】 можете себе представить.

Arkhangelsk is the farthest of the farthest places you can imagine.

[[Russian#^ru-Q0042-answer|Compare the answer]]
^ru-Q0042

**ru-Q0043 · Fill the gap**

____ перебрались с острова на материк на пароме.

We took a ferry from the island to the mainland.

[[Russian#^ru-Q0043-answer|Compare the answer]]
^ru-Q0043

**ru-Q0044 · Choose the form**

____ перебрались с острова на материк на пароме.

We took a ferry from the island to the mainland.

Choices: Мы / ты / он / я

[[Russian#^ru-Q0044-answer|Compare the answer]]
^ru-Q0044

**ru-Q0045 · Edit the changed sentence**

【ты】 вчера по дороге в школу Тома встретил.

Yesterday I met Tom on the way to school.

[[Russian#^ru-Q0045-answer|Compare the answer]]
^ru-Q0045

**ru-Q0046 · Build the sentence**

Arrange: Я / вчера / школу / по / Тома / в / встретил. / дороге

Yesterday I met Tom on the way to school.

[[Russian#^ru-Q0046-answer|Compare the answer]]
^ru-Q0046

**ru-Q0047 · Write a translation**

Write this in Russian: I did not know what to say and I said nothing.

[[Russian#^ru-Q0047-answer|Compare the answer]]
^ru-Q0047

**ru-Q0048 · Explain the grammar**

【Я】 не знал, что ответить, и промолчал.

I did not know what to say and I said nothing.

[[Russian#^ru-Q0048-answer|Compare the answer]]
^ru-Q0048

**ru-Q0049 · Fill the gap**

____ рад, что ты это спросил.

I'm glad you asked that.

[[Russian#^ru-Q0049-answer|Compare the answer]]
^ru-Q0049

**ru-Q0050 · Choose the form**

____ рад, что ты это спросил.

I'm glad you asked that.

Choices: ты / Я / он / она

[[Russian#^ru-Q0050-answer|Compare the answer]]
^ru-Q0050


### Object and oblique pronouns · 50 questions

**ru-Q0051 · Edit the changed sentence**

【меня】, по идее, здесь быть не должно.

You're not supposed to be here.

[[Russian#^ru-Q0051-answer|Compare the answer]]
^ru-Q0051

**ru-Q0052 · Build the sentence**

Arrange: не / по / идее, / здесь / Тебя, / быть / должно.

You're not supposed to be here.

[[Russian#^ru-Q0052-answer|Compare the answer]]
^ru-Q0052

**ru-Q0053 · Write a translation**

Write this in Russian: We need to test it.

[[Russian#^ru-Q0053-answer|Compare the answer]]
^ru-Q0053

**ru-Q0054 · Explain the grammar**

Нам нужно 【её】 протестировать.

We need to test it.

[[Russian#^ru-Q0054-answer|Compare the answer]]
^ru-Q0054

**ru-Q0055 · Fill the gap**

Думаю, вам следует ____ подождать.

I think you should wait for us.

[[Russian#^ru-Q0055-answer|Compare the answer]]
^ru-Q0055

**ru-Q0056 · Choose the form**

Думаю, вам следует ____ подождать.

I think you should wait for us.

Choices: нас / меня / тебя / его

[[Russian#^ru-Q0056-answer|Compare the answer]]
^ru-Q0056

**ru-Q0057 · Edit the changed sentence**

Один из 【меня】 врёт.

One of us is lying.

[[Russian#^ru-Q0057-answer|Compare the answer]]
^ru-Q0057

**ru-Q0058 · Build the sentence**

Arrange: нас / врёт. / Один / из

One of us is lying.

[[Russian#^ru-Q0058-answer|Compare the answer]]
^ru-Q0058

**ru-Q0059 · Write a translation**

Write this in Russian: What do you expect from us?

[[Russian#^ru-Q0059-answer|Compare the answer]]
^ru-Q0059

**ru-Q0060 · Explain the grammar**

Чего вы от 【нас】 ждёте?

What do you expect from us?

[[Russian#^ru-Q0060-answer|Compare the answer]]
^ru-Q0060

**ru-Q0061 · Fill the gap**

Покупайте землю. ____ сняли с производства.

Buy land. They ain't making any more of the stuff.

[[Russian#^ru-Q0061-answer|Compare the answer]]
^ru-Q0061

**ru-Q0062 · Choose the form**

Покупайте землю. ____ сняли с производства.

Buy land. They ain't making any more of the stuff.

Choices: меня / Её / его / тебя

[[Russian#^ru-Q0062-answer|Compare the answer]]
^ru-Q0062

**ru-Q0063 · Edit the changed sentence**

Мы выбрали 【меня】 мэром.

We elected him mayor.

[[Russian#^ru-Q0063-answer|Compare the answer]]
^ru-Q0063

**ru-Q0064 · Build the sentence**

Arrange: мэром. / его / Мы / выбрали

We elected him mayor.

[[Russian#^ru-Q0064-answer|Compare the answer]]
^ru-Q0064

**ru-Q0065 · Write a translation**

Write this in Russian: If she doesn't love you, what's the problem? You can love yourself.

[[Russian#^ru-Q0065-answer|Compare the answer]]
^ru-Q0065

**ru-Q0066 · Explain the grammar**

Если она 【тебя】 не любит, в чём проблема? Ты сам можешь любить себя.

If she doesn't love you, what's the problem? You can love yourself.

[[Russian#^ru-Q0066-answer|Compare the answer]]
^ru-Q0066

**ru-Q0067 · Fill the gap**

Не тревожь ____.

Don't disturb me.

[[Russian#^ru-Q0067-answer|Compare the answer]]
^ru-Q0067

**ru-Q0068 · Choose the form**

Не тревожь ____.

Don't disturb me.

Choices: нас / меня / его / тебя

[[Russian#^ru-Q0068-answer|Compare the answer]]
^ru-Q0068

**ru-Q0069 · Edit the changed sentence**

Есть у 【меня】 сдача с одного доллара?

Do you have change for a dollar?

[[Russian#^ru-Q0069-answer|Compare the answer]]
^ru-Q0069

**ru-Q0070 · Build the sentence**

Arrange: Есть / с / доллара? / у / одного / тебя / сдача

Do you have change for a dollar?

[[Russian#^ru-Q0070-answer|Compare the answer]]
^ru-Q0070

**ru-Q0071 · Write a translation**

Write this in Russian: We all hated you.

[[Russian#^ru-Q0071-answer|Compare the answer]]
^ru-Q0071

**ru-Q0072 · Explain the grammar**

Мы все 【тебя】 ненавидели.

We all hated you.

[[Russian#^ru-Q0072-answer|Compare the answer]]
^ru-Q0072

**ru-Q0073 · Fill the gap**

Том пришёл ____ повидать.

Tom has come to see you.

[[Russian#^ru-Q0073-answer|Compare the answer]]
^ru-Q0073

**ru-Q0074 · Choose the form**

Том пришёл ____ повидать.

Tom has come to see you.

Choices: меня / нас / тебя / его

[[Russian#^ru-Q0074-answer|Compare the answer]]
^ru-Q0074

**ru-Q0075 · Edit the changed sentence**

У 【меня】 не будет из-за этого проблем?

Won't you get in trouble for this?

[[Russian#^ru-Q0075-answer|Compare the answer]]
^ru-Q0075

**ru-Q0076 · Build the sentence**

Arrange: тебя / проблем? / не / У / из-за / будет / этого

Won't you get in trouble for this?

[[Russian#^ru-Q0076-answer|Compare the answer]]
^ru-Q0076

**ru-Q0077 · Write a translation**

Write this in Russian: Please fix it.

[[Russian#^ru-Q0077-answer|Compare the answer]]
^ru-Q0077

**ru-Q0078 · Explain the grammar**

Почини 【его】, пожалуйста.

Please fix it.

[[Russian#^ru-Q0078-answer|Compare the answer]]
^ru-Q0078

**ru-Q0079 · Fill the gap**

Не могу представить и дня без ____.

I can't imagine a day without you.

[[Russian#^ru-Q0079-answer|Compare the answer]]
^ru-Q0079

**ru-Q0080 · Choose the form**

Не могу представить и дня без ____.

I can't imagine a day without you.

Choices: тебя / его / нас / меня

[[Russian#^ru-Q0080-answer|Compare the answer]]
^ru-Q0080

**ru-Q0081 · Edit the changed sentence**

Я не хотел, чтобы ты от 【тебя】 уходила.

I didn't want you to leave me.

[[Russian#^ru-Q0081-answer|Compare the answer]]
^ru-Q0081

**ru-Q0082 · Build the sentence**

Arrange: не / чтобы / уходила. / хотел, / Я / меня / ты / от

I didn't want you to leave me.

[[Russian#^ru-Q0082-answer|Compare the answer]]
^ru-Q0082

**ru-Q0083 · Write a translation**

Write this in Russian: Her silence surprised me.

[[Russian#^ru-Q0083-answer|Compare the answer]]
^ru-Q0083

**ru-Q0084 · Explain the grammar**

【Её】 молчание удивило меня.

Her silence surprised me.

[[Russian#^ru-Q0084-answer|Compare the answer]]
^ru-Q0084

**ru-Q0085 · Fill the gap**

В этом году у ____ был рекордный урожай.

We had a record crop this year.

[[Russian#^ru-Q0085-answer|Compare the answer]]
^ru-Q0085

**ru-Q0086 · Choose the form**

В этом году у ____ был рекордный урожай.

We had a record crop this year.

Choices: тебя / меня / его / нас

[[Russian#^ru-Q0086-answer|Compare the answer]]
^ru-Q0086

**ru-Q0087 · Edit the changed sentence**

Вы никогда не будете любить 【тебя】 так, как я вас.

You'll never love me as much as I love you.

[[Russian#^ru-Q0087-answer|Compare the answer]]
^ru-Q0087

**ru-Q0088 · Build the sentence**

Arrange: любить / будете / меня / как / так, / Вы / не / никогда / я / вас.

You'll never love me as much as I love you.

[[Russian#^ru-Q0088-answer|Compare the answer]]
^ru-Q0088

**ru-Q0089 · Write a translation**

Write this in Russian: I tried to cheer her up, but she did nothing but cry.

[[Russian#^ru-Q0089-answer|Compare the answer]]
^ru-Q0089

**ru-Q0090 · Explain the grammar**

Я пытался развеселить 【её】, но она только плакала.

I tried to cheer her up, but she did nothing but cry.

[[Russian#^ru-Q0090-answer|Compare the answer]]
^ru-Q0090

**ru-Q0091 · Fill the gap**

Когда я видел ____ в последний раз, он был ещё ребёнком.

When I saw him last, he was still a child.

[[Russian#^ru-Q0091-answer|Compare the answer]]
^ru-Q0091

**ru-Q0092 · Choose the form**

Когда я видел ____ в последний раз, он был ещё ребёнком.

When I saw him last, he was still a child.

Choices: его / нас / меня / тебя

[[Russian#^ru-Q0092-answer|Compare the answer]]
^ru-Q0092

**ru-Q0093 · Edit the changed sentence**

У 【меня】 богатое воображение.

You have a fertile imagination.

[[Russian#^ru-Q0093-answer|Compare the answer]]
^ru-Q0093

**ru-Q0094 · Build the sentence**

Arrange: воображение. / У / тебя / богатое

You have a fertile imagination.

[[Russian#^ru-Q0094-answer|Compare the answer]]
^ru-Q0094

**ru-Q0095 · Write a translation**

Write this in Russian: It seems you aren't taking me seriously.

[[Russian#^ru-Q0095-answer|Compare the answer]]
^ru-Q0095

**ru-Q0096 · Explain the grammar**

Похоже, ты не принимаешь 【меня】 всерьёз.

It seems you aren't taking me seriously.

[[Russian#^ru-Q0096-answer|Compare the answer]]
^ru-Q0096

**ru-Q0097 · Fill the gap**

Сегодня у ____ нет домашнего задания.

I have no homework today.

[[Russian#^ru-Q0097-answer|Compare the answer]]
^ru-Q0097

**ru-Q0098 · Choose the form**

Сегодня у ____ нет домашнего задания.

I have no homework today.

Choices: нас / тебя / меня / его

[[Russian#^ru-Q0098-answer|Compare the answer]]
^ru-Q0098

**ru-Q0099 · Edit the changed sentence**

Мне всегда хотелось 【меня】 кое о чём спросить.

I've always wanted to ask you something.

[[Russian#^ru-Q0099-answer|Compare the answer]]
^ru-Q0099

**ru-Q0100 · Build the sentence**

Arrange: Мне / о / всегда / хотелось / чём / спросить. / тебя / кое

I've always wanted to ask you something.

[[Russian#^ru-Q0100-answer|Compare the answer]]
^ru-Q0100


### Dative pronouns · 50 questions

**ru-Q0101 · Write a translation**

Write this in Russian: Don't you think this has gone far enough?

[[Russian#^ru-Q0101-answer|Compare the answer]]
^ru-Q0101

**ru-Q0102 · Explain the grammar**

【Тебе】 не кажется, что это слишком далеко зашло?

Don't you think this has gone far enough?

[[Russian#^ru-Q0102-answer|Compare the answer]]
^ru-Q0102

**ru-Q0103 · Fill the gap**

____ в целом нравится китайская еда.

I like Chinese food in general.

[[Russian#^ru-Q0103-answer|Compare the answer]]
^ru-Q0103

**ru-Q0104 · Choose the form**

____ в целом нравится китайская еда.

I like Chinese food in general.

Choices: нам / Мне / ему / тебе

[[Russian#^ru-Q0104-answer|Compare the answer]]
^ru-Q0104

**ru-Q0105 · Edit the changed sentence**

Почисть 【тебе】, пожалуйста, этот апельсин.

Please peel this orange for me.

[[Russian#^ru-Q0105-answer|Compare the answer]]
^ru-Q0105

**ru-Q0106 · Build the sentence**

Arrange: мне, / пожалуйста, / Почисть / апельсин. / этот

Please peel this orange for me.

[[Russian#^ru-Q0106-answer|Compare the answer]]
^ru-Q0106

**ru-Q0107 · Write a translation**

Write this in Russian: I'll need to think about it.

[[Russian#^ru-Q0107-answer|Compare the answer]]
^ru-Q0107

**ru-Q0108 · Explain the grammar**

【Мне】 нужно будет подумать над этим.

I'll need to think about it.

[[Russian#^ru-Q0108-answer|Compare the answer]]
^ru-Q0108

**ru-Q0109 · Fill the gap**

Можешь ____ не верить.

You don't have to believe me.

[[Russian#^ru-Q0109-answer|Compare the answer]]
^ru-Q0109

**ru-Q0110 · Choose the form**

Можешь ____ не верить.

You don't have to believe me.

Choices: мне / ему / нам / тебе

[[Russian#^ru-Q0110-answer|Compare the answer]]
^ru-Q0110

**ru-Q0111 · Edit the changed sentence**

GPS позволяет 【мне】 определить своё местоположение с помощью спутников.

GPS allows you to determine your location using satellites.

[[Russian#^ru-Q0111-answer|Compare the answer]]
^ru-Q0111

**ru-Q0112 · Build the sentence**

Arrange: своё / позволяет / определить / вам / с / спутников. / помощью / местоположение / GPS

GPS allows you to determine your location using satellites.

[[Russian#^ru-Q0112-answer|Compare the answer]]
^ru-Q0112

**ru-Q0113 · Write a translation**

Write this in Russian: Tom wasn't able to find what he needed.

[[Russian#^ru-Q0113-answer|Compare the answer]]
^ru-Q0113

**ru-Q0114 · Explain the grammar**

Том не смог найти то, что 【ему】 было нужно.

Tom wasn't able to find what he needed.

[[Russian#^ru-Q0114-answer|Compare the answer]]
^ru-Q0114

**ru-Q0115 · Fill the gap**

Том говорил ____, на ком он женат?

Has Tom told you who he's married to?

[[Russian#^ru-Q0115-answer|Compare the answer]]
^ru-Q0115

**ru-Q0116 · Choose the form**

Том говорил ____, на ком он женат?

Has Tom told you who he's married to?

Choices: ему / нам / мне / тебе

[[Russian#^ru-Q0116-answer|Compare the answer]]
^ru-Q0116

**ru-Q0117 · Edit the changed sentence**

Скажите 【мне】, что мы заняты.

Tell him we're busy.

[[Russian#^ru-Q0117-answer|Compare the answer]]
^ru-Q0117

**ru-Q0118 · Build the sentence**

Arrange: мы / ему, / заняты. / что / Скажите

Tell him we're busy.

[[Russian#^ru-Q0118-answer|Compare the answer]]
^ru-Q0118

**ru-Q0119 · Write a translation**

Write this in Russian: Did Tom tell you where he and Mary met?

[[Russian#^ru-Q0119-answer|Compare the answer]]
^ru-Q0119

**ru-Q0120 · Explain the grammar**

Том рассказывал 【тебе】, где они с Мэри познакомились?

Did Tom tell you where he and Mary met?

[[Russian#^ru-Q0120-answer|Compare the answer]]
^ru-Q0120

**ru-Q0121 · Fill the gap**

____ надо сделать это сегодня.

We have to do that today.

[[Russian#^ru-Q0121-answer|Compare the answer]]
^ru-Q0121

**ru-Q0122 · Choose the form**

____ надо сделать это сегодня.

We have to do that today.

Choices: ему / Нам / мне / тебе

[[Russian#^ru-Q0122-answer|Compare the answer]]
^ru-Q0122

**ru-Q0123 · Edit the changed sentence**

Скажи Мэри, что 【мне】 нужно извиниться перед Томом.

Tell Mary that she needs to apologize to Tom.

[[Russian#^ru-Q0123-answer|Compare the answer]]
^ru-Q0123

**ru-Q0124 · Build the sentence**

Arrange: Мэри, / Скажи / ей / что / извиниться / Томом. / нужно / перед

Tell Mary that she needs to apologize to Tom.

[[Russian#^ru-Q0124-answer|Compare the answer]]
^ru-Q0124

**ru-Q0125 · Write a translation**

Write this in Russian: I owe you $1,000.

[[Russian#^ru-Q0125-answer|Compare the answer]]
^ru-Q0125

**ru-Q0126 · Explain the grammar**

Я должен 【вам】 тысячу долларов.

I owe you $1,000.

[[Russian#^ru-Q0126-answer|Compare the answer]]
^ru-Q0126

**ru-Q0127 · Fill the gap**

____ надо сказать Тому.

We have to tell Tom.

[[Russian#^ru-Q0127-answer|Compare the answer]]
^ru-Q0127

**ru-Q0128 · Choose the form**

____ надо сказать Тому.

We have to tell Tom.

Choices: Нам / тебе / мне / ему

[[Russian#^ru-Q0128-answer|Compare the answer]]
^ru-Q0128

**ru-Q0129 · Edit the changed sentence**

【тебе】 больше не нужна твоя помощь.

I don't need your help anymore.

[[Russian#^ru-Q0129-answer|Compare the answer]]
^ru-Q0129

**ru-Q0130 · Build the sentence**

Arrange: не / Мне / нужна / больше / помощь. / твоя

I don't need your help anymore.

[[Russian#^ru-Q0130-answer|Compare the answer]]
^ru-Q0130

**ru-Q0131 · Write a translation**

Write this in Russian: You fool, I had to do it!

[[Russian#^ru-Q0131-answer|Compare the answer]]
^ru-Q0131

**ru-Q0132 · Explain the grammar**

Дурак, 【мне】 пришлось это сделать!

You fool, I had to do it!

[[Russian#^ru-Q0132-answer|Compare the answer]]
^ru-Q0132

**ru-Q0133 · Fill the gap**

Я сказал ____, чтобы ты оставил Тома в покое.

I told you to leave Tom alone.

[[Russian#^ru-Q0133-answer|Compare the answer]]
^ru-Q0133

**ru-Q0134 · Choose the form**

Я сказал ____, чтобы ты оставил Тома в покое.

I told you to leave Tom alone.

Choices: нам / ему / мне / тебе

[[Russian#^ru-Q0134-answer|Compare the answer]]
^ru-Q0134

**ru-Q0135 · Edit the changed sentence**

Дадим 【мне】 минуту.

Let's give her a minute.

[[Russian#^ru-Q0135-answer|Compare the answer]]
^ru-Q0135

**ru-Q0136 · Build the sentence**

Arrange: минуту. / Дадим / ей

Let's give her a minute.

[[Russian#^ru-Q0136-answer|Compare the answer]]
^ru-Q0136

**ru-Q0137 · Write a translation**

Write this in Russian: Please tell me where Tom is.

[[Russian#^ru-Q0137-answer|Compare the answer]]
^ru-Q0137

**ru-Q0138 · Explain the grammar**

Скажи 【мне】, пожалуйста, где Том.

Please tell me where Tom is.

[[Russian#^ru-Q0138-answer|Compare the answer]]
^ru-Q0138

**ru-Q0139 · Fill the gap**

Одна ____, одна мне.

There's one for you and one for me.

[[Russian#^ru-Q0139-answer|Compare the answer]]
^ru-Q0139

**ru-Q0140 · Choose the form**

Одна ____, одна мне.

There's one for you and one for me.

Choices: мне / тебе / ему / вам

[[Russian#^ru-Q0140-answer|Compare the answer]]
^ru-Q0140

**ru-Q0141 · Edit the changed sentence**

Вы вроде говорили 【тебе】, что умеете это делать.

I thought you told me you could do that.

[[Russian#^ru-Q0141-answer|Compare the answer]]
^ru-Q0141

**ru-Q0142 · Build the sentence**

Arrange: вроде / это / умеете / Вы / делать. / говорили / что / мне,

I thought you told me you could do that.

[[Russian#^ru-Q0142-answer|Compare the answer]]
^ru-Q0142

**ru-Q0143 · Write a translation**

Write this in Russian: We only need a few more minutes.

[[Russian#^ru-Q0143-answer|Compare the answer]]
^ru-Q0143

**ru-Q0144 · Explain the grammar**

【Нам】 только нужно ещё несколько минут.

We only need a few more minutes.

[[Russian#^ru-Q0144-answer|Compare the answer]]
^ru-Q0144

**ru-Q0145 · Fill the gap**

____ нравятся любовные истории.

I like love stories.

[[Russian#^ru-Q0145-answer|Compare the answer]]
^ru-Q0145

**ru-Q0146 · Choose the form**

____ нравятся любовные истории.

I like love stories.

Choices: тебе / нам / ему / Мне

[[Russian#^ru-Q0146-answer|Compare the answer]]
^ru-Q0146

**ru-Q0147 · Edit the changed sentence**

Она преподнесла 【мне】 чудесный подарок.

She gave him a nice present.

[[Russian#^ru-Q0147-answer|Compare the answer]]
^ru-Q0147

**ru-Q0148 · Build the sentence**

Arrange: чудесный / подарок. / ему / преподнесла / Она

She gave him a nice present.

[[Russian#^ru-Q0148-answer|Compare the answer]]
^ru-Q0148

**ru-Q0149 · Write a translation**

Write this in Russian: I have something I need to talk to you about.

[[Russian#^ru-Q0149-answer|Compare the answer]]
^ru-Q0149

**ru-Q0150 · Explain the grammar**

【Мне】 нужно кое о чём с тобой поговорить.

I have something I need to talk to you about.

[[Russian#^ru-Q0150-answer|Compare the answer]]
^ru-Q0150


### Possessive forms · 50 questions

**ru-Q0151 · Fill the gap**

____ мама красивая.

My mother is beautiful.

[[Russian#^ru-Q0151-answer|Compare the answer]]
^ru-Q0151

**ru-Q0152 · Choose the form**

____ мама красивая.

My mother is beautiful.

Choices: Моя / мой / мои / наш

[[Russian#^ru-Q0152-answer|Compare the answer]]
^ru-Q0152

**ru-Q0153 · Edit the changed sentence**

【мой】 жена ещё в Америке?

Is your wife still in America?

[[Russian#^ru-Q0153-answer|Compare the answer]]
^ru-Q0153

**ru-Q0154 · Build the sentence**

Arrange: Ваша / ещё / Америке? / в / жена

Is your wife still in America?

[[Russian#^ru-Q0154-answer|Compare the answer]]
^ru-Q0154

**ru-Q0155 · Write a translation**

Write this in Russian: I just got a call from your teacher.

[[Russian#^ru-Q0155-answer|Compare the answer]]
^ru-Q0155

**ru-Q0156 · Explain the grammar**

Мне только что звонила 【ваша】 учительница.

I just got a call from your teacher.

[[Russian#^ru-Q0156-answer|Compare the answer]]
^ru-Q0156

**ru-Q0157 · Fill the gap**

Это ____ младшая сестра.

This is my younger sister.

[[Russian#^ru-Q0157-answer|Compare the answer]]
^ru-Q0157

**ru-Q0158 · Choose the form**

Это ____ младшая сестра.

This is my younger sister.

Choices: мои / наш / моя / мой

[[Russian#^ru-Q0158-answer|Compare the answer]]
^ru-Q0158

**ru-Q0159 · Edit the changed sentence**

Где он нашёл 【мой】 ключи?

Where did he find my keys?

[[Russian#^ru-Q0159-answer|Compare the answer]]
^ru-Q0159

**ru-Q0160 · Build the sentence**

Arrange: Где / нашёл / ключи? / он / мои

Where did he find my keys?

[[Russian#^ru-Q0160-answer|Compare the answer]]
^ru-Q0160

**ru-Q0161 · Write a translation**

Write this in Russian: Which one is my cup?

[[Russian#^ru-Q0161-answer|Compare the answer]]
^ru-Q0161

**ru-Q0162 · Explain the grammar**

Которая из чашек 【моя】?

Which one is my cup?

[[Russian#^ru-Q0162-answer|Compare the answer]]
^ru-Q0162

**ru-Q0163 · Fill the gap**

Как вам ____ стрижка?

What do you think of my haircut?

[[Russian#^ru-Q0163-answer|Compare the answer]]
^ru-Q0163

**ru-Q0164 · Choose the form**

Как вам ____ стрижка?

What do you think of my haircut?

Choices: моя / мои / мой / наш

[[Russian#^ru-Q0164-answer|Compare the answer]]
^ru-Q0164

**ru-Q0165 · Edit the changed sentence**

Это 【мой】 черепаха?

Is this turtle yours?

[[Russian#^ru-Q0165-answer|Compare the answer]]
^ru-Q0165

**ru-Q0166 · Build the sentence**

Arrange: черепаха? / ваша / Это

Is this turtle yours?

[[Russian#^ru-Q0166-answer|Compare the answer]]
^ru-Q0166

**ru-Q0167 · Write a translation**

Write this in Russian: My older sister finally got married.

[[Russian#^ru-Q0167-answer|Compare the answer]]
^ru-Q0167

**ru-Q0168 · Explain the grammar**

【Моя】 старшая сестра наконец вышла замуж.

My older sister finally got married.

[[Russian#^ru-Q0168-answer|Compare the answer]]
^ru-Q0168

**ru-Q0169 · Fill the gap**

Вы не видели, кто взял ____ рюкзак?

Did you see who took my backpack?

[[Russian#^ru-Q0169-answer|Compare the answer]]
^ru-Q0169

**ru-Q0170 · Choose the form**

Вы не видели, кто взял ____ рюкзак?

Did you see who took my backpack?

Choices: наш / моя / мой / мои

[[Russian#^ru-Q0170-answer|Compare the answer]]
^ru-Q0170

**ru-Q0171 · Edit the changed sentence**

【моя】 отец каждый день пьёт по чашке кофе.

My father has a cup of coffee every day.

[[Russian#^ru-Q0171-answer|Compare the answer]]
^ru-Q0171

**ru-Q0172 · Build the sentence**

Arrange: кофе. / каждый / день / отец / чашке / по / Мой / пьёт

My father has a cup of coffee every day.

[[Russian#^ru-Q0172-answer|Compare the answer]]
^ru-Q0172

**ru-Q0173 · Write a translation**

Write this in Russian: What's your favorite cereal?

[[Russian#^ru-Q0173-answer|Compare the answer]]
^ru-Q0173

**ru-Q0174 · Explain the grammar**

Какая 【твоя】 любимая крупа?

What's your favorite cereal?

[[Russian#^ru-Q0174-answer|Compare the answer]]
^ru-Q0174

**ru-Q0175 · Fill the gap**

____ хобби - коллекционирование старых монет.

My hobby is collecting old coins.

[[Russian#^ru-Q0175-answer|Compare the answer]]
^ru-Q0175

**ru-Q0176 · Choose the form**

____ хобби - коллекционирование старых монет.

My hobby is collecting old coins.

Choices: мои / Моё / моя / мой

[[Russian#^ru-Q0176-answer|Compare the answer]]
^ru-Q0176

**ru-Q0177 · Edit the changed sentence**

Элементарно, 【моя】 дорогой Том.

It's elementary, my dear Tom.

[[Russian#^ru-Q0177-answer|Compare the answer]]
^ru-Q0177

**ru-Q0178 · Build the sentence**

Arrange: Том. / мой / Элементарно, / дорогой

It's elementary, my dear Tom.

[[Russian#^ru-Q0178-answer|Compare the answer]]
^ru-Q0178

**ru-Q0179 · Write a translation**

Write this in Russian: My father-in-law is an engineer.

[[Russian#^ru-Q0179-answer|Compare the answer]]
^ru-Q0179

**ru-Q0180 · Explain the grammar**

【Мой】 тесть - инженер.

My father-in-law is an engineer.

[[Russian#^ru-Q0180-answer|Compare the answer]]
^ru-Q0180

**ru-Q0181 · Fill the gap**

____ ресторан находится около южной автобусной остановки.

Our restaurant is near the southern bus station.

[[Russian#^ru-Q0181-answer|Compare the answer]]
^ru-Q0181

**ru-Q0182 · Choose the form**

____ ресторан находится около южной автобусной остановки.

Our restaurant is near the southern bus station.

Choices: мои / Наш / моя / мой

[[Russian#^ru-Q0182-answer|Compare the answer]]
^ru-Q0182

**ru-Q0183 · Edit the changed sentence**

【мой】 сердце перестало биться.

My heart stopped beating.

[[Russian#^ru-Q0183-answer|Compare the answer]]
^ru-Q0183

**ru-Q0184 · Build the sentence**

Arrange: Моё / биться. / перестало / сердце

My heart stopped beating.

[[Russian#^ru-Q0184-answer|Compare the answer]]
^ru-Q0184

**ru-Q0185 · Write a translation**

Write this in Russian: My opinion hasn't changed.

[[Russian#^ru-Q0185-answer|Compare the answer]]
^ru-Q0185

**ru-Q0186 · Explain the grammar**

【Моё】 мнение не изменилось.

My opinion hasn't changed.

[[Russian#^ru-Q0186-answer|Compare the answer]]
^ru-Q0186

**ru-Q0187 · Fill the gap**

____ отец чинит сломанные кресла.

My father fixes broken armchairs.

[[Russian#^ru-Q0187-answer|Compare the answer]]
^ru-Q0187

**ru-Q0188 · Choose the form**

____ отец чинит сломанные кресла.

My father fixes broken armchairs.

Choices: Мой / моя / мои / наш

[[Russian#^ru-Q0188-answer|Compare the answer]]
^ru-Q0188

**ru-Q0189 · Edit the changed sentence**

【мой】 совет нам никак не помог.

Your advice did not help us at all.

[[Russian#^ru-Q0189-answer|Compare the answer]]
^ru-Q0189

**ru-Q0190 · Build the sentence**

Arrange: не / Ваш / никак / нам / помог. / совет

Your advice did not help us at all.

[[Russian#^ru-Q0190-answer|Compare the answer]]
^ru-Q0190

**ru-Q0191 · Write a translation**

Write this in Russian: Where's my eraser?

[[Russian#^ru-Q0191-answer|Compare the answer]]
^ru-Q0191

**ru-Q0192 · Explain the grammar**

Где 【мой】 ластик?

Where's my eraser?

[[Russian#^ru-Q0192-answer|Compare the answer]]
^ru-Q0192

**ru-Q0193 · Fill the gap**

Ей нравятся ____ шутки.

She likes my jokes.

[[Russian#^ru-Q0193-answer|Compare the answer]]
^ru-Q0193

**ru-Q0194 · Choose the form**

Ей нравятся ____ шутки.

She likes my jokes.

Choices: мои / наш / мой / моя

[[Russian#^ru-Q0194-answer|Compare the answer]]
^ru-Q0194

**ru-Q0195 · Edit the changed sentence**

Человек, читающий газету вон там, — 【моя】 дядя.

The man reading a paper over there is my uncle.

[[Russian#^ru-Q0195-answer|Compare the answer]]
^ru-Q0195

**ru-Q0196 · Build the sentence**

Arrange: — / Человек, / мой / читающий / газету / там, / дядя. / вон

The man reading a paper over there is my uncle.

[[Russian#^ru-Q0196-answer|Compare the answer]]
^ru-Q0196

**ru-Q0197 · Write a translation**

Write this in Russian: It wasn't mine.

[[Russian#^ru-Q0197-answer|Compare the answer]]
^ru-Q0197

**ru-Q0198 · Explain the grammar**

Это был не 【мой】.

It wasn't mine.

[[Russian#^ru-Q0198-answer|Compare the answer]]
^ru-Q0198

**ru-Q0199 · Fill the gap**

Это ____ корова.

This is my cow.

[[Russian#^ru-Q0199-answer|Compare the answer]]
^ru-Q0199

**ru-Q0200 · Choose the form**

Это ____ корова.

This is my cow.

Choices: мои / моя / мой / наш

[[Russian#^ru-Q0200-answer|Compare the answer]]
^ru-Q0200


### Locative prepositions · 50 questions

**ru-Q0201 · Edit the changed sentence**

Пойди поговори 【в】 ними.

Go talk to them.

[[Russian#^ru-Q0201-answer|Compare the answer]]
^ru-Q0201

**ru-Q0202 · Build the sentence**

Arrange: ними. / Пойди / поговори / с

Go talk to them.

[[Russian#^ru-Q0202-answer|Compare the answer]]
^ru-Q0202

**ru-Q0203 · Write a translation**

Write this in Russian: None of them are busy.

[[Russian#^ru-Q0203-answer|Compare the answer]]
^ru-Q0203

**ru-Q0204 · Explain the grammar**

Никто 【из】 них не занят.

None of them are busy.

[[Russian#^ru-Q0204-answer|Compare the answer]]
^ru-Q0204

**ru-Q0205 · Fill the gap**

Том встретил Мэри сегодня утром по дороге ____ школу.

Tom met Mary this morning on his way to school.

[[Russian#^ru-Q0205-answer|Compare the answer]]
^ru-Q0205

**ru-Q0206 · Choose the form**

Том встретил Мэри сегодня утром по дороге ____ школу.

Tom met Mary this morning on his way to school.

Choices: в / к / из / на

[[Russian#^ru-Q0206-answer|Compare the answer]]
^ru-Q0206

**ru-Q0207 · Edit the changed sentence**

Том даже не захотел говорить 【в】 Мэри.

Tom didn't even want to talk to Mary.

[[Russian#^ru-Q0207-answer|Compare the answer]]
^ru-Q0207

**ru-Q0208 · Build the sentence**

Arrange: не / Мэри. / Том / с / даже / говорить / захотел

Tom didn't even want to talk to Mary.

[[Russian#^ru-Q0208-answer|Compare the answer]]
^ru-Q0208

**ru-Q0209 · Write a translation**

Write this in Russian: Is it proper to enter a mosque wearing dirty socks?

[[Russian#^ru-Q0209-answer|Compare the answer]]
^ru-Q0209

**ru-Q0210 · Explain the grammar**

Правильно ли входить 【в】 мечеть в грязных носках?

Is it proper to enter a mosque wearing dirty socks?

[[Russian#^ru-Q0210-answer|Compare the answer]]
^ru-Q0210

**ru-Q0211 · Fill the gap**

Том подбавил дров ____ огонь.

Tom added wood to the fire.

[[Russian#^ru-Q0211-answer|Compare the answer]]
^ru-Q0211

**ru-Q0212 · Choose the form**

Том подбавил дров ____ огонь.

Tom added wood to the fire.

Choices: на / в / к / из

[[Russian#^ru-Q0212-answer|Compare the answer]]
^ru-Q0212

**ru-Q0213 · Edit the changed sentence**

Что было 【на】 духовке?

What was in the oven?

[[Russian#^ru-Q0213-answer|Compare the answer]]
^ru-Q0213

**ru-Q0214 · Build the sentence**

Arrange: в / было / духовке? / Что

What was in the oven?

[[Russian#^ru-Q0214-answer|Compare the answer]]
^ru-Q0214

**ru-Q0215 · Write a translation**

Write this in Russian: Sami and Layla were taking their lunches at a cozy hotel.

[[Russian#^ru-Q0215-answer|Compare the answer]]
^ru-Q0215

**ru-Q0216 · Explain the grammar**

Сами и Лейла обедали 【в】 уютной гостинице.

Sami and Layla were taking their lunches at a cozy hotel.

[[Russian#^ru-Q0216-answer|Compare the answer]]
^ru-Q0216

**ru-Q0217 · Fill the gap**

Вы ____ ними поговорили?

Have you talked to them?

[[Russian#^ru-Q0217-answer|Compare the answer]]
^ru-Q0217

**ru-Q0218 · Choose the form**

Вы ____ ними поговорили?

Have you talked to them?

Choices: из / с / на / в

[[Russian#^ru-Q0218-answer|Compare the answer]]
^ru-Q0218

**ru-Q0219 · Edit the changed sentence**

Я много тусовался 【в】 Томом.

I hang out with Tom a lot.

[[Russian#^ru-Q0219-answer|Compare the answer]]
^ru-Q0219

**ru-Q0220 · Build the sentence**

Arrange: тусовался / с / много / Томом. / Я

I hang out with Tom a lot.

[[Russian#^ru-Q0220-answer|Compare the answer]]
^ru-Q0220

**ru-Q0221 · Write a translation**

Write this in Russian: When was the last time you went fishing with Tom?

[[Russian#^ru-Q0221-answer|Compare the answer]]
^ru-Q0221

**ru-Q0222 · Explain the grammar**

Когда вы 【в】 последний раз ходили с Томом на рыбалку?

When was the last time you went fishing with Tom?

[[Russian#^ru-Q0222-answer|Compare the answer]]
^ru-Q0222

**ru-Q0223 · Fill the gap**

Ты не должен ни ____ кем обсуждать этот вопрос.

You must not discuss this matter with anyone.

[[Russian#^ru-Q0223-answer|Compare the answer]]
^ru-Q0223

**ru-Q0224 · Choose the form**

Ты не должен ни ____ кем обсуждать этот вопрос.

You must not discuss this matter with anyone.

Choices: с / на / из / в

[[Russian#^ru-Q0224-answer|Compare the answer]]
^ru-Q0224

**ru-Q0225 · Edit the changed sentence**

Том сейчас 【в】 работе в опале после нескольких самовольных отгулов.

Tom's in the doghouse at work, following several unapproved days off.

[[Russian#^ru-Q0225-answer|Compare the answer]]
^ru-Q0225

**ru-Q0226 · Build the sentence**

Arrange: работе / в / отгулов. / нескольких / опале / после / сейчас / самовольных / Том / на

Tom's in the doghouse at work, following several unapproved days off.

[[Russian#^ru-Q0226-answer|Compare the answer]]
^ru-Q0226

**ru-Q0227 · Write a translation**

Write this in Russian: China is the largest producer and consumer of coal in the world.

[[Russian#^ru-Q0227-answer|Compare the answer]]
^ru-Q0227

**ru-Q0228 · Explain the grammar**

Китай — крупнейший производитель и потребитель угля 【в】 мире.

China is the largest producer and consumer of coal in the world.

[[Russian#^ru-Q0228-answer|Compare the answer]]
^ru-Q0228

**ru-Q0229 · Fill the gap**

Почему ты не отправился ____ полицию?

Why haven't you gone to the police?

[[Russian#^ru-Q0229-answer|Compare the answer]]
^ru-Q0229

**ru-Q0230 · Choose the form**

Почему ты не отправился ____ полицию?

Why haven't you gone to the police?

Choices: к / в / из / на

[[Russian#^ru-Q0230-answer|Compare the answer]]
^ru-Q0230

**ru-Q0231 · Edit the changed sentence**

Вы согласны 【в】 рекомендациями Тома?

Do you agree with Tom's recommendations?

[[Russian#^ru-Q0231-answer|Compare the answer]]
^ru-Q0231

**ru-Q0232 · Build the sentence**

Arrange: Вы / рекомендациями / с / Тома? / согласны

Do you agree with Tom's recommendations?

[[Russian#^ru-Q0232-answer|Compare the answer]]
^ru-Q0232

**ru-Q0233 · Write a translation**

Write this in Russian: Can I speak to her?

[[Russian#^ru-Q0233-answer|Compare the answer]]
^ru-Q0233

**ru-Q0234 · Explain the grammar**

Я могу 【с】 ней поговорить?

Can I speak to her?

[[Russian#^ru-Q0234-answer|Compare the answer]]
^ru-Q0234

**ru-Q0235 · Fill the gap**

Том будет завтра играть ____ теннис.

Tom will play tennis tomorrow.

[[Russian#^ru-Q0235-answer|Compare the answer]]
^ru-Q0235

**ru-Q0236 · Choose the form**

Том будет завтра играть ____ теннис.

Tom will play tennis tomorrow.

Choices: к / из / в / на

[[Russian#^ru-Q0236-answer|Compare the answer]]
^ru-Q0236

**ru-Q0237 · Edit the changed sentence**

【на】 самом деле? Я этого не знал.

Really? I didn't know that.

[[Russian#^ru-Q0237-answer|Compare the answer]]
^ru-Q0237

**ru-Q0238 · Build the sentence**

Arrange: самом / этого / не / Я / деле? / знал. / В

Really? I didn't know that.

[[Russian#^ru-Q0238-answer|Compare the answer]]
^ru-Q0238

**ru-Q0239 · Write a translation**

Write this in Russian: I often wear blue jeans and a blue shirt.

[[Russian#^ru-Q0239-answer|Compare the answer]]
^ru-Q0239

**ru-Q0240 · Explain the grammar**

Я часто хожу 【в】 джинсах и синей рубашке.

I often wear blue jeans and a blue shirt.

[[Russian#^ru-Q0240-answer|Compare the answer]]
^ru-Q0240

**ru-Q0241 · Fill the gap**

Мы ____ Томом не дураки.

Tom and I aren't fools.

[[Russian#^ru-Q0241-answer|Compare the answer]]
^ru-Q0241

**ru-Q0242 · Choose the form**

Мы ____ Томом не дураки.

Tom and I aren't fools.

Choices: на / из / с / в

[[Russian#^ru-Q0242-answer|Compare the answer]]
^ru-Q0242

**ru-Q0243 · Edit the changed sentence**

Почему 【в】 берёз белая кора?

Why do birch trees have white bark?

[[Russian#^ru-Q0243-answer|Compare the answer]]
^ru-Q0243

**ru-Q0244 · Build the sentence**

Arrange: берёз / Почему / кора? / у / белая

Why do birch trees have white bark?

[[Russian#^ru-Q0244-answer|Compare the answer]]
^ru-Q0244

**ru-Q0245 · Write a translation**

Write this in Russian: Tom will probably go to Boston next week.

[[Russian#^ru-Q0245-answer|Compare the answer]]
^ru-Q0245

**ru-Q0246 · Explain the grammar**

Том, вероятно, поедет 【в】 Бостон на следующей неделе.

Tom will probably go to Boston next week.

[[Russian#^ru-Q0246-answer|Compare the answer]]
^ru-Q0246

**ru-Q0247 · Fill the gap**

Я был во многих местах ____ Ирландии.

I've been to many places in Ireland.

[[Russian#^ru-Q0247-answer|Compare the answer]]
^ru-Q0247

**ru-Q0248 · Choose the form**

Я был во многих местах ____ Ирландии.

I've been to many places in Ireland.

Choices: из / к / на / в

[[Russian#^ru-Q0248-answer|Compare the answer]]
^ru-Q0248

**ru-Q0249 · Edit the changed sentence**

【в】 меня сейчас нет с собой письма.

I don't have the letter on me now.

[[Russian#^ru-Q0249-answer|Compare the answer]]
^ru-Q0249

**ru-Q0250 · Build the sentence**

Arrange: У / меня / нет / сейчас / собой / письма. / с

I don't have the letter on me now.

[[Russian#^ru-Q0250-answer|Compare the answer]]
^ru-Q0250


### Adjective agreement · 50 questions

**ru-Q0251 · Write a translation**

Write this in Russian: The storm did great harm to the crop.

[[Russian#^ru-Q0251-answer|Compare the answer]]
^ru-Q0251

**ru-Q0252 · Explain the grammar**

Шторм нанёс 【большой】 урон урожаю.

The storm did great harm to the crop.

[[Russian#^ru-Q0252-answer|Compare the answer]]
^ru-Q0252

**ru-Q0253 · Fill the gap**

У Тома уже ____ девушка.

Tom already has a new girlfriend.

[[Russian#^ru-Q0253-answer|Compare the answer]]
^ru-Q0253

**ru-Q0254 · Choose the form**

У Тома уже ____ девушка.

Tom already has a new girlfriend.

Choices: хорошее / хороший / хорошая / новая

[[Russian#^ru-Q0254-answer|Compare the answer]]
^ru-Q0254

**ru-Q0255 · Edit the changed sentence**

Математика — 【хорошая】 урок.

The mathematics class is good.

[[Russian#^ru-Q0255-answer|Compare the answer]]
^ru-Q0255

**ru-Q0256 · Build the sentence**

Arrange: урок. / хороший / Математика / —

The mathematics class is good.

[[Russian#^ru-Q0256-answer|Compare the answer]]
^ru-Q0256

**ru-Q0257 · Write a translation**

Write this in Russian: It was a good job.

[[Russian#^ru-Q0257-answer|Compare the answer]]
^ru-Q0257

**ru-Q0258 · Explain the grammar**

Это была 【хорошая】 работа.

It was a good job.

[[Russian#^ru-Q0258-answer|Compare the answer]]
^ru-Q0258

**ru-Q0259 · Fill the gap**

Он слишком ____.

It's too small.

[[Russian#^ru-Q0259-answer|Compare the answer]]
^ru-Q0259

**ru-Q0260 · Choose the form**

Он слишком ____.

It's too small.

Choices: хорошее / хороший / маленький / хорошая

[[Russian#^ru-Q0260-answer|Compare the answer]]
^ru-Q0260

**ru-Q0261 · Edit the changed sentence**

Из дешёвого мяса 【хорошая】 суп ты не сваришь.

You can't make good soup with cheap meat.

[[Russian#^ru-Q0261-answer|Compare the answer]]
^ru-Q0261

**ru-Q0262 · Build the sentence**

Arrange: мяса / не / Из / сваришь. / ты / дешёвого / суп / хороший

You can't make good soup with cheap meat.

[[Russian#^ru-Q0262-answer|Compare the answer]]
^ru-Q0262

**ru-Q0263 · Write a translation**

Write this in Russian: Tom had a big argument with Mary.

[[Russian#^ru-Q0263-answer|Compare the answer]]
^ru-Q0263

**ru-Q0264 · Explain the grammar**

У Тома был 【большой】 спор с Машей.

Tom had a big argument with Mary.

[[Russian#^ru-Q0264-answer|Compare the answer]]
^ru-Q0264

**ru-Q0265 · Fill the gap**

Приезжайте в Албанию, там мы всегда делаем ____ кофе.

Come to Albania, we always make good coffee there.

[[Russian#^ru-Q0265-answer|Compare the answer]]
^ru-Q0265

**ru-Q0266 · Choose the form**

Приезжайте в Албанию, там мы всегда делаем ____ кофе.

Come to Albania, we always make good coffee there.

Choices: хорошее / хороший / хорошая

[[Russian#^ru-Q0266-answer|Compare the answer]]
^ru-Q0266

**ru-Q0267 · Edit the changed sentence**

Том очень 【хорошая】 музыкант.

Tom is a very good musician.

[[Russian#^ru-Q0267-answer|Compare the answer]]
^ru-Q0267

**ru-Q0268 · Build the sentence**

Arrange: музыкант. / очень / хороший / Том

Tom is a very good musician.

[[Russian#^ru-Q0268-answer|Compare the answer]]
^ru-Q0268

**ru-Q0269 · Write a translation**

Write this in Russian: I'm Tom's new secretary.

[[Russian#^ru-Q0269-answer|Compare the answer]]
^ru-Q0269

**ru-Q0270 · Explain the grammar**

Я 【новый】 секретарь Тома.

I'm Tom's new secretary.

[[Russian#^ru-Q0270-answer|Compare the answer]]
^ru-Q0270

**ru-Q0271 · Fill the gap**

Дырка достаточно ____.

The hole is big enough.

[[Russian#^ru-Q0271-answer|Compare the answer]]
^ru-Q0271

**ru-Q0272 · Choose the form**

Дырка достаточно ____.

The hole is big enough.

Choices: большая / хороший / хорошее / хорошая

[[Russian#^ru-Q0272-answer|Compare the answer]]
^ru-Q0272

**ru-Q0273 · Edit the changed sentence**

Почему ты считаешь, что это 【хороший】 идея?

Why do you think that's a good idea?

[[Russian#^ru-Q0273-answer|Compare the answer]]
^ru-Q0273

**ru-Q0274 · Build the sentence**

Arrange: это / хорошая / идея? / что / считаешь, / Почему / ты

Why do you think that's a good idea?

[[Russian#^ru-Q0274-answer|Compare the answer]]
^ru-Q0274

**ru-Q0275 · Write a translation**

Write this in Russian: Reading is a good activity.

[[Russian#^ru-Q0275-answer|Compare the answer]]
^ru-Q0275

**ru-Q0276 · Explain the grammar**

Чтение 【хорошее】 занятие.

Reading is a good activity.

[[Russian#^ru-Q0276-answer|Compare the answer]]
^ru-Q0276

**ru-Q0277 · Fill the gap**

Том был убеждён, что это ____ идея.

Tom was convinced it was a good idea.

[[Russian#^ru-Q0277-answer|Compare the answer]]
^ru-Q0277

**ru-Q0278 · Choose the form**

Том был убеждён, что это ____ идея.

Tom was convinced it was a good idea.

Choices: хорошее / хороший / хорошая

[[Russian#^ru-Q0278-answer|Compare the answer]]
^ru-Q0278

**ru-Q0279 · Edit the changed sentence**

Тому очень нравится 【хороший】 работа.

Tom really likes his new job

[[Russian#^ru-Q0279-answer|Compare the answer]]
^ru-Q0279

**ru-Q0280 · Build the sentence**

Arrange: новая / Тому / очень / работа. / нравится

Tom really likes his new job

[[Russian#^ru-Q0280-answer|Compare the answer]]
^ru-Q0280

**ru-Q0281 · Write a translation**

Write this in Russian: You've got a big mouth.

[[Russian#^ru-Q0281-answer|Compare the answer]]
^ru-Q0281

**ru-Q0282 · Explain the grammar**

У тебя 【большой】 рот.

You've got a big mouth.

[[Russian#^ru-Q0282-answer|Compare the answer]]
^ru-Q0282

**ru-Q0283 · Fill the gap**

____ разницы нет.

There's not a big difference.

[[Russian#^ru-Q0283-answer|Compare the answer]]
^ru-Q0283

**ru-Q0284 · Choose the form**

____ разницы нет.

There's not a big difference.

Choices: хорошее / хороший / хорошая / Большой

[[Russian#^ru-Q0284-answer|Compare the answer]]
^ru-Q0284

**ru-Q0285 · Edit the changed sentence**

【хороший】 дом мне нравится больше, чем старый.

I like the new house more than the old one.

[[Russian#^ru-Q0285-answer|Compare the answer]]
^ru-Q0285

**ru-Q0286 · Build the sentence**

Arrange: чем / дом / Новый / старый. / больше, / нравится / мне

I like the new house more than the old one.

[[Russian#^ru-Q0286-answer|Compare the answer]]
^ru-Q0286

**ru-Q0287 · Write a translation**

Write this in Russian: His house is not as large as my house.

[[Russian#^ru-Q0287-answer|Compare the answer]]
^ru-Q0287

**ru-Q0288 · Explain the grammar**

Его дом не такой 【большой】, как мой.

His house is not as large as my house.

[[Russian#^ru-Q0288-answer|Compare the answer]]
^ru-Q0288

**ru-Q0289 · Fill the gap**

Том - ____ бегун.

Tom is a good runner.

[[Russian#^ru-Q0289-answer|Compare the answer]]
^ru-Q0289

**ru-Q0290 · Choose the form**

Том - ____ бегун.

Tom is a good runner.

Choices: хорошее / хороший / хорошая

[[Russian#^ru-Q0290-answer|Compare the answer]]
^ru-Q0290

**ru-Q0291 · Edit the changed sentence**

Я купила 【хорошая】 фотоаппарат.

I bought a good camera.

[[Russian#^ru-Q0291-answer|Compare the answer]]
^ru-Q0291

**ru-Q0292 · Build the sentence**

Arrange: купила / хороший / фотоаппарат. / Я

I bought a good camera.

[[Russian#^ru-Q0292-answer|Compare the answer]]
^ru-Q0292

**ru-Q0293 · Write a translation**

Write this in Russian: There is a small pond in our garden.

[[Russian#^ru-Q0293-answer|Compare the answer]]
^ru-Q0293

**ru-Q0294 · Explain the grammar**

В нашем саду есть 【маленький】 пруд.

There is a small pond in our garden.

[[Russian#^ru-Q0294-answer|Compare the answer]]
^ru-Q0294

**ru-Q0295 · Fill the gap**

Она улыбнулась и приняла мой ____ подарок.

She smiled and accepted my little present.

[[Russian#^ru-Q0295-answer|Compare the answer]]
^ru-Q0295

**ru-Q0296 · Choose the form**

Она улыбнулась и приняла мой ____ подарок.

She smiled and accepted my little present.

Choices: маленький / хорошая / хорошее / хороший

[[Russian#^ru-Q0296-answer|Compare the answer]]
^ru-Q0296

**ru-Q0297 · Edit the changed sentence**

Думаю, это 【хороший】 идея.

I think it's a good idea.

[[Russian#^ru-Q0297-answer|Compare the answer]]
^ru-Q0297

**ru-Q0298 · Build the sentence**

Arrange: идея. / хорошая / Думаю, / это

I think it's a good idea.

[[Russian#^ru-Q0298-answer|Compare the answer]]
^ru-Q0298

**ru-Q0299 · Write a translation**

Write this in Russian: Tom has a new number.

[[Russian#^ru-Q0299-answer|Compare the answer]]
^ru-Q0299

**ru-Q0300 · Explain the grammar**

У Тома 【новый】 номер.

Tom has a new number.

[[Russian#^ru-Q0300-answer|Compare the answer]]
^ru-Q0300


### Past forms of быть · 50 questions

**ru-Q0301 · Fill the gap**

Том ____ напуган до смерти.

Tom was scared to death.

[[Russian#^ru-Q0301-answer|Compare the answer]]
^ru-Q0301

**ru-Q0302 · Choose the form**

Том ____ напуган до смерти.

Tom was scared to death.

Choices: были / был / была / было

[[Russian#^ru-Q0302-answer|Compare the answer]]
^ru-Q0302

**ru-Q0303 · Edit the changed sentence**

Том тоже 【была】 сильно голоден.

Tom also was very hungry.

[[Russian#^ru-Q0303-answer|Compare the answer]]
^ru-Q0303

**ru-Q0304 · Build the sentence**

Arrange: тоже / голоден. / Том / был / сильно

Tom also was very hungry.

[[Russian#^ru-Q0304-answer|Compare the answer]]
^ru-Q0304

**ru-Q0305 · Write a translation**

Write this in Russian: I think you were right.

[[Russian#^ru-Q0305-answer|Compare the answer]]
^ru-Q0305

**ru-Q0306 · Explain the grammar**

Думаю, ты 【была】 права.

I think you were right.

[[Russian#^ru-Q0306-answer|Compare the answer]]
^ru-Q0306

**ru-Q0307 · Fill the gap**

Это ____ ложная тревога.

It was a false alarm.

[[Russian#^ru-Q0307-answer|Compare the answer]]
^ru-Q0307

**ru-Q0308 · Choose the form**

Это ____ ложная тревога.

It was a false alarm.

Choices: был / было / была / были

[[Russian#^ru-Q0308-answer|Compare the answer]]
^ru-Q0308

**ru-Q0309 · Edit the changed sentence**

Мария 【был】 разочарована.

Mary was disappointed.

[[Russian#^ru-Q0309-answer|Compare the answer]]
^ru-Q0309

**ru-Q0310 · Build the sentence**

Arrange: была / разочарована. / Мария

Mary was disappointed.

[[Russian#^ru-Q0310-answer|Compare the answer]]
^ru-Q0310

**ru-Q0311 · Write a translation**

Write this in Russian: He married twice and had more than 20 children.

[[Russian#^ru-Q0311-answer|Compare the answer]]
^ru-Q0311

**ru-Q0312 · Explain the grammar**

Он 【был】 дважды женат, и у него было более двадцати детей.

He married twice and had more than 20 children.

[[Russian#^ru-Q0312-answer|Compare the answer]]
^ru-Q0312

**ru-Q0313 · Fill the gap**

У нас в последнее время ____ много дождей.

We've had a lot of rain recently.

[[Russian#^ru-Q0313-answer|Compare the answer]]
^ru-Q0313

**ru-Q0314 · Choose the form**

У нас в последнее время ____ много дождей.

We've had a lot of rain recently.

Choices: была / было / был / были

[[Russian#^ru-Q0314-answer|Compare the answer]]
^ru-Q0314

**ru-Q0315 · Edit the changed sentence**

Я 【была】 в ужасе.

I was horrified.

[[Russian#^ru-Q0315-answer|Compare the answer]]
^ru-Q0315

**ru-Q0316 · Build the sentence**

Arrange: в / Я / ужасе. / был

I was horrified.

[[Russian#^ru-Q0316-answer|Compare the answer]]
^ru-Q0316

**ru-Q0317 · Write a translation**

Write this in Russian: One student was arrested.

[[Russian#^ru-Q0317-answer|Compare the answer]]
^ru-Q0317

**ru-Q0318 · Explain the grammar**

Одна студентка 【была】 арестована.

One student was arrested.

[[Russian#^ru-Q0318-answer|Compare the answer]]
^ru-Q0318

**ru-Q0319 · Fill the gap**

Её не ____ в школе, потому что она болела.

She was absent from school because she was sick.

[[Russian#^ru-Q0319-answer|Compare the answer]]
^ru-Q0319

**ru-Q0320 · Choose the form**

Её не ____ в школе, потому что она болела.

She was absent from school because she was sick.

Choices: была / был / было / были

[[Russian#^ru-Q0320-answer|Compare the answer]]
^ru-Q0320

**ru-Q0321 · Edit the changed sentence**

Они 【был】 солдатами.

They were soldiers.

[[Russian#^ru-Q0321-answer|Compare the answer]]
^ru-Q0321

**ru-Q0322 · Build the sentence**

Arrange: были / Они / солдатами.

They were soldiers.

[[Russian#^ru-Q0322-answer|Compare the answer]]
^ru-Q0322

**ru-Q0323 · Write a translation**

Write this in Russian: We shouldn't have let you go.

[[Russian#^ru-Q0323-answer|Compare the answer]]
^ru-Q0323

**ru-Q0324 · Explain the grammar**

Нам не надо 【было】 вас отпускать.

We shouldn't have let you go.

[[Russian#^ru-Q0324-answer|Compare the answer]]
^ru-Q0324

**ru-Q0325 · Fill the gap**

У него ничего не ____.

He had nothing.

[[Russian#^ru-Q0325-answer|Compare the answer]]
^ru-Q0325

**ru-Q0326 · Choose the form**

У него ничего не ____.

He had nothing.

Choices: был / были / была / было

[[Russian#^ru-Q0326-answer|Compare the answer]]
^ru-Q0326

**ru-Q0327 · Edit the changed sentence**

Их глубокая любовь к друг другу 【был】 однозначна.

Their deep love for each other was unequivocal.

[[Russian#^ru-Q0327-answer|Compare the answer]]
^ru-Q0327

**ru-Q0328 · Build the sentence**

Arrange: Их / была / другу / к / любовь / однозначна. / друг / глубокая

Their deep love for each other was unequivocal.

[[Russian#^ru-Q0328-answer|Compare the answer]]
^ru-Q0328

**ru-Q0329 · Write a translation**

Write this in Russian: Do you remember how slow the Internet was?

[[Russian#^ru-Q0329-answer|Compare the answer]]
^ru-Q0329

**ru-Q0330 · Explain the grammar**

Вы помните, какой медленный 【был】 Интернет?

Do you remember how slow the Internet was?

[[Russian#^ru-Q0330-answer|Compare the answer]]
^ru-Q0330

**ru-Q0331 · Fill the gap**

Мне ____ очень интересно.

I was very interested.

[[Russian#^ru-Q0331-answer|Compare the answer]]
^ru-Q0331

**ru-Q0332 · Choose the form**

Мне ____ очень интересно.

I was very interested.

Choices: была / был / были / было

[[Russian#^ru-Q0332-answer|Compare the answer]]
^ru-Q0332

**ru-Q0333 · Edit the changed sentence**

Том 【была】 успешным предпринимателем.

Tom was a successful businessman.

[[Russian#^ru-Q0333-answer|Compare the answer]]
^ru-Q0333

**ru-Q0334 · Build the sentence**

Arrange: был / успешным / предпринимателем. / Том

Tom was a successful businessman.

[[Russian#^ru-Q0334-answer|Compare the answer]]
^ru-Q0334

**ru-Q0335 · Write a translation**

Write this in Russian: The ambassador was recalled from Warsaw.

[[Russian#^ru-Q0335-answer|Compare the answer]]
^ru-Q0335

**ru-Q0336 · Explain the grammar**

Посол 【был】 отозван из Варшавы.

The ambassador was recalled from Warsaw.

[[Russian#^ru-Q0336-answer|Compare the answer]]
^ru-Q0336

**ru-Q0337 · Fill the gap**

Тебе надо ____ попросить у Тома прощения.

You should've apologized to Tom.

[[Russian#^ru-Q0337-answer|Compare the answer]]
^ru-Q0337

**ru-Q0338 · Choose the form**

Тебе надо ____ попросить у Тома прощения.

You should've apologized to Tom.

Choices: были / был / была / было

[[Russian#^ru-Q0338-answer|Compare the answer]]
^ru-Q0338

**ru-Q0339 · Edit the changed sentence**

Она 【был】 очаровательной женщиной.

She was a charming woman.

[[Russian#^ru-Q0339-answer|Compare the answer]]
^ru-Q0339

**ru-Q0340 · Build the sentence**

Arrange: была / очаровательной / женщиной. / Она

She was a charming woman.

[[Russian#^ru-Q0340-answer|Compare the answer]]
^ru-Q0340

**ru-Q0341 · Write a translation**

Write this in Russian: You were busy last week.

[[Russian#^ru-Q0341-answer|Compare the answer]]
^ru-Q0341

**ru-Q0342 · Explain the grammar**

На прошлой неделе ты 【был】 занят.

You were busy last week.

[[Russian#^ru-Q0342-answer|Compare the answer]]
^ru-Q0342

**ru-Q0343 · Fill the gap**

Он ____ с ним знаком?

Did he know him?

[[Russian#^ru-Q0343-answer|Compare the answer]]
^ru-Q0343

**ru-Q0344 · Choose the form**

Он ____ с ним знаком?

Did he know him?

Choices: было / был / была / были

[[Russian#^ru-Q0344-answer|Compare the answer]]
^ru-Q0344

**ru-Q0345 · Edit the changed sentence**

Я ни в одном из тех ресторанов не 【была】.

I haven't been to either of those restaurants.

[[Russian#^ru-Q0345-answer|Compare the answer]]
^ru-Q0345

**ru-Q0346 · Build the sentence**

Arrange: в / тех / не / был. / из / одном / ресторанов / Я / ни

I haven't been to either of those restaurants.

[[Russian#^ru-Q0346-answer|Compare the answer]]
^ru-Q0346

**ru-Q0347 · Write a translation**

Write this in Russian: Tom was my assistant.

[[Russian#^ru-Q0347-answer|Compare the answer]]
^ru-Q0347

**ru-Q0348 · Explain the grammar**

Том 【был】 моим помощником.

Tom was my assistant.

[[Russian#^ru-Q0348-answer|Compare the answer]]
^ru-Q0348

**ru-Q0349 · Fill the gap**

Том ____ бездомным.

Tom was homeless.

[[Russian#^ru-Q0349-answer|Compare the answer]]
^ru-Q0349

**ru-Q0350 · Choose the form**

Том ____ бездомным.

Tom was homeless.

Choices: было / были / была / был

[[Russian#^ru-Q0350-answer|Compare the answer]]
^ru-Q0350


### Common present verbs · 50 questions

**ru-Q0351 · Edit the changed sentence**

【знаю】, когда-нибудь это произойдёт.

I think that'll happen someday.

[[Russian#^ru-Q0351-answer|Compare the answer]]
^ru-Q0351

**ru-Q0352 · Build the sentence**

Arrange: это / когда-нибудь / произойдёт. / Думаю,

I think that'll happen someday.

[[Russian#^ru-Q0352-answer|Compare the answer]]
^ru-Q0352

**ru-Q0353 · Write a translation**

Write this in Russian: Tom doesn't know much.

[[Russian#^ru-Q0353-answer|Compare the answer]]
^ru-Q0353

**ru-Q0354 · Explain the grammar**

Том мало что 【знает】.

Tom doesn't know much.

[[Russian#^ru-Q0354-answer|Compare the answer]]
^ru-Q0354

**ru-Q0355 · Fill the gap**

Том никогда не ____ о других.

Tom never thinks about others.

[[Russian#^ru-Q0355-answer|Compare the answer]]
^ru-Q0355

**ru-Q0356 · Choose the form**

Том никогда не ____ о других.

Tom never thinks about others.

Choices: думает / знаешь / знает / знаю

[[Russian#^ru-Q0356-answer|Compare the answer]]
^ru-Q0356

**ru-Q0357 · Edit the changed sentence**

Я 【знаю】, что пора идти.

I suppose it's time to go.

[[Russian#^ru-Q0357-answer|Compare the answer]]
^ru-Q0357

**ru-Q0358 · Build the sentence**

Arrange: что / думаю, / пора / Я / идти.

I suppose it's time to go.

[[Russian#^ru-Q0358-answer|Compare the answer]]
^ru-Q0358

**ru-Q0359 · Write a translation**

Write this in Russian: I think you'll need a loan.

[[Russian#^ru-Q0359-answer|Compare the answer]]
^ru-Q0359

**ru-Q0360 · Explain the grammar**

【Думаю】, тебе понадобится кредит.

I think you'll need a loan.

[[Russian#^ru-Q0360-answer|Compare the answer]]
^ru-Q0360

**ru-Q0361 · Fill the gap**

Всё, что он ____, — правда.

All that he says is true.

[[Russian#^ru-Q0361-answer|Compare the answer]]
^ru-Q0361

**ru-Q0362 · Choose the form**

Всё, что он ____, — правда.

All that he says is true.

Choices: знает / знаешь / говорит / знаю

[[Russian#^ru-Q0362-answer|Compare the answer]]
^ru-Q0362

**ru-Q0363 · Edit the changed sentence**

Она 【знаю】, что здорова.

She says that she's healthy.

[[Russian#^ru-Q0363-answer|Compare the answer]]
^ru-Q0363

**ru-Q0364 · Build the sentence**

Arrange: говорит, / Она / что / здорова.

She says that she's healthy.

[[Russian#^ru-Q0364-answer|Compare the answer]]
^ru-Q0364

**ru-Q0365 · Write a translation**

Write this in Russian: I don't think it affects us.

[[Russian#^ru-Q0365-answer|Compare the answer]]
^ru-Q0365

**ru-Q0366 · Explain the grammar**

Не 【думаю】, что это нас касается.

I don't think it affects us.

[[Russian#^ru-Q0366-answer|Compare the answer]]
^ru-Q0366

**ru-Q0367 · Fill the gap**

Не ____, что здесь это разрешено.

I don't think that's allowed here.

[[Russian#^ru-Q0367-answer|Compare the answer]]
^ru-Q0367

**ru-Q0368 · Choose the form**

Не ____, что здесь это разрешено.

I don't think that's allowed here.

Choices: знаю / знаешь / знает / думаю

[[Russian#^ru-Q0368-answer|Compare the answer]]
^ru-Q0368

**ru-Q0369 · Edit the changed sentence**

Он 【знаю】 так, словно знал преступника.

He speaks as if he knew the criminal.

[[Russian#^ru-Q0369-answer|Compare the answer]]
^ru-Q0369

**ru-Q0370 · Build the sentence**

Arrange: знал / словно / говорит / преступника. / так, / Он

He speaks as if he knew the criminal.

[[Russian#^ru-Q0370-answer|Compare the answer]]
^ru-Q0370

**ru-Q0371 · Write a translation**

Write this in Russian: Do you know where it is?

[[Russian#^ru-Q0371-answer|Compare the answer]]
^ru-Q0371

**ru-Q0372 · Explain the grammar**

Ты 【знаешь】, где это?

Do you know where it is?

[[Russian#^ru-Q0372-answer|Compare the answer]]
^ru-Q0372

**ru-Q0373 · Fill the gap**

Ты ____ английский?

Do you know how to speak English?

[[Russian#^ru-Q0373-answer|Compare the answer]]
^ru-Q0373

**ru-Q0374 · Choose the form**

Ты ____ английский?

Do you know how to speak English?

Choices: знаешь / знаю / знаем / знает

[[Russian#^ru-Q0374-answer|Compare the answer]]
^ru-Q0374

**ru-Q0375 · Edit the changed sentence**

Том об этом 【знаю】.

Tom knows about that.

[[Russian#^ru-Q0375-answer|Compare the answer]]
^ru-Q0375

**ru-Q0376 · Build the sentence**

Arrange: об / знает. / Том / этом

Tom knows about that.

[[Russian#^ru-Q0376-answer|Compare the answer]]
^ru-Q0376

**ru-Q0377 · Write a translation**

Write this in Russian: I know Tom wants us to help him.

[[Russian#^ru-Q0377-answer|Compare the answer]]
^ru-Q0377

**ru-Q0378 · Explain the grammar**

Я 【знаю】, что Том хочет, чтобы мы ему помогли.

I know Tom wants us to help him.

[[Russian#^ru-Q0378-answer|Compare the answer]]
^ru-Q0378

**ru-Q0379 · Fill the gap**

Я ____, что Том сделал это один.

I know that Tom did that alone.

[[Russian#^ru-Q0379-answer|Compare the answer]]
^ru-Q0379

**ru-Q0380 · Choose the form**

Я ____, что Том сделал это один.

I know that Tom did that alone.

Choices: знаю / знаешь / знает / знаем

[[Russian#^ru-Q0380-answer|Compare the answer]]
^ru-Q0380

**ru-Q0381 · Edit the changed sentence**

【знаю】, я нашёл способ помочь вам.

I think I've found a way to help you.

[[Russian#^ru-Q0381-answer|Compare the answer]]
^ru-Q0381

**ru-Q0382 · Build the sentence**

Arrange: помочь / нашёл / вам. / Думаю, / способ / я

I think I've found a way to help you.

[[Russian#^ru-Q0382-answer|Compare the answer]]
^ru-Q0382

**ru-Q0383 · Write a translation**

Write this in Russian: I don't know which one I want.

[[Russian#^ru-Q0383-answer|Compare the answer]]
^ru-Q0383

**ru-Q0384 · Explain the grammar**

Я не 【знаю】, какой хочу.

I don't know which one I want.

[[Russian#^ru-Q0384-answer|Compare the answer]]
^ru-Q0384

**ru-Q0385 · Fill the gap**

Том совершенно не представляет, о чём сейчас ____ Маша.

Tom doesn't have any idea what Mary is thinking.

[[Russian#^ru-Q0385-answer|Compare the answer]]
^ru-Q0385

**ru-Q0386 · Choose the form**

Том совершенно не представляет, о чём сейчас ____ Маша.

Tom doesn't have any idea what Mary is thinking.

Choices: знает / думает / знаю / знаешь

[[Russian#^ru-Q0386-answer|Compare the answer]]
^ru-Q0386

**ru-Q0387 · Edit the changed sentence**

Я не понимаю, что она 【знаю】.

I can't understand what she says.

[[Russian#^ru-Q0387-answer|Compare the answer]]
^ru-Q0387

**ru-Q0388 · Build the sentence**

Arrange: она / понимаю, / говорит. / что / не / Я

I can't understand what she says.

[[Russian#^ru-Q0388-answer|Compare the answer]]
^ru-Q0388

**ru-Q0389 · Write a translation**

Write this in Russian: I know you're not a doctor.

[[Russian#^ru-Q0389-answer|Compare the answer]]
^ru-Q0389

**ru-Q0390 · Explain the grammar**

Я 【знаю】, что Вы не врач.

I know you're not a doctor.

[[Russian#^ru-Q0390-answer|Compare the answer]]
^ru-Q0390

**ru-Q0391 · Fill the gap**

Мэри ____, что не останется.

Mary says she won't stay.

[[Russian#^ru-Q0391-answer|Compare the answer]]
^ru-Q0391

**ru-Q0392 · Choose the form**

Мэри ____, что не останется.

Mary says she won't stay.

Choices: знаю / знаешь / говорит / знает

[[Russian#^ru-Q0392-answer|Compare the answer]]
^ru-Q0392

**ru-Q0393 · Edit the changed sentence**

Я 【знаешь】, что вам нужно было это сделать.

I know you needed to do that.

[[Russian#^ru-Q0393-answer|Compare the answer]]
^ru-Q0393

**ru-Q0394 · Build the sentence**

Arrange: нужно / вам / знаю, / Я / что / было / сделать. / это

I know you needed to do that.

[[Russian#^ru-Q0394-answer|Compare the answer]]
^ru-Q0394

**ru-Q0395 · Write a translation**

Write this in Russian: I understand what you mean, but I'm not sure how to translate it.

[[Russian#^ru-Q0395-answer|Compare the answer]]
^ru-Q0395

**ru-Q0396 · Explain the grammar**

Я понимаю, что Вы имеете в виду, но точно не 【знаю】, как это перевести.

I understand what you mean, but I'm not sure how to translate it.

[[Russian#^ru-Q0396-answer|Compare the answer]]
^ru-Q0396

**ru-Q0397 · Fill the gap**

Мы ____, что ты трус.

We know you're a coward.

[[Russian#^ru-Q0397-answer|Compare the answer]]
^ru-Q0397

**ru-Q0398 · Choose the form**

Мы ____, что ты трус.

We know you're a coward.

Choices: знает / знаю / знаешь / знаем

[[Russian#^ru-Q0398-answer|Compare the answer]]
^ru-Q0398

**ru-Q0399 · Edit the changed sentence**

Не 【знаешь】, почему я сегодня такая счастливая.

I don't know why I'm so happy today.

[[Russian#^ru-Q0399-answer|Compare the answer]]
^ru-Q0399

**ru-Q0400 · Build the sentence**

Arrange: я / счастливая. / сегодня / Не / почему / знаю, / такая

I don't know why I'm so happy today.

[[Russian#^ru-Q0400-answer|Compare the answer]]
^ru-Q0400


### Bounded past and aspect · 50 questions

**ru-Q0401 · Write a translation**

Write this in Russian: She said she wouldn't wait.

[[Russian#^ru-Q0401-answer|Compare the answer]]
^ru-Q0401

**ru-Q0402 · Explain the grammar**

Она 【сказала】, что не будет ждать.

She said she wouldn't wait.

[[Russian#^ru-Q0402-answer|Compare the answer]]
^ru-Q0402

**ru-Q0403 · Fill the gap**

Даже Том такого бы не ____.

Even Tom wouldn't do that.

[[Russian#^ru-Q0403-answer|Compare the answer]]
^ru-Q0403

**ru-Q0404 · Choose the form**

Даже Том такого бы не ____.

Even Tom wouldn't do that.

Choices: сделала / сказал / сказала / сделал

[[Russian#^ru-Q0404-answer|Compare the answer]]
^ru-Q0404

**ru-Q0405 · Edit the changed sentence**

Ты не в ответе за то, что 【сказал】 Том.

You aren't responsible for what Tom did.

[[Russian#^ru-Q0405-answer|Compare the answer]]
^ru-Q0405

**ru-Q0406 · Build the sentence**

Arrange: то, / Том. / Ты / не / за / сделал / что / ответе / в

You aren't responsible for what Tom did.

[[Russian#^ru-Q0406-answer|Compare the answer]]
^ru-Q0406

**ru-Q0407 · Write a translation**

Write this in Russian: Tom said you speak French better than Mary.

[[Russian#^ru-Q0407-answer|Compare the answer]]
^ru-Q0407

**ru-Q0408 · Explain the grammar**

Том 【сказал】, что вы говорите по-французски лучше Мэри.

Tom said you speak French better than Mary.

[[Russian#^ru-Q0408-answer|Compare the answer]]
^ru-Q0408

**ru-Q0409 · Fill the gap**

Том ____ мне, что ты счастлив.

Tom told me you were happy.

[[Russian#^ru-Q0409-answer|Compare the answer]]
^ru-Q0409

**ru-Q0410 · Choose the form**

Том ____ мне, что ты счастлив.

Tom told me you were happy.

Choices: сказала / сделал / сказал / сделала

[[Russian#^ru-Q0410-answer|Compare the answer]]
^ru-Q0410

**ru-Q0411 · Edit the changed sentence**

Том 【сказала】, что надеется, что Мэри не опоздает.

Tom said he hopes Mary won't be late.

[[Russian#^ru-Q0411-answer|Compare the answer]]
^ru-Q0411

**ru-Q0412 · Build the sentence**

Arrange: что / не / сказал, / Том / что / опоздает. / надеется, / Мэри

Tom said he hopes Mary won't be late.

[[Russian#^ru-Q0412-answer|Compare the answer]]
^ru-Q0412

**ru-Q0413 · Write a translation**

Write this in Russian: Tom perused the menu.

[[Russian#^ru-Q0413-answer|Compare the answer]]
^ru-Q0413

**ru-Q0414 · Explain the grammar**

Том внимательно 【прочитал】 меню.

Tom perused the menu.

[[Russian#^ru-Q0414-answer|Compare the answer]]
^ru-Q0414

**ru-Q0415 · Fill the gap**

Не забудь, что я ____.

Don't forget what I said.

[[Russian#^ru-Q0415-answer|Compare the answer]]
^ru-Q0415

**ru-Q0416 · Choose the form**

Не забудь, что я ____.

Don't forget what I said.

Choices: сделала / сказал / сделал / сказала

[[Russian#^ru-Q0416-answer|Compare the answer]]
^ru-Q0416

**ru-Q0417 · Edit the changed sentence**

Если бы я знала ее адрес, я бы 【сказал】 ей.

If I had known her address, I would have written to her.

[[Russian#^ru-Q0417-answer|Compare the answer]]
^ru-Q0417

**ru-Q0418 · Build the sentence**

Arrange: ее / бы / ей. / адрес, / я / Если / написала / я / знала / бы

If I had known her address, I would have written to her.

[[Russian#^ru-Q0418-answer|Compare the answer]]
^ru-Q0418

**ru-Q0419 · Write a translation**

Write this in Russian: I'll say I did it.

[[Russian#^ru-Q0419-answer|Compare the answer]]
^ru-Q0419

**ru-Q0420 · Explain the grammar**

Я скажу, что я 【сделал】 это.

I'll say I did it.

[[Russian#^ru-Q0420-answer|Compare the answer]]
^ru-Q0420

**ru-Q0421 · Fill the gap**

Ты ведь специально это ____?

You did that intentionally, didn't you?

[[Russian#^ru-Q0421-answer|Compare the answer]]
^ru-Q0421

**ru-Q0422 · Choose the form**

Ты ведь специально это ____?

You did that intentionally, didn't you?

Choices: сказала / сказал / сделал / сделала

[[Russian#^ru-Q0422-answer|Compare the answer]]
^ru-Q0422

**ru-Q0423 · Edit the changed sentence**

Том 【сказала】, что хочет немного посмотреть телевизор.

Tom said he wanted to watch a little TV.

[[Russian#^ru-Q0423-answer|Compare the answer]]
^ru-Q0423

**ru-Q0424 · Build the sentence**

Arrange: сказал, / посмотреть / телевизор. / немного / хочет / Том / что

Tom said he wanted to watch a little TV.

[[Russian#^ru-Q0424-answer|Compare the answer]]
^ru-Q0424

**ru-Q0425 · Write a translation**

Write this in Russian: I saw a whale tail today.

[[Russian#^ru-Q0425-answer|Compare the answer]]
^ru-Q0425

**ru-Q0426 · Explain the grammar**

Я 【увидела】 хвост кита сегодня.

I saw a whale tail today.

[[Russian#^ru-Q0426-answer|Compare the answer]]
^ru-Q0426

**ru-Q0427 · Fill the gap**

Том ____, что опаздывает.

Tom said he was going to be late.

[[Russian#^ru-Q0427-answer|Compare the answer]]
^ru-Q0427

**ru-Q0428 · Choose the form**

Том ____, что опаздывает.

Tom said he was going to be late.

Choices: сделал / сказал / сделала / сказала

[[Russian#^ru-Q0428-answer|Compare the answer]]
^ru-Q0428

**ru-Q0429 · Edit the changed sentence**

Кто 【сказал】 ей?

Who wrote to her?

[[Russian#^ru-Q0429-answer|Compare the answer]]
^ru-Q0429

**ru-Q0430 · Build the sentence**

Arrange: ей? / написал / Кто

Who wrote to her?

[[Russian#^ru-Q0430-answer|Compare the answer]]
^ru-Q0430

**ru-Q0431 · Write a translation**

Write this in Russian: I already told your parents.

[[Russian#^ru-Q0431-answer|Compare the answer]]
^ru-Q0431

**ru-Q0432 · Explain the grammar**

Я уже 【сказал】 твоим родителям.

I already told your parents.

[[Russian#^ru-Q0432-answer|Compare the answer]]
^ru-Q0432

**ru-Q0433 · Fill the gap**

Что ты ____ полиции?

What did you tell the police?

[[Russian#^ru-Q0433-answer|Compare the answer]]
^ru-Q0433

**ru-Q0434 · Choose the form**

Что ты ____ полиции?

What did you tell the police?

Choices: сделала / сказал / сделал / сказала

[[Russian#^ru-Q0434-answer|Compare the answer]]
^ru-Q0434

**ru-Q0435 · Edit the changed sentence**

Пожалуйста, не говорите никому то, что я вам только что 【сказала】.

Please don't tell anybody what I just told you.

[[Russian#^ru-Q0435-answer|Compare the answer]]
^ru-Q0435

**ru-Q0436 · Build the sentence**

Arrange: сказал. / не / только / то, / говорите / Пожалуйста, / что / что / никому / вам / я

Please don't tell anybody what I just told you.

[[Russian#^ru-Q0436-answer|Compare the answer]]
^ru-Q0436

**ru-Q0437 · Write a translation**

Write this in Russian: I saw you yesterday at the funeral.

[[Russian#^ru-Q0437-answer|Compare the answer]]
^ru-Q0437

**ru-Q0438 · Explain the grammar**

Я 【увидела】 тебя вчера на похоронах.

I saw you yesterday at the funeral.

[[Russian#^ru-Q0438-answer|Compare the answer]]
^ru-Q0438

**ru-Q0439 · Fill the gap**

Мэри ____, что не верит этому.

Mary said she didn't believe it.

[[Russian#^ru-Q0439-answer|Compare the answer]]
^ru-Q0439

**ru-Q0440 · Choose the form**

Мэри ____, что не верит этому.

Mary said she didn't believe it.

Choices: сказал / сказала / сделала / сделал

[[Russian#^ru-Q0440-answer|Compare the answer]]
^ru-Q0440

**ru-Q0441 · Edit the changed sentence**

Мэри 【сказал】 мне, что поедет в Бостон в октябре.

Mary told me that she'd go to Boston in October.

[[Russian#^ru-Q0441-answer|Compare the answer]]
^ru-Q0441

**ru-Q0442 · Build the sentence**

Arrange: мне, / сказала / Мэри / что / октябре. / поедет / в / Бостон / в

Mary told me that she'd go to Boston in October.

[[Russian#^ru-Q0442-answer|Compare the answer]]
^ru-Q0442

**ru-Q0443 · Write a translation**

Write this in Russian: I would've told Tom if I had known.

[[Russian#^ru-Q0443-answer|Compare the answer]]
^ru-Q0443

**ru-Q0444 · Explain the grammar**

Я бы 【сказал】 Тому, если бы знал.

I would've told Tom if I had known.

[[Russian#^ru-Q0444-answer|Compare the answer]]
^ru-Q0444

**ru-Q0445 · Fill the gap**

Том ____, что Мэри настроена скептически.

Tom said Mary was skeptical.

[[Russian#^ru-Q0445-answer|Compare the answer]]
^ru-Q0445

**ru-Q0446 · Choose the form**

Том ____, что Мэри настроена скептически.

Tom said Mary was skeptical.

Choices: сделал / сказала / сделала / сказал

[[Russian#^ru-Q0446-answer|Compare the answer]]
^ru-Q0446

**ru-Q0447 · Edit the changed sentence**

«Что в лоб, что по лбу», — 【сказала】 он.

"Same difference", he said.

[[Russian#^ru-Q0447-answer|Compare the answer]]
^ru-Q0447

**ru-Q0448 · Build the sentence**

Arrange: сказал / — / «Что / в / лоб, / он. / что / по / лбу»,

"Same difference", he said.

[[Russian#^ru-Q0448-answer|Compare the answer]]
^ru-Q0448

**ru-Q0449 · Write a translation**

Write this in Russian: That's not what I told him.

[[Russian#^ru-Q0449-answer|Compare the answer]]
^ru-Q0449

**ru-Q0450 · Explain the grammar**

Я ему не это 【сказал】.

That's not what I told him.

[[Russian#^ru-Q0450-answer|Compare the answer]]
^ru-Q0450


### Future constructions · 50 questions

**ru-Q0451 · Fill the gap**

____ держать кулачки.

I'll keep my fingers crossed.

[[Russian#^ru-Q0451-answer|Compare the answer]]
^ru-Q0451

**ru-Q0452 · Choose the form**

____ держать кулачки.

I'll keep my fingers crossed.

Choices: будем / будет / Буду / будешь

[[Russian#^ru-Q0452-answer|Compare the answer]]
^ru-Q0452

**ru-Q0453 · Edit the changed sentence**

"На пикнике 【буду】 живая музыка". - "Что за музыка?"

"There will be live music at the picnic." "What kind of music?"

[[Russian#^ru-Q0453-answer|Compare the answer]]
^ru-Q0453

**ru-Q0454 · Build the sentence**

Arrange: живая / музыка?" / за / пикнике / музыка". / будет / "На / "Что / -

"There will be live music at the picnic." "What kind of music?"

[[Russian#^ru-Q0454-answer|Compare the answer]]
^ru-Q0454

**ru-Q0455 · Write a translation**

Write this in Russian: I will be very careful.

[[Russian#^ru-Q0455-answer|Compare the answer]]
^ru-Q0455

**ru-Q0456 · Explain the grammar**

Я 【буду】 очень осторожен.

I will be very careful.

[[Russian#^ru-Q0456-answer|Compare the answer]]
^ru-Q0456

**ru-Q0457 · Fill the gap**

Друзья ____ по вам скучать, когда вы уедете.

You will be missed by your friends when you're gone.

[[Russian#^ru-Q0457-answer|Compare the answer]]
^ru-Q0457

**ru-Q0458 · Choose the form**

Друзья ____ по вам скучать, когда вы уедете.

You will be missed by your friends when you're gone.

Choices: будет / будут / будешь / буду

[[Russian#^ru-Q0458-answer|Compare the answer]]
^ru-Q0458

**ru-Q0459 · Edit the changed sentence**

Я 【будешь】 там к концу недели.

I'll be there by the end of the week.

[[Russian#^ru-Q0459-answer|Compare the answer]]
^ru-Q0459

**ru-Q0460 · Build the sentence**

Arrange: концу / недели. / там / к / Я / буду

I'll be there by the end of the week.

[[Russian#^ru-Q0460-answer|Compare the answer]]
^ru-Q0460

**ru-Q0461 · Write a translation**

Write this in Russian: If it rains, we will put off our practice match.

[[Russian#^ru-Q0461-answer|Compare the answer]]
^ru-Q0461

**ru-Q0462 · Explain the grammar**

Если 【будет】 идти дождь, мы отменим тренировку.

If it rains, we will put off our practice match.

[[Russian#^ru-Q0462-answer|Compare the answer]]
^ru-Q0462

**ru-Q0463 · Fill the gap**

Если тебе когда-нибудь нужно ____ с кем-то поговорить, не стесняйся - звони мне.

If you ever need anyone to talk to, feel free to call me.

[[Russian#^ru-Q0463-answer|Compare the answer]]
^ru-Q0463

**ru-Q0464 · Choose the form**

Если тебе когда-нибудь нужно ____ с кем-то поговорить, не стесняйся - звони мне.

If you ever need anyone to talk to, feel free to call me.

Choices: будешь / буду / будем / будет

[[Russian#^ru-Q0464-answer|Compare the answer]]
^ru-Q0464

**ru-Q0465 · Edit the changed sentence**

Нам 【буду】 очень весело.

We'll have a lot of fun.

[[Russian#^ru-Q0465-answer|Compare the answer]]
^ru-Q0465

**ru-Q0466 · Build the sentence**

Arrange: Нам / очень / будет / весело.

We'll have a lot of fun.

[[Russian#^ru-Q0466-answer|Compare the answer]]
^ru-Q0466

**ru-Q0467 · Write a translation**

Write this in Russian: He swore that he would no longer drink.

[[Russian#^ru-Q0467-answer|Compare the answer]]
^ru-Q0467

**ru-Q0468 · Explain the grammar**

Он поклялся, что не 【будет】 больше пить.

He swore that he would no longer drink.

[[Russian#^ru-Q0468-answer|Compare the answer]]
^ru-Q0468

**ru-Q0469 · Fill the gap**

Том обязательно там ____.

Tom will definitely be there.

[[Russian#^ru-Q0469-answer|Compare the answer]]
^ru-Q0469

**ru-Q0470 · Choose the form**

Том обязательно там ____.

Tom will definitely be there.

Choices: будем / будет / буду / будешь

[[Russian#^ru-Q0470-answer|Compare the answer]]
^ru-Q0470

**ru-Q0471 · Edit the changed sentence**

Это 【буду】 стоить около десяти тысяч иен.

It will cost around 10,000 yen.

[[Russian#^ru-Q0471-answer|Compare the answer]]
^ru-Q0471

**ru-Q0472 · Build the sentence**

Arrange: будет / тысяч / стоить / около / иен. / десяти / Это

It will cost around 10,000 yen.

[[Russian#^ru-Q0472-answer|Compare the answer]]
^ru-Q0472

**ru-Q0473 · Write a translation**

Write this in Russian: I'll just be extra careful.

[[Russian#^ru-Q0473-answer|Compare the answer]]
^ru-Q0473

**ru-Q0474 · Explain the grammar**

Я просто 【буду】 очень осторожен.

I'll just be extra careful.

[[Russian#^ru-Q0474-answer|Compare the answer]]
^ru-Q0474

**ru-Q0475 · Fill the gap**

Том ____ по мне скучать.

Tom will miss me.

[[Russian#^ru-Q0475-answer|Compare the answer]]
^ru-Q0475

**ru-Q0476 · Choose the form**

Том ____ по мне скучать.

Tom will miss me.

Choices: буду / будешь / будет / будем

[[Russian#^ru-Q0476-answer|Compare the answer]]
^ru-Q0476

**ru-Q0477 · Edit the changed sentence**

Интересно, что 【буду】.

I wonder what will happen.

[[Russian#^ru-Q0477-answer|Compare the answer]]
^ru-Q0477

**ru-Q0478 · Build the sentence**

Arrange: что / будет. / Интересно,

I wonder what will happen.

[[Russian#^ru-Q0478-answer|Compare the answer]]
^ru-Q0478

**ru-Q0479 · Write a translation**

Write this in Russian: I will love you forever.

[[Russian#^ru-Q0479-answer|Compare the answer]]
^ru-Q0479

**ru-Q0480 · Explain the grammar**

Я 【буду】 любить тебя вечно.

I will love you forever.

[[Russian#^ru-Q0480-answer|Compare the answer]]
^ru-Q0480

**ru-Q0481 · Fill the gap**

Ты ____ по мне скучать?

Will you miss me?

[[Russian#^ru-Q0481-answer|Compare the answer]]
^ru-Q0481

**ru-Q0482 · Choose the form**

Ты ____ по мне скучать?

Will you miss me?

Choices: будет / буду / будем / будешь

[[Russian#^ru-Q0482-answer|Compare the answer]]
^ru-Q0482

**ru-Q0483 · Edit the changed sentence**

Том знал, что ему надо 【буду】 это сделать.

Tom knew he'd have to do that.

[[Russian#^ru-Q0483-answer|Compare the answer]]
^ru-Q0483

**ru-Q0484 · Build the sentence**

Arrange: будет / надо / знал, / это / ему / Том / что / сделать.

Tom knew he'd have to do that.

[[Russian#^ru-Q0484-answer|Compare the answer]]
^ru-Q0484

**ru-Q0485 · Write a translation**

Write this in Russian: He will be ready.

[[Russian#^ru-Q0485-answer|Compare the answer]]
^ru-Q0485

**ru-Q0486 · Explain the grammar**

Он 【будет】 готов.

He will be ready.

[[Russian#^ru-Q0486-answer|Compare the answer]]
^ru-Q0486

**ru-Q0487 · Fill the gap**

Я думаю, вы знаете, что сделать это ____ невозможно.

I think you know that'll be impossible to do.

[[Russian#^ru-Q0487-answer|Compare the answer]]
^ru-Q0487

**ru-Q0488 · Choose the form**

Я думаю, вы знаете, что сделать это ____ невозможно.

I think you know that'll be impossible to do.

Choices: будем / будет / буду / будешь

[[Russian#^ru-Q0488-answer|Compare the answer]]
^ru-Q0488

**ru-Q0489 · Edit the changed sentence**

Сколько верёвочке ни виться, всё равно конец 【буду】.

Sooner or later secrets become widely known.

[[Russian#^ru-Q0489-answer|Compare the answer]]
^ru-Q0489

**ru-Q0490 · Build the sentence**

Arrange: виться, / Сколько / будет. / конец / ни / равно / всё / верёвочке

Sooner or later secrets become widely known.

[[Russian#^ru-Q0490-answer|Compare the answer]]
^ru-Q0490

**ru-Q0491 · Write a translation**

Write this in Russian: I knew you wouldn't be there.

[[Russian#^ru-Q0491-answer|Compare the answer]]
^ru-Q0491

**ru-Q0492 · Explain the grammar**

Я знал, что вас там не 【будет】.

I knew you wouldn't be there.

[[Russian#^ru-Q0492-answer|Compare the answer]]
^ru-Q0492

**ru-Q0493 · Fill the gap**

Я решил, что не ____ этого делать.

I decided I wouldn't do that.

[[Russian#^ru-Q0493-answer|Compare the answer]]
^ru-Q0493

**ru-Q0494 · Choose the form**

Я решил, что не ____ этого делать.

I decided I wouldn't do that.

Choices: будем / будешь / будет / буду

[[Russian#^ru-Q0494-answer|Compare the answer]]
^ru-Q0494

**ru-Q0495 · Edit the changed sentence**

Я даже не 【будешь】 пытаться Тома от этого отговаривать.

I'm not even going to try to talk Tom out of doing that.

[[Russian#^ru-Q0495-answer|Compare the answer]]
^ru-Q0495

**ru-Q0496 · Build the sentence**

Arrange: от / Тома / даже / отговаривать. / буду / Я / не / этого / пытаться

I'm not even going to try to talk Tom out of doing that.

[[Russian#^ru-Q0496-answer|Compare the answer]]
^ru-Q0496

**ru-Q0497 · Write a translation**

Write this in Russian: I'll be busy all week.

[[Russian#^ru-Q0497-answer|Compare the answer]]
^ru-Q0497

**ru-Q0498 · Explain the grammar**

Я 【буду】 занят всю неделю.

I'll be busy all week.

[[Russian#^ru-Q0498-answer|Compare the answer]]
^ru-Q0498

**ru-Q0499 · Fill the gap**

Мы ____ скучать по Тому.

We'll miss Tom.

[[Russian#^ru-Q0499-answer|Compare the answer]]
^ru-Q0499

**ru-Q0500 · Choose the form**

Мы ____ скучать по Тому.

We'll miss Tom.

Choices: будем / буду / будет / будешь

[[Russian#^ru-Q0500-answer|Compare the answer]]
^ru-Q0500


### Motion forms · 50 questions

**ru-Q0501 · Edit the changed sentence**

Он 【иду】 домой через три часа.

He went home three hours later.

[[Russian#^ru-Q0501-answer|Compare the answer]]
^ru-Q0501

**ru-Q0502 · Build the sentence**

Arrange: через / пошёл / часа. / три / домой / Он

He went home three hours later.

[[Russian#^ru-Q0502-answer|Compare the answer]]
^ru-Q0502

**ru-Q0503 · Write a translation**

Write this in Russian: I was on my way home.

[[Russian#^ru-Q0503-answer|Compare the answer]]
^ru-Q0503

**ru-Q0504 · Explain the grammar**

Я 【ехал】 домой.

I was on my way home.

[[Russian#^ru-Q0504-answer|Compare the answer]]
^ru-Q0504

**ru-Q0505 · Fill the gap**

Дома я ____ без обуви.

I don't wear shoes in my house.

[[Russian#^ru-Q0505-answer|Compare the answer]]
^ru-Q0505

**ru-Q0506 · Choose the form**

Дома я ____ без обуви.

I don't wear shoes in my house.

Choices: ходит / иду / еду / хожу

[[Russian#^ru-Q0506-answer|Compare the answer]]
^ru-Q0506

**ru-Q0507 · Edit the changed sentence**

Я ни 【еду】, ни бегу.

I neither walk nor run.

[[Russian#^ru-Q0507-answer|Compare the answer]]
^ru-Q0507

**ru-Q0508 · Build the sentence**

Arrange: ни / бегу. / ни / иду, / Я

I neither walk nor run.

[[Russian#^ru-Q0508-answer|Compare the answer]]
^ru-Q0508

**ru-Q0509 · Write a translation**

Write this in Russian: I go to university.

[[Russian#^ru-Q0509-answer|Compare the answer]]
^ru-Q0509

**ru-Q0510 · Explain the grammar**

Я 【хожу】 в университет.

I go to university.

[[Russian#^ru-Q0510-answer|Compare the answer]]
^ru-Q0510

**ru-Q0511 · Fill the gap**

Пусть Том ____ домой один.

Let Tom go home by himself.

[[Russian#^ru-Q0511-answer|Compare the answer]]
^ru-Q0511

**ru-Q0512 · Choose the form**

Пусть Том ____ домой один.

Let Tom go home by himself.

Choices: еду / хожу / иду / идёт

[[Russian#^ru-Q0512-answer|Compare the answer]]
^ru-Q0512

**ru-Q0513 · Edit the changed sentence**

Я 【иду】 в парк поиграть.

I went to the park to play.

[[Russian#^ru-Q0513-answer|Compare the answer]]
^ru-Q0513

**ru-Q0514 · Build the sentence**

Arrange: парк / в / пошёл / Я / поиграть.

I went to the park to play.

[[Russian#^ru-Q0514-answer|Compare the answer]]
^ru-Q0514

**ru-Q0515 · Write a translation**

Write this in Russian: She goes to night school.

[[Russian#^ru-Q0515-answer|Compare the answer]]
^ru-Q0515

**ru-Q0516 · Explain the grammar**

Она 【ходит】 в вечернюю школу.

She goes to night school.

[[Russian#^ru-Q0516-answer|Compare the answer]]
^ru-Q0516

**ru-Q0517 · Fill the gap**

Я правильно ____?

Am I on the right road?

[[Russian#^ru-Q0517-answer|Compare the answer]]
^ru-Q0517

**ru-Q0518 · Choose the form**

Я правильно ____?

Am I on the right road?

Choices: хожу / еду / ходит / иду

[[Russian#^ru-Q0518-answer|Compare the answer]]
^ru-Q0518

**ru-Q0519 · Edit the changed sentence**

Я нечасто 【иду】 в вельветовых брюках.

I don't often wear corduroys.

[[Russian#^ru-Q0519-answer|Compare the answer]]
^ru-Q0519

**ru-Q0520 · Build the sentence**

Arrange: нечасто / Я / брюках. / в / хожу / вельветовых

I don't often wear corduroys.

[[Russian#^ru-Q0520-answer|Compare the answer]]
^ru-Q0520

**ru-Q0521 · Write a translation**

Write this in Russian: He didn't go there.

[[Russian#^ru-Q0521-answer|Compare the answer]]
^ru-Q0521

**ru-Q0522 · Explain the grammar**

Он не 【пошел】 туда.

He didn't go there.

[[Russian#^ru-Q0522-answer|Compare the answer]]
^ru-Q0522

**ru-Q0523 · Fill the gap**

Он жаловался на ____.

He complained about the food.

[[Russian#^ru-Q0523-answer|Compare the answer]]
^ru-Q0523

**ru-Q0524 · Choose the form**

Он жаловался на ____.

He complained about the food.

Choices: иду / хожу / еду / ходит

[[Russian#^ru-Q0524-answer|Compare the answer]]
^ru-Q0524

**ru-Q0525 · Edit the changed sentence**

Он 【иду】 в библиотеку читать книги.

He goes to the library to read books.

[[Russian#^ru-Q0525-answer|Compare the answer]]
^ru-Q0525

**ru-Q0526 · Build the sentence**

Arrange: в / ходит / читать / Он / книги. / библиотеку

He goes to the library to read books.

[[Russian#^ru-Q0526-answer|Compare the answer]]
^ru-Q0526

**ru-Q0527 · Write a translation**

Write this in Russian: What kind of meal did you eat?

[[Russian#^ru-Q0527-answer|Compare the answer]]
^ru-Q0527

**ru-Q0528 · Explain the grammar**

Какую 【еду】 ты ел?

What kind of meal did you eat?

[[Russian#^ru-Q0528-answer|Compare the answer]]
^ru-Q0528

**ru-Q0529 · Fill the gap**

Я ____ в ресторан раз в пятилетку.

I go to a restaurant once in a blue moon.

[[Russian#^ru-Q0529-answer|Compare the answer]]
^ru-Q0529

**ru-Q0530 · Choose the form**

Я ____ в ресторан раз в пятилетку.

I go to a restaurant once in a blue moon.

Choices: иду / хожу / ходит / еду

[[Russian#^ru-Q0530-answer|Compare the answer]]
^ru-Q0530

**ru-Q0531 · Edit the changed sentence**

Том 【иду】 на кухню, чтобы помыть руки.

Tom went to the kitchen to wash his hands.

[[Russian#^ru-Q0531-answer|Compare the answer]]
^ru-Q0531

**ru-Q0532 · Build the sentence**

Arrange: кухню, / пошёл / чтобы / руки. / помыть / на / Том

Tom went to the kitchen to wash his hands.

[[Russian#^ru-Q0532-answer|Compare the answer]]
^ru-Q0532

**ru-Q0533 · Write a translation**

Write this in Russian: The dog is eating its food.

[[Russian#^ru-Q0533-answer|Compare the answer]]
^ru-Q0533

**ru-Q0534 · Explain the grammar**

Собака ест свою 【еду】.

The dog is eating its food.

[[Russian#^ru-Q0534-answer|Compare the answer]]
^ru-Q0534

**ru-Q0535 · Fill the gap**

Моя бабушка по вечерам ____ гулять.

My grandmother goes for a walk in the evening.

[[Russian#^ru-Q0535-answer|Compare the answer]]
^ru-Q0535

**ru-Q0536 · Choose the form**

Моя бабушка по вечерам ____ гулять.

My grandmother goes for a walk in the evening.

Choices: еду / хожу / ходит / иду

[[Russian#^ru-Q0536-answer|Compare the answer]]
^ru-Q0536

**ru-Q0537 · Edit the changed sentence**

Том не солит 【иду】, которую готовит.

Tom doesn't use salt in his cooking.

[[Russian#^ru-Q0537-answer|Compare the answer]]
^ru-Q0537

**ru-Q0538 · Build the sentence**

Arrange: готовит. / еду, / Том / не / которую / солит

Tom doesn't use salt in his cooking.

[[Russian#^ru-Q0538-answer|Compare the answer]]
^ru-Q0538

**ru-Q0539 · Write a translation**

Write this in Russian: I'm walking to school.

[[Russian#^ru-Q0539-answer|Compare the answer]]
^ru-Q0539

**ru-Q0540 · Explain the grammar**

Я 【иду】 в школу пешком.

I'm walking to school.

[[Russian#^ru-Q0540-answer|Compare the answer]]
^ru-Q0540

**ru-Q0541 · Fill the gap**

Как всегда, он ____ на работу небритый.

As always, he went to work without shaving.

[[Russian#^ru-Q0541-answer|Compare the answer]]
^ru-Q0541

**ru-Q0542 · Choose the form**

Как всегда, он ____ на работу небритый.

As always, he went to work without shaving.

Choices: еду / пошёл / хожу / иду

[[Russian#^ru-Q0542-answer|Compare the answer]]
^ru-Q0542

**ru-Q0543 · Edit the changed sentence**

Мы как раз собирались выходить, когда 【иду】 дождь.

We were just about to leave when it started to rain.

[[Russian#^ru-Q0543-answer|Compare the answer]]
^ru-Q0543

**ru-Q0544 · Build the sentence**

Arrange: раз / выходить, / когда / дождь. / Мы / как / собирались / пошёл

We were just about to leave when it started to rain.

[[Russian#^ru-Q0544-answer|Compare the answer]]
^ru-Q0544

**ru-Q0545 · Write a translation**

Write this in Russian: This color doesn't suit you.

[[Russian#^ru-Q0545-answer|Compare the answer]]
^ru-Q0545

**ru-Q0546 · Explain the grammar**

Этот цвет тебе не 【идёт】.

This color doesn't suit you.

[[Russian#^ru-Q0546-answer|Compare the answer]]
^ru-Q0546

**ru-Q0547 · Fill the gap**

Я ____ с ним в Бостон.

I'm going with him to Boston.

[[Russian#^ru-Q0547-answer|Compare the answer]]
^ru-Q0547

**ru-Q0548 · Choose the form**

Я ____ с ним в Бостон.

I'm going with him to Boston.

Choices: ходит / еду / хожу / иду

[[Russian#^ru-Q0548-answer|Compare the answer]]
^ru-Q0548

**ru-Q0549 · Edit the changed sentence**

Она 【иду】 во Францию на следующей неделе.

She is going to France next week.

[[Russian#^ru-Q0549-answer|Compare the answer]]
^ru-Q0549

**ru-Q0550 · Build the sentence**

Arrange: Она / неделе. / во / Францию / следующей / на / едет

She is going to France next week.

[[Russian#^ru-Q0550-answer|Compare the answer]]
^ru-Q0550


### Negation · 50 questions

**ru-Q0551 · Write a translation**

Write this in Russian: Fish don't like sunlight.

[[Russian#^ru-Q0551-answer|Compare the answer]]
^ru-Q0551

**ru-Q0552 · Explain the grammar**

Рыбы 【не】 любят солнечный свет.

Fish don't like sunlight.

[[Russian#^ru-Q0552-answer|Compare the answer]]
^ru-Q0552

**ru-Q0553 · Fill the gap**

Тому ____ пришлось ничего объяснять.

Tom didn't have to explain anything.

[[Russian#^ru-Q0553-answer|Compare the answer]]
^ru-Q0553

**ru-Q0554 · Choose the form**

Тому ____ пришлось ничего объяснять.

Tom didn't have to explain anything.

Choices: нет / нельзя / не / никогда

[[Russian#^ru-Q0554-answer|Compare the answer]]
^ru-Q0554

**ru-Q0555 · Edit the changed sentence**

Том 【нет】 лентяй.

Tom isn't lazy.

[[Russian#^ru-Q0555-answer|Compare the answer]]
^ru-Q0555

**ru-Q0556 · Build the sentence**

Arrange: не / лентяй. / Том

Tom isn't lazy.

[[Russian#^ru-Q0556-answer|Compare the answer]]
^ru-Q0556

**ru-Q0557 · Write a translation**

Write this in Russian: I didn't look.

[[Russian#^ru-Q0557-answer|Compare the answer]]
^ru-Q0557

**ru-Q0558 · Explain the grammar**

Я 【не】 смотрел.

I didn't look.

[[Russian#^ru-Q0558-answer|Compare the answer]]
^ru-Q0558

**ru-Q0559 · Fill the gap**

Тут ____ нет.

There's nothing in here.

[[Russian#^ru-Q0559-answer|Compare the answer]]
^ru-Q0559

**ru-Q0560 · Choose the form**

Тут ____ нет.

There's nothing in here.

Choices: нет / ничего / не / никогда

[[Russian#^ru-Q0560-answer|Compare the answer]]
^ru-Q0560

**ru-Q0561 · Edit the changed sentence**

Я 【нет】 люблю горячую пищу.

I don't like hot food.

[[Russian#^ru-Q0561-answer|Compare the answer]]
^ru-Q0561

**ru-Q0562 · Build the sentence**

Arrange: не / Я / горячую / пищу. / люблю

I don't like hot food.

[[Russian#^ru-Q0562-answer|Compare the answer]]
^ru-Q0562

**ru-Q0563 · Write a translation**

Write this in Russian: Tom isn't as intelligent as you.

[[Russian#^ru-Q0563-answer|Compare the answer]]
^ru-Q0563

**ru-Q0564 · Explain the grammar**

Том 【не】 такой умный, как ты.

Tom isn't as intelligent as you.

[[Russian#^ru-Q0564-answer|Compare the answer]]
^ru-Q0564

**ru-Q0565 · Fill the gap**

Я ____ знал, что она там.

I didn't know it was there.

[[Russian#^ru-Q0565-answer|Compare the answer]]
^ru-Q0565

**ru-Q0566 · Choose the form**

Я ____ знал, что она там.

I didn't know it was there.

Choices: нельзя / нет / никогда / не

[[Russian#^ru-Q0566-answer|Compare the answer]]
^ru-Q0566

**ru-Q0567 · Edit the changed sentence**

Я просто 【нет】 люблю жену.

I just don't love my wife.

[[Russian#^ru-Q0567-answer|Compare the answer]]
^ru-Q0567

**ru-Q0568 · Build the sentence**

Arrange: жену. / не / Я / люблю / просто

I just don't love my wife.

[[Russian#^ru-Q0568-answer|Compare the answer]]
^ru-Q0568

**ru-Q0569 · Write a translation**

Write this in Russian: Could you wait outside?

[[Russian#^ru-Q0569-answer|Compare the answer]]
^ru-Q0569

**ru-Q0570 · Explain the grammar**

Ты 【не】 мог бы подождать снаружи?

Could you wait outside?

[[Russian#^ru-Q0570-answer|Compare the answer]]
^ru-Q0570

**ru-Q0571 · Fill the gap**

____ путай кометы и астероиды.

Don't confuse comets and asteroids.

[[Russian#^ru-Q0571-answer|Compare the answer]]
^ru-Q0571

**ru-Q0572 · Choose the form**

____ путай кометы и астероиды.

Don't confuse comets and asteroids.

Choices: Не / нельзя / нет / никогда

[[Russian#^ru-Q0572-answer|Compare the answer]]
^ru-Q0572

**ru-Q0573 · Edit the changed sentence**

Я 【нет】 хочу давать свой ключ Тому.

I don't want to give Tom my key.

[[Russian#^ru-Q0573-answer|Compare the answer]]
^ru-Q0573

**ru-Q0574 · Build the sentence**

Arrange: не / хочу / свой / ключ / Тому. / Я / давать

I don't want to give Tom my key.

[[Russian#^ru-Q0574-answer|Compare the answer]]
^ru-Q0574

**ru-Q0575 · Write a translation**

Write this in Russian: Please don't tell my wife.

[[Russian#^ru-Q0575-answer|Compare the answer]]
^ru-Q0575

**ru-Q0576 · Explain the grammar**

Пожалуйста, 【не】 говори моей жене.

Please don't tell my wife.

[[Russian#^ru-Q0576-answer|Compare the answer]]
^ru-Q0576

**ru-Q0577 · Fill the gap**

Ты раньше ____ этого не делала?

Haven't you ever done this before?

[[Russian#^ru-Q0577-answer|Compare the answer]]
^ru-Q0577

**ru-Q0578 · Choose the form**

Ты раньше ____ этого не делала?

Haven't you ever done this before?

Choices: никогда / нельзя / не / нет

[[Russian#^ru-Q0578-answer|Compare the answer]]
^ru-Q0578

**ru-Q0579 · Edit the changed sentence**

Она 【нет】 хочет идти спать.

She does not want to go to bed.

[[Russian#^ru-Q0579-answer|Compare the answer]]
^ru-Q0579

**ru-Q0580 · Build the sentence**

Arrange: спать. / хочет / не / Она / идти

She does not want to go to bed.

[[Russian#^ru-Q0580-answer|Compare the answer]]
^ru-Q0580

**ru-Q0581 · Write a translation**

Write this in Russian: Why didn't you listen to Tom?

[[Russian#^ru-Q0581-answer|Compare the answer]]
^ru-Q0581

**ru-Q0582 · Explain the grammar**

Почему вы 【не】 послушали Тома?

Why didn't you listen to Tom?

[[Russian#^ru-Q0582-answer|Compare the answer]]
^ru-Q0582

**ru-Q0583 · Fill the gap**

Ты уверен, что мы ____ можем отремонтировать этот фотоаппарат?

Are you sure we can't repair this camera?

[[Russian#^ru-Q0583-answer|Compare the answer]]
^ru-Q0583

**ru-Q0584 · Choose the form**

Ты уверен, что мы ____ можем отремонтировать этот фотоаппарат?

Are you sure we can't repair this camera?

Choices: нет / не / никогда / нельзя

[[Russian#^ru-Q0584-answer|Compare the answer]]
^ru-Q0584

**ru-Q0585 · Edit the changed sentence**

Том 【нет】 просил Мэри, чтобы она этого не делала.

Tom didn't ask Mary not to do that.

[[Russian#^ru-Q0585-answer|Compare the answer]]
^ru-Q0585

**ru-Q0586 · Build the sentence**

Arrange: этого / она / делала. / Мэри, / Том / не / чтобы / просил / не

Tom didn't ask Mary not to do that.

[[Russian#^ru-Q0586-answer|Compare the answer]]
^ru-Q0586

**ru-Q0587 · Write a translation**

Write this in Russian: Tom doesn't like to wear ties.

[[Russian#^ru-Q0587-answer|Compare the answer]]
^ru-Q0587

**ru-Q0588 · Explain the grammar**

Том 【не】 любит ходить в галстуке.

Tom doesn't like to wear ties.

[[Russian#^ru-Q0588-answer|Compare the answer]]
^ru-Q0588

**ru-Q0589 · Fill the gap**

Том ____ хотел разочаровывать Мэри.

Tom didn't want to disappoint Mary.

[[Russian#^ru-Q0589-answer|Compare the answer]]
^ru-Q0589

**ru-Q0590 · Choose the form**

Том ____ хотел разочаровывать Мэри.

Tom didn't want to disappoint Mary.

Choices: никогда / нельзя / не / нет

[[Russian#^ru-Q0590-answer|Compare the answer]]
^ru-Q0590

**ru-Q0591 · Edit the changed sentence**

Том 【нет】 тот парень, с которым стоит связываться.

Tom is the wrong guy to mess with.

[[Russian#^ru-Q0591-answer|Compare the answer]]
^ru-Q0591

**ru-Q0592 · Build the sentence**

Arrange: которым / с / связываться. / стоит / Том / тот / парень, / не

Tom is the wrong guy to mess with.

[[Russian#^ru-Q0592-answer|Compare the answer]]
^ru-Q0592

**ru-Q0593 · Write a translation**

Write this in Russian: Didn't you know where Tom wanted to go?

[[Russian#^ru-Q0593-answer|Compare the answer]]
^ru-Q0593

**ru-Q0594 · Explain the grammar**

Ты 【не】 знал, что Том хочет пойти?

Didn't you know where Tom wanted to go?

[[Russian#^ru-Q0594-answer|Compare the answer]]
^ru-Q0594

**ru-Q0595 · Fill the gap**

Я бы пришёл, даже если бы ты меня ____ пригласила.

I would've come even if you hadn't invited me.

[[Russian#^ru-Q0595-answer|Compare the answer]]
^ru-Q0595

**ru-Q0596 · Choose the form**

Я бы пришёл, даже если бы ты меня ____ пригласила.

I would've come even if you hadn't invited me.

Choices: не / нет / нельзя / никогда

[[Russian#^ru-Q0596-answer|Compare the answer]]
^ru-Q0596

**ru-Q0597 · Edit the changed sentence**

Есть люди, которые 【нет】 любят шпинат.

There are people who don't like spinach.

[[Russian#^ru-Q0597-answer|Compare the answer]]
^ru-Q0597

**ru-Q0598 · Build the sentence**

Arrange: шпинат. / люди, / Есть / любят / которые / не

There are people who don't like spinach.

[[Russian#^ru-Q0598-answer|Compare the answer]]
^ru-Q0598

**ru-Q0599 · Write a translation**

Write this in Russian: We couldn't kill them.

[[Russian#^ru-Q0599-answer|Compare the answer]]
^ru-Q0599

**ru-Q0600 · Explain the grammar**

Мы 【не】 смогли бы их убить.

We couldn't kill them.

[[Russian#^ru-Q0600-answer|Compare the answer]]
^ru-Q0600


### Modal and impersonal words · 50 questions

**ru-Q0601 · Fill the gap**

Тому ____ внимание.

Tom needs attention.

[[Russian#^ru-Q0601-answer|Compare the answer]]
^ru-Q0601

**ru-Q0602 · Choose the form**

Тому ____ внимание.

Tom needs attention.

Choices: могу / нужно / можно / надо

[[Russian#^ru-Q0602-answer|Compare the answer]]
^ru-Q0602

**ru-Q0603 · Edit the changed sentence**

Тому 【можно】, чтобы Мэри кто-нибудь помог.

Tom needs somebody to help Mary.

[[Russian#^ru-Q0603-answer|Compare the answer]]
^ru-Q0603

**ru-Q0604 · Build the sentence**

Arrange: Тому / помог. / чтобы / Мэри / кто-нибудь / нужно,

Tom needs somebody to help Mary.

[[Russian#^ru-Q0604-answer|Compare the answer]]
^ru-Q0604

**ru-Q0605 · Write a translation**

Write this in Russian: I thought it might be you.

[[Russian#^ru-Q0605-answer|Compare the answer]]
^ru-Q0605

**ru-Q0606 · Explain the grammar**

Я думал, 【может】, это вы.

I thought it might be you.

[[Russian#^ru-Q0606-answer|Compare the answer]]
^ru-Q0606

**ru-Q0607 · Fill the gap**

Тому уже ____ уезжать?

Does Tom need to leave now?

[[Russian#^ru-Q0607-answer|Compare the answer]]
^ru-Q0607

**ru-Q0608 · Choose the form**

Тому уже ____ уезжать?

Does Tom need to leave now?

Choices: можно / надо / могу / нужно

[[Russian#^ru-Q0608-answer|Compare the answer]]
^ru-Q0608

**ru-Q0609 · Edit the changed sentence**

Чтобы сделать жизнь счастливой, 【можно】 любить повседневные мелочи.

In order to make life happy, you must love the everyday trifles.

[[Russian#^ru-Q0609-answer|Compare the answer]]
^ru-Q0609

**ru-Q0610 · Build the sentence**

Arrange: сделать / мелочи. / повседневные / любить / надо / счастливой, / Чтобы / жизнь

In order to make life happy, you must love the everyday trifles.

[[Russian#^ru-Q0610-answer|Compare the answer]]
^ru-Q0610

**ru-Q0611 · Write a translation**

Write this in Russian: I want to see the horses.

[[Russian#^ru-Q0611-answer|Compare the answer]]
^ru-Q0611

**ru-Q0612 · Explain the grammar**

Я 【хочу】 увидеть лошадей.

I want to see the horses.

[[Russian#^ru-Q0612-answer|Compare the answer]]
^ru-Q0612

**ru-Q0613 · Fill the gap**

Я ____ найти для этого ящик.

I want to find a box for this.

[[Russian#^ru-Q0613-answer|Compare the answer]]
^ru-Q0613

**ru-Q0614 · Choose the form**

Я ____ найти для этого ящик.

I want to find a box for this.

Choices: можно / хочу / нужно / надо

[[Russian#^ru-Q0614-answer|Compare the answer]]
^ru-Q0614

**ru-Q0615 · Edit the changed sentence**

Том не 【можно】 справиться с этой работой самостоятельно.

Tom can't handle this job on his own.

[[Russian#^ru-Q0615-answer|Compare the answer]]
^ru-Q0615

**ru-Q0616 · Build the sentence**

Arrange: самостоятельно. / этой / Том / с / работой / может / справиться / не

Tom can't handle this job on his own.

[[Russian#^ru-Q0616-answer|Compare the answer]]
^ru-Q0616

**ru-Q0617 · Write a translation**

Write this in Russian: You need to exercise more.

[[Russian#^ru-Q0617-answer|Compare the answer]]
^ru-Q0617

**ru-Q0618 · Explain the grammar**

Тебе 【нужно】 больше заниматься.

You need to exercise more.

[[Russian#^ru-Q0618-answer|Compare the answer]]
^ru-Q0618

**ru-Q0619 · Fill the gap**

Мне ____ с вами переговорить.

I want a word with you.

[[Russian#^ru-Q0619-answer|Compare the answer]]
^ru-Q0619

**ru-Q0620 · Choose the form**

Мне ____ с вами переговорить.

I want a word with you.

Choices: надо / могу / можно / нужно

[[Russian#^ru-Q0620-answer|Compare the answer]]
^ru-Q0620

**ru-Q0621 · Edit the changed sentence**

Я 【можно】 купить другую.

I want to buy another one.

[[Russian#^ru-Q0621-answer|Compare the answer]]
^ru-Q0621

**ru-Q0622 · Build the sentence**

Arrange: хочу / Я / другую. / купить

I want to buy another one.

[[Russian#^ru-Q0622-answer|Compare the answer]]
^ru-Q0622

**ru-Q0623 · Write a translation**

Write this in Russian: I have to solve this problem myself.

[[Russian#^ru-Q0623-answer|Compare the answer]]
^ru-Q0623

**ru-Q0624 · Explain the grammar**

Я 【должен】 решить эту проблему сам.

I have to solve this problem myself.

[[Russian#^ru-Q0624-answer|Compare the answer]]
^ru-Q0624

**ru-Q0625 · Fill the gap**

Ты ____ помочь нам.

You have to help us.

[[Russian#^ru-Q0625-answer|Compare the answer]]
^ru-Q0625

**ru-Q0626 · Choose the form**

Ты ____ помочь нам.

You have to help us.

Choices: должен / надо / нужно / можно

[[Russian#^ru-Q0626-answer|Compare the answer]]
^ru-Q0626

**ru-Q0627 · Edit the changed sentence**

Далеко не всё в интернете 【нужно】 найти с помощью гугла.

Not everything on the web can be found through Google.

[[Russian#^ru-Q0627-answer|Compare the answer]]
^ru-Q0627

**ru-Q0628 · Build the sentence**

Arrange: Далеко / в / с / помощью / интернете / можно / всё / не / гугла. / найти

Not everything on the web can be found through Google.

[[Russian#^ru-Q0628-answer|Compare the answer]]
^ru-Q0628

**ru-Q0629 · Write a translation**

Write this in Russian: If you need to borrow some money, let me know.

[[Russian#^ru-Q0629-answer|Compare the answer]]
^ru-Q0629

**ru-Q0630 · Explain the grammar**

Если вам 【нужно】 одолжить денег, скажите.

If you need to borrow some money, let me know.

[[Russian#^ru-Q0630-answer|Compare the answer]]
^ru-Q0630

**ru-Q0631 · Fill the gap**

Мне ____, чтобы вы помогли мне их найти.

I need you to help me find them.

[[Russian#^ru-Q0631-answer|Compare the answer]]
^ru-Q0631

**ru-Q0632 · Choose the form**

Мне ____, чтобы вы помогли мне их найти.

I need you to help me find them.

Choices: нужно / можно / надо / могу

[[Russian#^ru-Q0632-answer|Compare the answer]]
^ru-Q0632

**ru-Q0633 · Edit the changed sentence**

Тебе 【можно】 лучше следить за тем, что ты говоришь.

You should pay more attention to what you say.

[[Russian#^ru-Q0633-answer|Compare the answer]]
^ru-Q0633

**ru-Q0634 · Build the sentence**

Arrange: за / Тебе / что / нужно / следить / лучше / говоришь. / ты / тем,

You should pay more attention to what you say.

[[Russian#^ru-Q0634-answer|Compare the answer]]
^ru-Q0634

**ru-Q0635 · Write a translation**

Write this in Russian: I want to talk to Tom alone.

[[Russian#^ru-Q0635-answer|Compare the answer]]
^ru-Q0635

**ru-Q0636 · Explain the grammar**

Я 【хочу】 поговорить с Томом наедине.

I want to talk to Tom alone.

[[Russian#^ru-Q0636-answer|Compare the answer]]
^ru-Q0636

**ru-Q0637 · Fill the gap**

____ мне сесть рядом с тобой?

May I sit next to you?

[[Russian#^ru-Q0637-answer|Compare the answer]]
^ru-Q0637

**ru-Q0638 · Choose the form**

____ мне сесть рядом с тобой?

May I sit next to you?

Choices: могу / надо / нужно / Можно

[[Russian#^ru-Q0638-answer|Compare the answer]]
^ru-Q0638

**ru-Q0639 · Edit the changed sentence**

Вы действительно думаете, что Том 【можно】 выиграть?

Do you really think Tom can win?

[[Russian#^ru-Q0639-answer|Compare the answer]]
^ru-Q0639

**ru-Q0640 · Build the sentence**

Arrange: Вы / может / Том / выиграть? / что / действительно / думаете,

Do you really think Tom can win?

[[Russian#^ru-Q0640-answer|Compare the answer]]
^ru-Q0640

**ru-Q0641 · Write a translation**

Write this in Russian: The same holds true for Germany.

[[Russian#^ru-Q0641-answer|Compare the answer]]
^ru-Q0641

**ru-Q0642 · Explain the grammar**

То же самое 【можно】 сказать и о Германии.

The same holds true for Germany.

[[Russian#^ru-Q0642-answer|Compare the answer]]
^ru-Q0642

**ru-Q0643 · Fill the gap**

Я ____ сесть на диету, чтобы похудеть.

I have to go on a diet to lose weight.

[[Russian#^ru-Q0643-answer|Compare the answer]]
^ru-Q0643

**ru-Q0644 · Choose the form**

Я ____ сесть на диету, чтобы похудеть.

I have to go on a diet to lose weight.

Choices: надо / должна / можно / нужно

[[Russian#^ru-Q0644-answer|Compare the answer]]
^ru-Q0644

**ru-Q0645 · Edit the changed sentence**

Знаете, чего я 【можно】?

Do you know what I want?

[[Russian#^ru-Q0645-answer|Compare the answer]]
^ru-Q0645

**ru-Q0646 · Build the sentence**

Arrange: я / чего / хочу? / Знаете,

Do you know what I want?

[[Russian#^ru-Q0646-answer|Compare the answer]]
^ru-Q0646

**ru-Q0647 · Write a translation**

Write this in Russian: Next spring I want to go to Hawaii.

[[Russian#^ru-Q0647-answer|Compare the answer]]
^ru-Q0647

**ru-Q0648 · Explain the grammar**

Следующей весной я 【хочу】 поехать на Гавайи.

Next spring I want to go to Hawaii.

[[Russian#^ru-Q0648-answer|Compare the answer]]
^ru-Q0648

**ru-Q0649 · Fill the gap**

Санта, вместо подарка я ____ получить на Рождество девушку.

Santa Claus, I want to receive a girlfriend for Christmas.

[[Russian#^ru-Q0649-answer|Compare the answer]]
^ru-Q0649

**ru-Q0650 · Choose the form**

Санта, вместо подарка я ____ получить на Рождество девушку.

Santa Claus, I want to receive a girlfriend for Christmas.

Choices: хочу / надо / нужно / можно

[[Russian#^ru-Q0650-answer|Compare the answer]]
^ru-Q0650


### Questions · 50 questions

**ru-Q0651 · Edit the changed sentence**

【кто】 мы можем пойти купаться?

When can we go swimming?

[[Russian#^ru-Q0651-answer|Compare the answer]]
^ru-Q0651

**ru-Q0652 · Build the sentence**

Arrange: купаться? / можем / мы / пойти / Когда

When can we go swimming?

[[Russian#^ru-Q0652-answer|Compare the answer]]
^ru-Q0652

**ru-Q0653 · Write a translation**

Write this in Russian: Tom probably thought I was happy.

[[Russian#^ru-Q0653-answer|Compare the answer]]
^ru-Q0653

**ru-Q0654 · Explain the grammar**

Том, вероятно, думал, 【что】 я счастлив.

Tom probably thought I was happy.

[[Russian#^ru-Q0654-answer|Compare the answer]]
^ru-Q0654

**ru-Q0655 · Fill the gap**

____ ближайшая пиццерия?

Where's the nearest pizzeria?

[[Russian#^ru-Q0655-answer|Compare the answer]]
^ru-Q0655

**ru-Q0656 · Choose the form**

____ ближайшая пиццерия?

Where's the nearest pizzeria?

Choices: куда / кто / что / Где

[[Russian#^ru-Q0656-answer|Compare the answer]]
^ru-Q0656

**ru-Q0657 · Edit the changed sentence**

【кто】 Том решил изучать французский?

Why did Tom decide to study French?

[[Russian#^ru-Q0657-answer|Compare the answer]]
^ru-Q0657

**ru-Q0658 · Build the sentence**

Arrange: французский? / Том / решил / изучать / Почему

Why did Tom decide to study French?

[[Russian#^ru-Q0658-answer|Compare the answer]]
^ru-Q0658

**ru-Q0659 · Write a translation**

Write this in Russian: I wonder if Tom ever works on Sunday.

[[Russian#^ru-Q0659-answer|Compare the answer]]
^ru-Q0659

**ru-Q0660 · Explain the grammar**

Интересно, работает ли Том 【когда】-либо по воскресеньям.

I wonder if Tom ever works on Sunday.

[[Russian#^ru-Q0660-answer|Compare the answer]]
^ru-Q0660

**ru-Q0661 · Fill the gap**

Я думал, ____ тону.

I thought I was drowning.

[[Russian#^ru-Q0661-answer|Compare the answer]]
^ru-Q0661

**ru-Q0662 · Choose the form**

Я думал, ____ тону.

I thought I was drowning.

Choices: где / кто / куда / что

[[Russian#^ru-Q0662-answer|Compare the answer]]
^ru-Q0662

**ru-Q0663 · Edit the changed sentence**

Ненависть слепа, 【кто】 и любовь.

Hatred is blind, as well as love.

[[Russian#^ru-Q0663-answer|Compare the answer]]
^ru-Q0663

**ru-Q0664 · Build the sentence**

Arrange: и / слепа, / Ненависть / как / любовь.

Hatred is blind, as well as love.

[[Russian#^ru-Q0664-answer|Compare the answer]]
^ru-Q0664

**ru-Q0665 · Write a translation**

Write this in Russian: How do you feel about this?

[[Russian#^ru-Q0665-answer|Compare the answer]]
^ru-Q0665

**ru-Q0666 · Explain the grammar**

【Как】 вы к этому относитесь?

How do you feel about this?

[[Russian#^ru-Q0666-answer|Compare the answer]]
^ru-Q0666

**ru-Q0667 · Fill the gap**

Кажется, Том ____-то бормочет.

Tom seems to be babbling.

[[Russian#^ru-Q0667-answer|Compare the answer]]
^ru-Q0667

**ru-Q0668 · Choose the form**

Кажется, Том ____-то бормочет.

Tom seems to be babbling.

Choices: куда / что / кто / где

[[Russian#^ru-Q0668-answer|Compare the answer]]
^ru-Q0668

**ru-Q0669 · Edit the changed sentence**

Том позвонил сказать, 【кто】 опоздает.

Tom called to say that he'd be late.

[[Russian#^ru-Q0669-answer|Compare the answer]]
^ru-Q0669

**ru-Q0670 · Build the sentence**

Arrange: опоздает. / Том / что / позвонил / сказать,

Tom called to say that he'd be late.

[[Russian#^ru-Q0670-answer|Compare the answer]]
^ru-Q0670

**ru-Q0671 · Write a translation**

Write this in Russian: Tom married Mary after her husband died.

[[Russian#^ru-Q0671-answer|Compare the answer]]
^ru-Q0671

**ru-Q0672 · Explain the grammar**

Том женился на Мэри, после того 【как】 её муж умер.

Tom married Mary after her husband died.

[[Russian#^ru-Q0672-answer|Compare the answer]]
^ru-Q0672

**ru-Q0673 · Fill the gap**

Вы знаете, ____ с ними связаться?

Do you know how to reach them?

[[Russian#^ru-Q0673-answer|Compare the answer]]
^ru-Q0673

**ru-Q0674 · Choose the form**

Вы знаете, ____ с ними связаться?

Do you know how to reach them?

Choices: кто / где / что / как

[[Russian#^ru-Q0674-answer|Compare the answer]]
^ru-Q0674

**ru-Q0675 · Edit the changed sentence**

【кто】 ты это починишь?

How will you fix it?

[[Russian#^ru-Q0675-answer|Compare the answer]]
^ru-Q0675

**ru-Q0676 · Build the sentence**

Arrange: ты / Как / это / починишь?

How will you fix it?

[[Russian#^ru-Q0676-answer|Compare the answer]]
^ru-Q0676

**ru-Q0677 · Write a translation**

Write this in Russian: Where does Tom sing?

[[Russian#^ru-Q0677-answer|Compare the answer]]
^ru-Q0677

**ru-Q0678 · Explain the grammar**

【Где】 Том поёт?

Where does Tom sing?

[[Russian#^ru-Q0678-answer|Compare the answer]]
^ru-Q0678

**ru-Q0679 · Fill the gap**

Тщательно обдумай это перед тем, ____ решить.

Sleep on it before deciding.

[[Russian#^ru-Q0679-answer|Compare the answer]]
^ru-Q0679

**ru-Q0680 · Choose the form**

Тщательно обдумай это перед тем, ____ решить.

Sleep on it before deciding.

Choices: где / как / что / кто

[[Russian#^ru-Q0680-answer|Compare the answer]]
^ru-Q0680

**ru-Q0681 · Edit the changed sentence**

Я рад, 【кто】 кто-то понимает.

I'm glad someone understands.

[[Russian#^ru-Q0681-answer|Compare the answer]]
^ru-Q0681

**ru-Q0682 · Build the sentence**

Arrange: понимает. / Я / рад, / кто-то / что

I'm glad someone understands.

[[Russian#^ru-Q0682-answer|Compare the answer]]
^ru-Q0682

**ru-Q0683 · Write a translation**

Write this in Russian: Tatoeba: Where debates are hotter than two rabbits making babies in a sock!

[[Russian#^ru-Q0683-answer|Compare the answer]]
^ru-Q0683

**ru-Q0684 · Explain the grammar**

Татоэба: там, 【где】 споры разгорячённей, чем два совокупляющихся в носке кролика!

Tatoeba: Where debates are hotter than two rabbits making babies in a sock!

[[Russian#^ru-Q0684-answer|Compare the answer]]
^ru-Q0684

**ru-Q0685 · Fill the gap**

Ты ____, не видишь, что Том и Мэри умирают?

Can't you see Tom and Mary are dying?

[[Russian#^ru-Q0685-answer|Compare the answer]]
^ru-Q0685

**ru-Q0686 · Choose the form**

Ты ____, не видишь, что Том и Мэри умирают?

Can't you see Tom and Mary are dying?

Choices: кто / где / куда / что

[[Russian#^ru-Q0686-answer|Compare the answer]]
^ru-Q0686

**ru-Q0687 · Edit the changed sentence**

【кто】 ты украшаешь свой дом к Рождеству?

How do you decorate your house for Christmas?

[[Russian#^ru-Q0687-answer|Compare the answer]]
^ru-Q0687

**ru-Q0688 · Build the sentence**

Arrange: свой / Рождеству? / Как / к / дом / ты / украшаешь

How do you decorate your house for Christmas?

[[Russian#^ru-Q0688-answer|Compare the answer]]
^ru-Q0688

**ru-Q0689 · Write a translation**

Write this in Russian: Did you find out what time the meeting starts?

[[Russian#^ru-Q0689-answer|Compare the answer]]
^ru-Q0689

**ru-Q0690 · Explain the grammar**

Ты узнал, во 【сколько】 начинается собрание?

Did you find out what time the meeting starts?

[[Russian#^ru-Q0690-answer|Compare the answer]]
^ru-Q0690

**ru-Q0691 · Fill the gap**

____ мне делать в этой ситуации?

What should I do in this situation?

[[Russian#^ru-Q0691-answer|Compare the answer]]
^ru-Q0691

**ru-Q0692 · Choose the form**

____ мне делать в этой ситуации?

What should I do in this situation?

Choices: кто / куда / Что / где

[[Russian#^ru-Q0692-answer|Compare the answer]]
^ru-Q0692

**ru-Q0693 · Edit the changed sentence**

Нам придётся 【кто】-то сделать.

We will have to do something.

[[Russian#^ru-Q0693-answer|Compare the answer]]
^ru-Q0693

**ru-Q0694 · Build the sentence**

Arrange: сделать. / Нам / что-то / придётся

We will have to do something.

[[Russian#^ru-Q0694-answer|Compare the answer]]
^ru-Q0694

**ru-Q0695 · Write a translation**

Write this in Russian: No wonder nobody likes you.

[[Russian#^ru-Q0695-answer|Compare the answer]]
^ru-Q0695

**ru-Q0696 · Explain the grammar**

Неудивительно, 【что】 вы никому не нравитесь.

No wonder nobody likes you.

[[Russian#^ru-Q0696-answer|Compare the answer]]
^ru-Q0696

**ru-Q0697 · Fill the gap**

____ у тебя служащих?

How many employees do you have?

[[Russian#^ru-Q0697-answer|Compare the answer]]
^ru-Q0697

**ru-Q0698 · Choose the form**

____ у тебя служащих?

How many employees do you have?

Choices: кто / где / Сколько / что

[[Russian#^ru-Q0698-answer|Compare the answer]]
^ru-Q0698

**ru-Q0699 · Edit the changed sentence**

【кто】 ты пришёл так рано?

Why did you come so early?

[[Russian#^ru-Q0699-answer|Compare the answer]]
^ru-Q0699

**ru-Q0700 · Build the sentence**

Arrange: Почему / рано? / так / пришёл / ты

Why did you come so early?

[[Russian#^ru-Q0700-answer|Compare the answer]]
^ru-Q0700


### Content clauses · 50 questions

**ru-Q0701 · Write a translation**

Write this in Russian: Tom came here to study French.

[[Russian#^ru-Q0701-answer|Compare the answer]]
^ru-Q0701

**ru-Q0702 · Explain the grammar**

Том приехал сюда, 【чтобы】 учить французский.

Tom came here to study French.

[[Russian#^ru-Q0702-answer|Compare the answer]]
^ru-Q0702

**ru-Q0703 · Fill the gap**

Том использовал лом, ____ открыть крышку ящика.

Tom used a crowbar to pry open the lid of the crate.

[[Russian#^ru-Q0703-answer|Compare the answer]]
^ru-Q0703

**ru-Q0704 · Choose the form**

Том использовал лом, ____ открыть крышку ящика.

Tom used a crowbar to pry open the lid of the crate.

Choices: чтобы / ли / что / как

[[Russian#^ru-Q0704-answer|Compare the answer]]
^ru-Q0704

**ru-Q0705 · Edit the changed sentence**

Том хотел, 【что】 они оба ушли.

Tom wanted both of them to leave.

[[Russian#^ru-Q0705-answer|Compare the answer]]
^ru-Q0705

**ru-Q0706 · Build the sentence**

Arrange: хотел, / чтобы / Том / они / ушли. / оба

Tom wanted both of them to leave.

[[Russian#^ru-Q0706-answer|Compare the answer]]
^ru-Q0706

**ru-Q0707 · Write a translation**

Write this in Russian: I don't see how that can be true.

[[Russian#^ru-Q0707-answer|Compare the answer]]
^ru-Q0707

**ru-Q0708 · Explain the grammar**

Я не понимаю, 【как】 это возможно.

I don't see how that can be true.

[[Russian#^ru-Q0708-answer|Compare the answer]]
^ru-Q0708

**ru-Q0709 · Fill the gap**

Я знал, ____ Том не умеет врать.

I knew Tom wasn't good at lying.

[[Russian#^ru-Q0709-answer|Compare the answer]]
^ru-Q0709

**ru-Q0710 · Choose the form**

Я знал, ____ Том не умеет врать.

I knew Tom wasn't good at lying.

Choices: ли / как / что / чтобы

[[Russian#^ru-Q0710-answer|Compare the answer]]
^ru-Q0710

**ru-Q0711 · Edit the changed sentence**

Никогда не думал, 【чтобы】 такая нежная девочка станет такой грубой и высокомерной женщиной.

I never thought that such a tender girl would become such a rude and arrogant woman.

[[Russian#^ru-Q0711-answer|Compare the answer]]
^ru-Q0711

**ru-Q0712 · Build the sentence**

Arrange: нежная / думал, / что / не / женщиной. / высокомерной / Никогда / и / станет / такой / девочка / такая / грубой

I never thought that such a tender girl would become such a rude and arrogant woman.

[[Russian#^ru-Q0712-answer|Compare the answer]]
^ru-Q0712

**ru-Q0713 · Write a translation**

Write this in Russian: It took me five hours to finish the work.

[[Russian#^ru-Q0713-answer|Compare the answer]]
^ru-Q0713

**ru-Q0714 · Explain the grammar**

На то, 【чтобы】 закончить работу, у меня ушло пять часов.

It took me five hours to finish the work.

[[Russian#^ru-Q0714-answer|Compare the answer]]
^ru-Q0714

**ru-Q0715 · Fill the gap**

Он точен ____ часы.

He is as punctual as a clock.

[[Russian#^ru-Q0715-answer|Compare the answer]]
^ru-Q0715

**ru-Q0716 · Choose the form**

Он точен ____ часы.

He is as punctual as a clock.

Choices: чтобы / как / ли / что

[[Russian#^ru-Q0716-answer|Compare the answer]]
^ru-Q0716

**ru-Q0717 · Edit the changed sentence**

Извините за то, 【чтобы】 я вас беспокою, но не могли бы вы помочь мне?

Sorry to trouble you, but can you help me?

[[Russian#^ru-Q0717-answer|Compare the answer]]
^ru-Q0717

**ru-Q0718 · Build the sentence**

Arrange: то, / Извините / я / помочь / вы / но / за / что / не / беспокою, / могли / вас / мне? / бы

Sorry to trouble you, but can you help me?

[[Russian#^ru-Q0718-answer|Compare the answer]]
^ru-Q0718

**ru-Q0719 · Write a translation**

Write this in Russian: You won't believe what Tom told me!

[[Russian#^ru-Q0719-answer|Compare the answer]]
^ru-Q0719

**ru-Q0720 · Explain the grammar**

Ты не поверишь, 【что】 Том мне рассказал!

You won't believe what Tom told me!

[[Russian#^ru-Q0720-answer|Compare the answer]]
^ru-Q0720

**ru-Q0721 · Fill the gap**

Я говорила вам, ____ вы держались от меня подальше.

I told you to stay away from me.

[[Russian#^ru-Q0721-answer|Compare the answer]]
^ru-Q0721

**ru-Q0722 · Choose the form**

Я говорила вам, ____ вы держались от меня подальше.

I told you to stay away from me.

Choices: как / чтобы / ли / что

[[Russian#^ru-Q0722-answer|Compare the answer]]
^ru-Q0722

**ru-Q0723 · Edit the changed sentence**

Я видел, 【что】 пожилая женщина переходила улицу.

I saw an old woman cross the street.

[[Russian#^ru-Q0723-answer|Compare the answer]]
^ru-Q0723

**ru-Q0724 · Build the sentence**

Arrange: как / Я / улицу. / видел, / переходила / пожилая / женщина

I saw an old woman cross the street.

[[Russian#^ru-Q0724-answer|Compare the answer]]
^ru-Q0724

**ru-Q0725 · Write a translation**

Write this in Russian: I never thought I'd say that.

[[Russian#^ru-Q0725-answer|Compare the answer]]
^ru-Q0725

**ru-Q0726 · Explain the grammar**

Никогда не думал, 【что】 скажу такое.

I never thought I'd say that.

[[Russian#^ru-Q0726-answer|Compare the answer]]
^ru-Q0726

**ru-Q0727 · Fill the gap**

Воздух человеку, ____ рыбе вода.

Air is to man what water is to fish.

[[Russian#^ru-Q0727-answer|Compare the answer]]
^ru-Q0727

**ru-Q0728 · Choose the form**

Воздух человеку, ____ рыбе вода.

Air is to man what water is to fish.

Choices: ли / как / что / чтобы

[[Russian#^ru-Q0728-answer|Compare the answer]]
^ru-Q0728

**ru-Q0729 · Edit the changed sentence**

【чтобы】, если она ушла насовсем?

What if she's gone for good?

[[Russian#^ru-Q0729-answer|Compare the answer]]
^ru-Q0729

**ru-Q0730 · Build the sentence**

Arrange: если / ушла / Что, / насовсем? / она

What if she's gone for good?

[[Russian#^ru-Q0730-answer|Compare the answer]]
^ru-Q0730

**ru-Q0731 · Write a translation**

Write this in Russian: I would like shoes like that.

[[Russian#^ru-Q0731-answer|Compare the answer]]
^ru-Q0731

**ru-Q0732 · Explain the grammar**

Я бы хотела такие же туфли, 【как】 эти.

I would like shoes like that.

[[Russian#^ru-Q0732-answer|Compare the answer]]
^ru-Q0732

**ru-Q0733 · Fill the gap**

Я не хотел, ____ правда вышла наружу.

I didn't want the truth to come out.

[[Russian#^ru-Q0733-answer|Compare the answer]]
^ru-Q0733

**ru-Q0734 · Choose the form**

Я не хотел, ____ правда вышла наружу.

I didn't want the truth to come out.

Choices: как / ли / что / чтобы

[[Russian#^ru-Q0734-answer|Compare the answer]]
^ru-Q0734

**ru-Q0735 · Edit the changed sentence**

Я не знал, 【что】 отказаться.

I didn't know how to say no.

[[Russian#^ru-Q0735-answer|Compare the answer]]
^ru-Q0735

**ru-Q0736 · Build the sentence**

Arrange: знал, / не / Я / отказаться. / как

I didn't know how to say no.

[[Russian#^ru-Q0736-answer|Compare the answer]]
^ru-Q0736

**ru-Q0737 · Write a translation**

Write this in Russian: Tell them to go home.

[[Russian#^ru-Q0737-answer|Compare the answer]]
^ru-Q0737

**ru-Q0738 · Explain the grammar**

Скажи им, 【чтобы】 шли домой.

Tell them to go home.

[[Russian#^ru-Q0738-answer|Compare the answer]]
^ru-Q0738

**ru-Q0739 · Fill the gap**

Я знал, ____ этот день придёт.

I knew this day was coming.

[[Russian#^ru-Q0739-answer|Compare the answer]]
^ru-Q0739

**ru-Q0740 · Choose the form**

Я знал, ____ этот день придёт.

I knew this day was coming.

Choices: ли / что / чтобы / как

[[Russian#^ru-Q0740-answer|Compare the answer]]
^ru-Q0740

**ru-Q0741 · Edit the changed sentence**

Планируете 【что】 вы сказать об этом Тому?

Do you plan on telling Tom to do that?

[[Russian#^ru-Q0741-answer|Compare the answer]]
^ru-Q0741

**ru-Q0742 · Build the sentence**

Arrange: этом / ли / об / вы / Тому? / Планируете / сказать

Do you plan on telling Tom to do that?

[[Russian#^ru-Q0742-answer|Compare the answer]]
^ru-Q0742

**ru-Q0743 · Write a translation**

Write this in Russian: Thanks for saving my life.

[[Russian#^ru-Q0743-answer|Compare the answer]]
^ru-Q0743

**ru-Q0744 · Explain the grammar**

Спасибо, 【что】 спасла мне жизнь.

Thanks for saving my life.

[[Russian#^ru-Q0744-answer|Compare the answer]]
^ru-Q0744

**ru-Q0745 · Fill the gap**

Разве я тебе не говорил, ____ ты туда не ездил?

Didn't I tell you not to go there?

[[Russian#^ru-Q0745-answer|Compare the answer]]
^ru-Q0745

**ru-Q0746 · Choose the form**

Разве я тебе не говорил, ____ ты туда не ездил?

Didn't I tell you not to go there?

Choices: ли / что / как / чтобы

[[Russian#^ru-Q0746-answer|Compare the answer]]
^ru-Q0746

**ru-Q0747 · Edit the changed sentence**

Том тебе не говорил, потому 【чтобы】 не хотел, чтобы ты о нём беспокоилась.

Tom never told you because he didn't want you to worry about him.

[[Russian#^ru-Q0747-answer|Compare the answer]]
^ru-Q0747

**ru-Q0748 · Build the sentence**

Arrange: нём / что / потому / о / говорил, / хотел, / не / ты / беспокоилась. / чтобы / Том / не / тебе

Tom never told you because he didn't want you to worry about him.

[[Russian#^ru-Q0748-answer|Compare the answer]]
^ru-Q0748

**ru-Q0749 · Write a translation**

Write this in Russian: Thanks for coming back.

[[Russian#^ru-Q0749-answer|Compare the answer]]
^ru-Q0749

**ru-Q0750 · Explain the grammar**

Спасибо, 【что】 вернулись.

Thanks for coming back.

[[Russian#^ru-Q0750-answer|Compare the answer]]
^ru-Q0750


### Relative forms · 50 questions

**ru-Q0751 · Fill the gap**

Первым предметом, ____ он приобрёл, стал будильник.

The first item he bought was an alarm clock.

[[Russian#^ru-Q0751-answer|Compare the answer]]
^ru-Q0751

**ru-Q0752 · Choose the form**

Первым предметом, ____ он приобрёл, стал будильник.

The first item he bought was an alarm clock.

Choices: которое / который / которые / которая

[[Russian#^ru-Q0752-answer|Compare the answer]]
^ru-Q0752

**ru-Q0753 · Edit the changed sentence**

Есть математическое понятие, 【который】 я не понимаю. Не могли бы вы мне его объяснить?

There's a mathematical concept that I don't understand. Could you explain it to me?

[[Russian#^ru-Q0753-answer|Compare the answer]]
^ru-Q0753

**ru-Q0754 · Build the sentence**

Arrange: понятие, / его / Есть / которого / бы / мне / объяснить? / Не / не / понимаю. / могли / я / математическое / вы

There's a mathematical concept that I don't understand. Could you explain it to me?

[[Russian#^ru-Q0754-answer|Compare the answer]]
^ru-Q0754

**ru-Q0755 · Write a translation**

Write this in Russian: An exomoon is a moon that orbits around an exoplanet.

[[Russian#^ru-Q0755-answer|Compare the answer]]
^ru-Q0755

**ru-Q0756 · Explain the grammar**

Экзолуна - это луна, 【которая】 вращается вокруг экзопланеты.

An exomoon is a moon that orbits around an exoplanet.

[[Russian#^ru-Q0756-answer|Compare the answer]]
^ru-Q0756

**ru-Q0757 · Fill the gap**

Я думаю, маловероятно, что Тому разрешат оставить себе золото, ____ он нашел.

I think it's highly unlikely that Tom will be allowed to keep the gold that he found.

[[Russian#^ru-Q0757-answer|Compare the answer]]
^ru-Q0757

**ru-Q0758 · Choose the form**

Я думаю, маловероятно, что Тому разрешат оставить себе золото, ____ он нашел.

I think it's highly unlikely that Tom will be allowed to keep the gold that he found.

Choices: которые / которая / который / которое

[[Russian#^ru-Q0758-answer|Compare the answer]]
^ru-Q0758

**ru-Q0759 · Edit the changed sentence**

Мужчина, 【который】 мы видели сегодня утром, был мистер Грин.

The man we saw this morning was Mr Green.

[[Russian#^ru-Q0759-answer|Compare the answer]]
^ru-Q0759

**ru-Q0760 · Build the sentence**

Arrange: видели / мистер / которого / был / Грин. / утром, / Мужчина, / сегодня / мы

The man we saw this morning was Mr Green.

[[Russian#^ru-Q0760-answer|Compare the answer]]
^ru-Q0760

**ru-Q0761 · Write a translation**

Write this in Russian: I have not failed. I've just found 10,000 ways that won't work.

[[Russian#^ru-Q0761-answer|Compare the answer]]
^ru-Q0761

**ru-Q0762 · Explain the grammar**

Я не ошибался. Я просто нашёл 10000 способов, 【которые】 не работают.

I have not failed. I've just found 10,000 ways that won't work.

[[Russian#^ru-Q0762-answer|Compare the answer]]
^ru-Q0762

**ru-Q0763 · Fill the gap**

Нет ничего пугающего в обычной, естественной смерти; в смерти человека, ____ реализовал себя и прожил свою жизнь.

There is nothing frightening about a normal, natural death, the death of a man who has fulfilled himself and lived out his life.

[[Russian#^ru-Q0763-answer|Compare the answer]]
^ru-Q0763

**ru-Q0764 · Choose the form**

Нет ничего пугающего в обычной, естественной смерти; в смерти человека, ____ реализовал себя и прожил свою жизнь.

There is nothing frightening about a normal, natural death, the death of a man who has fulfilled himself and lived out his life.

Choices: которое / который / которая / которые

[[Russian#^ru-Q0764-answer|Compare the answer]]
^ru-Q0764

**ru-Q0765 · Edit the changed sentence**

Машина красивая, но она не стоит тех денег, 【который】 я отдал за неё.

It is a beautiful car, but it is not worth the price that I paid for it.

[[Russian#^ru-Q0765-answer|Compare the answer]]
^ru-Q0765

**ru-Q0766 · Build the sentence**

Arrange: Машина / я / она / тех / за / стоит / которые / не / красивая, / но / денег, / отдал / неё.

It is a beautiful car, but it is not worth the price that I paid for it.

[[Russian#^ru-Q0766-answer|Compare the answer]]
^ru-Q0766

**ru-Q0767 · Write a translation**

Write this in Russian: This is the place where my father was born.

[[Russian#^ru-Q0767-answer|Compare the answer]]
^ru-Q0767

**ru-Q0768 · Explain the grammar**

Это место, в 【котором】 родился мой отец.

This is the place where my father was born.

[[Russian#^ru-Q0768-answer|Compare the answer]]
^ru-Q0768

**ru-Q0769 · Fill the gap**

Это тот мужчина, жена ____ умерла.

That's the man whose wife died.

[[Russian#^ru-Q0769-answer|Compare the answer]]
^ru-Q0769

**ru-Q0770 · Choose the form**

Это тот мужчина, жена ____ умерла.

That's the man whose wife died.

Choices: который / которая / которого / которое

[[Russian#^ru-Q0770-answer|Compare the answer]]
^ru-Q0770

**ru-Q0771 · Edit the changed sentence**

Мы нашли ту вещь, 【который】 искали.

We found the thing we were looking for.

[[Russian#^ru-Q0771-answer|Compare the answer]]
^ru-Q0771

**ru-Q0772 · Build the sentence**

Arrange: которую / нашли / вещь, / искали. / Мы / ту

We found the thing we were looking for.

[[Russian#^ru-Q0772-answer|Compare the answer]]
^ru-Q0772

**ru-Q0773 · Write a translation**

Write this in Russian: I have a Me 2, which is stronger than my Me 1.

[[Russian#^ru-Q0773-answer|Compare the answer]]
^ru-Q0773

**ru-Q0774 · Explain the grammar**

У меня есть я-2, 【который】 сильнее, чем мой я-1.

I have a Me 2, which is stronger than my Me 1.

[[Russian#^ru-Q0774-answer|Compare the answer]]
^ru-Q0774

**ru-Q0775 · Fill the gap**

Зонтик, ____ я вам дал, всё ещё у вас?

Do you still have that umbrella I gave you?

[[Russian#^ru-Q0775-answer|Compare the answer]]
^ru-Q0775

**ru-Q0776 · Choose the form**

Зонтик, ____ я вам дал, всё ещё у вас?

Do you still have that umbrella I gave you?

Choices: которая / которое / который / которые

[[Russian#^ru-Q0776-answer|Compare the answer]]
^ru-Q0776

**ru-Q0777 · Edit the changed sentence**

Нам сложно выбрать, 【которая】 из них купить.

We find it difficult to decide which one to buy.

[[Russian#^ru-Q0777-answer|Compare the answer]]
^ru-Q0777

**ru-Q0778 · Build the sentence**

Arrange: Нам / выбрать, / который / купить. / сложно / них / из

We find it difficult to decide which one to buy.

[[Russian#^ru-Q0778-answer|Compare the answer]]
^ru-Q0778

**ru-Q0779 · Write a translation**

Write this in Russian: Have you read the book Tom bought for you?

[[Russian#^ru-Q0779-answer|Compare the answer]]
^ru-Q0779

**ru-Q0780 · Explain the grammar**

Вы прочли книгу, 【которую】 Том вам купил?

Have you read the book Tom bought for you?

[[Russian#^ru-Q0780-answer|Compare the answer]]
^ru-Q0780

**ru-Q0781 · Fill the gap**

Я помню радостные дни, ____ мы провели вместе.

I remember the happy days we spent together.

[[Russian#^ru-Q0781-answer|Compare the answer]]
^ru-Q0781

**ru-Q0782 · Choose the form**

Я помню радостные дни, ____ мы провели вместе.

I remember the happy days we spent together.

Choices: которое / который / которая / которые

[[Russian#^ru-Q0782-answer|Compare the answer]]
^ru-Q0782

**ru-Q0783 · Edit the changed sentence**

Все, чего хотел Том, - это найти женщину, 【который】 была бы способна принять его любовь.

All Tom wanted was to find a woman who would accept all the love he had to give.

[[Russian#^ru-Q0783-answer|Compare the answer]]
^ru-Q0783

**ru-Q0784 · Build the sentence**

Arrange: бы / его / способна / любовь. / женщину, / принять / хотел / Том, / чего / была / которая / это / Все, / - / найти

All Tom wanted was to find a woman who would accept all the love he had to give.

[[Russian#^ru-Q0784-answer|Compare the answer]]
^ru-Q0784

**ru-Q0785 · Write a translation**

Write this in Russian: I know a girl who speaks French.

[[Russian#^ru-Q0785-answer|Compare the answer]]
^ru-Q0785

**ru-Q0786 · Explain the grammar**

Я знаю одну девушку, 【которая】 говорит по-французски.

I know a girl who speaks French.

[[Russian#^ru-Q0786-answer|Compare the answer]]
^ru-Q0786

**ru-Q0787 · Fill the gap**

Когда читаешь книгу на английском, плохая идея искать перевод каждого слова, ____ не знаешь.

When you're reading an English book, it isn't a great idea to look up every word you don't know.

[[Russian#^ru-Q0787-answer|Compare the answer]]
^ru-Q0787

**ru-Q0788 · Choose the form**

Когда читаешь книгу на английском, плохая идея искать перевод каждого слова, ____ не знаешь.

When you're reading an English book, it isn't a great idea to look up every word you don't know.

Choices: которое / которого / который / которая

[[Russian#^ru-Q0788-answer|Compare the answer]]
^ru-Q0788

**ru-Q0789 · Edit the changed sentence**

Тому были нужны деньги, и он сказал, что устроится на любую работу, 【который】 ему предложат.

Tom was hard up for money and said he would take any job he was offered.

[[Russian#^ru-Q0789-answer|Compare the answer]]
^ru-Q0789

**ru-Q0790 · Build the sentence**

Arrange: что / любую / предложат. / которую / ему / работу, / и / деньги, / устроится / на / Тому / он / нужны / были / сказал,

Tom was hard up for money and said he would take any job he was offered.

[[Russian#^ru-Q0790-answer|Compare the answer]]
^ru-Q0790

**ru-Q0791 · Write a translation**

Write this in Russian: Tom still hasn't eaten the cookies you made for him.

[[Russian#^ru-Q0791-answer|Compare the answer]]
^ru-Q0791

**ru-Q0792 · Explain the grammar**

Том ещё не съел печенье, 【которое】 вы ему испекли.

Tom still hasn't eaten the cookies you made for him.

[[Russian#^ru-Q0792-answer|Compare the answer]]
^ru-Q0792

**ru-Q0793 · Fill the gap**

Мне не понравилось платье, в ____ Мэри была.

I didn't like the dress that Mary was wearing.

[[Russian#^ru-Q0793-answer|Compare the answer]]
^ru-Q0793

**ru-Q0794 · Choose the form**

Мне не понравилось платье, в ____ Мэри была.

I didn't like the dress that Mary was wearing.

Choices: которое / которая / который / котором

[[Russian#^ru-Q0794-answer|Compare the answer]]
^ru-Q0794

**ru-Q0795 · Edit the changed sentence**

Том нашёл то место, 【который】 искал.

Tom found the place he was looking for.

[[Russian#^ru-Q0795-answer|Compare the answer]]
^ru-Q0795

**ru-Q0796 · Build the sentence**

Arrange: искал. / нашёл / которое / место, / Том / то

Tom found the place he was looking for.

[[Russian#^ru-Q0796-answer|Compare the answer]]
^ru-Q0796

**ru-Q0797 · Write a translation**

Write this in Russian: My grandfather, who has an old-fashioned attitude, complains about how girls dress nowadays.

[[Russian#^ru-Q0797-answer|Compare the answer]]
^ru-Q0797

**ru-Q0798 · Explain the grammar**

Мой дедушка, у 【которого】 старомодные взгляды на жизнь, сетует на то, как одеваются современные девушки.

My grandfather, who has an old-fashioned attitude, complains about how girls dress nowadays.

[[Russian#^ru-Q0798-answer|Compare the answer]]
^ru-Q0798

**ru-Q0799 · Fill the gap**

Машина, ____ он ведёт, не его.

The car he's driving is not his.

[[Russian#^ru-Q0799-answer|Compare the answer]]
^ru-Q0799

**ru-Q0800 · Choose the form**

Машина, ____ он ведёт, не его.

The car he's driving is not his.

Choices: который / которая / которое / которую

[[Russian#^ru-Q0800-answer|Compare the answer]]
^ru-Q0800


### Hypothetical бы · 50 questions

**ru-Q0801 · Edit the changed sentence**

Она 【если】 вам понравилась.

You would've liked her.

[[Russian#^ru-Q0801-answer|Compare the answer]]
^ru-Q0801

**ru-Q0802 · Build the sentence**

Arrange: бы / понравилась. / Она / вам

You would've liked her.

[[Russian#^ru-Q0802-answer|Compare the answer]]
^ru-Q0802

**ru-Q0803 · Write a translation**

Write this in Russian: I wish I had Tom's brains.

[[Russian#^ru-Q0803-answer|Compare the answer]]
^ru-Q0803

**ru-Q0804 · Explain the grammar**

Вот 【бы】 мне мозги Тома.

I wish I had Tom's brains.

[[Russian#^ru-Q0804-answer|Compare the answer]]
^ru-Q0804

**ru-Q0805 · Fill the gap**

О чём ____ вы хотели поговорить?

What would you like to talk about?

[[Russian#^ru-Q0805-answer|Compare the answer]]
^ru-Q0805

**ru-Q0806 · Choose the form**

О чём ____ вы хотели поговорить?

What would you like to talk about?

Choices: когда / бы / если

[[Russian#^ru-Q0806-answer|Compare the answer]]
^ru-Q0806

**ru-Q0807 · Edit the changed sentence**

【бы】 он занят, помогите ему.

If he's busy, help him.

[[Russian#^ru-Q0807-answer|Compare the answer]]
^ru-Q0807

**ru-Q0808 · Build the sentence**

Arrange: он / помогите / ему. / Если / занят,

If he's busy, help him.

[[Russian#^ru-Q0808-answer|Compare the answer]]
^ru-Q0808

**ru-Q0809 · Write a translation**

Write this in Russian: If you want to leave, leave.

[[Russian#^ru-Q0809-answer|Compare the answer]]
^ru-Q0809

**ru-Q0810 · Explain the grammar**

【Если】 хочешь уехать, уезжай.

If you want to leave, leave.

[[Russian#^ru-Q0810-answer|Compare the answer]]
^ru-Q0810

**ru-Q0811 · Fill the gap**

____ вы написали на сиденье в туалете, то вытрите за собой!

If you piss on the toilet seat, wipe it off!

[[Russian#^ru-Q0811-answer|Compare the answer]]
^ru-Q0811

**ru-Q0812 · Choose the form**

____ вы написали на сиденье в туалете, то вытрите за собой!

If you piss on the toilet seat, wipe it off!

Choices: бы / когда / Если

[[Russian#^ru-Q0812-answer|Compare the answer]]
^ru-Q0812

**ru-Q0813 · Edit the changed sentence**

Том хотел 【если】 это сделать.

Tom would want to do that.

[[Russian#^ru-Q0813-answer|Compare the answer]]
^ru-Q0813

**ru-Q0814 · Build the sentence**

Arrange: хотел / это / Том / бы / сделать.

Tom would want to do that.

[[Russian#^ru-Q0814-answer|Compare the answer]]
^ru-Q0814

**ru-Q0815 · Write a translation**

Write this in Russian: I'd like to join you.

[[Russian#^ru-Q0815-answer|Compare the answer]]
^ru-Q0815

**ru-Q0816 · Explain the grammar**

Я хотел 【бы】 к вам присоединиться.

I'd like to join you.

[[Russian#^ru-Q0816-answer|Compare the answer]]
^ru-Q0816

**ru-Q0817 · Fill the gap**

Почему ____ тебе не поехать с нами?

Why don't you go with us?

[[Russian#^ru-Q0817-answer|Compare the answer]]
^ru-Q0817

**ru-Q0818 · Choose the form**

Почему ____ тебе не поехать с нами?

Why don't you go with us?

Choices: бы / если / когда

[[Russian#^ru-Q0818-answer|Compare the answer]]
^ru-Q0818

**ru-Q0819 · Edit the changed sentence**

Том не понимает, почему кто-либо стал 【если】 так делать.

Tom doesn't see why anybody would want to do that.

[[Russian#^ru-Q0819-answer|Compare the answer]]
^ru-Q0819

**ru-Q0820 · Build the sentence**

Arrange: почему / кто-либо / Том / так / стал / понимает, / бы / делать. / не

Tom doesn't see why anybody would want to do that.

[[Russian#^ru-Q0820-answer|Compare the answer]]
^ru-Q0820

**ru-Q0821 · Write a translation**

Write this in Russian: Why don't you ask Tom to help?

[[Russian#^ru-Q0821-answer|Compare the answer]]
^ru-Q0821

**ru-Q0822 · Explain the grammar**

Почему 【бы】 тебе не попросить Тома помочь?

Why don't you ask Tom to help?

[[Russian#^ru-Q0822-answer|Compare the answer]]
^ru-Q0822

**ru-Q0823 · Fill the gap**

Том не стал ____ объяснять почему.

Tom wouldn't explain why.

[[Russian#^ru-Q0823-answer|Compare the answer]]
^ru-Q0823

**ru-Q0824 · Choose the form**

Том не стал ____ объяснять почему.

Tom wouldn't explain why.

Choices: если / когда / бы

[[Russian#^ru-Q0824-answer|Compare the answer]]
^ru-Q0824

**ru-Q0825 · Edit the changed sentence**

Почему 【если】 вам не дать ему самому решить?

Why don't you let him decide?

[[Russian#^ru-Q0825-answer|Compare the answer]]
^ru-Q0825

**ru-Q0826 · Build the sentence**

Arrange: не / самому / бы / дать / решить? / ему / Почему / вам

Why don't you let him decide?

[[Russian#^ru-Q0826-answer|Compare the answer]]
^ru-Q0826

**ru-Q0827 · Write a translation**

Write this in Russian: Tom should tell him the truth.

[[Russian#^ru-Q0827-answer|Compare the answer]]
^ru-Q0827

**ru-Q0828 · Explain the grammar**

Тому надо 【бы】 сказать ему правду.

Tom should tell him the truth.

[[Russian#^ru-Q0828-answer|Compare the answer]]
^ru-Q0828

**ru-Q0829 · Fill the gap**

Я ____ хотел апельсинового сока.

I'd like an orange juice.

[[Russian#^ru-Q0829-answer|Compare the answer]]
^ru-Q0829

**ru-Q0830 · Choose the form**

Я ____ хотел апельсинового сока.

I'd like an orange juice.

Choices: бы / когда / если

[[Russian#^ru-Q0830-answer|Compare the answer]]
^ru-Q0830

**ru-Q0831 · Edit the changed sentence**

Я 【если】 никогда не стал пробовать это делать.

I'd never try to do that.

[[Russian#^ru-Q0831-answer|Compare the answer]]
^ru-Q0831

**ru-Q0832 · Build the sentence**

Arrange: не / никогда / Я / бы / пробовать / стал / это / делать.

I'd never try to do that.

[[Russian#^ru-Q0832-answer|Compare the answer]]
^ru-Q0832

**ru-Q0833 · Write a translation**

Write this in Russian: You could have told me.

[[Russian#^ru-Q0833-answer|Compare the answer]]
^ru-Q0833

**ru-Q0834 · Explain the grammar**

Могли 【бы】 и сказать.

You could have told me.

[[Russian#^ru-Q0834-answer|Compare the answer]]
^ru-Q0834

**ru-Q0835 · Fill the gap**

А что, ____ он отвергнет меня?

And what if he rejects me?

[[Russian#^ru-Q0835-answer|Compare the answer]]
^ru-Q0835

**ru-Q0836 · Choose the form**

А что, ____ он отвергнет меня?

And what if he rejects me?

Choices: бы / если / когда

[[Russian#^ru-Q0836-answer|Compare the answer]]
^ru-Q0836

**ru-Q0837 · Edit the changed sentence**

Почему 【если】 нам не встретиться напротив вокзала?

Why don't we meet in front of the station?

[[Russian#^ru-Q0837-answer|Compare the answer]]
^ru-Q0837

**ru-Q0838 · Build the sentence**

Arrange: встретиться / нам / Почему / не / напротив / вокзала? / бы

Why don't we meet in front of the station?

[[Russian#^ru-Q0838-answer|Compare the answer]]
^ru-Q0838

**ru-Q0839 · Write a translation**

Write this in Russian: I suppose we could ask him.

[[Russian#^ru-Q0839-answer|Compare the answer]]
^ru-Q0839

**ru-Q0840 · Explain the grammar**

Полагаю, мы могли 【бы】 спросить у него.

I suppose we could ask him.

[[Russian#^ru-Q0840-answer|Compare the answer]]
^ru-Q0840

**ru-Q0841 · Fill the gap**

Почему ____ тебе не присесть прямо вон там на кушетке?

Why don't you sit right there on the couch?

[[Russian#^ru-Q0841-answer|Compare the answer]]
^ru-Q0841

**ru-Q0842 · Choose the form**

Почему ____ тебе не присесть прямо вон там на кушетке?

Why don't you sit right there on the couch?

Choices: когда / если / бы

[[Russian#^ru-Q0842-answer|Compare the answer]]
^ru-Q0842

**ru-Q0843 · Edit the changed sentence**

【бы】 вы этого не сделаете, Том рассердится.

If you don't do that, Tom will get angry.

[[Russian#^ru-Q0843-answer|Compare the answer]]
^ru-Q0843

**ru-Q0844 · Build the sentence**

Arrange: не / вы / Если / сделаете, / Том / рассердится. / этого

If you don't do that, Tom will get angry.

[[Russian#^ru-Q0844-answer|Compare the answer]]
^ru-Q0844

**ru-Q0845 · Write a translation**

Write this in Russian: What would you like to do today?

[[Russian#^ru-Q0845-answer|Compare the answer]]
^ru-Q0845

**ru-Q0846 · Explain the grammar**

Чем 【бы】 вы хотели сегодня заняться?

What would you like to do today?

[[Russian#^ru-Q0846-answer|Compare the answer]]
^ru-Q0846

**ru-Q0847 · Fill the gap**

Видел ____ ты выражение своего лица.

You should've seen the look on your face.

[[Russian#^ru-Q0847-answer|Compare the answer]]
^ru-Q0847

**ru-Q0848 · Choose the form**

Видел ____ ты выражение своего лица.

You should've seen the look on your face.

Choices: когда / бы / если

[[Russian#^ru-Q0848-answer|Compare the answer]]
^ru-Q0848

**ru-Q0849 · Edit the changed sentence**

Пожалуйста, вы 【если】 не могли это взять?

Could you take this, please?

[[Russian#^ru-Q0849-answer|Compare the answer]]
^ru-Q0849

**ru-Q0850 · Build the sentence**

Arrange: вы / могли / бы / не / Пожалуйста, / это / взять?

Could you take this, please?

[[Russian#^ru-Q0850-answer|Compare the answer]]
^ru-Q0850


### Logical connectors · 50 questions

**ru-Q0851 · Write a translation**

Write this in Russian: There is only one religion, though there are a hundred versions of it.

[[Russian#^ru-Q0851-answer|Compare the answer]]
^ru-Q0851

**ru-Q0852 · Explain the grammar**

Есть только одна религия, 【хотя】 у неё сотня вариаций.

There is only one religion, though there are a hundred versions of it.

[[Russian#^ru-Q0852-answer|Compare the answer]]
^ru-Q0852

**ru-Q0853 · Fill the gap**

Он не извинился, ____ и был неправ.

Although he was wrong, he didn't say he was sorry.

[[Russian#^ru-Q0853-answer|Compare the answer]]
^ru-Q0853

**ru-Q0854 · Choose the form**

Он не извинился, ____ и был неправ.

Although he was wrong, he didn't say he was sorry.

Choices: хотя / однако / поэтому / потому что

[[Russian#^ru-Q0854-answer|Compare the answer]]
^ru-Q0854

**ru-Q0855 · Edit the changed sentence**

【потому что】 автобуса не было, мне пришлось идти пешком.

Since there was no bus, I had to walk.

[[Russian#^ru-Q0855-answer|Compare the answer]]
^ru-Q0855

**ru-Q0856 · Build the sentence**

Arrange: было, / мне / пешком. / не / автобуса / пришлось / Так / идти / как

Since there was no bus, I had to walk.

[[Russian#^ru-Q0856-answer|Compare the answer]]
^ru-Q0856

**ru-Q0857 · Write a translation**

Write this in Russian: Don't be angry with me, for I did it for your sake.

[[Russian#^ru-Q0857-answer|Compare the answer]]
^ru-Q0857

**ru-Q0858 · Explain the grammar**

Не сердитесь на меня, 【потому что】 я сделал это ради вас.

Don't be angry with me, for I did it for your sake.

[[Russian#^ru-Q0858-answer|Compare the answer]]
^ru-Q0858

**ru-Q0859 · Fill the gap**

____ Том вырос рядом с океаном, он так и не научился плавать.

Even though Tom grew up near the ocean, he never learned how to swim.

[[Russian#^ru-Q0859-answer|Compare the answer]]
^ru-Q0859

**ru-Q0860 · Choose the form**

____ Том вырос рядом с океаном, он так и не научился плавать.

Even though Tom grew up near the ocean, he never learned how to swim.

Choices: однако / потому что / поэтому / Хотя

[[Russian#^ru-Q0860-answer|Compare the answer]]
^ru-Q0860

**ru-Q0861 · Edit the changed sentence**

Я не буду разгружать машину, 【хотя】 это не моя работа.

I won't unload the car because that's somebody else's job.

[[Russian#^ru-Q0861-answer|Compare the answer]]
^ru-Q0861

**ru-Q0862 · Build the sentence**

Arrange: разгружать / буду / это / Я / моя / машину, / работа. / что / не / не / потому

I won't unload the car because that's somebody else's job.

[[Russian#^ru-Q0862-answer|Compare the answer]]
^ru-Q0862

**ru-Q0863 · Write a translation**

Write this in Russian: I'll always love you. No matter what.

[[Russian#^ru-Q0863-answer|Compare the answer]]
^ru-Q0863

**ru-Q0864 · Explain the grammar**

Я всегда буду тебя любить. 【Несмотря】 ни на что.

I'll always love you. No matter what.

[[Russian#^ru-Q0864-answer|Compare the answer]]
^ru-Q0864

**ru-Q0865 · Fill the gap**

Даже ____ на то, что она была занята, она пришла повидаться со мной.

Even though she was busy, she came to see me.

[[Russian#^ru-Q0865-answer|Compare the answer]]
^ru-Q0865

**ru-Q0866 · Choose the form**

Даже ____ на то, что она была занята, она пришла повидаться со мной.

Even though she was busy, she came to see me.

Choices: хотя / потому что / несмотря / однако

[[Russian#^ru-Q0866-answer|Compare the answer]]
^ru-Q0866

**ru-Q0867 · Edit the changed sentence**

【хотя】 ты идиот!

Because you are an idiot!

[[Russian#^ru-Q0867-answer|Compare the answer]]
^ru-Q0867

**ru-Q0868 · Build the sentence**

Arrange: что / идиот! / Потому / ты

Because you are an idiot!

[[Russian#^ru-Q0868-answer|Compare the answer]]
^ru-Q0868

**ru-Q0869 · Write a translation**

Write this in Russian: You came despite my ban.

[[Russian#^ru-Q0869-answer|Compare the answer]]
^ru-Q0869

**ru-Q0870 · Explain the grammar**

Ты пришла, 【несмотря】 на мой запрет.

You came despite my ban.

[[Russian#^ru-Q0870-answer|Compare the answer]]
^ru-Q0870

**ru-Q0871 · Fill the gap**

Мы выжаты как лимон, ____ мы весь день предавались греху.

We are worn out because we fucked all day long.

[[Russian#^ru-Q0871-answer|Compare the answer]]
^ru-Q0871

**ru-Q0872 · Choose the form**

Мы выжаты как лимон, ____ мы весь день предавались греху.

We are worn out because we fucked all day long.

Choices: потому что / поэтому / однако / хотя

[[Russian#^ru-Q0872-answer|Compare the answer]]
^ru-Q0872

**ru-Q0873 · Edit the changed sentence**

Вчера - уже история, а завтра - тайна. 【потому что】, сегодня - подарок судьбы, а подарки должны приносить радость.

Yesterday is already history, and tomorrow, a mystery. However, today is a present of fate, and presents are supposed to bring joy.

[[Russian#^ru-Q0873-answer|Compare the answer]]
^ru-Q0873

**ru-Q0874 · Build the sentence**

Arrange: уже / - / история, / завтра / подарок / а / тайна. / приносить / сегодня / а / радость. / подарки / - / Вчера / - / судьбы, / должны / Однако,

Yesterday is already history, and tomorrow, a mystery. However, today is a present of fate, and presents are supposed to bring joy.

[[Russian#^ru-Q0874-answer|Compare the answer]]
^ru-Q0874

**ru-Q0875 · Write a translation**

Write this in Russian: He isn't here because he's ill.

[[Russian#^ru-Q0875-answer|Compare the answer]]
^ru-Q0875

**ru-Q0876 · Explain the grammar**

Его нет, 【потому что】 он болеет.

He isn't here because he's ill.

[[Russian#^ru-Q0876-answer|Compare the answer]]
^ru-Q0876

**ru-Q0877 · Fill the gap**

Тому было трудно дышать, ____ мы отвезли его в больницу.

Tom was having trouble breathing, so we took him to the hospital.

[[Russian#^ru-Q0877-answer|Compare the answer]]
^ru-Q0877

**ru-Q0878 · Choose the form**

Тому было трудно дышать, ____ мы отвезли его в больницу.

Tom was having trouble breathing, so we took him to the hospital.

Choices: однако / поэтому / хотя / потому что

[[Russian#^ru-Q0878-answer|Compare the answer]]
^ru-Q0878

**ru-Q0879 · Edit the changed sentence**

【потому что】 в истории существуют примеры, когда успешно истреблялись целые народы.

However, there are instances in history where entire peoples were successfully exterminated.

[[Russian#^ru-Q0879-answer|Compare the answer]]
^ru-Q0879

**ru-Q0880 · Build the sentence**

Arrange: целые / успешно / истреблялись / народы. / существуют / примеры, / в / истории / когда / Однако

However, there are instances in history where entire peoples were successfully exterminated.

[[Russian#^ru-Q0880-answer|Compare the answer]]
^ru-Q0880

**ru-Q0881 · Write a translation**

Write this in Russian: I can't go to work today because I have the flu.

[[Russian#^ru-Q0881-answer|Compare the answer]]
^ru-Q0881

**ru-Q0882 · Explain the grammar**

Я не могу сегодня идти на работу, 【потому что】 у меня грипп.

I can't go to work today because I have the flu.

[[Russian#^ru-Q0882-answer|Compare the answer]]
^ru-Q0882

**ru-Q0883 · Fill the gap**

Шкурки были слишком повреждены и не годились для продажи, ____ он сшил из них сыну пару рукавичек.

The pelts were too damaged to be sold, so he used them to make his son a pair of mittens.

[[Russian#^ru-Q0883-answer|Compare the answer]]
^ru-Q0883

**ru-Q0884 · Choose the form**

Шкурки были слишком повреждены и не годились для продажи, ____ он сшил из них сыну пару рукавичек.

The pelts were too damaged to be sold, so he used them to make his son a pair of mittens.

Choices: хотя / поэтому / однако / потому что

[[Russian#^ru-Q0884-answer|Compare the answer]]
^ru-Q0884

**ru-Q0885 · Edit the changed sentence**

Я купила цветы, 【потому что】 сегодня в гости заедет бабушка.

I bought flowers because my grandmother is coming today for a visit.

[[Russian#^ru-Q0885-answer|Compare the answer]]
^ru-Q0885

**ru-Q0886 · Build the sentence**

Arrange: так / как / купила / заедет / в / цветы, / гости / Я / бабушка. / сегодня

I bought flowers because my grandmother is coming today for a visit.

[[Russian#^ru-Q0886-answer|Compare the answer]]
^ru-Q0886

**ru-Q0887 · Write a translation**

Write this in Russian: I'm crying because I'm sad.

[[Russian#^ru-Q0887-answer|Compare the answer]]
^ru-Q0887

**ru-Q0888 · Explain the grammar**

Я плачу, 【потому что】 мне грустно.

I'm crying because I'm sad.

[[Russian#^ru-Q0888-answer|Compare the answer]]
^ru-Q0888

**ru-Q0889 · Fill the gap**

Вы ____ опоздали?

Is that why you were late?

[[Russian#^ru-Q0889-answer|Compare the answer]]
^ru-Q0889

**ru-Q0890 · Choose the form**

Вы ____ опоздали?

Is that why you were late?

Choices: однако / поэтому / потому что / хотя

[[Russian#^ru-Q0890-answer|Compare the answer]]
^ru-Q0890

**ru-Q0891 · Edit the changed sentence**

"Почему ты не идёшь?" - "【хотя】 не хочу".

"Why aren't you going?" "Because I don't want to."

[[Russian#^ru-Q0891-answer|Compare the answer]]
^ru-Q0891

**ru-Q0892 · Build the sentence**

Arrange: "Потому / "Почему / ты / идёшь?" / что / хочу". / не / - / не

"Why aren't you going?" "Because I don't want to."

[[Russian#^ru-Q0892-answer|Compare the answer]]
^ru-Q0892

**ru-Q0893 · Write a translation**

Write this in Russian: Tom could at least have said thank you.

[[Russian#^ru-Q0893-answer|Compare the answer]]
^ru-Q0893

**ru-Q0894 · Explain the grammar**

Том мог бы 【хотя】 бы спасибо сказать.

Tom could at least have said thank you.

[[Russian#^ru-Q0894-answer|Compare the answer]]
^ru-Q0894

**ru-Q0895 · Fill the gap**

Том не может сейчас с тобой поговорить, ____ занят.

Tom can't talk to you right now because he's busy.

[[Russian#^ru-Q0895-answer|Compare the answer]]
^ru-Q0895

**ru-Q0896 · Choose the form**

Том не может сейчас с тобой поговорить, ____ занят.

Tom can't talk to you right now because he's busy.

Choices: хотя / потому что / однако / поэтому

[[Russian#^ru-Q0896-answer|Compare the answer]]
^ru-Q0896

**ru-Q0897 · Edit the changed sentence**

Вот именно 【потому что】 я и пришла!

That's exactly why I came!

[[Russian#^ru-Q0897-answer|Compare the answer]]
^ru-Q0897

**ru-Q0898 · Build the sentence**

Arrange: пришла! / Вот / поэтому / именно / и / я

That's exactly why I came!

[[Russian#^ru-Q0898-answer|Compare the answer]]
^ru-Q0898

**ru-Q0899 · Write a translation**

Write this in Russian: It started raining hard. Because of that, we played inside.

[[Russian#^ru-Q0899-answer|Compare the answer]]
^ru-Q0899

**ru-Q0900 · Explain the grammar**

Начался сильный дождь. 【Поэтому】 мы играли внутри.

It started raining hard. Because of that, we played inside.

[[Russian#^ru-Q0900-answer|Compare the answer]]
^ru-Q0900


### Quantity and comparison · 50 questions

**ru-Q0901 · Fill the gap**

Она оказалась ____, чем я себе её представлял.

She turned out to be smaller than I'd thought she was.

[[Russian#^ru-Q0901-answer|Compare the answer]]
^ru-Q0901

**ru-Q0902 · Choose the form**

Она оказалась ____, чем я себе её представлял.

She turned out to be smaller than I'd thought she was.

Choices: две / много / два / меньше

[[Russian#^ru-Q0902-answer|Compare the answer]]
^ru-Q0902

**ru-Q0903 · Edit the changed sentence**

Том и Мария 【два】 не любят друг друга.

Tom and Mary don't love each other anymore.

[[Russian#^ru-Q0903-answer|Compare the answer]]
^ru-Q0903

**ru-Q0904 · Build the sentence**

Arrange: друг / и / Мария / Том / друга. / любят / больше / не

Tom and Mary don't love each other anymore.

[[Russian#^ru-Q0904-answer|Compare the answer]]
^ru-Q0904

**ru-Q0905 · Write a translation**

Write this in Russian: Tom ate more than I did.

[[Russian#^ru-Q0905-answer|Compare the answer]]
^ru-Q0905

**ru-Q0906 · Explain the grammar**

Том съел 【больше】 меня.

Tom ate more than I did.

[[Russian#^ru-Q0906-answer|Compare the answer]]
^ru-Q0906

**ru-Q0907 · Fill the gap**

Том совершает пробежку ____ раза в неделю.

Tom jogs three times a week.

[[Russian#^ru-Q0907-answer|Compare the answer]]
^ru-Q0907

**ru-Q0908 · Choose the form**

Том совершает пробежку ____ раза в неделю.

Tom jogs three times a week.

Choices: три / две / много / два

[[Russian#^ru-Q0908-answer|Compare the answer]]
^ru-Q0908

**ru-Q0909 · Edit the changed sentence**

Похоже, на Татоэбе слишком 【два】 турецких троллей.

Seems like there are too many Turkish trolls on Tatoeba.

[[Russian#^ru-Q0909-answer|Compare the answer]]
^ru-Q0909

**ru-Q0910 · Build the sentence**

Arrange: Похоже, / Татоэбе / много / слишком / турецких / троллей. / на

Seems like there are too many Turkish trolls on Tatoeba.

[[Russian#^ru-Q0910-answer|Compare the answer]]
^ru-Q0910

**ru-Q0911 · Write a translation**

Write this in Russian: Which car do you like more?

[[Russian#^ru-Q0911-answer|Compare the answer]]
^ru-Q0911

**ru-Q0912 · Explain the grammar**

Какая машина тебе 【больше】 нравится?

Which car do you like more?

[[Russian#^ru-Q0912-answer|Compare the answer]]
^ru-Q0912

**ru-Q0913 · Fill the gap**

Никогда ____ не опаздывай в школу.

Never be late for school again.

[[Russian#^ru-Q0913-answer|Compare the answer]]
^ru-Q0913

**ru-Q0914 · Choose the form**

Никогда ____ не опаздывай в школу.

Never be late for school again.

Choices: больше / две / два / много

[[Russian#^ru-Q0914-answer|Compare the answer]]
^ru-Q0914

**ru-Q0915 · Edit the changed sentence**

На строительство дома им понадобилось 【две】 года.

It took them two years to build the house.

[[Russian#^ru-Q0915-answer|Compare the answer]]
^ru-Q0915

**ru-Q0916 · Build the sentence**

Arrange: года. / два / строительство / им / дома / понадобилось / На

It took them two years to build the house.

[[Russian#^ru-Q0916-answer|Compare the answer]]
^ru-Q0916

**ru-Q0917 · Write a translation**

Write this in Russian: I'm sure we have a lot in common.

[[Russian#^ru-Q0917-answer|Compare the answer]]
^ru-Q0917

**ru-Q0918 · Explain the grammar**

Уверен, что у нас 【много】 общего.

I'm sure we have a lot in common.

[[Russian#^ru-Q0918-answer|Compare the answer]]
^ru-Q0918

**ru-Q0919 · Fill the gap**

Лео начал рычать, когда ему было ____ года.

Leo started to roar when he was two years old.

[[Russian#^ru-Q0919-answer|Compare the answer]]
^ru-Q0919

**ru-Q0920 · Choose the form**

Лео начал рычать, когда ему было ____ года.

Leo started to roar when he was two years old.

Choices: много / два / больше / две

[[Russian#^ru-Q0920-answer|Compare the answer]]
^ru-Q0920

**ru-Q0921 · Edit the changed sentence**

Пожалуйста, 【два】 не плачь.

Please don't cry again.

[[Russian#^ru-Q0921-answer|Compare the answer]]
^ru-Q0921

**ru-Q0922 · Build the sentence**

Arrange: Пожалуйста, / не / больше / плачь.

Please don't cry again.

[[Russian#^ru-Q0922-answer|Compare the answer]]
^ru-Q0922

**ru-Q0923 · Write a translation**

Write this in Russian: We'll be back in three hours.

[[Russian#^ru-Q0923-answer|Compare the answer]]
^ru-Q0923

**ru-Q0924 · Explain the grammar**

Мы вернёмся через 【три】 часа.

We'll be back in three hours.

[[Russian#^ru-Q0924-answer|Compare the answer]]
^ru-Q0924

**ru-Q0925 · Fill the gap**

Я не отниму у вас ____ времени.

I won't take up much of your time.

[[Russian#^ru-Q0925-answer|Compare the answer]]
^ru-Q0925

**ru-Q0926 · Choose the form**

Я не отниму у вас ____ времени.

I won't take up much of your time.

Choices: две / больше / два / много

[[Russian#^ru-Q0926-answer|Compare the answer]]
^ru-Q0926

**ru-Q0927 · Edit the changed sentence**

Я 【два】 боюсь Тома, чем Мэри.

I'm more afraid of Tom than I am of Mary.

[[Russian#^ru-Q0927-answer|Compare the answer]]
^ru-Q0927

**ru-Q0928 · Build the sentence**

Arrange: Тома, / боюсь / Я / больше / чем / Мэри.

I'm more afraid of Tom than I am of Mary.

[[Russian#^ru-Q0928-answer|Compare the answer]]
^ru-Q0928

**ru-Q0929 · Write a translation**

Write this in Russian: I don't want to stay in bed any longer.

[[Russian#^ru-Q0929-answer|Compare the answer]]
^ru-Q0929

**ru-Q0930 · Explain the grammar**

Я не хочу 【больше】 лежать в постели.

I don't want to stay in bed any longer.

[[Russian#^ru-Q0930-answer|Compare the answer]]
^ru-Q0930

**ru-Q0931 · Fill the gap**

Люди ошибаются, думая, будто прошлое было ____, чем настоящее.

People mistakenly think that the past was better than the present.

[[Russian#^ru-Q0931-answer|Compare the answer]]
^ru-Q0931

**ru-Q0932 · Choose the form**

Люди ошибаются, думая, будто прошлое было ____, чем настоящее.

People mistakenly think that the past was better than the present.

Choices: много / две / лучше / два

[[Russian#^ru-Q0932-answer|Compare the answer]]
^ru-Q0932

**ru-Q0933 · Edit the changed sentence**

Я об этом уже 【два】 не думаю.

I never think about it anymore.

[[Russian#^ru-Q0933-answer|Compare the answer]]
^ru-Q0933

**ru-Q0934 · Build the sentence**

Arrange: уже / не / Я / думаю. / об / больше / этом

I never think about it anymore.

[[Russian#^ru-Q0934-answer|Compare the answer]]
^ru-Q0934

**ru-Q0935 · Write a translation**

Write this in Russian: Many kinds of birds live in Japan.

[[Russian#^ru-Q0935-answer|Compare the answer]]
^ru-Q0935

**ru-Q0936 · Explain the grammar**

В Японии живёт 【много】 видов птиц.

Many kinds of birds live in Japan.

[[Russian#^ru-Q0936-answer|Compare the answer]]
^ru-Q0936

**ru-Q0937 · Fill the gap**

Мы никогда его ____ не увидим.

We'll never see him again.

[[Russian#^ru-Q0937-answer|Compare the answer]]
^ru-Q0937

**ru-Q0938 · Choose the form**

Мы никогда его ____ не увидим.

We'll never see him again.

Choices: две / больше / много / два

[[Russian#^ru-Q0938-answer|Compare the answer]]
^ru-Q0938

**ru-Q0939 · Edit the changed sentence**

Тома, похоже, 【два】 ничего не волнует.

Tom doesn't seem to care about anything else.

[[Russian#^ru-Q0939-answer|Compare the answer]]
^ru-Q0939

**ru-Q0940 · Build the sentence**

Arrange: Тома, / больше / похоже, / волнует. / не / ничего

Tom doesn't seem to care about anything else.

[[Russian#^ru-Q0940-answer|Compare the answer]]
^ru-Q0940

**ru-Q0941 · Write a translation**

Write this in Russian: Tom doesn't need anything else.

[[Russian#^ru-Q0941-answer|Compare the answer]]
^ru-Q0941

**ru-Q0942 · Explain the grammar**

Тому 【больше】 ничего не нужно.

Tom doesn't need anything else.

[[Russian#^ru-Q0942-answer|Compare the answer]]
^ru-Q0942

**ru-Q0943 · Fill the gap**

У неё ____ дочери.

She has two daughters.

[[Russian#^ru-Q0943-answer|Compare the answer]]
^ru-Q0943

**ru-Q0944 · Choose the form**

У неё ____ дочери.

She has two daughters.

Choices: больше / два / много / две

[[Russian#^ru-Q0944-answer|Compare the answer]]
^ru-Q0944

**ru-Q0945 · Edit the changed sentence**

Я женился 【два】 года назад.

I got married three years ago.

[[Russian#^ru-Q0945-answer|Compare the answer]]
^ru-Q0945

**ru-Q0946 · Build the sentence**

Arrange: три / Я / года / назад. / женился

I got married three years ago.

[[Russian#^ru-Q0946-answer|Compare the answer]]
^ru-Q0946

**ru-Q0947 · Write a translation**

Write this in Russian: Mary plays her guitar about three hours a day.

[[Russian#^ru-Q0947-answer|Compare the answer]]
^ru-Q0947

**ru-Q0948 · Explain the grammar**

Мэри играет на гитаре приблизительно 【три】 часа в день.

Mary plays her guitar about three hours a day.

[[Russian#^ru-Q0948-answer|Compare the answer]]
^ru-Q0948

**ru-Q0949 · Fill the gap**

В этой коробке ____ яблока.

There are three apples in this box.

[[Russian#^ru-Q0949-answer|Compare the answer]]
^ru-Q0949

**ru-Q0950 · Choose the form**

В этой коробке ____ яблока.

There are three apples in this box.

Choices: две / два / много / три

[[Russian#^ru-Q0950-answer|Compare the answer]]
^ru-Q0950


### Professional stance and courtesy · 50 questions

**ru-Q0951 · Edit the changed sentence**

Оставь его, 【возможно】, в покое.

Leave him alone, please.

[[Russian#^ru-Q0951-answer|Compare the answer]]
^ru-Q0951

**ru-Q0952 · Build the sentence**

Arrange: Оставь / покое. / его, / пожалуйста, / в

Leave him alone, please.

[[Russian#^ru-Q0952-answer|Compare the answer]]
^ru-Q0952

**ru-Q0953 · Write a translation**

Write this in Russian: Please come again.

[[Russian#^ru-Q0953-answer|Compare the answer]]
^ru-Q0953

**ru-Q0954 · Explain the grammar**

Приходи ещё, 【пожалуйста】.

Please come again.

[[Russian#^ru-Q0954-answer|Compare the answer]]
^ru-Q0954

**ru-Q0955 · Fill the gap**

Подвинь стол влево, ____.

Please move the desk to the left.

[[Russian#^ru-Q0955-answer|Compare the answer]]
^ru-Q0955

**ru-Q0956 · Choose the form**

Подвинь стол влево, ____.

Please move the desk to the left.

Choices: пожалуйста / возможно / следует

[[Russian#^ru-Q0956-answer|Compare the answer]]
^ru-Q0956

**ru-Q0957 · Edit the changed sentence**

Не оставляйте меня одну, 【возможно】.

Please don't leave me alone.

[[Russian#^ru-Q0957-answer|Compare the answer]]
^ru-Q0957

**ru-Q0958 · Build the sentence**

Arrange: пожалуйста. / меня / Не / оставляйте / одну,

Please don't leave me alone.

[[Russian#^ru-Q0958-answer|Compare the answer]]
^ru-Q0958

**ru-Q0959 · Write a translation**

Write this in Russian: Please pass me the salt and pepper.

[[Russian#^ru-Q0959-answer|Compare the answer]]
^ru-Q0959

**ru-Q0960 · Explain the grammar**

Передайте мне соль и перец, 【пожалуйста】.

Please pass me the salt and pepper.

[[Russian#^ru-Q0960-answer|Compare the answer]]
^ru-Q0960

**ru-Q0961 · Fill the gap**

____, не тратьтесь на меня.

Please don't go to any expense on my account.

[[Russian#^ru-Q0961-answer|Compare the answer]]
^ru-Q0961

**ru-Q0962 · Choose the form**

____, не тратьтесь на меня.

Please don't go to any expense on my account.

Choices: Пожалуйста / следует / возможно

[[Russian#^ru-Q0962-answer|Compare the answer]]
^ru-Q0962

**ru-Q0963 · Edit the changed sentence**

【возможно】, не заставляй меня это делать.

Please don't force me to do this.

[[Russian#^ru-Q0963-answer|Compare the answer]]
^ru-Q0963

**ru-Q0964 · Build the sentence**

Arrange: делать. / заставляй / это / не / меня / Пожалуйста,

Please don't force me to do this.

[[Russian#^ru-Q0964-answer|Compare the answer]]
^ru-Q0964

**ru-Q0965 · Write a translation**

Write this in Russian: Tom should stop his tomfoolery.

[[Russian#^ru-Q0965-answer|Compare the answer]]
^ru-Q0965

**ru-Q0966 · Explain the grammar**

Тому 【следует】 прекратить фиглярничать.

Tom should stop his tomfoolery.

[[Russian#^ru-Q0966-answer|Compare the answer]]
^ru-Q0966

**ru-Q0967 · Fill the gap**

Откройте мне эту банку, ____.

Open this jar for me, please.

[[Russian#^ru-Q0967-answer|Compare the answer]]
^ru-Q0967

**ru-Q0968 · Choose the form**

Откройте мне эту банку, ____.

Open this jar for me, please.

Choices: пожалуйста / возможно / следует

[[Russian#^ru-Q0968-answer|Compare the answer]]
^ru-Q0968

**ru-Q0969 · Edit the changed sentence**

Скажи мне, 【возможно】, что случилось с Томом.

Please tell me what happened to Tom.

[[Russian#^ru-Q0969-answer|Compare the answer]]
^ru-Q0969

**ru-Q0970 · Build the sentence**

Arrange: что / случилось / Скажи / Томом. / с / пожалуйста, / мне,

Please tell me what happened to Tom.

[[Russian#^ru-Q0970-answer|Compare the answer]]
^ru-Q0970

**ru-Q0971 · Write a translation**

Write this in Russian: Please put it back in its place.

[[Russian#^ru-Q0971-answer|Compare the answer]]
^ru-Q0971

**ru-Q0972 · Explain the grammar**

Положи его, 【пожалуйста】, на место.

Please put it back in its place.

[[Russian#^ru-Q0972-answer|Compare the answer]]
^ru-Q0972

**ru-Q0973 · Fill the gap**

"Да, апельсиновый сок, ____", - сказал Майк.

"Yes, orange juice please," Mike said.

[[Russian#^ru-Q0973-answer|Compare the answer]]
^ru-Q0973

**ru-Q0974 · Choose the form**

"Да, апельсиновый сок, ____", - сказал Майк.

"Yes, orange juice please," Mike said.

Choices: возможно / следует / пожалуйста

[[Russian#^ru-Q0974-answer|Compare the answer]]
^ru-Q0974

**ru-Q0975 · Edit the changed sentence**

【возможно】, соедините меня с господином Брауном.

Please put me through to Mr Brown.

[[Russian#^ru-Q0975-answer|Compare the answer]]
^ru-Q0975

**ru-Q0976 · Build the sentence**

Arrange: Пожалуйста, / с / соедините / Брауном. / господином / меня

Please put me through to Mr Brown.

[[Russian#^ru-Q0976-answer|Compare the answer]]
^ru-Q0976

**ru-Q0977 · Write a translation**

Write this in Russian: Please turn the music down a bit.

[[Russian#^ru-Q0977-answer|Compare the answer]]
^ru-Q0977

**ru-Q0978 · Explain the grammar**

Сделайте, 【пожалуйста】, музыку потише.

Please turn the music down a bit.

[[Russian#^ru-Q0978-answer|Compare the answer]]
^ru-Q0978

**ru-Q0979 · Fill the gap**

____, Том может нам что-нибудь рассказать.

Maybe Tom can tell us something.

[[Russian#^ru-Q0979-answer|Compare the answer]]
^ru-Q0979

**ru-Q0980 · Choose the form**

____, Том может нам что-нибудь рассказать.

Maybe Tom can tell us something.

Choices: следует / пожалуйста / Возможно

[[Russian#^ru-Q0980-answer|Compare the answer]]
^ru-Q0980

**ru-Q0981 · Edit the changed sentence**

【возможно】, скажите нам правду.

Please tell us the truth.

[[Russian#^ru-Q0981-answer|Compare the answer]]
^ru-Q0981

**ru-Q0982 · Build the sentence**

Arrange: нам / скажите / правду. / Пожалуйста,

Please tell us the truth.

[[Russian#^ru-Q0982-answer|Compare the answer]]
^ru-Q0982

**ru-Q0983 · Write a translation**

Write this in Russian: Maybe you should tell her.

[[Russian#^ru-Q0983-answer|Compare the answer]]
^ru-Q0983

**ru-Q0984 · Explain the grammar**

【Возможно】, тебе следует ей сказать.

Maybe you should tell her.

[[Russian#^ru-Q0984-answer|Compare the answer]]
^ru-Q0984

**ru-Q0985 · Fill the gap**

"Том, ты знаешь, что это за письменность?" "____ тибетская, но я не могу прочитать и символа."

"Tom, do you know what kind of script this is?" "Probably Tibetan, but I can't read a bit of it."

[[Russian#^ru-Q0985-answer|Compare the answer]]
^ru-Q0985

**ru-Q0986 · Choose the form**

"Том, ты знаешь, что это за письменность?" "____ тибетская, но я не могу прочитать и символа."

"Tom, do you know what kind of script this is?" "Probably Tibetan, but I can't read a bit of it."

Choices: пожалуйста / Возможно / следует

[[Russian#^ru-Q0986-answer|Compare the answer]]
^ru-Q0986

**ru-Q0987 · Edit the changed sentence**

Вам 【пожалуйста】 читать книги, написанные на английском языке.

You should read books written in English.

[[Russian#^ru-Q0987-answer|Compare the answer]]
^ru-Q0987

**ru-Q0988 · Build the sentence**

Arrange: на / английском / следует / языке. / читать / написанные / Вам / книги,

You should read books written in English.

[[Russian#^ru-Q0988-answer|Compare the answer]]
^ru-Q0988

**ru-Q0989 · Write a translation**

Write this in Russian: Please tell me where you bought that.

[[Russian#^ru-Q0989-answer|Compare the answer]]
^ru-Q0989

**ru-Q0990 · Explain the grammar**

Скажи, 【пожалуйста】, где ты это купил.

Please tell me where you bought that.

[[Russian#^ru-Q0990-answer|Compare the answer]]
^ru-Q0990

**ru-Q0991 · Fill the gap**

____, не трогай цветы.

Please don't touch the flowers.

[[Russian#^ru-Q0991-answer|Compare the answer]]
^ru-Q0991

**ru-Q0992 · Choose the form**

____, не трогай цветы.

Please don't touch the flowers.

Choices: возможно / Пожалуйста / следует

[[Russian#^ru-Q0992-answer|Compare the answer]]
^ru-Q0992

**ru-Q0993 · Edit the changed sentence**

Если увидите Тома, 【возможно】, сразу скажите нам.

If you see Tom, please tell us immediately.

[[Russian#^ru-Q0993-answer|Compare the answer]]
^ru-Q0993

**ru-Q0994 · Build the sentence**

Arrange: нам. / сразу / Если / скажите / увидите / Тома, / пожалуйста,

If you see Tom, please tell us immediately.

[[Russian#^ru-Q0994-answer|Compare the answer]]
^ru-Q0994

**ru-Q0995 · Write a translation**

Write this in Russian: My husband was probably drunk when he signed this.

[[Russian#^ru-Q0995-answer|Compare the answer]]
^ru-Q0995

**ru-Q0996 · Explain the grammar**

Мой муж был, 【вероятно】, пьян, когда это подписал.

My husband was probably drunk when he signed this.

[[Russian#^ru-Q0996-answer|Compare the answer]]
^ru-Q0996

**ru-Q0997 · Fill the gap**

Передай мясо, ____.

Pass the meat please.

[[Russian#^ru-Q0997-answer|Compare the answer]]
^ru-Q0997

**ru-Q0998 · Choose the form**

Передай мясо, ____.

Pass the meat please.

Choices: пожалуйста / следует / возможно

[[Russian#^ru-Q0998-answer|Compare the answer]]
^ru-Q0998

**ru-Q0999 · Edit the changed sentence**

Убавь музыку, 【возможно】.

Please turn down the music.

[[Russian#^ru-Q0999-answer|Compare the answer]]
^ru-Q0999

**ru-Q1000 · Build the sentence**

Arrange: пожалуйста. / Убавь / музыку,

Please turn down the music.

[[Russian#^ru-Q1000-answer|Compare the answer]]
^ru-Q1000


## Answers

The full sentence is a model. For translation, judge whether meaning and grammar are preserved. Each grammar rule above explains the form.

### Answers 1–50

**ru-Q0001** — Ты должен сделать своих родителей счастливыми.

You must make your parents happy.

Expected form: **Ты**

Why: Subject pronouns. [[Russian#^ru-Q0001|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%B4%D0%BE%D0%BB%D0%B6%D0%B5%D0%BD%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C%20%D1%81%D0%B2%D0%BE%D0%B8%D1%85%20%D1%80%D0%BE%D0%B4%D0%B8%D1%82%D0%B5%D0%BB%D0%B5%D0%B9%20%D1%81%D1%87%D0%B0%D1%81%D1%82%D0%BB%D0%B8%D0%B2%D1%8B%D0%BC%D0%B8.)
^ru-Q0001-answer

**ru-Q0002** — Ты должен сделать своих родителей счастливыми.

You must make your parents happy.

Expected form: **Ты**

Why: Subject pronouns. [[Russian#^ru-Q0002|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%B4%D0%BE%D0%BB%D0%B6%D0%B5%D0%BD%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C%20%D1%81%D0%B2%D0%BE%D0%B8%D1%85%20%D1%80%D0%BE%D0%B4%D0%B8%D1%82%D0%B5%D0%BB%D0%B5%D0%B9%20%D1%81%D1%87%D0%B0%D1%81%D1%82%D0%BB%D0%B8%D0%B2%D1%8B%D0%BC%D0%B8.)
^ru-Q0002-answer

**ru-Q0003** — Вы расскажете Тому?

Will you tell Tom?

Expected form: **Вы**

Why: Subject pronouns. [[Russian#^ru-Q0003|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D1%80%D0%B0%D1%81%D1%81%D0%BA%D0%B0%D0%B6%D0%B5%D1%82%D0%B5%20%D0%A2%D0%BE%D0%BC%D1%83%3F)
^ru-Q0003-answer

**ru-Q0004** — Вы расскажете Тому?

Will you tell Tom?

Why: Subject pronouns. [[Russian#^ru-Q0004|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D1%80%D0%B0%D1%81%D1%81%D0%BA%D0%B0%D0%B6%D0%B5%D1%82%D0%B5%20%D0%A2%D0%BE%D0%BC%D1%83%3F)
^ru-Q0004-answer

**ru-Q0005** — Я хочу выполнить план любой ценой.

I want to execute the plan by all means.

Why: Subject pronouns. [[Russian#^ru-Q0005|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%85%D0%BE%D1%87%D1%83%20%D0%B2%D1%8B%D0%BF%D0%BE%D0%BB%D0%BD%D0%B8%D1%82%D1%8C%20%D0%BF%D0%BB%D0%B0%D0%BD%20%D0%BB%D1%8E%D0%B1%D0%BE%D0%B9%20%D1%86%D0%B5%D0%BD%D0%BE%D0%B9.)
^ru-Q0005-answer

**ru-Q0006** — Я хочу выполнить план любой ценой.

I want to execute the plan by all means.

Subject pronouns distinguish person and number. Вы can address one person politely or multiple people. Russian often omits the present copula in identity and classification statements.

Why: Subject pronouns. [[Russian#^ru-Q0006|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%85%D0%BE%D1%87%D1%83%20%D0%B2%D1%8B%D0%BF%D0%BE%D0%BB%D0%BD%D0%B8%D1%82%D1%8C%20%D0%BF%D0%BB%D0%B0%D0%BD%20%D0%BB%D1%8E%D0%B1%D0%BE%D0%B9%20%D1%86%D0%B5%D0%BD%D0%BE%D0%B9.)
^ru-Q0006-answer

**ru-Q0007** — Я должен приготовить ей завтрак.

I must cook breakfast for her.

Expected form: **Я**

Why: Subject pronouns. [[Russian#^ru-Q0007|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B4%D0%BE%D0%BB%D0%B6%D0%B5%D0%BD%20%D0%BF%D1%80%D0%B8%D0%B3%D0%BE%D1%82%D0%BE%D0%B2%D0%B8%D1%82%D1%8C%20%D0%B5%D0%B9%20%D0%B7%D0%B0%D0%B2%D1%82%D1%80%D0%B0%D0%BA.)
^ru-Q0007-answer

**ru-Q0008** — Я должен приготовить ей завтрак.

I must cook breakfast for her.

Expected form: **Я**

Why: Subject pronouns. [[Russian#^ru-Q0008|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B4%D0%BE%D0%BB%D0%B6%D0%B5%D0%BD%20%D0%BF%D1%80%D0%B8%D0%B3%D0%BE%D1%82%D0%BE%D0%B2%D0%B8%D1%82%D1%8C%20%D0%B5%D0%B9%20%D0%B7%D0%B0%D0%B2%D1%82%D1%80%D0%B0%D0%BA.)
^ru-Q0008-answer

**ru-Q0009** — Я бы сказал тебе, если бы мог.

I would tell you if I could.

Expected form: **Я**

Why: Subject pronouns. [[Russian#^ru-Q0009|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%8B%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%20%D1%82%D0%B5%D0%B1%D0%B5%2C%20%D0%B5%D1%81%D0%BB%D0%B8%20%D0%B1%D1%8B%20%D0%BC%D0%BE%D0%B3.)
^ru-Q0009-answer

**ru-Q0010** — Я бы сказал тебе, если бы мог.

I would tell you if I could.

Why: Subject pronouns. [[Russian#^ru-Q0010|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%8B%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%20%D1%82%D0%B5%D0%B1%D0%B5%2C%20%D0%B5%D1%81%D0%BB%D0%B8%20%D0%B1%D1%8B%20%D0%BC%D0%BE%D0%B3.)
^ru-Q0010-answer

**ru-Q0011** — Как ты собираешься это чинить?

How are you going to fix that?

Why: Subject pronouns. [[Russian#^ru-Q0011|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%B0%D0%BA%20%D1%82%D1%8B%20%D1%81%D0%BE%D0%B1%D0%B8%D1%80%D0%B0%D0%B5%D1%88%D1%8C%D1%81%D1%8F%20%D1%8D%D1%82%D0%BE%20%D1%87%D0%B8%D0%BD%D0%B8%D1%82%D1%8C%3F)
^ru-Q0011-answer

**ru-Q0012** — Как ты собираешься это чинить?

How are you going to fix that?

Subject pronouns distinguish person and number. Вы can address one person politely or multiple people. Russian often omits the present copula in identity and classification statements.

Why: Subject pronouns. [[Russian#^ru-Q0012|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%B0%D0%BA%20%D1%82%D1%8B%20%D1%81%D0%BE%D0%B1%D0%B8%D1%80%D0%B0%D0%B5%D1%88%D1%8C%D1%81%D1%8F%20%D1%8D%D1%82%D0%BE%20%D1%87%D0%B8%D0%BD%D0%B8%D1%82%D1%8C%3F)
^ru-Q0012-answer

**ru-Q0013** — Она самая высокая в классе.

She's the tallest in her class.

Expected form: **Она**

Why: Subject pronouns. [[Russian#^ru-Q0013|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D1%81%D0%B0%D0%BC%D0%B0%D1%8F%20%D0%B2%D1%8B%D1%81%D0%BE%D0%BA%D0%B0%D1%8F%20%D0%B2%20%D0%BA%D0%BB%D0%B0%D1%81%D1%81%D0%B5.)
^ru-Q0013-answer

**ru-Q0014** — Она самая высокая в классе.

She's the tallest in her class.

Expected form: **Она**

Why: Subject pronouns. [[Russian#^ru-Q0014|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D1%81%D0%B0%D0%BC%D0%B0%D1%8F%20%D0%B2%D1%8B%D1%81%D0%BE%D0%BA%D0%B0%D1%8F%20%D0%B2%20%D0%BA%D0%BB%D0%B0%D1%81%D1%81%D0%B5.)
^ru-Q0014-answer

**ru-Q0015** — Я никогда не разрешаю кому-нибудь другому кормить свою собаку.

I never let anyone else feed my dog.

Expected form: **Я**

Why: Subject pronouns. [[Russian#^ru-Q0015|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B8%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%BD%D0%B5%20%D1%80%D0%B0%D0%B7%D1%80%D0%B5%D1%88%D0%B0%D1%8E%20%D0%BA%D0%BE%D0%BC%D1%83-%D0%BD%D0%B8%D0%B1%D1%83%D0%B4%D1%8C%20%D0%B4%D1%80%D1%83%D0%B3%D0%BE%D0%BC%D1%83%20%D0%BA%D0%BE%D1%80%D0%BC%D0%B8%D1%82%D1%8C%20%D1%81%D0%B2%D0%BE%D1%8E%20%D1%81%D0%BE%D0%B1%D0%B0%D0%BA%D1%83.)
^ru-Q0015-answer

**ru-Q0016** — Я никогда не разрешаю кому-нибудь другому кормить свою собаку.

I never let anyone else feed my dog.

Why: Subject pronouns. [[Russian#^ru-Q0016|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B8%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%BD%D0%B5%20%D1%80%D0%B0%D0%B7%D1%80%D0%B5%D1%88%D0%B0%D1%8E%20%D0%BA%D0%BE%D0%BC%D1%83-%D0%BD%D0%B8%D0%B1%D1%83%D0%B4%D1%8C%20%D0%B4%D1%80%D1%83%D0%B3%D0%BE%D0%BC%D1%83%20%D0%BA%D0%BE%D1%80%D0%BC%D0%B8%D1%82%D1%8C%20%D1%81%D0%B2%D0%BE%D1%8E%20%D1%81%D0%BE%D0%B1%D0%B0%D0%BA%D1%83.)
^ru-Q0016-answer

**ru-Q0017** — Почему я должен с ней разговаривать?

Why do I have to talk to her?

Why: Subject pronouns. [[Russian#^ru-Q0017|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D1%8F%20%D0%B4%D0%BE%D0%BB%D0%B6%D0%B5%D0%BD%20%D1%81%20%D0%BD%D0%B5%D0%B9%20%D1%80%D0%B0%D0%B7%D0%B3%D0%BE%D0%B2%D0%B0%D1%80%D0%B8%D0%B2%D0%B0%D1%82%D1%8C%3F)
^ru-Q0017-answer

**ru-Q0018** — Почему я должен с ней разговаривать?

Why do I have to talk to her?

Subject pronouns distinguish person and number. Вы can address one person politely or multiple people. Russian often omits the present copula in identity and classification statements.

Why: Subject pronouns. [[Russian#^ru-Q0018|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D1%8F%20%D0%B4%D0%BE%D0%BB%D0%B6%D0%B5%D0%BD%20%D1%81%20%D0%BD%D0%B5%D0%B9%20%D1%80%D0%B0%D0%B7%D0%B3%D0%BE%D0%B2%D0%B0%D1%80%D0%B8%D0%B2%D0%B0%D1%82%D1%8C%3F)
^ru-Q0018-answer

**ru-Q0019** — Я знал, что мне не стоило этого делать.

I knew I shouldn't have done that.

Expected form: **Я**

Why: Subject pronouns. [[Russian#^ru-Q0019|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B7%D0%BD%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%BC%D0%BD%D0%B5%20%D0%BD%D0%B5%20%D1%81%D1%82%D0%BE%D0%B8%D0%BB%D0%BE%20%D1%8D%D1%82%D0%BE%D0%B3%D0%BE%20%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C.)
^ru-Q0019-answer

**ru-Q0020** — Я знал, что мне не стоило этого делать.

I knew I shouldn't have done that.

Expected form: **Я**

Why: Subject pronouns. [[Russian#^ru-Q0020|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B7%D0%BD%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%BC%D0%BD%D0%B5%20%D0%BD%D0%B5%20%D1%81%D1%82%D0%BE%D0%B8%D0%BB%D0%BE%20%D1%8D%D1%82%D0%BE%D0%B3%D0%BE%20%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C.)
^ru-Q0020-answer

**ru-Q0021** — Он учит друзей английскому.

He teaches English to his friends.

Expected form: **Он**

Why: Subject pronouns. [[Russian#^ru-Q0021|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D1%83%D1%87%D0%B8%D1%82%20%D0%B4%D1%80%D1%83%D0%B7%D0%B5%D0%B9%20%D0%B0%D0%BD%D0%B3%D0%BB%D0%B8%D0%B9%D1%81%D0%BA%D0%BE%D0%BC%D1%83.)
^ru-Q0021-answer

**ru-Q0022** — Он учит друзей английскому.

He teaches English to his friends.

Why: Subject pronouns. [[Russian#^ru-Q0022|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D1%83%D1%87%D0%B8%D1%82%20%D0%B4%D1%80%D1%83%D0%B7%D0%B5%D0%B9%20%D0%B0%D0%BD%D0%B3%D0%BB%D0%B8%D0%B9%D1%81%D0%BA%D0%BE%D0%BC%D1%83.)
^ru-Q0022-answer

**ru-Q0023** — Мы вместе работаем.

We work together.

Why: Subject pronouns. [[Russian#^ru-Q0023|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%B2%D0%BC%D0%B5%D1%81%D1%82%D0%B5%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B0%D0%B5%D0%BC.)
^ru-Q0023-answer

**ru-Q0024** — Мы вместе работаем.

We work together.

Subject pronouns distinguish person and number. Вы can address one person politely or multiple people. Russian often omits the present copula in identity and classification statements.

Why: Subject pronouns. [[Russian#^ru-Q0024|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%B2%D0%BC%D0%B5%D1%81%D1%82%D0%B5%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B0%D0%B5%D0%BC.)
^ru-Q0024-answer

**ru-Q0025** — Я ему нравлюсь.

He likes me.

Expected form: **Я**

Why: Subject pronouns. [[Russian#^ru-Q0025|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B5%D0%BC%D1%83%20%D0%BD%D1%80%D0%B0%D0%B2%D0%BB%D1%8E%D1%81%D1%8C.)
^ru-Q0025-answer

**ru-Q0026** — Я ему нравлюсь.

He likes me.

Expected form: **Я**

Why: Subject pronouns. [[Russian#^ru-Q0026|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B5%D0%BC%D1%83%20%D0%BD%D1%80%D0%B0%D0%B2%D0%BB%D1%8E%D1%81%D1%8C.)
^ru-Q0026-answer

**ru-Q0027** — Она же шутила.

She was just kidding.

Expected form: **Она**

Why: Subject pronouns. [[Russian#^ru-Q0027|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D0%B6%D0%B5%20%D1%88%D1%83%D1%82%D0%B8%D0%BB%D0%B0.)
^ru-Q0027-answer

**ru-Q0028** — Она же шутила.

She was just kidding.

Why: Subject pronouns. [[Russian#^ru-Q0028|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D0%B6%D0%B5%20%D1%88%D1%83%D1%82%D0%B8%D0%BB%D0%B0.)
^ru-Q0028-answer

**ru-Q0029** — Я был очень уставшим.

I was very tired.

Why: Subject pronouns. [[Russian#^ru-Q0029|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%8B%D0%BB%20%D0%BE%D1%87%D0%B5%D0%BD%D1%8C%20%D1%83%D1%81%D1%82%D0%B0%D0%B2%D1%88%D0%B8%D0%BC.)
^ru-Q0029-answer

**ru-Q0030** — Я был очень уставшим.

I was very tired.

Subject pronouns distinguish person and number. Вы can address one person politely or multiple people. Russian often omits the present copula in identity and classification statements.

Why: Subject pronouns. [[Russian#^ru-Q0030|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%8B%D0%BB%20%D0%BE%D1%87%D0%B5%D0%BD%D1%8C%20%D1%83%D1%81%D1%82%D0%B0%D0%B2%D1%88%D0%B8%D0%BC.)
^ru-Q0030-answer

**ru-Q0031** — Он погиб за свою страну.

He died for his country.

Expected form: **Он**

Why: Subject pronouns. [[Russian#^ru-Q0031|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D0%BF%D0%BE%D0%B3%D0%B8%D0%B1%20%D0%B7%D0%B0%20%D1%81%D0%B2%D0%BE%D1%8E%20%D1%81%D1%82%D1%80%D0%B0%D0%BD%D1%83.)
^ru-Q0031-answer

**ru-Q0032** — Он погиб за свою страну.

He died for his country.

Expected form: **Он**

Why: Subject pronouns. [[Russian#^ru-Q0032|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D0%BF%D0%BE%D0%B3%D0%B8%D0%B1%20%D0%B7%D0%B0%20%D1%81%D0%B2%D0%BE%D1%8E%20%D1%81%D1%82%D1%80%D0%B0%D0%BD%D1%83.)
^ru-Q0032-answer

**ru-Q0033** — Они были очень заняты.

They were very busy.

Expected form: **Они**

Why: Subject pronouns. [[Russian#^ru-Q0033|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B8%20%D0%B1%D1%8B%D0%BB%D0%B8%20%D0%BE%D1%87%D0%B5%D0%BD%D1%8C%20%D0%B7%D0%B0%D0%BD%D1%8F%D1%82%D1%8B.)
^ru-Q0033-answer

**ru-Q0034** — Они были очень заняты.

They were very busy.

Why: Subject pronouns. [[Russian#^ru-Q0034|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B8%20%D0%B1%D1%8B%D0%BB%D0%B8%20%D0%BE%D1%87%D0%B5%D0%BD%D1%8C%20%D0%B7%D0%B0%D0%BD%D1%8F%D1%82%D1%8B.)
^ru-Q0034-answer

**ru-Q0035** — Можно я сегодня к вам зайду?

Can I come over to your place today?

Why: Subject pronouns. [[Russian#^ru-Q0035|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D0%B6%D0%BD%D0%BE%20%D1%8F%20%D1%81%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F%20%D0%BA%20%D0%B2%D0%B0%D0%BC%20%D0%B7%D0%B0%D0%B9%D0%B4%D1%83%3F)
^ru-Q0035-answer

**ru-Q0036** — Можно я сегодня к вам зайду?

Can I come over to your place today?

Subject pronouns distinguish person and number. Вы can address one person politely or multiple people. Russian often omits the present copula in identity and classification statements.

Why: Subject pronouns. [[Russian#^ru-Q0036|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D0%B6%D0%BD%D0%BE%20%D1%8F%20%D1%81%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F%20%D0%BA%20%D0%B2%D0%B0%D0%BC%20%D0%B7%D0%B0%D0%B9%D0%B4%D1%83%3F)
^ru-Q0036-answer

**ru-Q0037** — Что я теперь скажу Тому?

What am I going to tell Tom now?

Expected form: **я**

Why: Subject pronouns. [[Russian#^ru-Q0037|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A7%D1%82%D0%BE%20%D1%8F%20%D1%82%D0%B5%D0%BF%D0%B5%D1%80%D1%8C%20%D1%81%D0%BA%D0%B0%D0%B6%D1%83%20%D0%A2%D0%BE%D0%BC%D1%83%3F)
^ru-Q0037-answer

**ru-Q0038** — Что я теперь скажу Тому?

What am I going to tell Tom now?

Expected form: **я**

Why: Subject pronouns. [[Russian#^ru-Q0038|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A7%D1%82%D0%BE%20%D1%8F%20%D1%82%D0%B5%D0%BF%D0%B5%D1%80%D1%8C%20%D1%81%D0%BA%D0%B0%D0%B6%D1%83%20%D0%A2%D0%BE%D0%BC%D1%83%3F)
^ru-Q0038-answer

**ru-Q0039** — Вы знали, что на этой горе живёт несколько лис?

Did you know that some foxes lived on this mountain?

Expected form: **Вы**

Why: Subject pronouns. [[Russian#^ru-Q0039|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D0%B7%D0%BD%D0%B0%D0%BB%D0%B8%2C%20%D1%87%D1%82%D0%BE%20%D0%BD%D0%B0%20%D1%8D%D1%82%D0%BE%D0%B9%20%D0%B3%D0%BE%D1%80%D0%B5%20%D0%B6%D0%B8%D0%B2%D1%91%D1%82%20%D0%BD%D0%B5%D1%81%D0%BA%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE%20%D0%BB%D0%B8%D1%81%3F)
^ru-Q0039-answer

**ru-Q0040** — Вы знали, что на этой горе живёт несколько лис?

Did you know that some foxes lived on this mountain?

Why: Subject pronouns. [[Russian#^ru-Q0040|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D0%B7%D0%BD%D0%B0%D0%BB%D0%B8%2C%20%D1%87%D1%82%D0%BE%20%D0%BD%D0%B0%20%D1%8D%D1%82%D0%BE%D0%B9%20%D0%B3%D0%BE%D1%80%D0%B5%20%D0%B6%D0%B8%D0%B2%D1%91%D1%82%20%D0%BD%D0%B5%D1%81%D0%BA%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE%20%D0%BB%D0%B8%D1%81%3F)
^ru-Q0040-answer

**ru-Q0041** — Архангельск дальше, чем самое дальнее место, какое вы можете себе представить.

Arkhangelsk is the farthest of the farthest places you can imagine.

Why: Subject pronouns. [[Russian#^ru-Q0041|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%90%D1%80%D1%85%D0%B0%D0%BD%D0%B3%D0%B5%D0%BB%D1%8C%D1%81%D0%BA%20%D0%B4%D0%B0%D0%BB%D1%8C%D1%88%D0%B5%2C%20%D1%87%D0%B5%D0%BC%20%D1%81%D0%B0%D0%BC%D0%BE%D0%B5%20%D0%B4%D0%B0%D0%BB%D1%8C%D0%BD%D0%B5%D0%B5%20%D0%BC%D0%B5%D1%81%D1%82%D0%BE%2C%20%D0%BA%D0%B0%D0%BA%D0%BE%D0%B5%20%D0%B2%D1%8B%20%D0%BC%D0%BE%D0%B6%D0%B5%D1%82%D0%B5%20%D1%81%D0%B5%D0%B1%D0%B5%20%D0%BF%D1%80%D0%B5%D0%B4%D1%81%D1%82%D0%B0%D0%B2%D0%B8%D1%82%D1%8C.)
^ru-Q0041-answer

**ru-Q0042** — Архангельск дальше, чем самое дальнее место, какое вы можете себе представить.

Arkhangelsk is the farthest of the farthest places you can imagine.

Subject pronouns distinguish person and number. Вы can address one person politely or multiple people. Russian often omits the present copula in identity and classification statements.

Why: Subject pronouns. [[Russian#^ru-Q0042|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%90%D1%80%D1%85%D0%B0%D0%BD%D0%B3%D0%B5%D0%BB%D1%8C%D1%81%D0%BA%20%D0%B4%D0%B0%D0%BB%D1%8C%D1%88%D0%B5%2C%20%D1%87%D0%B5%D0%BC%20%D1%81%D0%B0%D0%BC%D0%BE%D0%B5%20%D0%B4%D0%B0%D0%BB%D1%8C%D0%BD%D0%B5%D0%B5%20%D0%BC%D0%B5%D1%81%D1%82%D0%BE%2C%20%D0%BA%D0%B0%D0%BA%D0%BE%D0%B5%20%D0%B2%D1%8B%20%D0%BC%D0%BE%D0%B6%D0%B5%D1%82%D0%B5%20%D1%81%D0%B5%D0%B1%D0%B5%20%D0%BF%D1%80%D0%B5%D0%B4%D1%81%D1%82%D0%B0%D0%B2%D0%B8%D1%82%D1%8C.)
^ru-Q0042-answer

**ru-Q0043** — Мы перебрались с острова на материк на пароме.

We took a ferry from the island to the mainland.

Expected form: **Мы**

Why: Subject pronouns. [[Russian#^ru-Q0043|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%BF%D0%B5%D1%80%D0%B5%D0%B1%D1%80%D0%B0%D0%BB%D0%B8%D1%81%D1%8C%20%D1%81%20%D0%BE%D1%81%D1%82%D1%80%D0%BE%D0%B2%D0%B0%20%D0%BD%D0%B0%20%D0%BC%D0%B0%D1%82%D0%B5%D1%80%D0%B8%D0%BA%20%D0%BD%D0%B0%20%D0%BF%D0%B0%D1%80%D0%BE%D0%BC%D0%B5.)
^ru-Q0043-answer

**ru-Q0044** — Мы перебрались с острова на материк на пароме.

We took a ferry from the island to the mainland.

Expected form: **Мы**

Why: Subject pronouns. [[Russian#^ru-Q0044|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%BF%D0%B5%D1%80%D0%B5%D0%B1%D1%80%D0%B0%D0%BB%D0%B8%D1%81%D1%8C%20%D1%81%20%D0%BE%D1%81%D1%82%D1%80%D0%BE%D0%B2%D0%B0%20%D0%BD%D0%B0%20%D0%BC%D0%B0%D1%82%D0%B5%D1%80%D0%B8%D0%BA%20%D0%BD%D0%B0%20%D0%BF%D0%B0%D1%80%D0%BE%D0%BC%D0%B5.)
^ru-Q0044-answer

**ru-Q0045** — Я вчера по дороге в школу Тома встретил.

Yesterday I met Tom on the way to school.

Expected form: **Я**

Why: Subject pronouns. [[Russian#^ru-Q0045|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B2%D1%87%D0%B5%D1%80%D0%B0%20%D0%BF%D0%BE%20%D0%B4%D0%BE%D1%80%D0%BE%D0%B3%D0%B5%20%D0%B2%20%D1%88%D0%BA%D0%BE%D0%BB%D1%83%20%D0%A2%D0%BE%D0%BC%D0%B0%20%D0%B2%D1%81%D1%82%D1%80%D0%B5%D1%82%D0%B8%D0%BB.)
^ru-Q0045-answer

**ru-Q0046** — Я вчера по дороге в школу Тома встретил.

Yesterday I met Tom on the way to school.

Why: Subject pronouns. [[Russian#^ru-Q0046|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B2%D1%87%D0%B5%D1%80%D0%B0%20%D0%BF%D0%BE%20%D0%B4%D0%BE%D1%80%D0%BE%D0%B3%D0%B5%20%D0%B2%20%D1%88%D0%BA%D0%BE%D0%BB%D1%83%20%D0%A2%D0%BE%D0%BC%D0%B0%20%D0%B2%D1%81%D1%82%D1%80%D0%B5%D1%82%D0%B8%D0%BB.)
^ru-Q0046-answer

**ru-Q0047** — Я не знал, что ответить, и промолчал.

I did not know what to say and I said nothing.

Why: Subject pronouns. [[Russian#^ru-Q0047|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D0%B7%D0%BD%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%BE%D1%82%D0%B2%D0%B5%D1%82%D0%B8%D1%82%D1%8C%2C%20%D0%B8%20%D0%BF%D1%80%D0%BE%D0%BC%D0%BE%D0%BB%D1%87%D0%B0%D0%BB.)
^ru-Q0047-answer

**ru-Q0048** — Я не знал, что ответить, и промолчал.

I did not know what to say and I said nothing.

Subject pronouns distinguish person and number. Вы can address one person politely or multiple people. Russian often omits the present copula in identity and classification statements.

Why: Subject pronouns. [[Russian#^ru-Q0048|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D0%B7%D0%BD%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%BE%D1%82%D0%B2%D0%B5%D1%82%D0%B8%D1%82%D1%8C%2C%20%D0%B8%20%D0%BF%D1%80%D0%BE%D0%BC%D0%BE%D0%BB%D1%87%D0%B0%D0%BB.)
^ru-Q0048-answer

**ru-Q0049** — Я рад, что ты это спросил.

I'm glad you asked that.

Expected form: **Я**

Why: Subject pronouns. [[Russian#^ru-Q0049|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%80%D0%B0%D0%B4%2C%20%D1%87%D1%82%D0%BE%20%D1%82%D1%8B%20%D1%8D%D1%82%D0%BE%20%D1%81%D0%BF%D1%80%D0%BE%D1%81%D0%B8%D0%BB.)
^ru-Q0049-answer

**ru-Q0050** — Я рад, что ты это спросил.

I'm glad you asked that.

Expected form: **Я**

Why: Subject pronouns. [[Russian#^ru-Q0050|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%80%D0%B0%D0%B4%2C%20%D1%87%D1%82%D0%BE%20%D1%82%D1%8B%20%D1%8D%D1%82%D0%BE%20%D1%81%D0%BF%D1%80%D0%BE%D1%81%D0%B8%D0%BB.)
^ru-Q0050-answer


### Answers 51–100

**ru-Q0051** — Тебя, по идее, здесь быть не должно.

You're not supposed to be here.

Expected form: **Тебя**

Why: Object and oblique pronouns. [[Russian#^ru-Q0051|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%B5%D0%B1%D1%8F%2C%20%D0%BF%D0%BE%20%D0%B8%D0%B4%D0%B5%D0%B5%2C%20%D0%B7%D0%B4%D0%B5%D1%81%D1%8C%20%D0%B1%D1%8B%D1%82%D1%8C%20%D0%BD%D0%B5%20%D0%B4%D0%BE%D0%BB%D0%B6%D0%BD%D0%BE.)
^ru-Q0051-answer

**ru-Q0052** — Тебя, по идее, здесь быть не должно.

You're not supposed to be here.

Why: Object and oblique pronouns. [[Russian#^ru-Q0052|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%B5%D0%B1%D1%8F%2C%20%D0%BF%D0%BE%20%D0%B8%D0%B4%D0%B5%D0%B5%2C%20%D0%B7%D0%B4%D0%B5%D1%81%D1%8C%20%D0%B1%D1%8B%D1%82%D1%8C%20%D0%BD%D0%B5%20%D0%B4%D0%BE%D0%BB%D0%B6%D0%BD%D0%BE.)
^ru-Q0052-answer

**ru-Q0053** — Нам нужно её протестировать.

We need to test it.

Why: Object and oblique pronouns. [[Russian#^ru-Q0053|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%D0%BC%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D0%B5%D1%91%20%D0%BF%D1%80%D0%BE%D1%82%D0%B5%D1%81%D1%82%D0%B8%D1%80%D0%BE%D0%B2%D0%B0%D1%82%D1%8C.)
^ru-Q0053-answer

**ru-Q0054** — Нам нужно её протестировать.

We need to test it.

Pronouns have case-specific forms, and several cases share a surface form. Identify the governing verb/preposition and intended relationship rather than translating by word order alone.

Why: Object and oblique pronouns. [[Russian#^ru-Q0054|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%D0%BC%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D0%B5%D1%91%20%D0%BF%D1%80%D0%BE%D1%82%D0%B5%D1%81%D1%82%D0%B8%D1%80%D0%BE%D0%B2%D0%B0%D1%82%D1%8C.)
^ru-Q0054-answer

**ru-Q0055** — Думаю, вам следует нас подождать.

I think you should wait for us.

Expected form: **нас**

Why: Object and oblique pronouns. [[Russian#^ru-Q0055|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D1%83%D0%BC%D0%B0%D1%8E%2C%20%D0%B2%D0%B0%D0%BC%20%D1%81%D0%BB%D0%B5%D0%B4%D1%83%D0%B5%D1%82%20%D0%BD%D0%B0%D1%81%20%D0%BF%D0%BE%D0%B4%D0%BE%D0%B6%D0%B4%D0%B0%D1%82%D1%8C.)
^ru-Q0055-answer

**ru-Q0056** — Думаю, вам следует нас подождать.

I think you should wait for us.

Expected form: **нас**

Why: Object and oblique pronouns. [[Russian#^ru-Q0056|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D1%83%D0%BC%D0%B0%D1%8E%2C%20%D0%B2%D0%B0%D0%BC%20%D1%81%D0%BB%D0%B5%D0%B4%D1%83%D0%B5%D1%82%20%D0%BD%D0%B0%D1%81%20%D0%BF%D0%BE%D0%B4%D0%BE%D0%B6%D0%B4%D0%B0%D1%82%D1%8C.)
^ru-Q0056-answer

**ru-Q0057** — Один из нас врёт.

One of us is lying.

Expected form: **нас**

Why: Object and oblique pronouns. [[Russian#^ru-Q0057|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%B4%D0%B8%D0%BD%20%D0%B8%D0%B7%20%D0%BD%D0%B0%D1%81%20%D0%B2%D1%80%D1%91%D1%82.)
^ru-Q0057-answer

**ru-Q0058** — Один из нас врёт.

One of us is lying.

Why: Object and oblique pronouns. [[Russian#^ru-Q0058|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%B4%D0%B8%D0%BD%20%D0%B8%D0%B7%20%D0%BD%D0%B0%D1%81%20%D0%B2%D1%80%D1%91%D1%82.)
^ru-Q0058-answer

**ru-Q0059** — Чего вы от нас ждёте?

What do you expect from us?

Why: Object and oblique pronouns. [[Russian#^ru-Q0059|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A7%D0%B5%D0%B3%D0%BE%20%D0%B2%D1%8B%20%D0%BE%D1%82%20%D0%BD%D0%B0%D1%81%20%D0%B6%D0%B4%D1%91%D1%82%D0%B5%3F)
^ru-Q0059-answer

**ru-Q0060** — Чего вы от нас ждёте?

What do you expect from us?

Pronouns have case-specific forms, and several cases share a surface form. Identify the governing verb/preposition and intended relationship rather than translating by word order alone.

Why: Object and oblique pronouns. [[Russian#^ru-Q0060|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A7%D0%B5%D0%B3%D0%BE%20%D0%B2%D1%8B%20%D0%BE%D1%82%20%D0%BD%D0%B0%D1%81%20%D0%B6%D0%B4%D1%91%D1%82%D0%B5%3F)
^ru-Q0060-answer

**ru-Q0061** — Покупайте землю. Её сняли с производства.

Buy land. They ain't making any more of the stuff.

Expected form: **Её**

Why: Object and oblique pronouns. [[Russian#^ru-Q0061|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%BA%D1%83%D0%BF%D0%B0%D0%B9%D1%82%D0%B5%20%D0%B7%D0%B5%D0%BC%D0%BB%D1%8E.%20%D0%95%D1%91%20%D1%81%D0%BD%D1%8F%D0%BB%D0%B8%20%D1%81%20%D0%BF%D1%80%D0%BE%D0%B8%D0%B7%D0%B2%D0%BE%D0%B4%D1%81%D1%82%D0%B2%D0%B0.)
^ru-Q0061-answer

**ru-Q0062** — Покупайте землю. Её сняли с производства.

Buy land. They ain't making any more of the stuff.

Expected form: **Её**

Why: Object and oblique pronouns. [[Russian#^ru-Q0062|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%BA%D1%83%D0%BF%D0%B0%D0%B9%D1%82%D0%B5%20%D0%B7%D0%B5%D0%BC%D0%BB%D1%8E.%20%D0%95%D1%91%20%D1%81%D0%BD%D1%8F%D0%BB%D0%B8%20%D1%81%20%D0%BF%D1%80%D0%BE%D0%B8%D0%B7%D0%B2%D0%BE%D0%B4%D1%81%D1%82%D0%B2%D0%B0.)
^ru-Q0062-answer

**ru-Q0063** — Мы выбрали его мэром.

We elected him mayor.

Expected form: **его**

Why: Object and oblique pronouns. [[Russian#^ru-Q0063|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%B2%D1%8B%D0%B1%D1%80%D0%B0%D0%BB%D0%B8%20%D0%B5%D0%B3%D0%BE%20%D0%BC%D1%8D%D1%80%D0%BE%D0%BC.)
^ru-Q0063-answer

**ru-Q0064** — Мы выбрали его мэром.

We elected him mayor.

Why: Object and oblique pronouns. [[Russian#^ru-Q0064|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%B2%D1%8B%D0%B1%D1%80%D0%B0%D0%BB%D0%B8%20%D0%B5%D0%B3%D0%BE%20%D0%BC%D1%8D%D1%80%D0%BE%D0%BC.)
^ru-Q0064-answer

**ru-Q0065** — Если она тебя не любит, в чём проблема? Ты сам можешь любить себя.

If she doesn't love you, what's the problem? You can love yourself.

Why: Object and oblique pronouns. [[Russian#^ru-Q0065|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D0%BB%D0%B8%20%D0%BE%D0%BD%D0%B0%20%D1%82%D0%B5%D0%B1%D1%8F%20%D0%BD%D0%B5%20%D0%BB%D1%8E%D0%B1%D0%B8%D1%82%2C%20%D0%B2%20%D1%87%D1%91%D0%BC%20%D0%BF%D1%80%D0%BE%D0%B1%D0%BB%D0%B5%D0%BC%D0%B0%3F%20%D0%A2%D1%8B%20%D1%81%D0%B0%D0%BC%20%D0%BC%D0%BE%D0%B6%D0%B5%D1%88%D1%8C%20%D0%BB%D1%8E%D0%B1%D0%B8%D1%82%D1%8C%20%D1%81%D0%B5%D0%B1%D1%8F.)
^ru-Q0065-answer

**ru-Q0066** — Если она тебя не любит, в чём проблема? Ты сам можешь любить себя.

If she doesn't love you, what's the problem? You can love yourself.

Pronouns have case-specific forms, and several cases share a surface form. Identify the governing verb/preposition and intended relationship rather than translating by word order alone.

Why: Object and oblique pronouns. [[Russian#^ru-Q0066|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D0%BB%D0%B8%20%D0%BE%D0%BD%D0%B0%20%D1%82%D0%B5%D0%B1%D1%8F%20%D0%BD%D0%B5%20%D0%BB%D1%8E%D0%B1%D0%B8%D1%82%2C%20%D0%B2%20%D1%87%D1%91%D0%BC%20%D0%BF%D1%80%D0%BE%D0%B1%D0%BB%D0%B5%D0%BC%D0%B0%3F%20%D0%A2%D1%8B%20%D1%81%D0%B0%D0%BC%20%D0%BC%D0%BE%D0%B6%D0%B5%D1%88%D1%8C%20%D0%BB%D1%8E%D0%B1%D0%B8%D1%82%D1%8C%20%D1%81%D0%B5%D0%B1%D1%8F.)
^ru-Q0066-answer

**ru-Q0067** — Не тревожь меня.

Don't disturb me.

Expected form: **меня**

Why: Object and oblique pronouns. [[Russian#^ru-Q0067|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%20%D1%82%D1%80%D0%B5%D0%B2%D0%BE%D0%B6%D1%8C%20%D0%BC%D0%B5%D0%BD%D1%8F.)
^ru-Q0067-answer

**ru-Q0068** — Не тревожь меня.

Don't disturb me.

Expected form: **меня**

Why: Object and oblique pronouns. [[Russian#^ru-Q0068|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%20%D1%82%D1%80%D0%B5%D0%B2%D0%BE%D0%B6%D1%8C%20%D0%BC%D0%B5%D0%BD%D1%8F.)
^ru-Q0068-answer

**ru-Q0069** — Есть у тебя сдача с одного доллара?

Do you have change for a dollar?

Expected form: **тебя**

Why: Object and oblique pronouns. [[Russian#^ru-Q0069|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D1%82%D1%8C%20%D1%83%20%D1%82%D0%B5%D0%B1%D1%8F%20%D1%81%D0%B4%D0%B0%D1%87%D0%B0%20%D1%81%20%D0%BE%D0%B4%D0%BD%D0%BE%D0%B3%D0%BE%20%D0%B4%D0%BE%D0%BB%D0%BB%D0%B0%D1%80%D0%B0%3F)
^ru-Q0069-answer

**ru-Q0070** — Есть у тебя сдача с одного доллара?

Do you have change for a dollar?

Why: Object and oblique pronouns. [[Russian#^ru-Q0070|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D1%82%D1%8C%20%D1%83%20%D1%82%D0%B5%D0%B1%D1%8F%20%D1%81%D0%B4%D0%B0%D1%87%D0%B0%20%D1%81%20%D0%BE%D0%B4%D0%BD%D0%BE%D0%B3%D0%BE%20%D0%B4%D0%BE%D0%BB%D0%BB%D0%B0%D1%80%D0%B0%3F)
^ru-Q0070-answer

**ru-Q0071** — Мы все тебя ненавидели.

We all hated you.

Why: Object and oblique pronouns. [[Russian#^ru-Q0071|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%B2%D1%81%D0%B5%20%D1%82%D0%B5%D0%B1%D1%8F%20%D0%BD%D0%B5%D0%BD%D0%B0%D0%B2%D0%B8%D0%B4%D0%B5%D0%BB%D0%B8.)
^ru-Q0071-answer

**ru-Q0072** — Мы все тебя ненавидели.

We all hated you.

Pronouns have case-specific forms, and several cases share a surface form. Identify the governing verb/preposition and intended relationship rather than translating by word order alone.

Why: Object and oblique pronouns. [[Russian#^ru-Q0072|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%B2%D1%81%D0%B5%20%D1%82%D0%B5%D0%B1%D1%8F%20%D0%BD%D0%B5%D0%BD%D0%B0%D0%B2%D0%B8%D0%B4%D0%B5%D0%BB%D0%B8.)
^ru-Q0072-answer

**ru-Q0073** — Том пришёл тебя повидать.

Tom has come to see you.

Expected form: **тебя**

Why: Object and oblique pronouns. [[Russian#^ru-Q0073|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BF%D1%80%D0%B8%D1%88%D1%91%D0%BB%20%D1%82%D0%B5%D0%B1%D1%8F%20%D0%BF%D0%BE%D0%B2%D0%B8%D0%B4%D0%B0%D1%82%D1%8C.)
^ru-Q0073-answer

**ru-Q0074** — Том пришёл тебя повидать.

Tom has come to see you.

Expected form: **тебя**

Why: Object and oblique pronouns. [[Russian#^ru-Q0074|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BF%D1%80%D0%B8%D1%88%D1%91%D0%BB%20%D1%82%D0%B5%D0%B1%D1%8F%20%D0%BF%D0%BE%D0%B2%D0%B8%D0%B4%D0%B0%D1%82%D1%8C.)
^ru-Q0074-answer

**ru-Q0075** — У тебя не будет из-за этого проблем?

Won't you get in trouble for this?

Expected form: **тебя**

Why: Object and oblique pronouns. [[Russian#^ru-Q0075|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%20%D1%82%D0%B5%D0%B1%D1%8F%20%D0%BD%D0%B5%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D0%B8%D0%B7-%D0%B7%D0%B0%20%D1%8D%D1%82%D0%BE%D0%B3%D0%BE%20%D0%BF%D1%80%D0%BE%D0%B1%D0%BB%D0%B5%D0%BC%3F)
^ru-Q0075-answer

**ru-Q0076** — У тебя не будет из-за этого проблем?

Won't you get in trouble for this?

Why: Object and oblique pronouns. [[Russian#^ru-Q0076|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%20%D1%82%D0%B5%D0%B1%D1%8F%20%D0%BD%D0%B5%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D0%B8%D0%B7-%D0%B7%D0%B0%20%D1%8D%D1%82%D0%BE%D0%B3%D0%BE%20%D0%BF%D1%80%D0%BE%D0%B1%D0%BB%D0%B5%D0%BC%3F)
^ru-Q0076-answer

**ru-Q0077** — Почини его, пожалуйста.

Please fix it.

Why: Object and oblique pronouns. [[Russian#^ru-Q0077|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B8%D0%BD%D0%B8%20%D0%B5%D0%B3%D0%BE%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0.)
^ru-Q0077-answer

**ru-Q0078** — Почини его, пожалуйста.

Please fix it.

Pronouns have case-specific forms, and several cases share a surface form. Identify the governing verb/preposition and intended relationship rather than translating by word order alone.

Why: Object and oblique pronouns. [[Russian#^ru-Q0078|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B8%D0%BD%D0%B8%20%D0%B5%D0%B3%D0%BE%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0.)
^ru-Q0078-answer

**ru-Q0079** — Не могу представить и дня без тебя.

I can't imagine a day without you.

Expected form: **тебя**

Why: Object and oblique pronouns. [[Russian#^ru-Q0079|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%20%D0%BC%D0%BE%D0%B3%D1%83%20%D0%BF%D1%80%D0%B5%D0%B4%D1%81%D1%82%D0%B0%D0%B2%D0%B8%D1%82%D1%8C%20%D0%B8%20%D0%B4%D0%BD%D1%8F%20%D0%B1%D0%B5%D0%B7%20%D1%82%D0%B5%D0%B1%D1%8F.)
^ru-Q0079-answer

**ru-Q0080** — Не могу представить и дня без тебя.

I can't imagine a day without you.

Expected form: **тебя**

Why: Object and oblique pronouns. [[Russian#^ru-Q0080|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%20%D0%BC%D0%BE%D0%B3%D1%83%20%D0%BF%D1%80%D0%B5%D0%B4%D1%81%D1%82%D0%B0%D0%B2%D0%B8%D1%82%D1%8C%20%D0%B8%20%D0%B4%D0%BD%D1%8F%20%D0%B1%D0%B5%D0%B7%20%D1%82%D0%B5%D0%B1%D1%8F.)
^ru-Q0080-answer

**ru-Q0081** — Я не хотел, чтобы ты от меня уходила.

I didn't want you to leave me.

Expected form: **меня**

Why: Object and oblique pronouns. [[Russian#^ru-Q0081|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D1%82%D1%8B%20%D0%BE%D1%82%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D1%83%D1%85%D0%BE%D0%B4%D0%B8%D0%BB%D0%B0.)
^ru-Q0081-answer

**ru-Q0082** — Я не хотел, чтобы ты от меня уходила.

I didn't want you to leave me.

Why: Object and oblique pronouns. [[Russian#^ru-Q0082|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D1%82%D1%8B%20%D0%BE%D1%82%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D1%83%D1%85%D0%BE%D0%B4%D0%B8%D0%BB%D0%B0.)
^ru-Q0082-answer

**ru-Q0083** — Её молчание удивило меня.

Her silence surprised me.

Why: Object and oblique pronouns. [[Russian#^ru-Q0083|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%91%20%D0%BC%D0%BE%D0%BB%D1%87%D0%B0%D0%BD%D0%B8%D0%B5%20%D1%83%D0%B4%D0%B8%D0%B2%D0%B8%D0%BB%D0%BE%20%D0%BC%D0%B5%D0%BD%D1%8F.)
^ru-Q0083-answer

**ru-Q0084** — Её молчание удивило меня.

Her silence surprised me.

Pronouns have case-specific forms, and several cases share a surface form. Identify the governing verb/preposition and intended relationship rather than translating by word order alone.

Why: Object and oblique pronouns. [[Russian#^ru-Q0084|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%91%20%D0%BC%D0%BE%D0%BB%D1%87%D0%B0%D0%BD%D0%B8%D0%B5%20%D1%83%D0%B4%D0%B8%D0%B2%D0%B8%D0%BB%D0%BE%20%D0%BC%D0%B5%D0%BD%D1%8F.)
^ru-Q0084-answer

**ru-Q0085** — В этом году у нас был рекордный урожай.

We had a record crop this year.

Expected form: **нас**

Why: Object and oblique pronouns. [[Russian#^ru-Q0085|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%20%D1%8D%D1%82%D0%BE%D0%BC%20%D0%B3%D0%BE%D0%B4%D1%83%20%D1%83%20%D0%BD%D0%B0%D1%81%20%D0%B1%D1%8B%D0%BB%20%D1%80%D0%B5%D0%BA%D0%BE%D1%80%D0%B4%D0%BD%D1%8B%D0%B9%20%D1%83%D1%80%D0%BE%D0%B6%D0%B0%D0%B9.)
^ru-Q0085-answer

**ru-Q0086** — В этом году у нас был рекордный урожай.

We had a record crop this year.

Expected form: **нас**

Why: Object and oblique pronouns. [[Russian#^ru-Q0086|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%20%D1%8D%D1%82%D0%BE%D0%BC%20%D0%B3%D0%BE%D0%B4%D1%83%20%D1%83%20%D0%BD%D0%B0%D1%81%20%D0%B1%D1%8B%D0%BB%20%D1%80%D0%B5%D0%BA%D0%BE%D1%80%D0%B4%D0%BD%D1%8B%D0%B9%20%D1%83%D1%80%D0%BE%D0%B6%D0%B0%D0%B9.)
^ru-Q0086-answer

**ru-Q0087** — Вы никогда не будете любить меня так, как я вас.

You'll never love me as much as I love you.

Expected form: **меня**

Why: Object and oblique pronouns. [[Russian#^ru-Q0087|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D0%BD%D0%B8%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%BD%D0%B5%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%D0%B5%20%D0%BB%D1%8E%D0%B1%D0%B8%D1%82%D1%8C%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D1%82%D0%B0%D0%BA%2C%20%D0%BA%D0%B0%D0%BA%20%D1%8F%20%D0%B2%D0%B0%D1%81.)
^ru-Q0087-answer

**ru-Q0088** — Вы никогда не будете любить меня так, как я вас.

You'll never love me as much as I love you.

Why: Object and oblique pronouns. [[Russian#^ru-Q0088|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D0%BD%D0%B8%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%BD%D0%B5%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%D0%B5%20%D0%BB%D1%8E%D0%B1%D0%B8%D1%82%D1%8C%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D1%82%D0%B0%D0%BA%2C%20%D0%BA%D0%B0%D0%BA%20%D1%8F%20%D0%B2%D0%B0%D1%81.)
^ru-Q0088-answer

**ru-Q0089** — Я пытался развеселить её, но она только плакала.

I tried to cheer her up, but she did nothing but cry.

Why: Object and oblique pronouns. [[Russian#^ru-Q0089|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BF%D1%8B%D1%82%D0%B0%D0%BB%D1%81%D1%8F%20%D1%80%D0%B0%D0%B7%D0%B2%D0%B5%D1%81%D0%B5%D0%BB%D0%B8%D1%82%D1%8C%20%D0%B5%D1%91%2C%20%D0%BD%D0%BE%20%D0%BE%D0%BD%D0%B0%20%D1%82%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE%20%D0%BF%D0%BB%D0%B0%D0%BA%D0%B0%D0%BB%D0%B0.)
^ru-Q0089-answer

**ru-Q0090** — Я пытался развеселить её, но она только плакала.

I tried to cheer her up, but she did nothing but cry.

Pronouns have case-specific forms, and several cases share a surface form. Identify the governing verb/preposition and intended relationship rather than translating by word order alone.

Why: Object and oblique pronouns. [[Russian#^ru-Q0090|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BF%D1%8B%D1%82%D0%B0%D0%BB%D1%81%D1%8F%20%D1%80%D0%B0%D0%B7%D0%B2%D0%B5%D1%81%D0%B5%D0%BB%D0%B8%D1%82%D1%8C%20%D0%B5%D1%91%2C%20%D0%BD%D0%BE%20%D0%BE%D0%BD%D0%B0%20%D1%82%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE%20%D0%BF%D0%BB%D0%B0%D0%BA%D0%B0%D0%BB%D0%B0.)
^ru-Q0090-answer

**ru-Q0091** — Когда я видел его в последний раз, он был ещё ребёнком.

When I saw him last, he was still a child.

Expected form: **его**

Why: Object and oblique pronouns. [[Russian#^ru-Q0091|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%BE%D0%B3%D0%B4%D0%B0%20%D1%8F%20%D0%B2%D0%B8%D0%B4%D0%B5%D0%BB%20%D0%B5%D0%B3%D0%BE%20%D0%B2%20%D0%BF%D0%BE%D1%81%D0%BB%D0%B5%D0%B4%D0%BD%D0%B8%D0%B9%20%D1%80%D0%B0%D0%B7%2C%20%D0%BE%D0%BD%20%D0%B1%D1%8B%D0%BB%20%D0%B5%D1%89%D1%91%20%D1%80%D0%B5%D0%B1%D1%91%D0%BD%D0%BA%D0%BE%D0%BC.)
^ru-Q0091-answer

**ru-Q0092** — Когда я видел его в последний раз, он был ещё ребёнком.

When I saw him last, he was still a child.

Expected form: **его**

Why: Object and oblique pronouns. [[Russian#^ru-Q0092|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%BE%D0%B3%D0%B4%D0%B0%20%D1%8F%20%D0%B2%D0%B8%D0%B4%D0%B5%D0%BB%20%D0%B5%D0%B3%D0%BE%20%D0%B2%20%D0%BF%D0%BE%D1%81%D0%BB%D0%B5%D0%B4%D0%BD%D0%B8%D0%B9%20%D1%80%D0%B0%D0%B7%2C%20%D0%BE%D0%BD%20%D0%B1%D1%8B%D0%BB%20%D0%B5%D1%89%D1%91%20%D1%80%D0%B5%D0%B1%D1%91%D0%BD%D0%BA%D0%BE%D0%BC.)
^ru-Q0092-answer

**ru-Q0093** — У тебя богатое воображение.

You have a fertile imagination.

Expected form: **тебя**

Why: Object and oblique pronouns. [[Russian#^ru-Q0093|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%20%D1%82%D0%B5%D0%B1%D1%8F%20%D0%B1%D0%BE%D0%B3%D0%B0%D1%82%D0%BE%D0%B5%20%D0%B2%D0%BE%D0%BE%D0%B1%D1%80%D0%B0%D0%B6%D0%B5%D0%BD%D0%B8%D0%B5.)
^ru-Q0093-answer

**ru-Q0094** — У тебя богатое воображение.

You have a fertile imagination.

Why: Object and oblique pronouns. [[Russian#^ru-Q0094|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%20%D1%82%D0%B5%D0%B1%D1%8F%20%D0%B1%D0%BE%D0%B3%D0%B0%D1%82%D0%BE%D0%B5%20%D0%B2%D0%BE%D0%BE%D0%B1%D1%80%D0%B0%D0%B6%D0%B5%D0%BD%D0%B8%D0%B5.)
^ru-Q0094-answer

**ru-Q0095** — Похоже, ты не принимаешь меня всерьёз.

It seems you aren't taking me seriously.

Why: Object and oblique pronouns. [[Russian#^ru-Q0095|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%85%D0%BE%D0%B6%D0%B5%2C%20%D1%82%D1%8B%20%D0%BD%D0%B5%20%D0%BF%D1%80%D0%B8%D0%BD%D0%B8%D0%BC%D0%B0%D0%B5%D1%88%D1%8C%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D0%B2%D1%81%D0%B5%D1%80%D1%8C%D1%91%D0%B7.)
^ru-Q0095-answer

**ru-Q0096** — Похоже, ты не принимаешь меня всерьёз.

It seems you aren't taking me seriously.

Pronouns have case-specific forms, and several cases share a surface form. Identify the governing verb/preposition and intended relationship rather than translating by word order alone.

Why: Object and oblique pronouns. [[Russian#^ru-Q0096|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%85%D0%BE%D0%B6%D0%B5%2C%20%D1%82%D1%8B%20%D0%BD%D0%B5%20%D0%BF%D1%80%D0%B8%D0%BD%D0%B8%D0%BC%D0%B0%D0%B5%D1%88%D1%8C%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D0%B2%D1%81%D0%B5%D1%80%D1%8C%D1%91%D0%B7.)
^ru-Q0096-answer

**ru-Q0097** — Сегодня у меня нет домашнего задания.

I have no homework today.

Expected form: **меня**

Why: Object and oblique pronouns. [[Russian#^ru-Q0097|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F%20%D1%83%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D0%BD%D0%B5%D1%82%20%D0%B4%D0%BE%D0%BC%D0%B0%D1%88%D0%BD%D0%B5%D0%B3%D0%BE%20%D0%B7%D0%B0%D0%B4%D0%B0%D0%BD%D0%B8%D1%8F.)
^ru-Q0097-answer

**ru-Q0098** — Сегодня у меня нет домашнего задания.

I have no homework today.

Expected form: **меня**

Why: Object and oblique pronouns. [[Russian#^ru-Q0098|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F%20%D1%83%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D0%BD%D0%B5%D1%82%20%D0%B4%D0%BE%D0%BC%D0%B0%D1%88%D0%BD%D0%B5%D0%B3%D0%BE%20%D0%B7%D0%B0%D0%B4%D0%B0%D0%BD%D0%B8%D1%8F.)
^ru-Q0098-answer

**ru-Q0099** — Мне всегда хотелось тебя кое о чём спросить.

I've always wanted to ask you something.

Expected form: **тебя**

Why: Object and oblique pronouns. [[Russian#^ru-Q0099|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BD%D0%B5%20%D0%B2%D1%81%D0%B5%D0%B3%D0%B4%D0%B0%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%D0%BE%D1%81%D1%8C%20%D1%82%D0%B5%D0%B1%D1%8F%20%D0%BA%D0%BE%D0%B5%20%D0%BE%20%D1%87%D1%91%D0%BC%20%D1%81%D0%BF%D1%80%D0%BE%D1%81%D0%B8%D1%82%D1%8C.)
^ru-Q0099-answer

**ru-Q0100** — Мне всегда хотелось тебя кое о чём спросить.

I've always wanted to ask you something.

Why: Object and oblique pronouns. [[Russian#^ru-Q0100|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BD%D0%B5%20%D0%B2%D1%81%D0%B5%D0%B3%D0%B4%D0%B0%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%D0%BE%D1%81%D1%8C%20%D1%82%D0%B5%D0%B1%D1%8F%20%D0%BA%D0%BE%D0%B5%20%D0%BE%20%D1%87%D1%91%D0%BC%20%D1%81%D0%BF%D1%80%D0%BE%D1%81%D0%B8%D1%82%D1%8C.)
^ru-Q0100-answer


### Answers 101–150

**ru-Q0101** — Тебе не кажется, что это слишком далеко зашло?

Don't you think this has gone far enough?

Why: Dative pronouns. [[Russian#^ru-Q0101|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%B5%D0%B1%D0%B5%20%D0%BD%D0%B5%20%D0%BA%D0%B0%D0%B6%D0%B5%D1%82%D1%81%D1%8F%2C%20%D1%87%D1%82%D0%BE%20%D1%8D%D1%82%D0%BE%20%D1%81%D0%BB%D0%B8%D1%88%D0%BA%D0%BE%D0%BC%20%D0%B4%D0%B0%D0%BB%D0%B5%D0%BA%D0%BE%20%D0%B7%D0%B0%D1%88%D0%BB%D0%BE%3F)
^ru-Q0101-answer

**ru-Q0102** — Тебе не кажется, что это слишком далеко зашло?

Don't you think this has gone far enough?

Dative often marks a recipient or experiencer. Impersonal constructions such as Мне холодно use dative where English uses a subject plus be.

Why: Dative pronouns. [[Russian#^ru-Q0102|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%B5%D0%B1%D0%B5%20%D0%BD%D0%B5%20%D0%BA%D0%B0%D0%B6%D0%B5%D1%82%D1%81%D1%8F%2C%20%D1%87%D1%82%D0%BE%20%D1%8D%D1%82%D0%BE%20%D1%81%D0%BB%D0%B8%D1%88%D0%BA%D0%BE%D0%BC%20%D0%B4%D0%B0%D0%BB%D0%B5%D0%BA%D0%BE%20%D0%B7%D0%B0%D1%88%D0%BB%D0%BE%3F)
^ru-Q0102-answer

**ru-Q0103** — Мне в целом нравится китайская еда.

I like Chinese food in general.

Expected form: **Мне**

Why: Dative pronouns. [[Russian#^ru-Q0103|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BD%D0%B5%20%D0%B2%20%D1%86%D0%B5%D0%BB%D0%BE%D0%BC%20%D0%BD%D1%80%D0%B0%D0%B2%D0%B8%D1%82%D1%81%D1%8F%20%D0%BA%D0%B8%D1%82%D0%B0%D0%B9%D1%81%D0%BA%D0%B0%D1%8F%20%D0%B5%D0%B4%D0%B0.)
^ru-Q0103-answer

**ru-Q0104** — Мне в целом нравится китайская еда.

I like Chinese food in general.

Expected form: **Мне**

Why: Dative pronouns. [[Russian#^ru-Q0104|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BD%D0%B5%20%D0%B2%20%D1%86%D0%B5%D0%BB%D0%BE%D0%BC%20%D0%BD%D1%80%D0%B0%D0%B2%D0%B8%D1%82%D1%81%D1%8F%20%D0%BA%D0%B8%D1%82%D0%B0%D0%B9%D1%81%D0%BA%D0%B0%D1%8F%20%D0%B5%D0%B4%D0%B0.)
^ru-Q0104-answer

**ru-Q0105** — Почисть мне, пожалуйста, этот апельсин.

Please peel this orange for me.

Expected form: **мне**

Why: Dative pronouns. [[Russian#^ru-Q0105|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B8%D1%81%D1%82%D1%8C%20%D0%BC%D0%BD%D0%B5%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D1%8D%D1%82%D0%BE%D1%82%20%D0%B0%D0%BF%D0%B5%D0%BB%D1%8C%D1%81%D0%B8%D0%BD.)
^ru-Q0105-answer

**ru-Q0106** — Почисть мне, пожалуйста, этот апельсин.

Please peel this orange for me.

Why: Dative pronouns. [[Russian#^ru-Q0106|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B8%D1%81%D1%82%D1%8C%20%D0%BC%D0%BD%D0%B5%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D1%8D%D1%82%D0%BE%D1%82%20%D0%B0%D0%BF%D0%B5%D0%BB%D1%8C%D1%81%D0%B8%D0%BD.)
^ru-Q0106-answer

**ru-Q0107** — Мне нужно будет подумать над этим.

I'll need to think about it.

Why: Dative pronouns. [[Russian#^ru-Q0107|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BD%D0%B5%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D0%BF%D0%BE%D0%B4%D1%83%D0%BC%D0%B0%D1%82%D1%8C%20%D0%BD%D0%B0%D0%B4%20%D1%8D%D1%82%D0%B8%D0%BC.)
^ru-Q0107-answer

**ru-Q0108** — Мне нужно будет подумать над этим.

I'll need to think about it.

Dative often marks a recipient or experiencer. Impersonal constructions such as Мне холодно use dative where English uses a subject plus be.

Why: Dative pronouns. [[Russian#^ru-Q0108|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BD%D0%B5%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D0%BF%D0%BE%D0%B4%D1%83%D0%BC%D0%B0%D1%82%D1%8C%20%D0%BD%D0%B0%D0%B4%20%D1%8D%D1%82%D0%B8%D0%BC.)
^ru-Q0108-answer

**ru-Q0109** — Можешь мне не верить.

You don't have to believe me.

Expected form: **мне**

Why: Dative pronouns. [[Russian#^ru-Q0109|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D0%B6%D0%B5%D1%88%D1%8C%20%D0%BC%D0%BD%D0%B5%20%D0%BD%D0%B5%20%D0%B2%D0%B5%D1%80%D0%B8%D1%82%D1%8C.)
^ru-Q0109-answer

**ru-Q0110** — Можешь мне не верить.

You don't have to believe me.

Expected form: **мне**

Why: Dative pronouns. [[Russian#^ru-Q0110|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D0%B6%D0%B5%D1%88%D1%8C%20%D0%BC%D0%BD%D0%B5%20%D0%BD%D0%B5%20%D0%B2%D0%B5%D1%80%D0%B8%D1%82%D1%8C.)
^ru-Q0110-answer

**ru-Q0111** — GPS позволяет вам определить своё местоположение с помощью спутников.

GPS allows you to determine your location using satellites.

Expected form: **вам**

Why: Dative pronouns. [[Russian#^ru-Q0111|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=GPS%20%D0%BF%D0%BE%D0%B7%D0%B2%D0%BE%D0%BB%D1%8F%D0%B5%D1%82%20%D0%B2%D0%B0%D0%BC%20%D0%BE%D0%BF%D1%80%D0%B5%D0%B4%D0%B5%D0%BB%D0%B8%D1%82%D1%8C%20%D1%81%D0%B2%D0%BE%D1%91%20%D0%BC%D0%B5%D1%81%D1%82%D0%BE%D0%BF%D0%BE%D0%BB%D0%BE%D0%B6%D0%B5%D0%BD%D0%B8%D0%B5%20%D1%81%20%D0%BF%D0%BE%D0%BC%D0%BE%D1%89%D1%8C%D1%8E%20%D1%81%D0%BF%D1%83%D1%82%D0%BD%D0%B8%D0%BA%D0%BE%D0%B2.)
^ru-Q0111-answer

**ru-Q0112** — GPS позволяет вам определить своё местоположение с помощью спутников.

GPS allows you to determine your location using satellites.

Why: Dative pronouns. [[Russian#^ru-Q0112|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=GPS%20%D0%BF%D0%BE%D0%B7%D0%B2%D0%BE%D0%BB%D1%8F%D0%B5%D1%82%20%D0%B2%D0%B0%D0%BC%20%D0%BE%D0%BF%D1%80%D0%B5%D0%B4%D0%B5%D0%BB%D0%B8%D1%82%D1%8C%20%D1%81%D0%B2%D0%BE%D1%91%20%D0%BC%D0%B5%D1%81%D1%82%D0%BE%D0%BF%D0%BE%D0%BB%D0%BE%D0%B6%D0%B5%D0%BD%D0%B8%D0%B5%20%D1%81%20%D0%BF%D0%BE%D0%BC%D0%BE%D1%89%D1%8C%D1%8E%20%D1%81%D0%BF%D1%83%D1%82%D0%BD%D0%B8%D0%BA%D0%BE%D0%B2.)
^ru-Q0112-answer

**ru-Q0113** — Том не смог найти то, что ему было нужно.

Tom wasn't able to find what he needed.

Why: Dative pronouns. [[Russian#^ru-Q0113|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D1%81%D0%BC%D0%BE%D0%B3%20%D0%BD%D0%B0%D0%B9%D1%82%D0%B8%20%D1%82%D0%BE%2C%20%D1%87%D1%82%D0%BE%20%D0%B5%D0%BC%D1%83%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE.)
^ru-Q0113-answer

**ru-Q0114** — Том не смог найти то, что ему было нужно.

Tom wasn't able to find what he needed.

Dative often marks a recipient or experiencer. Impersonal constructions such as Мне холодно use dative where English uses a subject plus be.

Why: Dative pronouns. [[Russian#^ru-Q0114|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D1%81%D0%BC%D0%BE%D0%B3%20%D0%BD%D0%B0%D0%B9%D1%82%D0%B8%20%D1%82%D0%BE%2C%20%D1%87%D1%82%D0%BE%20%D0%B5%D0%BC%D1%83%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE.)
^ru-Q0114-answer

**ru-Q0115** — Том говорил тебе, на ком он женат?

Has Tom told you who he's married to?

Expected form: **тебе**

Why: Dative pronouns. [[Russian#^ru-Q0115|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D0%BB%20%D1%82%D0%B5%D0%B1%D0%B5%2C%20%D0%BD%D0%B0%20%D0%BA%D0%BE%D0%BC%20%D0%BE%D0%BD%20%D0%B6%D0%B5%D0%BD%D0%B0%D1%82%3F)
^ru-Q0115-answer

**ru-Q0116** — Том говорил тебе, на ком он женат?

Has Tom told you who he's married to?

Expected form: **тебе**

Why: Dative pronouns. [[Russian#^ru-Q0116|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D0%BB%20%D1%82%D0%B5%D0%B1%D0%B5%2C%20%D0%BD%D0%B0%20%D0%BA%D0%BE%D0%BC%20%D0%BE%D0%BD%20%D0%B6%D0%B5%D0%BD%D0%B0%D1%82%3F)
^ru-Q0116-answer

**ru-Q0117** — Скажите ему, что мы заняты.

Tell him we're busy.

Expected form: **ему**

Why: Dative pronouns. [[Russian#^ru-Q0117|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BA%D0%B0%D0%B6%D0%B8%D1%82%D0%B5%20%D0%B5%D0%BC%D1%83%2C%20%D1%87%D1%82%D0%BE%20%D0%BC%D1%8B%20%D0%B7%D0%B0%D0%BD%D1%8F%D1%82%D1%8B.)
^ru-Q0117-answer

**ru-Q0118** — Скажите ему, что мы заняты.

Tell him we're busy.

Why: Dative pronouns. [[Russian#^ru-Q0118|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BA%D0%B0%D0%B6%D0%B8%D1%82%D0%B5%20%D0%B5%D0%BC%D1%83%2C%20%D1%87%D1%82%D0%BE%20%D0%BC%D1%8B%20%D0%B7%D0%B0%D0%BD%D1%8F%D1%82%D1%8B.)
^ru-Q0118-answer

**ru-Q0119** — Том рассказывал тебе, где они с Мэри познакомились?

Did Tom tell you where he and Mary met?

Why: Dative pronouns. [[Russian#^ru-Q0119|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%80%D0%B0%D1%81%D1%81%D0%BA%D0%B0%D0%B7%D1%8B%D0%B2%D0%B0%D0%BB%20%D1%82%D0%B5%D0%B1%D0%B5%2C%20%D0%B3%D0%B4%D0%B5%20%D0%BE%D0%BD%D0%B8%20%D1%81%20%D0%9C%D1%8D%D1%80%D0%B8%20%D0%BF%D0%BE%D0%B7%D0%BD%D0%B0%D0%BA%D0%BE%D0%BC%D0%B8%D0%BB%D0%B8%D1%81%D1%8C%3F)
^ru-Q0119-answer

**ru-Q0120** — Том рассказывал тебе, где они с Мэри познакомились?

Did Tom tell you where he and Mary met?

Dative often marks a recipient or experiencer. Impersonal constructions such as Мне холодно use dative where English uses a subject plus be.

Why: Dative pronouns. [[Russian#^ru-Q0120|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%80%D0%B0%D1%81%D1%81%D0%BA%D0%B0%D0%B7%D1%8B%D0%B2%D0%B0%D0%BB%20%D1%82%D0%B5%D0%B1%D0%B5%2C%20%D0%B3%D0%B4%D0%B5%20%D0%BE%D0%BD%D0%B8%20%D1%81%20%D0%9C%D1%8D%D1%80%D0%B8%20%D0%BF%D0%BE%D0%B7%D0%BD%D0%B0%D0%BA%D0%BE%D0%BC%D0%B8%D0%BB%D0%B8%D1%81%D1%8C%3F)
^ru-Q0120-answer

**ru-Q0121** — Нам надо сделать это сегодня.

We have to do that today.

Expected form: **Нам**

Why: Dative pronouns. [[Russian#^ru-Q0121|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%D0%BC%20%D0%BD%D0%B0%D0%B4%D0%BE%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C%20%D1%8D%D1%82%D0%BE%20%D1%81%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F.)
^ru-Q0121-answer

**ru-Q0122** — Нам надо сделать это сегодня.

We have to do that today.

Expected form: **Нам**

Why: Dative pronouns. [[Russian#^ru-Q0122|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%D0%BC%20%D0%BD%D0%B0%D0%B4%D0%BE%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C%20%D1%8D%D1%82%D0%BE%20%D1%81%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F.)
^ru-Q0122-answer

**ru-Q0123** — Скажи Мэри, что ей нужно извиниться перед Томом.

Tell Mary that she needs to apologize to Tom.

Expected form: **ей**

Why: Dative pronouns. [[Russian#^ru-Q0123|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BA%D0%B0%D0%B6%D0%B8%20%D0%9C%D1%8D%D1%80%D0%B8%2C%20%D1%87%D1%82%D0%BE%20%D0%B5%D0%B9%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D0%B8%D0%B7%D0%B2%D0%B8%D0%BD%D0%B8%D1%82%D1%8C%D1%81%D1%8F%20%D0%BF%D0%B5%D1%80%D0%B5%D0%B4%20%D0%A2%D0%BE%D0%BC%D0%BE%D0%BC.)
^ru-Q0123-answer

**ru-Q0124** — Скажи Мэри, что ей нужно извиниться перед Томом.

Tell Mary that she needs to apologize to Tom.

Why: Dative pronouns. [[Russian#^ru-Q0124|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BA%D0%B0%D0%B6%D0%B8%20%D0%9C%D1%8D%D1%80%D0%B8%2C%20%D1%87%D1%82%D0%BE%20%D0%B5%D0%B9%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D0%B8%D0%B7%D0%B2%D0%B8%D0%BD%D0%B8%D1%82%D1%8C%D1%81%D1%8F%20%D0%BF%D0%B5%D1%80%D0%B5%D0%B4%20%D0%A2%D0%BE%D0%BC%D0%BE%D0%BC.)
^ru-Q0124-answer

**ru-Q0125** — Я должен вам тысячу долларов.

I owe you $1,000.

Why: Dative pronouns. [[Russian#^ru-Q0125|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B4%D0%BE%D0%BB%D0%B6%D0%B5%D0%BD%20%D0%B2%D0%B0%D0%BC%20%D1%82%D1%8B%D1%81%D1%8F%D1%87%D1%83%20%D0%B4%D0%BE%D0%BB%D0%BB%D0%B0%D1%80%D0%BE%D0%B2.)
^ru-Q0125-answer

**ru-Q0126** — Я должен вам тысячу долларов.

I owe you $1,000.

Dative often marks a recipient or experiencer. Impersonal constructions such as Мне холодно use dative where English uses a subject plus be.

Why: Dative pronouns. [[Russian#^ru-Q0126|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B4%D0%BE%D0%BB%D0%B6%D0%B5%D0%BD%20%D0%B2%D0%B0%D0%BC%20%D1%82%D1%8B%D1%81%D1%8F%D1%87%D1%83%20%D0%B4%D0%BE%D0%BB%D0%BB%D0%B0%D1%80%D0%BE%D0%B2.)
^ru-Q0126-answer

**ru-Q0127** — Нам надо сказать Тому.

We have to tell Tom.

Expected form: **Нам**

Why: Dative pronouns. [[Russian#^ru-Q0127|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%D0%BC%20%D0%BD%D0%B0%D0%B4%D0%BE%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C%20%D0%A2%D0%BE%D0%BC%D1%83.)
^ru-Q0127-answer

**ru-Q0128** — Нам надо сказать Тому.

We have to tell Tom.

Expected form: **Нам**

Why: Dative pronouns. [[Russian#^ru-Q0128|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%D0%BC%20%D0%BD%D0%B0%D0%B4%D0%BE%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C%20%D0%A2%D0%BE%D0%BC%D1%83.)
^ru-Q0128-answer

**ru-Q0129** — Мне больше не нужна твоя помощь.

I don't need your help anymore.

Expected form: **Мне**

Why: Dative pronouns. [[Russian#^ru-Q0129|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BD%D0%B5%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BD%D0%B5%20%D0%BD%D1%83%D0%B6%D0%BD%D0%B0%20%D1%82%D0%B2%D0%BE%D1%8F%20%D0%BF%D0%BE%D0%BC%D0%BE%D1%89%D1%8C.)
^ru-Q0129-answer

**ru-Q0130** — Мне больше не нужна твоя помощь.

I don't need your help anymore.

Why: Dative pronouns. [[Russian#^ru-Q0130|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BD%D0%B5%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BD%D0%B5%20%D0%BD%D1%83%D0%B6%D0%BD%D0%B0%20%D1%82%D0%B2%D0%BE%D1%8F%20%D0%BF%D0%BE%D0%BC%D0%BE%D1%89%D1%8C.)
^ru-Q0130-answer

**ru-Q0131** — Дурак, мне пришлось это сделать!

You fool, I had to do it!

Why: Dative pronouns. [[Russian#^ru-Q0131|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D1%83%D1%80%D0%B0%D0%BA%2C%20%D0%BC%D0%BD%D0%B5%20%D0%BF%D1%80%D0%B8%D1%88%D0%BB%D0%BE%D1%81%D1%8C%20%D1%8D%D1%82%D0%BE%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C%21)
^ru-Q0131-answer

**ru-Q0132** — Дурак, мне пришлось это сделать!

You fool, I had to do it!

Dative often marks a recipient or experiencer. Impersonal constructions such as Мне холодно use dative where English uses a subject plus be.

Why: Dative pronouns. [[Russian#^ru-Q0132|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D1%83%D1%80%D0%B0%D0%BA%2C%20%D0%BC%D0%BD%D0%B5%20%D0%BF%D1%80%D0%B8%D1%88%D0%BB%D0%BE%D1%81%D1%8C%20%D1%8D%D1%82%D0%BE%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C%21)
^ru-Q0132-answer

**ru-Q0133** — Я сказал тебе, чтобы ты оставил Тома в покое.

I told you to leave Tom alone.

Expected form: **тебе**

Why: Dative pronouns. [[Russian#^ru-Q0133|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%20%D1%82%D0%B5%D0%B1%D0%B5%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D1%82%D1%8B%20%D0%BE%D1%81%D1%82%D0%B0%D0%B2%D0%B8%D0%BB%20%D0%A2%D0%BE%D0%BC%D0%B0%20%D0%B2%20%D0%BF%D0%BE%D0%BA%D0%BE%D0%B5.)
^ru-Q0133-answer

**ru-Q0134** — Я сказал тебе, чтобы ты оставил Тома в покое.

I told you to leave Tom alone.

Expected form: **тебе**

Why: Dative pronouns. [[Russian#^ru-Q0134|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%20%D1%82%D0%B5%D0%B1%D0%B5%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D1%82%D1%8B%20%D0%BE%D1%81%D1%82%D0%B0%D0%B2%D0%B8%D0%BB%20%D0%A2%D0%BE%D0%BC%D0%B0%20%D0%B2%20%D0%BF%D0%BE%D0%BA%D0%BE%D0%B5.)
^ru-Q0134-answer

**ru-Q0135** — Дадим ей минуту.

Let's give her a minute.

Expected form: **ей**

Why: Dative pronouns. [[Russian#^ru-Q0135|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D0%B0%D0%B4%D0%B8%D0%BC%20%D0%B5%D0%B9%20%D0%BC%D0%B8%D0%BD%D1%83%D1%82%D1%83.)
^ru-Q0135-answer

**ru-Q0136** — Дадим ей минуту.

Let's give her a minute.

Why: Dative pronouns. [[Russian#^ru-Q0136|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D0%B0%D0%B4%D0%B8%D0%BC%20%D0%B5%D0%B9%20%D0%BC%D0%B8%D0%BD%D1%83%D1%82%D1%83.)
^ru-Q0136-answer

**ru-Q0137** — Скажи мне, пожалуйста, где Том.

Please tell me where Tom is.

Why: Dative pronouns. [[Russian#^ru-Q0137|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BA%D0%B0%D0%B6%D0%B8%20%D0%BC%D0%BD%D0%B5%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%B3%D0%B4%D0%B5%20%D0%A2%D0%BE%D0%BC.)
^ru-Q0137-answer

**ru-Q0138** — Скажи мне, пожалуйста, где Том.

Please tell me where Tom is.

Dative often marks a recipient or experiencer. Impersonal constructions such as Мне холодно use dative where English uses a subject plus be.

Why: Dative pronouns. [[Russian#^ru-Q0138|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BA%D0%B0%D0%B6%D0%B8%20%D0%BC%D0%BD%D0%B5%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%B3%D0%B4%D0%B5%20%D0%A2%D0%BE%D0%BC.)
^ru-Q0138-answer

**ru-Q0139** — Одна вам, одна мне.

There's one for you and one for me.

Expected form: **вам**

Why: Dative pronouns. [[Russian#^ru-Q0139|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%B4%D0%BD%D0%B0%20%D0%B2%D0%B0%D0%BC%2C%20%D0%BE%D0%B4%D0%BD%D0%B0%20%D0%BC%D0%BD%D0%B5.)
^ru-Q0139-answer

**ru-Q0140** — Одна вам, одна мне.

There's one for you and one for me.

Expected form: **вам**

Why: Dative pronouns. [[Russian#^ru-Q0140|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%B4%D0%BD%D0%B0%20%D0%B2%D0%B0%D0%BC%2C%20%D0%BE%D0%B4%D0%BD%D0%B0%20%D0%BC%D0%BD%D0%B5.)
^ru-Q0140-answer

**ru-Q0141** — Вы вроде говорили мне, что умеете это делать.

I thought you told me you could do that.

Expected form: **мне**

Why: Dative pronouns. [[Russian#^ru-Q0141|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D0%B2%D1%80%D0%BE%D0%B4%D0%B5%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D0%BB%D0%B8%20%D0%BC%D0%BD%D0%B5%2C%20%D1%87%D1%82%D0%BE%20%D1%83%D0%BC%D0%B5%D0%B5%D1%82%D0%B5%20%D1%8D%D1%82%D0%BE%20%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C.)
^ru-Q0141-answer

**ru-Q0142** — Вы вроде говорили мне, что умеете это делать.

I thought you told me you could do that.

Why: Dative pronouns. [[Russian#^ru-Q0142|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D0%B2%D1%80%D0%BE%D0%B4%D0%B5%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D0%BB%D0%B8%20%D0%BC%D0%BD%D0%B5%2C%20%D1%87%D1%82%D0%BE%20%D1%83%D0%BC%D0%B5%D0%B5%D1%82%D0%B5%20%D1%8D%D1%82%D0%BE%20%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C.)
^ru-Q0142-answer

**ru-Q0143** — Нам только нужно ещё несколько минут.

We only need a few more minutes.

Why: Dative pronouns. [[Russian#^ru-Q0143|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%D0%BC%20%D1%82%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D0%B5%D1%89%D1%91%20%D0%BD%D0%B5%D1%81%D0%BA%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE%20%D0%BC%D0%B8%D0%BD%D1%83%D1%82.)
^ru-Q0143-answer

**ru-Q0144** — Нам только нужно ещё несколько минут.

We only need a few more minutes.

Dative often marks a recipient or experiencer. Impersonal constructions such as Мне холодно use dative where English uses a subject plus be.

Why: Dative pronouns. [[Russian#^ru-Q0144|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%D0%BC%20%D1%82%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D0%B5%D1%89%D1%91%20%D0%BD%D0%B5%D1%81%D0%BA%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE%20%D0%BC%D0%B8%D0%BD%D1%83%D1%82.)
^ru-Q0144-answer

**ru-Q0145** — Мне нравятся любовные истории.

I like love stories.

Expected form: **Мне**

Why: Dative pronouns. [[Russian#^ru-Q0145|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BD%D0%B5%20%D0%BD%D1%80%D0%B0%D0%B2%D1%8F%D1%82%D1%81%D1%8F%20%D0%BB%D1%8E%D0%B1%D0%BE%D0%B2%D0%BD%D1%8B%D0%B5%20%D0%B8%D1%81%D1%82%D0%BE%D1%80%D0%B8%D0%B8.)
^ru-Q0145-answer

**ru-Q0146** — Мне нравятся любовные истории.

I like love stories.

Expected form: **Мне**

Why: Dative pronouns. [[Russian#^ru-Q0146|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BD%D0%B5%20%D0%BD%D1%80%D0%B0%D0%B2%D1%8F%D1%82%D1%81%D1%8F%20%D0%BB%D1%8E%D0%B1%D0%BE%D0%B2%D0%BD%D1%8B%D0%B5%20%D0%B8%D1%81%D1%82%D0%BE%D1%80%D0%B8%D0%B8.)
^ru-Q0146-answer

**ru-Q0147** — Она преподнесла ему чудесный подарок.

She gave him a nice present.

Expected form: **ему**

Why: Dative pronouns. [[Russian#^ru-Q0147|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D0%BF%D1%80%D0%B5%D0%BF%D0%BE%D0%B4%D0%BD%D0%B5%D1%81%D0%BB%D0%B0%20%D0%B5%D0%BC%D1%83%20%D1%87%D1%83%D0%B4%D0%B5%D1%81%D0%BD%D1%8B%D0%B9%20%D0%BF%D0%BE%D0%B4%D0%B0%D1%80%D0%BE%D0%BA.)
^ru-Q0147-answer

**ru-Q0148** — Она преподнесла ему чудесный подарок.

She gave him a nice present.

Why: Dative pronouns. [[Russian#^ru-Q0148|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D0%BF%D1%80%D0%B5%D0%BF%D0%BE%D0%B4%D0%BD%D0%B5%D1%81%D0%BB%D0%B0%20%D0%B5%D0%BC%D1%83%20%D1%87%D1%83%D0%B4%D0%B5%D1%81%D0%BD%D1%8B%D0%B9%20%D0%BF%D0%BE%D0%B4%D0%B0%D1%80%D0%BE%D0%BA.)
^ru-Q0148-answer

**ru-Q0149** — Мне нужно кое о чём с тобой поговорить.

I have something I need to talk to you about.

Why: Dative pronouns. [[Russian#^ru-Q0149|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BD%D0%B5%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D0%BA%D0%BE%D0%B5%20%D0%BE%20%D1%87%D1%91%D0%BC%20%D1%81%20%D1%82%D0%BE%D0%B1%D0%BE%D0%B9%20%D0%BF%D0%BE%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D1%8C.)
^ru-Q0149-answer

**ru-Q0150** — Мне нужно кое о чём с тобой поговорить.

I have something I need to talk to you about.

Dative often marks a recipient or experiencer. Impersonal constructions such as Мне холодно use dative where English uses a subject plus be.

Why: Dative pronouns. [[Russian#^ru-Q0150|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BD%D0%B5%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D0%BA%D0%BE%D0%B5%20%D0%BE%20%D1%87%D1%91%D0%BC%20%D1%81%20%D1%82%D0%BE%D0%B1%D0%BE%D0%B9%20%D0%BF%D0%BE%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D1%8C.)
^ru-Q0150-answer


### Answers 151–200

**ru-Q0151** — Моя мама красивая.

My mother is beautiful.

Expected form: **Моя**

Why: Possessive forms. [[Russian#^ru-Q0151|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D1%8F%20%D0%BC%D0%B0%D0%BC%D0%B0%20%D0%BA%D1%80%D0%B0%D1%81%D0%B8%D0%B2%D0%B0%D1%8F.)
^ru-Q0151-answer

**ru-Q0152** — Моя мама красивая.

My mother is beautiful.

Expected form: **Моя**

Why: Possessive forms. [[Russian#^ru-Q0152|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D1%8F%20%D0%BC%D0%B0%D0%BC%D0%B0%20%D0%BA%D1%80%D0%B0%D1%81%D0%B8%D0%B2%D0%B0%D1%8F.)
^ru-Q0152-answer

**ru-Q0153** — Ваша жена ещё в Америке?

Is your wife still in America?

Expected form: **Ваша**

Why: Possessive forms. [[Russian#^ru-Q0153|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D0%B0%D1%88%D0%B0%20%D0%B6%D0%B5%D0%BD%D0%B0%20%D0%B5%D1%89%D1%91%20%D0%B2%20%D0%90%D0%BC%D0%B5%D1%80%D0%B8%D0%BA%D0%B5%3F)
^ru-Q0153-answer

**ru-Q0154** — Ваша жена ещё в Америке?

Is your wife still in America?

Why: Possessive forms. [[Russian#^ru-Q0154|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D0%B0%D1%88%D0%B0%20%D0%B6%D0%B5%D0%BD%D0%B0%20%D0%B5%D1%89%D1%91%20%D0%B2%20%D0%90%D0%BC%D0%B5%D1%80%D0%B8%D0%BA%D0%B5%3F)
^ru-Q0154-answer

**ru-Q0155** — Мне только что звонила ваша учительница.

I just got a call from your teacher.

Why: Possessive forms. [[Russian#^ru-Q0155|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BD%D0%B5%20%D1%82%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE%20%D1%87%D1%82%D0%BE%20%D0%B7%D0%B2%D0%BE%D0%BD%D0%B8%D0%BB%D0%B0%20%D0%B2%D0%B0%D1%88%D0%B0%20%D1%83%D1%87%D0%B8%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D0%B8%D1%86%D0%B0.)
^ru-Q0155-answer

**ru-Q0156** — Мне только что звонила ваша учительница.

I just got a call from your teacher.

Possessive adjectives agree with the possessed noun in case, gender and number. The possessor’s sex does not choose мой versus моя.

Why: Possessive forms. [[Russian#^ru-Q0156|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BD%D0%B5%20%D1%82%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE%20%D1%87%D1%82%D0%BE%20%D0%B7%D0%B2%D0%BE%D0%BD%D0%B8%D0%BB%D0%B0%20%D0%B2%D0%B0%D1%88%D0%B0%20%D1%83%D1%87%D0%B8%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D0%B8%D1%86%D0%B0.)
^ru-Q0156-answer

**ru-Q0157** — Это моя младшая сестра.

This is my younger sister.

Expected form: **моя**

Why: Possessive forms. [[Russian#^ru-Q0157|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D1%82%D0%BE%20%D0%BC%D0%BE%D1%8F%20%D0%BC%D0%BB%D0%B0%D0%B4%D1%88%D0%B0%D1%8F%20%D1%81%D0%B5%D1%81%D1%82%D1%80%D0%B0.)
^ru-Q0157-answer

**ru-Q0158** — Это моя младшая сестра.

This is my younger sister.

Expected form: **моя**

Why: Possessive forms. [[Russian#^ru-Q0158|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D1%82%D0%BE%20%D0%BC%D0%BE%D1%8F%20%D0%BC%D0%BB%D0%B0%D0%B4%D1%88%D0%B0%D1%8F%20%D1%81%D0%B5%D1%81%D1%82%D1%80%D0%B0.)
^ru-Q0158-answer

**ru-Q0159** — Где он нашёл мои ключи?

Where did he find my keys?

Expected form: **мои**

Why: Possessive forms. [[Russian#^ru-Q0159|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%93%D0%B4%D0%B5%20%D0%BE%D0%BD%20%D0%BD%D0%B0%D1%88%D1%91%D0%BB%20%D0%BC%D0%BE%D0%B8%20%D0%BA%D0%BB%D1%8E%D1%87%D0%B8%3F)
^ru-Q0159-answer

**ru-Q0160** — Где он нашёл мои ключи?

Where did he find my keys?

Why: Possessive forms. [[Russian#^ru-Q0160|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%93%D0%B4%D0%B5%20%D0%BE%D0%BD%20%D0%BD%D0%B0%D1%88%D1%91%D0%BB%20%D0%BC%D0%BE%D0%B8%20%D0%BA%D0%BB%D1%8E%D1%87%D0%B8%3F)
^ru-Q0160-answer

**ru-Q0161** — Которая из чашек моя?

Which one is my cup?

Why: Possessive forms. [[Russian#^ru-Q0161|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%BE%D1%82%D0%BE%D1%80%D0%B0%D1%8F%20%D0%B8%D0%B7%20%D1%87%D0%B0%D1%88%D0%B5%D0%BA%20%D0%BC%D0%BE%D1%8F%3F)
^ru-Q0161-answer

**ru-Q0162** — Которая из чашек моя?

Which one is my cup?

Possessive adjectives agree with the possessed noun in case, gender and number. The possessor’s sex does not choose мой versus моя.

Why: Possessive forms. [[Russian#^ru-Q0162|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%BE%D1%82%D0%BE%D1%80%D0%B0%D1%8F%20%D0%B8%D0%B7%20%D1%87%D0%B0%D1%88%D0%B5%D0%BA%20%D0%BC%D0%BE%D1%8F%3F)
^ru-Q0162-answer

**ru-Q0163** — Как вам моя стрижка?

What do you think of my haircut?

Expected form: **моя**

Why: Possessive forms. [[Russian#^ru-Q0163|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%B0%D0%BA%20%D0%B2%D0%B0%D0%BC%20%D0%BC%D0%BE%D1%8F%20%D1%81%D1%82%D1%80%D0%B8%D0%B6%D0%BA%D0%B0%3F)
^ru-Q0163-answer

**ru-Q0164** — Как вам моя стрижка?

What do you think of my haircut?

Expected form: **моя**

Why: Possessive forms. [[Russian#^ru-Q0164|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%B0%D0%BA%20%D0%B2%D0%B0%D0%BC%20%D0%BC%D0%BE%D1%8F%20%D1%81%D1%82%D1%80%D0%B8%D0%B6%D0%BA%D0%B0%3F)
^ru-Q0164-answer

**ru-Q0165** — Это ваша черепаха?

Is this turtle yours?

Expected form: **ваша**

Why: Possessive forms. [[Russian#^ru-Q0165|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D1%82%D0%BE%20%D0%B2%D0%B0%D1%88%D0%B0%20%D1%87%D0%B5%D1%80%D0%B5%D0%BF%D0%B0%D1%85%D0%B0%3F)
^ru-Q0165-answer

**ru-Q0166** — Это ваша черепаха?

Is this turtle yours?

Why: Possessive forms. [[Russian#^ru-Q0166|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D1%82%D0%BE%20%D0%B2%D0%B0%D1%88%D0%B0%20%D1%87%D0%B5%D1%80%D0%B5%D0%BF%D0%B0%D1%85%D0%B0%3F)
^ru-Q0166-answer

**ru-Q0167** — Моя старшая сестра наконец вышла замуж.

My older sister finally got married.

Why: Possessive forms. [[Russian#^ru-Q0167|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D1%8F%20%D1%81%D1%82%D0%B0%D1%80%D1%88%D0%B0%D1%8F%20%D1%81%D0%B5%D1%81%D1%82%D1%80%D0%B0%20%D0%BD%D0%B0%D0%BA%D0%BE%D0%BD%D0%B5%D1%86%20%D0%B2%D1%8B%D1%88%D0%BB%D0%B0%20%D0%B7%D0%B0%D0%BC%D1%83%D0%B6.)
^ru-Q0167-answer

**ru-Q0168** — Моя старшая сестра наконец вышла замуж.

My older sister finally got married.

Possessive adjectives agree with the possessed noun in case, gender and number. The possessor’s sex does not choose мой versus моя.

Why: Possessive forms. [[Russian#^ru-Q0168|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D1%8F%20%D1%81%D1%82%D0%B0%D1%80%D1%88%D0%B0%D1%8F%20%D1%81%D0%B5%D1%81%D1%82%D1%80%D0%B0%20%D0%BD%D0%B0%D0%BA%D0%BE%D0%BD%D0%B5%D1%86%20%D0%B2%D1%8B%D1%88%D0%BB%D0%B0%20%D0%B7%D0%B0%D0%BC%D1%83%D0%B6.)
^ru-Q0168-answer

**ru-Q0169** — Вы не видели, кто взял мой рюкзак?

Did you see who took my backpack?

Expected form: **мой**

Why: Possessive forms. [[Russian#^ru-Q0169|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D0%BD%D0%B5%20%D0%B2%D0%B8%D0%B4%D0%B5%D0%BB%D0%B8%2C%20%D0%BA%D1%82%D0%BE%20%D0%B2%D0%B7%D1%8F%D0%BB%20%D0%BC%D0%BE%D0%B9%20%D1%80%D1%8E%D0%BA%D0%B7%D0%B0%D0%BA%3F)
^ru-Q0169-answer

**ru-Q0170** — Вы не видели, кто взял мой рюкзак?

Did you see who took my backpack?

Expected form: **мой**

Why: Possessive forms. [[Russian#^ru-Q0170|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D0%BD%D0%B5%20%D0%B2%D0%B8%D0%B4%D0%B5%D0%BB%D0%B8%2C%20%D0%BA%D1%82%D0%BE%20%D0%B2%D0%B7%D1%8F%D0%BB%20%D0%BC%D0%BE%D0%B9%20%D1%80%D1%8E%D0%BA%D0%B7%D0%B0%D0%BA%3F)
^ru-Q0170-answer

**ru-Q0171** — Мой отец каждый день пьёт по чашке кофе.

My father has a cup of coffee every day.

Expected form: **Мой**

Why: Possessive forms. [[Russian#^ru-Q0171|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D0%B9%20%D0%BE%D1%82%D0%B5%D1%86%20%D0%BA%D0%B0%D0%B6%D0%B4%D1%8B%D0%B9%20%D0%B4%D0%B5%D0%BD%D1%8C%20%D0%BF%D1%8C%D1%91%D1%82%20%D0%BF%D0%BE%20%D1%87%D0%B0%D1%88%D0%BA%D0%B5%20%D0%BA%D0%BE%D1%84%D0%B5.)
^ru-Q0171-answer

**ru-Q0172** — Мой отец каждый день пьёт по чашке кофе.

My father has a cup of coffee every day.

Why: Possessive forms. [[Russian#^ru-Q0172|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D0%B9%20%D0%BE%D1%82%D0%B5%D1%86%20%D0%BA%D0%B0%D0%B6%D0%B4%D1%8B%D0%B9%20%D0%B4%D0%B5%D0%BD%D1%8C%20%D0%BF%D1%8C%D1%91%D1%82%20%D0%BF%D0%BE%20%D1%87%D0%B0%D1%88%D0%BA%D0%B5%20%D0%BA%D0%BE%D1%84%D0%B5.)
^ru-Q0172-answer

**ru-Q0173** — Какая твоя любимая крупа?

What's your favorite cereal?

Why: Possessive forms. [[Russian#^ru-Q0173|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%B0%D0%BA%D0%B0%D1%8F%20%D1%82%D0%B2%D0%BE%D1%8F%20%D0%BB%D1%8E%D0%B1%D0%B8%D0%BC%D0%B0%D1%8F%20%D0%BA%D1%80%D1%83%D0%BF%D0%B0%3F)
^ru-Q0173-answer

**ru-Q0174** — Какая твоя любимая крупа?

What's your favorite cereal?

Possessive adjectives agree with the possessed noun in case, gender and number. The possessor’s sex does not choose мой versus моя.

Why: Possessive forms. [[Russian#^ru-Q0174|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%B0%D0%BA%D0%B0%D1%8F%20%D1%82%D0%B2%D0%BE%D1%8F%20%D0%BB%D1%8E%D0%B1%D0%B8%D0%BC%D0%B0%D1%8F%20%D0%BA%D1%80%D1%83%D0%BF%D0%B0%3F)
^ru-Q0174-answer

**ru-Q0175** — Моё хобби - коллекционирование старых монет.

My hobby is collecting old coins.

Expected form: **Моё**

Why: Possessive forms. [[Russian#^ru-Q0175|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D1%91%20%D1%85%D0%BE%D0%B1%D0%B1%D0%B8%20-%20%D0%BA%D0%BE%D0%BB%D0%BB%D0%B5%D0%BA%D1%86%D0%B8%D0%BE%D0%BD%D0%B8%D1%80%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5%20%D1%81%D1%82%D0%B0%D1%80%D1%8B%D1%85%20%D0%BC%D0%BE%D0%BD%D0%B5%D1%82.)
^ru-Q0175-answer

**ru-Q0176** — Моё хобби - коллекционирование старых монет.

My hobby is collecting old coins.

Expected form: **Моё**

Why: Possessive forms. [[Russian#^ru-Q0176|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D1%91%20%D1%85%D0%BE%D0%B1%D0%B1%D0%B8%20-%20%D0%BA%D0%BE%D0%BB%D0%BB%D0%B5%D0%BA%D1%86%D0%B8%D0%BE%D0%BD%D0%B8%D1%80%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5%20%D1%81%D1%82%D0%B0%D1%80%D1%8B%D1%85%20%D0%BC%D0%BE%D0%BD%D0%B5%D1%82.)
^ru-Q0176-answer

**ru-Q0177** — Элементарно, мой дорогой Том.

It's elementary, my dear Tom.

Expected form: **мой**

Why: Possessive forms. [[Russian#^ru-Q0177|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D0%BB%D0%B5%D0%BC%D0%B5%D0%BD%D1%82%D0%B0%D1%80%D0%BD%D0%BE%2C%20%D0%BC%D0%BE%D0%B9%20%D0%B4%D0%BE%D1%80%D0%BE%D0%B3%D0%BE%D0%B9%20%D0%A2%D0%BE%D0%BC.)
^ru-Q0177-answer

**ru-Q0178** — Элементарно, мой дорогой Том.

It's elementary, my dear Tom.

Why: Possessive forms. [[Russian#^ru-Q0178|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D0%BB%D0%B5%D0%BC%D0%B5%D0%BD%D1%82%D0%B0%D1%80%D0%BD%D0%BE%2C%20%D0%BC%D0%BE%D0%B9%20%D0%B4%D0%BE%D1%80%D0%BE%D0%B3%D0%BE%D0%B9%20%D0%A2%D0%BE%D0%BC.)
^ru-Q0178-answer

**ru-Q0179** — Мой тесть - инженер.

My father-in-law is an engineer.

Why: Possessive forms. [[Russian#^ru-Q0179|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D0%B9%20%D1%82%D0%B5%D1%81%D1%82%D1%8C%20-%20%D0%B8%D0%BD%D0%B6%D0%B5%D0%BD%D0%B5%D1%80.)
^ru-Q0179-answer

**ru-Q0180** — Мой тесть - инженер.

My father-in-law is an engineer.

Possessive adjectives agree with the possessed noun in case, gender and number. The possessor’s sex does not choose мой versus моя.

Why: Possessive forms. [[Russian#^ru-Q0180|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D0%B9%20%D1%82%D0%B5%D1%81%D1%82%D1%8C%20-%20%D0%B8%D0%BD%D0%B6%D0%B5%D0%BD%D0%B5%D1%80.)
^ru-Q0180-answer

**ru-Q0181** — Наш ресторан находится около южной автобусной остановки.

Our restaurant is near the southern bus station.

Expected form: **Наш**

Why: Possessive forms. [[Russian#^ru-Q0181|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%D1%88%20%D1%80%D0%B5%D1%81%D1%82%D0%BE%D1%80%D0%B0%D0%BD%20%D0%BD%D0%B0%D1%85%D0%BE%D0%B4%D0%B8%D1%82%D1%81%D1%8F%20%D0%BE%D0%BA%D0%BE%D0%BB%D0%BE%20%D1%8E%D0%B6%D0%BD%D0%BE%D0%B9%20%D0%B0%D0%B2%D1%82%D0%BE%D0%B1%D1%83%D1%81%D0%BD%D0%BE%D0%B9%20%D0%BE%D1%81%D1%82%D0%B0%D0%BD%D0%BE%D0%B2%D0%BA%D0%B8.)
^ru-Q0181-answer

**ru-Q0182** — Наш ресторан находится около южной автобусной остановки.

Our restaurant is near the southern bus station.

Expected form: **Наш**

Why: Possessive forms. [[Russian#^ru-Q0182|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%D1%88%20%D1%80%D0%B5%D1%81%D1%82%D0%BE%D1%80%D0%B0%D0%BD%20%D0%BD%D0%B0%D1%85%D0%BE%D0%B4%D0%B8%D1%82%D1%81%D1%8F%20%D0%BE%D0%BA%D0%BE%D0%BB%D0%BE%20%D1%8E%D0%B6%D0%BD%D0%BE%D0%B9%20%D0%B0%D0%B2%D1%82%D0%BE%D0%B1%D1%83%D1%81%D0%BD%D0%BE%D0%B9%20%D0%BE%D1%81%D1%82%D0%B0%D0%BD%D0%BE%D0%B2%D0%BA%D0%B8.)
^ru-Q0182-answer

**ru-Q0183** — Моё сердце перестало биться.

My heart stopped beating.

Expected form: **Моё**

Why: Possessive forms. [[Russian#^ru-Q0183|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D1%91%20%D1%81%D0%B5%D1%80%D0%B4%D1%86%D0%B5%20%D0%BF%D0%B5%D1%80%D0%B5%D1%81%D1%82%D0%B0%D0%BB%D0%BE%20%D0%B1%D0%B8%D1%82%D1%8C%D1%81%D1%8F.)
^ru-Q0183-answer

**ru-Q0184** — Моё сердце перестало биться.

My heart stopped beating.

Why: Possessive forms. [[Russian#^ru-Q0184|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D1%91%20%D1%81%D0%B5%D1%80%D0%B4%D1%86%D0%B5%20%D0%BF%D0%B5%D1%80%D0%B5%D1%81%D1%82%D0%B0%D0%BB%D0%BE%20%D0%B1%D0%B8%D1%82%D1%8C%D1%81%D1%8F.)
^ru-Q0184-answer

**ru-Q0185** — Моё мнение не изменилось.

My opinion hasn't changed.

Why: Possessive forms. [[Russian#^ru-Q0185|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D1%91%20%D0%BC%D0%BD%D0%B5%D0%BD%D0%B8%D0%B5%20%D0%BD%D0%B5%20%D0%B8%D0%B7%D0%BC%D0%B5%D0%BD%D0%B8%D0%BB%D0%BE%D1%81%D1%8C.)
^ru-Q0185-answer

**ru-Q0186** — Моё мнение не изменилось.

My opinion hasn't changed.

Possessive adjectives agree with the possessed noun in case, gender and number. The possessor’s sex does not choose мой versus моя.

Why: Possessive forms. [[Russian#^ru-Q0186|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D1%91%20%D0%BC%D0%BD%D0%B5%D0%BD%D0%B8%D0%B5%20%D0%BD%D0%B5%20%D0%B8%D0%B7%D0%BC%D0%B5%D0%BD%D0%B8%D0%BB%D0%BE%D1%81%D1%8C.)
^ru-Q0186-answer

**ru-Q0187** — Мой отец чинит сломанные кресла.

My father fixes broken armchairs.

Expected form: **Мой**

Why: Possessive forms. [[Russian#^ru-Q0187|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D0%B9%20%D0%BE%D1%82%D0%B5%D1%86%20%D1%87%D0%B8%D0%BD%D0%B8%D1%82%20%D1%81%D0%BB%D0%BE%D0%BC%D0%B0%D0%BD%D0%BD%D1%8B%D0%B5%20%D0%BA%D1%80%D0%B5%D1%81%D0%BB%D0%B0.)
^ru-Q0187-answer

**ru-Q0188** — Мой отец чинит сломанные кресла.

My father fixes broken armchairs.

Expected form: **Мой**

Why: Possessive forms. [[Russian#^ru-Q0188|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D0%B9%20%D0%BE%D1%82%D0%B5%D1%86%20%D1%87%D0%B8%D0%BD%D0%B8%D1%82%20%D1%81%D0%BB%D0%BE%D0%BC%D0%B0%D0%BD%D0%BD%D1%8B%D0%B5%20%D0%BA%D1%80%D0%B5%D1%81%D0%BB%D0%B0.)
^ru-Q0188-answer

**ru-Q0189** — Ваш совет нам никак не помог.

Your advice did not help us at all.

Expected form: **Ваш**

Why: Possessive forms. [[Russian#^ru-Q0189|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D0%B0%D1%88%20%D1%81%D0%BE%D0%B2%D0%B5%D1%82%20%D0%BD%D0%B0%D0%BC%20%D0%BD%D0%B8%D0%BA%D0%B0%D0%BA%20%D0%BD%D0%B5%20%D0%BF%D0%BE%D0%BC%D0%BE%D0%B3.)
^ru-Q0189-answer

**ru-Q0190** — Ваш совет нам никак не помог.

Your advice did not help us at all.

Why: Possessive forms. [[Russian#^ru-Q0190|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D0%B0%D1%88%20%D1%81%D0%BE%D0%B2%D0%B5%D1%82%20%D0%BD%D0%B0%D0%BC%20%D0%BD%D0%B8%D0%BA%D0%B0%D0%BA%20%D0%BD%D0%B5%20%D0%BF%D0%BE%D0%BC%D0%BE%D0%B3.)
^ru-Q0190-answer

**ru-Q0191** — Где мой ластик?

Where's my eraser?

Why: Possessive forms. [[Russian#^ru-Q0191|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%93%D0%B4%D0%B5%20%D0%BC%D0%BE%D0%B9%20%D0%BB%D0%B0%D1%81%D1%82%D0%B8%D0%BA%3F)
^ru-Q0191-answer

**ru-Q0192** — Где мой ластик?

Where's my eraser?

Possessive adjectives agree with the possessed noun in case, gender and number. The possessor’s sex does not choose мой versus моя.

Why: Possessive forms. [[Russian#^ru-Q0192|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%93%D0%B4%D0%B5%20%D0%BC%D0%BE%D0%B9%20%D0%BB%D0%B0%D1%81%D1%82%D0%B8%D0%BA%3F)
^ru-Q0192-answer

**ru-Q0193** — Ей нравятся мои шутки.

She likes my jokes.

Expected form: **мои**

Why: Possessive forms. [[Russian#^ru-Q0193|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D0%B9%20%D0%BD%D1%80%D0%B0%D0%B2%D1%8F%D1%82%D1%81%D1%8F%20%D0%BC%D0%BE%D0%B8%20%D1%88%D1%83%D1%82%D0%BA%D0%B8.)
^ru-Q0193-answer

**ru-Q0194** — Ей нравятся мои шутки.

She likes my jokes.

Expected form: **мои**

Why: Possessive forms. [[Russian#^ru-Q0194|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D0%B9%20%D0%BD%D1%80%D0%B0%D0%B2%D1%8F%D1%82%D1%81%D1%8F%20%D0%BC%D0%BE%D0%B8%20%D1%88%D1%83%D1%82%D0%BA%D0%B8.)
^ru-Q0194-answer

**ru-Q0195** — Человек, читающий газету вон там, — мой дядя.

The man reading a paper over there is my uncle.

Expected form: **мой**

Why: Possessive forms. [[Russian#^ru-Q0195|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A7%D0%B5%D0%BB%D0%BE%D0%B2%D0%B5%D0%BA%2C%20%D1%87%D0%B8%D1%82%D0%B0%D1%8E%D1%89%D0%B8%D0%B9%20%D0%B3%D0%B0%D0%B7%D0%B5%D1%82%D1%83%20%D0%B2%D0%BE%D0%BD%20%D1%82%D0%B0%D0%BC%2C%20%E2%80%94%20%D0%BC%D0%BE%D0%B9%20%D0%B4%D1%8F%D0%B4%D1%8F.)
^ru-Q0195-answer

**ru-Q0196** — Человек, читающий газету вон там, — мой дядя.

The man reading a paper over there is my uncle.

Why: Possessive forms. [[Russian#^ru-Q0196|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A7%D0%B5%D0%BB%D0%BE%D0%B2%D0%B5%D0%BA%2C%20%D1%87%D0%B8%D1%82%D0%B0%D1%8E%D1%89%D0%B8%D0%B9%20%D0%B3%D0%B0%D0%B7%D0%B5%D1%82%D1%83%20%D0%B2%D0%BE%D0%BD%20%D1%82%D0%B0%D0%BC%2C%20%E2%80%94%20%D0%BC%D0%BE%D0%B9%20%D0%B4%D1%8F%D0%B4%D1%8F.)
^ru-Q0196-answer

**ru-Q0197** — Это был не мой.

It wasn't mine.

Why: Possessive forms. [[Russian#^ru-Q0197|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D1%82%D0%BE%20%D0%B1%D1%8B%D0%BB%20%D0%BD%D0%B5%20%D0%BC%D0%BE%D0%B9.)
^ru-Q0197-answer

**ru-Q0198** — Это был не мой.

It wasn't mine.

Possessive adjectives agree with the possessed noun in case, gender and number. The possessor’s sex does not choose мой versus моя.

Why: Possessive forms. [[Russian#^ru-Q0198|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D1%82%D0%BE%20%D0%B1%D1%8B%D0%BB%20%D0%BD%D0%B5%20%D0%BC%D0%BE%D0%B9.)
^ru-Q0198-answer

**ru-Q0199** — Это моя корова.

This is my cow.

Expected form: **моя**

Why: Possessive forms. [[Russian#^ru-Q0199|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D1%82%D0%BE%20%D0%BC%D0%BE%D1%8F%20%D0%BA%D0%BE%D1%80%D0%BE%D0%B2%D0%B0.)
^ru-Q0199-answer

**ru-Q0200** — Это моя корова.

This is my cow.

Expected form: **моя**

Why: Possessive forms. [[Russian#^ru-Q0200|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D1%82%D0%BE%20%D0%BC%D0%BE%D1%8F%20%D0%BA%D0%BE%D1%80%D0%BE%D0%B2%D0%B0.)
^ru-Q0200-answer


### Answers 201–250

**ru-Q0201** — Пойди поговори с ними.

Go talk to them.

Expected form: **с**

Why: Locative prepositions. [[Russian#^ru-Q0201|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%B9%D0%B4%D0%B8%20%D0%BF%D0%BE%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%20%D1%81%20%D0%BD%D0%B8%D0%BC%D0%B8.)
^ru-Q0201-answer

**ru-Q0202** — Пойди поговори с ними.

Go talk to them.

Why: Locative prepositions. [[Russian#^ru-Q0202|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%B9%D0%B4%D0%B8%20%D0%BF%D0%BE%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%20%D1%81%20%D0%BD%D0%B8%D0%BC%D0%B8.)
^ru-Q0202-answer

**ru-Q0203** — Никто из них не занят.

None of them are busy.

Why: Locative prepositions. [[Russian#^ru-Q0203|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B8%D0%BA%D1%82%D0%BE%20%D0%B8%D0%B7%20%D0%BD%D0%B8%D1%85%20%D0%BD%D0%B5%20%D0%B7%D0%B0%D0%BD%D1%8F%D1%82.)
^ru-Q0203-answer

**ru-Q0204** — Никто из них не занят.

None of them are busy.

Prepositions govern case. В/на commonly distinguish destination with accusative and location with prepositional. У + genitive is frequent in possession; с has more than one case/meaning pattern.

Why: Locative prepositions. [[Russian#^ru-Q0204|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B8%D0%BA%D1%82%D0%BE%20%D0%B8%D0%B7%20%D0%BD%D0%B8%D1%85%20%D0%BD%D0%B5%20%D0%B7%D0%B0%D0%BD%D1%8F%D1%82.)
^ru-Q0204-answer

**ru-Q0205** — Том встретил Мэри сегодня утром по дороге в школу.

Tom met Mary this morning on his way to school.

Expected form: **в**

Why: Locative prepositions. [[Russian#^ru-Q0205|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B2%D1%81%D1%82%D1%80%D0%B5%D1%82%D0%B8%D0%BB%20%D0%9C%D1%8D%D1%80%D0%B8%20%D1%81%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F%20%D1%83%D1%82%D1%80%D0%BE%D0%BC%20%D0%BF%D0%BE%20%D0%B4%D0%BE%D1%80%D0%BE%D0%B3%D0%B5%20%D0%B2%20%D1%88%D0%BA%D0%BE%D0%BB%D1%83.)
^ru-Q0205-answer

**ru-Q0206** — Том встретил Мэри сегодня утром по дороге в школу.

Tom met Mary this morning on his way to school.

Expected form: **в**

Why: Locative prepositions. [[Russian#^ru-Q0206|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B2%D1%81%D1%82%D1%80%D0%B5%D1%82%D0%B8%D0%BB%20%D0%9C%D1%8D%D1%80%D0%B8%20%D1%81%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F%20%D1%83%D1%82%D1%80%D0%BE%D0%BC%20%D0%BF%D0%BE%20%D0%B4%D0%BE%D1%80%D0%BE%D0%B3%D0%B5%20%D0%B2%20%D1%88%D0%BA%D0%BE%D0%BB%D1%83.)
^ru-Q0206-answer

**ru-Q0207** — Том даже не захотел говорить с Мэри.

Tom didn't even want to talk to Mary.

Expected form: **с**

Why: Locative prepositions. [[Russian#^ru-Q0207|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B4%D0%B0%D0%B6%D0%B5%20%D0%BD%D0%B5%20%D0%B7%D0%B0%D1%85%D0%BE%D1%82%D0%B5%D0%BB%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D1%8C%20%D1%81%20%D0%9C%D1%8D%D1%80%D0%B8.)
^ru-Q0207-answer

**ru-Q0208** — Том даже не захотел говорить с Мэри.

Tom didn't even want to talk to Mary.

Why: Locative prepositions. [[Russian#^ru-Q0208|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B4%D0%B0%D0%B6%D0%B5%20%D0%BD%D0%B5%20%D0%B7%D0%B0%D1%85%D0%BE%D1%82%D0%B5%D0%BB%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D1%8C%20%D1%81%20%D0%9C%D1%8D%D1%80%D0%B8.)
^ru-Q0208-answer

**ru-Q0209** — Правильно ли входить в мечеть в грязных носках?

Is it proper to enter a mosque wearing dirty socks?

Why: Locative prepositions. [[Russian#^ru-Q0209|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D1%80%D0%B0%D0%B2%D0%B8%D0%BB%D1%8C%D0%BD%D0%BE%20%D0%BB%D0%B8%20%D0%B2%D1%85%D0%BE%D0%B4%D0%B8%D1%82%D1%8C%20%D0%B2%20%D0%BC%D0%B5%D1%87%D0%B5%D1%82%D1%8C%20%D0%B2%20%D0%B3%D1%80%D1%8F%D0%B7%D0%BD%D1%8B%D1%85%20%D0%BD%D0%BE%D1%81%D0%BA%D0%B0%D1%85%3F)
^ru-Q0209-answer

**ru-Q0210** — Правильно ли входить в мечеть в грязных носках?

Is it proper to enter a mosque wearing dirty socks?

Prepositions govern case. В/на commonly distinguish destination with accusative and location with prepositional. У + genitive is frequent in possession; с has more than one case/meaning pattern.

Why: Locative prepositions. [[Russian#^ru-Q0210|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D1%80%D0%B0%D0%B2%D0%B8%D0%BB%D1%8C%D0%BD%D0%BE%20%D0%BB%D0%B8%20%D0%B2%D1%85%D0%BE%D0%B4%D0%B8%D1%82%D1%8C%20%D0%B2%20%D0%BC%D0%B5%D1%87%D0%B5%D1%82%D1%8C%20%D0%B2%20%D0%B3%D1%80%D1%8F%D0%B7%D0%BD%D1%8B%D1%85%20%D0%BD%D0%BE%D1%81%D0%BA%D0%B0%D1%85%3F)
^ru-Q0210-answer

**ru-Q0211** — Том подбавил дров в огонь.

Tom added wood to the fire.

Expected form: **в**

Why: Locative prepositions. [[Russian#^ru-Q0211|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BF%D0%BE%D0%B4%D0%B1%D0%B0%D0%B2%D0%B8%D0%BB%20%D0%B4%D1%80%D0%BE%D0%B2%20%D0%B2%20%D0%BE%D0%B3%D0%BE%D0%BD%D1%8C.)
^ru-Q0211-answer

**ru-Q0212** — Том подбавил дров в огонь.

Tom added wood to the fire.

Expected form: **в**

Why: Locative prepositions. [[Russian#^ru-Q0212|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BF%D0%BE%D0%B4%D0%B1%D0%B0%D0%B2%D0%B8%D0%BB%20%D0%B4%D1%80%D0%BE%D0%B2%20%D0%B2%20%D0%BE%D0%B3%D0%BE%D0%BD%D1%8C.)
^ru-Q0212-answer

**ru-Q0213** — Что было в духовке?

What was in the oven?

Expected form: **в**

Why: Locative prepositions. [[Russian#^ru-Q0213|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A7%D1%82%D0%BE%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D0%B2%20%D0%B4%D1%83%D1%85%D0%BE%D0%B2%D0%BA%D0%B5%3F)
^ru-Q0213-answer

**ru-Q0214** — Что было в духовке?

What was in the oven?

Why: Locative prepositions. [[Russian#^ru-Q0214|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A7%D1%82%D0%BE%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D0%B2%20%D0%B4%D1%83%D1%85%D0%BE%D0%B2%D0%BA%D0%B5%3F)
^ru-Q0214-answer

**ru-Q0215** — Сами и Лейла обедали в уютной гостинице.

Sami and Layla were taking their lunches at a cozy hotel.

Why: Locative prepositions. [[Russian#^ru-Q0215|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%B0%D0%BC%D0%B8%20%D0%B8%20%D0%9B%D0%B5%D0%B9%D0%BB%D0%B0%20%D0%BE%D0%B1%D0%B5%D0%B4%D0%B0%D0%BB%D0%B8%20%D0%B2%20%D1%83%D1%8E%D1%82%D0%BD%D0%BE%D0%B9%20%D0%B3%D0%BE%D1%81%D1%82%D0%B8%D0%BD%D0%B8%D1%86%D0%B5.)
^ru-Q0215-answer

**ru-Q0216** — Сами и Лейла обедали в уютной гостинице.

Sami and Layla were taking their lunches at a cozy hotel.

Prepositions govern case. В/на commonly distinguish destination with accusative and location with prepositional. У + genitive is frequent in possession; с has more than one case/meaning pattern.

Why: Locative prepositions. [[Russian#^ru-Q0216|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%B0%D0%BC%D0%B8%20%D0%B8%20%D0%9B%D0%B5%D0%B9%D0%BB%D0%B0%20%D0%BE%D0%B1%D0%B5%D0%B4%D0%B0%D0%BB%D0%B8%20%D0%B2%20%D1%83%D1%8E%D1%82%D0%BD%D0%BE%D0%B9%20%D0%B3%D0%BE%D1%81%D1%82%D0%B8%D0%BD%D0%B8%D1%86%D0%B5.)
^ru-Q0216-answer

**ru-Q0217** — Вы с ними поговорили?

Have you talked to them?

Expected form: **с**

Why: Locative prepositions. [[Russian#^ru-Q0217|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D1%81%20%D0%BD%D0%B8%D0%BC%D0%B8%20%D0%BF%D0%BE%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D0%BB%D0%B8%3F)
^ru-Q0217-answer

**ru-Q0218** — Вы с ними поговорили?

Have you talked to them?

Expected form: **с**

Why: Locative prepositions. [[Russian#^ru-Q0218|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D1%81%20%D0%BD%D0%B8%D0%BC%D0%B8%20%D0%BF%D0%BE%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D0%BB%D0%B8%3F)
^ru-Q0218-answer

**ru-Q0219** — Я много тусовался с Томом.

I hang out with Tom a lot.

Expected form: **с**

Why: Locative prepositions. [[Russian#^ru-Q0219|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BC%D0%BD%D0%BE%D0%B3%D0%BE%20%D1%82%D1%83%D1%81%D0%BE%D0%B2%D0%B0%D0%BB%D1%81%D1%8F%20%D1%81%20%D0%A2%D0%BE%D0%BC%D0%BE%D0%BC.)
^ru-Q0219-answer

**ru-Q0220** — Я много тусовался с Томом.

I hang out with Tom a lot.

Why: Locative prepositions. [[Russian#^ru-Q0220|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BC%D0%BD%D0%BE%D0%B3%D0%BE%20%D1%82%D1%83%D1%81%D0%BE%D0%B2%D0%B0%D0%BB%D1%81%D1%8F%20%D1%81%20%D0%A2%D0%BE%D0%BC%D0%BE%D0%BC.)
^ru-Q0220-answer

**ru-Q0221** — Когда вы в последний раз ходили с Томом на рыбалку?

When was the last time you went fishing with Tom?

Why: Locative prepositions. [[Russian#^ru-Q0221|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%B2%D1%8B%20%D0%B2%20%D0%BF%D0%BE%D1%81%D0%BB%D0%B5%D0%B4%D0%BD%D0%B8%D0%B9%20%D1%80%D0%B0%D0%B7%20%D1%85%D0%BE%D0%B4%D0%B8%D0%BB%D0%B8%20%D1%81%20%D0%A2%D0%BE%D0%BC%D0%BE%D0%BC%20%D0%BD%D0%B0%20%D1%80%D1%8B%D0%B1%D0%B0%D0%BB%D0%BA%D1%83%3F)
^ru-Q0221-answer

**ru-Q0222** — Когда вы в последний раз ходили с Томом на рыбалку?

When was the last time you went fishing with Tom?

Prepositions govern case. В/на commonly distinguish destination with accusative and location with prepositional. У + genitive is frequent in possession; с has more than one case/meaning pattern.

Why: Locative prepositions. [[Russian#^ru-Q0222|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%B2%D1%8B%20%D0%B2%20%D0%BF%D0%BE%D1%81%D0%BB%D0%B5%D0%B4%D0%BD%D0%B8%D0%B9%20%D1%80%D0%B0%D0%B7%20%D1%85%D0%BE%D0%B4%D0%B8%D0%BB%D0%B8%20%D1%81%20%D0%A2%D0%BE%D0%BC%D0%BE%D0%BC%20%D0%BD%D0%B0%20%D1%80%D1%8B%D0%B1%D0%B0%D0%BB%D0%BA%D1%83%3F)
^ru-Q0222-answer

**ru-Q0223** — Ты не должен ни с кем обсуждать этот вопрос.

You must not discuss this matter with anyone.

Expected form: **с**

Why: Locative prepositions. [[Russian#^ru-Q0223|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%BD%D0%B5%20%D0%B4%D0%BE%D0%BB%D0%B6%D0%B5%D0%BD%20%D0%BD%D0%B8%20%D1%81%20%D0%BA%D0%B5%D0%BC%20%D0%BE%D0%B1%D1%81%D1%83%D0%B6%D0%B4%D0%B0%D1%82%D1%8C%20%D1%8D%D1%82%D0%BE%D1%82%20%D0%B2%D0%BE%D0%BF%D1%80%D0%BE%D1%81.)
^ru-Q0223-answer

**ru-Q0224** — Ты не должен ни с кем обсуждать этот вопрос.

You must not discuss this matter with anyone.

Expected form: **с**

Why: Locative prepositions. [[Russian#^ru-Q0224|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%BD%D0%B5%20%D0%B4%D0%BE%D0%BB%D0%B6%D0%B5%D0%BD%20%D0%BD%D0%B8%20%D1%81%20%D0%BA%D0%B5%D0%BC%20%D0%BE%D0%B1%D1%81%D1%83%D0%B6%D0%B4%D0%B0%D1%82%D1%8C%20%D1%8D%D1%82%D0%BE%D1%82%20%D0%B2%D0%BE%D0%BF%D1%80%D0%BE%D1%81.)
^ru-Q0224-answer

**ru-Q0225** — Том сейчас на работе в опале после нескольких самовольных отгулов.

Tom's in the doghouse at work, following several unapproved days off.

Expected form: **на**

Why: Locative prepositions. [[Russian#^ru-Q0225|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%81%D0%B5%D0%B9%D1%87%D0%B0%D1%81%20%D0%BD%D0%B0%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B5%20%D0%B2%20%D0%BE%D0%BF%D0%B0%D0%BB%D0%B5%20%D0%BF%D0%BE%D1%81%D0%BB%D0%B5%20%D0%BD%D0%B5%D1%81%D0%BA%D0%BE%D0%BB%D1%8C%D0%BA%D0%B8%D1%85%20%D1%81%D0%B0%D0%BC%D0%BE%D0%B2%D0%BE%D0%BB%D1%8C%D0%BD%D1%8B%D1%85%20%D0%BE%D1%82%D0%B3%D1%83%D0%BB%D0%BE%D0%B2.)
^ru-Q0225-answer

**ru-Q0226** — Том сейчас на работе в опале после нескольких самовольных отгулов.

Tom's in the doghouse at work, following several unapproved days off.

Why: Locative prepositions. [[Russian#^ru-Q0226|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%81%D0%B5%D0%B9%D1%87%D0%B0%D1%81%20%D0%BD%D0%B0%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B5%20%D0%B2%20%D0%BE%D0%BF%D0%B0%D0%BB%D0%B5%20%D0%BF%D0%BE%D1%81%D0%BB%D0%B5%20%D0%BD%D0%B5%D1%81%D0%BA%D0%BE%D0%BB%D1%8C%D0%BA%D0%B8%D1%85%20%D1%81%D0%B0%D0%BC%D0%BE%D0%B2%D0%BE%D0%BB%D1%8C%D0%BD%D1%8B%D1%85%20%D0%BE%D1%82%D0%B3%D1%83%D0%BB%D0%BE%D0%B2.)
^ru-Q0226-answer

**ru-Q0227** — Китай — крупнейший производитель и потребитель угля в мире.

China is the largest producer and consumer of coal in the world.

Why: Locative prepositions. [[Russian#^ru-Q0227|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%B8%D1%82%D0%B0%D0%B9%20%E2%80%94%20%D0%BA%D1%80%D1%83%D0%BF%D0%BD%D0%B5%D0%B9%D1%88%D0%B8%D0%B9%20%D0%BF%D1%80%D0%BE%D0%B8%D0%B7%D0%B2%D0%BE%D0%B4%D0%B8%D1%82%D0%B5%D0%BB%D1%8C%20%D0%B8%20%D0%BF%D0%BE%D1%82%D1%80%D0%B5%D0%B1%D0%B8%D1%82%D0%B5%D0%BB%D1%8C%20%D1%83%D0%B3%D0%BB%D1%8F%20%D0%B2%20%D0%BC%D0%B8%D1%80%D0%B5.)
^ru-Q0227-answer

**ru-Q0228** — Китай — крупнейший производитель и потребитель угля в мире.

China is the largest producer and consumer of coal in the world.

Prepositions govern case. В/на commonly distinguish destination with accusative and location with prepositional. У + genitive is frequent in possession; с has more than one case/meaning pattern.

Why: Locative prepositions. [[Russian#^ru-Q0228|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%B8%D1%82%D0%B0%D0%B9%20%E2%80%94%20%D0%BA%D1%80%D1%83%D0%BF%D0%BD%D0%B5%D0%B9%D1%88%D0%B8%D0%B9%20%D0%BF%D1%80%D0%BE%D0%B8%D0%B7%D0%B2%D0%BE%D0%B4%D0%B8%D1%82%D0%B5%D0%BB%D1%8C%20%D0%B8%20%D0%BF%D0%BE%D1%82%D1%80%D0%B5%D0%B1%D0%B8%D1%82%D0%B5%D0%BB%D1%8C%20%D1%83%D0%B3%D0%BB%D1%8F%20%D0%B2%20%D0%BC%D0%B8%D1%80%D0%B5.)
^ru-Q0228-answer

**ru-Q0229** — Почему ты не отправился в полицию?

Why haven't you gone to the police?

Expected form: **в**

Why: Locative prepositions. [[Russian#^ru-Q0229|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D1%82%D1%8B%20%D0%BD%D0%B5%20%D0%BE%D1%82%D0%BF%D1%80%D0%B0%D0%B2%D0%B8%D0%BB%D1%81%D1%8F%20%D0%B2%20%D0%BF%D0%BE%D0%BB%D0%B8%D1%86%D0%B8%D1%8E%3F)
^ru-Q0229-answer

**ru-Q0230** — Почему ты не отправился в полицию?

Why haven't you gone to the police?

Expected form: **в**

Why: Locative prepositions. [[Russian#^ru-Q0230|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D1%82%D1%8B%20%D0%BD%D0%B5%20%D0%BE%D1%82%D0%BF%D1%80%D0%B0%D0%B2%D0%B8%D0%BB%D1%81%D1%8F%20%D0%B2%20%D0%BF%D0%BE%D0%BB%D0%B8%D1%86%D0%B8%D1%8E%3F)
^ru-Q0230-answer

**ru-Q0231** — Вы согласны с рекомендациями Тома?

Do you agree with Tom's recommendations?

Expected form: **с**

Why: Locative prepositions. [[Russian#^ru-Q0231|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D1%81%D0%BE%D0%B3%D0%BB%D0%B0%D1%81%D0%BD%D1%8B%20%D1%81%20%D1%80%D0%B5%D0%BA%D0%BE%D0%BC%D0%B5%D0%BD%D0%B4%D0%B0%D1%86%D0%B8%D1%8F%D0%BC%D0%B8%20%D0%A2%D0%BE%D0%BC%D0%B0%3F)
^ru-Q0231-answer

**ru-Q0232** — Вы согласны с рекомендациями Тома?

Do you agree with Tom's recommendations?

Why: Locative prepositions. [[Russian#^ru-Q0232|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D1%81%D0%BE%D0%B3%D0%BB%D0%B0%D1%81%D0%BD%D1%8B%20%D1%81%20%D1%80%D0%B5%D0%BA%D0%BE%D0%BC%D0%B5%D0%BD%D0%B4%D0%B0%D1%86%D0%B8%D1%8F%D0%BC%D0%B8%20%D0%A2%D0%BE%D0%BC%D0%B0%3F)
^ru-Q0232-answer

**ru-Q0233** — Я могу с ней поговорить?

Can I speak to her?

Why: Locative prepositions. [[Russian#^ru-Q0233|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BC%D0%BE%D0%B3%D1%83%20%D1%81%20%D0%BD%D0%B5%D0%B9%20%D0%BF%D0%BE%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D1%8C%3F)
^ru-Q0233-answer

**ru-Q0234** — Я могу с ней поговорить?

Can I speak to her?

Prepositions govern case. В/на commonly distinguish destination with accusative and location with prepositional. У + genitive is frequent in possession; с has more than one case/meaning pattern.

Why: Locative prepositions. [[Russian#^ru-Q0234|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BC%D0%BE%D0%B3%D1%83%20%D1%81%20%D0%BD%D0%B5%D0%B9%20%D0%BF%D0%BE%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D1%8C%3F)
^ru-Q0234-answer

**ru-Q0235** — Том будет завтра играть в теннис.

Tom will play tennis tomorrow.

Expected form: **в**

Why: Locative prepositions. [[Russian#^ru-Q0235|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D0%B7%D0%B0%D0%B2%D1%82%D1%80%D0%B0%20%D0%B8%D0%B3%D1%80%D0%B0%D1%82%D1%8C%20%D0%B2%20%D1%82%D0%B5%D0%BD%D0%BD%D0%B8%D1%81.)
^ru-Q0235-answer

**ru-Q0236** — Том будет завтра играть в теннис.

Tom will play tennis tomorrow.

Expected form: **в**

Why: Locative prepositions. [[Russian#^ru-Q0236|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D0%B7%D0%B0%D0%B2%D1%82%D1%80%D0%B0%20%D0%B8%D0%B3%D1%80%D0%B0%D1%82%D1%8C%20%D0%B2%20%D1%82%D0%B5%D0%BD%D0%BD%D0%B8%D1%81.)
^ru-Q0236-answer

**ru-Q0237** — В самом деле? Я этого не знал.

Really? I didn't know that.

Expected form: **В**

Why: Locative prepositions. [[Russian#^ru-Q0237|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%20%D1%81%D0%B0%D0%BC%D0%BE%D0%BC%20%D0%B4%D0%B5%D0%BB%D0%B5%3F%20%D0%AF%20%D1%8D%D1%82%D0%BE%D0%B3%D0%BE%20%D0%BD%D0%B5%20%D0%B7%D0%BD%D0%B0%D0%BB.)
^ru-Q0237-answer

**ru-Q0238** — В самом деле? Я этого не знал.

Really? I didn't know that.

Why: Locative prepositions. [[Russian#^ru-Q0238|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%20%D1%81%D0%B0%D0%BC%D0%BE%D0%BC%20%D0%B4%D0%B5%D0%BB%D0%B5%3F%20%D0%AF%20%D1%8D%D1%82%D0%BE%D0%B3%D0%BE%20%D0%BD%D0%B5%20%D0%B7%D0%BD%D0%B0%D0%BB.)
^ru-Q0238-answer

**ru-Q0239** — Я часто хожу в джинсах и синей рубашке.

I often wear blue jeans and a blue shirt.

Why: Locative prepositions. [[Russian#^ru-Q0239|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%87%D0%B0%D1%81%D1%82%D0%BE%20%D1%85%D0%BE%D0%B6%D1%83%20%D0%B2%20%D0%B4%D0%B6%D0%B8%D0%BD%D1%81%D0%B0%D1%85%20%D0%B8%20%D1%81%D0%B8%D0%BD%D0%B5%D0%B9%20%D1%80%D1%83%D0%B1%D0%B0%D1%88%D0%BA%D0%B5.)
^ru-Q0239-answer

**ru-Q0240** — Я часто хожу в джинсах и синей рубашке.

I often wear blue jeans and a blue shirt.

Prepositions govern case. В/на commonly distinguish destination with accusative and location with prepositional. У + genitive is frequent in possession; с has more than one case/meaning pattern.

Why: Locative prepositions. [[Russian#^ru-Q0240|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%87%D0%B0%D1%81%D1%82%D0%BE%20%D1%85%D0%BE%D0%B6%D1%83%20%D0%B2%20%D0%B4%D0%B6%D0%B8%D0%BD%D1%81%D0%B0%D1%85%20%D0%B8%20%D1%81%D0%B8%D0%BD%D0%B5%D0%B9%20%D1%80%D1%83%D0%B1%D0%B0%D1%88%D0%BA%D0%B5.)
^ru-Q0240-answer

**ru-Q0241** — Мы с Томом не дураки.

Tom and I aren't fools.

Expected form: **с**

Why: Locative prepositions. [[Russian#^ru-Q0241|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D1%81%20%D0%A2%D0%BE%D0%BC%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D0%B4%D1%83%D1%80%D0%B0%D0%BA%D0%B8.)
^ru-Q0241-answer

**ru-Q0242** — Мы с Томом не дураки.

Tom and I aren't fools.

Expected form: **с**

Why: Locative prepositions. [[Russian#^ru-Q0242|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D1%81%20%D0%A2%D0%BE%D0%BC%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D0%B4%D1%83%D1%80%D0%B0%D0%BA%D0%B8.)
^ru-Q0242-answer

**ru-Q0243** — Почему у берёз белая кора?

Why do birch trees have white bark?

Expected form: **у**

Why: Locative prepositions. [[Russian#^ru-Q0243|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D1%83%20%D0%B1%D0%B5%D1%80%D1%91%D0%B7%20%D0%B1%D0%B5%D0%BB%D0%B0%D1%8F%20%D0%BA%D0%BE%D1%80%D0%B0%3F)
^ru-Q0243-answer

**ru-Q0244** — Почему у берёз белая кора?

Why do birch trees have white bark?

Why: Locative prepositions. [[Russian#^ru-Q0244|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D1%83%20%D0%B1%D0%B5%D1%80%D1%91%D0%B7%20%D0%B1%D0%B5%D0%BB%D0%B0%D1%8F%20%D0%BA%D0%BE%D1%80%D0%B0%3F)
^ru-Q0244-answer

**ru-Q0245** — Том, вероятно, поедет в Бостон на следующей неделе.

Tom will probably go to Boston next week.

Why: Locative prepositions. [[Russian#^ru-Q0245|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%2C%20%D0%B2%D0%B5%D1%80%D0%BE%D1%8F%D1%82%D0%BD%D0%BE%2C%20%D0%BF%D0%BE%D0%B5%D0%B4%D0%B5%D1%82%20%D0%B2%20%D0%91%D0%BE%D1%81%D1%82%D0%BE%D0%BD%20%D0%BD%D0%B0%20%D1%81%D0%BB%D0%B5%D0%B4%D1%83%D1%8E%D1%89%D0%B5%D0%B9%20%D0%BD%D0%B5%D0%B4%D0%B5%D0%BB%D0%B5.)
^ru-Q0245-answer

**ru-Q0246** — Том, вероятно, поедет в Бостон на следующей неделе.

Tom will probably go to Boston next week.

Prepositions govern case. В/на commonly distinguish destination with accusative and location with prepositional. У + genitive is frequent in possession; с has more than one case/meaning pattern.

Why: Locative prepositions. [[Russian#^ru-Q0246|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%2C%20%D0%B2%D0%B5%D1%80%D0%BE%D1%8F%D1%82%D0%BD%D0%BE%2C%20%D0%BF%D0%BE%D0%B5%D0%B4%D0%B5%D1%82%20%D0%B2%20%D0%91%D0%BE%D1%81%D1%82%D0%BE%D0%BD%20%D0%BD%D0%B0%20%D1%81%D0%BB%D0%B5%D0%B4%D1%83%D1%8E%D1%89%D0%B5%D0%B9%20%D0%BD%D0%B5%D0%B4%D0%B5%D0%BB%D0%B5.)
^ru-Q0246-answer

**ru-Q0247** — Я был во многих местах в Ирландии.

I've been to many places in Ireland.

Expected form: **в**

Why: Locative prepositions. [[Russian#^ru-Q0247|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%8B%D0%BB%20%D0%B2%D0%BE%20%D0%BC%D0%BD%D0%BE%D0%B3%D0%B8%D1%85%20%D0%BC%D0%B5%D1%81%D1%82%D0%B0%D1%85%20%D0%B2%20%D0%98%D1%80%D0%BB%D0%B0%D0%BD%D0%B4%D0%B8%D0%B8.)
^ru-Q0247-answer

**ru-Q0248** — Я был во многих местах в Ирландии.

I've been to many places in Ireland.

Expected form: **в**

Why: Locative prepositions. [[Russian#^ru-Q0248|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%8B%D0%BB%20%D0%B2%D0%BE%20%D0%BC%D0%BD%D0%BE%D0%B3%D0%B8%D1%85%20%D0%BC%D0%B5%D1%81%D1%82%D0%B0%D1%85%20%D0%B2%20%D0%98%D1%80%D0%BB%D0%B0%D0%BD%D0%B4%D0%B8%D0%B8.)
^ru-Q0248-answer

**ru-Q0249** — У меня сейчас нет с собой письма.

I don't have the letter on me now.

Expected form: **У**

Why: Locative prepositions. [[Russian#^ru-Q0249|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D1%81%D0%B5%D0%B9%D1%87%D0%B0%D1%81%20%D0%BD%D0%B5%D1%82%20%D1%81%20%D1%81%D0%BE%D0%B1%D0%BE%D0%B9%20%D0%BF%D0%B8%D1%81%D1%8C%D0%BC%D0%B0.)
^ru-Q0249-answer

**ru-Q0250** — У меня сейчас нет с собой письма.

I don't have the letter on me now.

Why: Locative prepositions. [[Russian#^ru-Q0250|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D1%81%D0%B5%D0%B9%D1%87%D0%B0%D1%81%20%D0%BD%D0%B5%D1%82%20%D1%81%20%D1%81%D0%BE%D0%B1%D0%BE%D0%B9%20%D0%BF%D0%B8%D1%81%D1%8C%D0%BC%D0%B0.)
^ru-Q0250-answer


### Answers 251–300

**ru-Q0251** — Шторм нанёс большой урон урожаю.

The storm did great harm to the crop.

Why: Adjective agreement. [[Russian#^ru-Q0251|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A8%D1%82%D0%BE%D1%80%D0%BC%20%D0%BD%D0%B0%D0%BD%D1%91%D1%81%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%BE%D0%B9%20%D1%83%D1%80%D0%BE%D0%BD%20%D1%83%D1%80%D0%BE%D0%B6%D0%B0%D1%8E.)
^ru-Q0251-answer

**ru-Q0252** — Шторм нанёс большой урон урожаю.

The storm did great harm to the crop.

Adjectives agree with the noun in gender, number and case. Short and long adjective forms have distinct distributions and meanings. Learn a full phrase, not an isolated ending.

Why: Adjective agreement. [[Russian#^ru-Q0252|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A8%D1%82%D0%BE%D1%80%D0%BC%20%D0%BD%D0%B0%D0%BD%D1%91%D1%81%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%BE%D0%B9%20%D1%83%D1%80%D0%BE%D0%BD%20%D1%83%D1%80%D0%BE%D0%B6%D0%B0%D1%8E.)
^ru-Q0252-answer

**ru-Q0253** — У Тома уже новая девушка.

Tom already has a new girlfriend.

Expected form: **новая**

Why: Adjective agreement. [[Russian#^ru-Q0253|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%20%D0%A2%D0%BE%D0%BC%D0%B0%20%D1%83%D0%B6%D0%B5%20%D0%BD%D0%BE%D0%B2%D0%B0%D1%8F%20%D0%B4%D0%B5%D0%B2%D1%83%D1%88%D0%BA%D0%B0.)
^ru-Q0253-answer

**ru-Q0254** — У Тома уже новая девушка.

Tom already has a new girlfriend.

Expected form: **новая**

Why: Adjective agreement. [[Russian#^ru-Q0254|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%20%D0%A2%D0%BE%D0%BC%D0%B0%20%D1%83%D0%B6%D0%B5%20%D0%BD%D0%BE%D0%B2%D0%B0%D1%8F%20%D0%B4%D0%B5%D0%B2%D1%83%D1%88%D0%BA%D0%B0.)
^ru-Q0254-answer

**ru-Q0255** — Математика — хороший урок.

The mathematics class is good.

Expected form: **хороший**

Why: Adjective agreement. [[Russian#^ru-Q0255|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%B0%D1%82%D0%B5%D0%BC%D0%B0%D1%82%D0%B8%D0%BA%D0%B0%20%E2%80%94%20%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B8%D0%B9%20%D1%83%D1%80%D0%BE%D0%BA.)
^ru-Q0255-answer

**ru-Q0256** — Математика — хороший урок.

The mathematics class is good.

Why: Adjective agreement. [[Russian#^ru-Q0256|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%B0%D1%82%D0%B5%D0%BC%D0%B0%D1%82%D0%B8%D0%BA%D0%B0%20%E2%80%94%20%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B8%D0%B9%20%D1%83%D1%80%D0%BE%D0%BA.)
^ru-Q0256-answer

**ru-Q0257** — Это была хорошая работа.

It was a good job.

Why: Adjective agreement. [[Russian#^ru-Q0257|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D1%82%D0%BE%20%D0%B1%D1%8B%D0%BB%D0%B0%20%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B0%D1%8F%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B0.)
^ru-Q0257-answer

**ru-Q0258** — Это была хорошая работа.

It was a good job.

Adjectives agree with the noun in gender, number and case. Short and long adjective forms have distinct distributions and meanings. Learn a full phrase, not an isolated ending.

Why: Adjective agreement. [[Russian#^ru-Q0258|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D1%82%D0%BE%20%D0%B1%D1%8B%D0%BB%D0%B0%20%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B0%D1%8F%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B0.)
^ru-Q0258-answer

**ru-Q0259** — Он слишком маленький.

It's too small.

Expected form: **маленький**

Why: Adjective agreement. [[Russian#^ru-Q0259|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D1%81%D0%BB%D0%B8%D1%88%D0%BA%D0%BE%D0%BC%20%D0%BC%D0%B0%D0%BB%D0%B5%D0%BD%D1%8C%D0%BA%D0%B8%D0%B9.)
^ru-Q0259-answer

**ru-Q0260** — Он слишком маленький.

It's too small.

Expected form: **маленький**

Why: Adjective agreement. [[Russian#^ru-Q0260|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D1%81%D0%BB%D0%B8%D1%88%D0%BA%D0%BE%D0%BC%20%D0%BC%D0%B0%D0%BB%D0%B5%D0%BD%D1%8C%D0%BA%D0%B8%D0%B9.)
^ru-Q0260-answer

**ru-Q0261** — Из дешёвого мяса хороший суп ты не сваришь.

You can't make good soup with cheap meat.

Expected form: **хороший**

Why: Adjective agreement. [[Russian#^ru-Q0261|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%98%D0%B7%20%D0%B4%D0%B5%D1%88%D1%91%D0%B2%D0%BE%D0%B3%D0%BE%20%D0%BC%D1%8F%D1%81%D0%B0%20%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B8%D0%B9%20%D1%81%D1%83%D0%BF%20%D1%82%D1%8B%20%D0%BD%D0%B5%20%D1%81%D0%B2%D0%B0%D1%80%D0%B8%D1%88%D1%8C.)
^ru-Q0261-answer

**ru-Q0262** — Из дешёвого мяса хороший суп ты не сваришь.

You can't make good soup with cheap meat.

Why: Adjective agreement. [[Russian#^ru-Q0262|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%98%D0%B7%20%D0%B4%D0%B5%D1%88%D1%91%D0%B2%D0%BE%D0%B3%D0%BE%20%D0%BC%D1%8F%D1%81%D0%B0%20%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B8%D0%B9%20%D1%81%D1%83%D0%BF%20%D1%82%D1%8B%20%D0%BD%D0%B5%20%D1%81%D0%B2%D0%B0%D1%80%D0%B8%D1%88%D1%8C.)
^ru-Q0262-answer

**ru-Q0263** — У Тома был большой спор с Машей.

Tom had a big argument with Mary.

Why: Adjective agreement. [[Russian#^ru-Q0263|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%20%D0%A2%D0%BE%D0%BC%D0%B0%20%D0%B1%D1%8B%D0%BB%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%BE%D0%B9%20%D1%81%D0%BF%D0%BE%D1%80%20%D1%81%20%D0%9C%D0%B0%D1%88%D0%B5%D0%B9.)
^ru-Q0263-answer

**ru-Q0264** — У Тома был большой спор с Машей.

Tom had a big argument with Mary.

Adjectives agree with the noun in gender, number and case. Short and long adjective forms have distinct distributions and meanings. Learn a full phrase, not an isolated ending.

Why: Adjective agreement. [[Russian#^ru-Q0264|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%20%D0%A2%D0%BE%D0%BC%D0%B0%20%D0%B1%D1%8B%D0%BB%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%BE%D0%B9%20%D1%81%D0%BF%D0%BE%D1%80%20%D1%81%20%D0%9C%D0%B0%D1%88%D0%B5%D0%B9.)
^ru-Q0264-answer

**ru-Q0265** — Приезжайте в Албанию, там мы всегда делаем хороший кофе.

Come to Albania, we always make good coffee there.

Expected form: **хороший**

Why: Adjective agreement. [[Russian#^ru-Q0265|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D1%80%D0%B8%D0%B5%D0%B7%D0%B6%D0%B0%D0%B9%D1%82%D0%B5%20%D0%B2%20%D0%90%D0%BB%D0%B1%D0%B0%D0%BD%D0%B8%D1%8E%2C%20%D1%82%D0%B0%D0%BC%20%D0%BC%D1%8B%20%D0%B2%D1%81%D0%B5%D0%B3%D0%B4%D0%B0%20%D0%B4%D0%B5%D0%BB%D0%B0%D0%B5%D0%BC%20%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B8%D0%B9%20%D0%BA%D0%BE%D1%84%D0%B5.)
^ru-Q0265-answer

**ru-Q0266** — Приезжайте в Албанию, там мы всегда делаем хороший кофе.

Come to Albania, we always make good coffee there.

Expected form: **хороший**

Why: Adjective agreement. [[Russian#^ru-Q0266|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D1%80%D0%B8%D0%B5%D0%B7%D0%B6%D0%B0%D0%B9%D1%82%D0%B5%20%D0%B2%20%D0%90%D0%BB%D0%B1%D0%B0%D0%BD%D0%B8%D1%8E%2C%20%D1%82%D0%B0%D0%BC%20%D0%BC%D1%8B%20%D0%B2%D1%81%D0%B5%D0%B3%D0%B4%D0%B0%20%D0%B4%D0%B5%D0%BB%D0%B0%D0%B5%D0%BC%20%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B8%D0%B9%20%D0%BA%D0%BE%D1%84%D0%B5.)
^ru-Q0266-answer

**ru-Q0267** — Том очень хороший музыкант.

Tom is a very good musician.

Expected form: **хороший**

Why: Adjective agreement. [[Russian#^ru-Q0267|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BE%D1%87%D0%B5%D0%BD%D1%8C%20%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B8%D0%B9%20%D0%BC%D1%83%D0%B7%D1%8B%D0%BA%D0%B0%D0%BD%D1%82.)
^ru-Q0267-answer

**ru-Q0268** — Том очень хороший музыкант.

Tom is a very good musician.

Why: Adjective agreement. [[Russian#^ru-Q0268|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BE%D1%87%D0%B5%D0%BD%D1%8C%20%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B8%D0%B9%20%D0%BC%D1%83%D0%B7%D1%8B%D0%BA%D0%B0%D0%BD%D1%82.)
^ru-Q0268-answer

**ru-Q0269** — Я новый секретарь Тома.

I'm Tom's new secretary.

Why: Adjective agreement. [[Russian#^ru-Q0269|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%BE%D0%B2%D1%8B%D0%B9%20%D1%81%D0%B5%D0%BA%D1%80%D0%B5%D1%82%D0%B0%D1%80%D1%8C%20%D0%A2%D0%BE%D0%BC%D0%B0.)
^ru-Q0269-answer

**ru-Q0270** — Я новый секретарь Тома.

I'm Tom's new secretary.

Adjectives agree with the noun in gender, number and case. Short and long adjective forms have distinct distributions and meanings. Learn a full phrase, not an isolated ending.

Why: Adjective agreement. [[Russian#^ru-Q0270|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%BE%D0%B2%D1%8B%D0%B9%20%D1%81%D0%B5%D0%BA%D1%80%D0%B5%D1%82%D0%B0%D1%80%D1%8C%20%D0%A2%D0%BE%D0%BC%D0%B0.)
^ru-Q0270-answer

**ru-Q0271** — Дырка достаточно большая.

The hole is big enough.

Expected form: **большая**

Why: Adjective agreement. [[Russian#^ru-Q0271|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D1%8B%D1%80%D0%BA%D0%B0%20%D0%B4%D0%BE%D1%81%D1%82%D0%B0%D1%82%D0%BE%D1%87%D0%BD%D0%BE%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B0%D1%8F.)
^ru-Q0271-answer

**ru-Q0272** — Дырка достаточно большая.

The hole is big enough.

Expected form: **большая**

Why: Adjective agreement. [[Russian#^ru-Q0272|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D1%8B%D1%80%D0%BA%D0%B0%20%D0%B4%D0%BE%D1%81%D1%82%D0%B0%D1%82%D0%BE%D1%87%D0%BD%D0%BE%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B0%D1%8F.)
^ru-Q0272-answer

**ru-Q0273** — Почему ты считаешь, что это хорошая идея?

Why do you think that's a good idea?

Expected form: **хорошая**

Why: Adjective agreement. [[Russian#^ru-Q0273|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D1%82%D1%8B%20%D1%81%D1%87%D0%B8%D1%82%D0%B0%D0%B5%D1%88%D1%8C%2C%20%D1%87%D1%82%D0%BE%20%D1%8D%D1%82%D0%BE%20%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B0%D1%8F%20%D0%B8%D0%B4%D0%B5%D1%8F%3F)
^ru-Q0273-answer

**ru-Q0274** — Почему ты считаешь, что это хорошая идея?

Why do you think that's a good idea?

Why: Adjective agreement. [[Russian#^ru-Q0274|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D1%82%D1%8B%20%D1%81%D1%87%D0%B8%D1%82%D0%B0%D0%B5%D1%88%D1%8C%2C%20%D1%87%D1%82%D0%BE%20%D1%8D%D1%82%D0%BE%20%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B0%D1%8F%20%D0%B8%D0%B4%D0%B5%D1%8F%3F)
^ru-Q0274-answer

**ru-Q0275** — Чтение хорошее занятие.

Reading is a good activity.

Why: Adjective agreement. [[Russian#^ru-Q0275|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A7%D1%82%D0%B5%D0%BD%D0%B8%D0%B5%20%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B5%D0%B5%20%D0%B7%D0%B0%D0%BD%D1%8F%D1%82%D0%B8%D0%B5.)
^ru-Q0275-answer

**ru-Q0276** — Чтение хорошее занятие.

Reading is a good activity.

Adjectives agree with the noun in gender, number and case. Short and long adjective forms have distinct distributions and meanings. Learn a full phrase, not an isolated ending.

Why: Adjective agreement. [[Russian#^ru-Q0276|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A7%D1%82%D0%B5%D0%BD%D0%B8%D0%B5%20%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B5%D0%B5%20%D0%B7%D0%B0%D0%BD%D1%8F%D1%82%D0%B8%D0%B5.)
^ru-Q0276-answer

**ru-Q0277** — Том был убеждён, что это хорошая идея.

Tom was convinced it was a good idea.

Expected form: **хорошая**

Why: Adjective agreement. [[Russian#^ru-Q0277|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B1%D1%8B%D0%BB%20%D1%83%D0%B1%D0%B5%D0%B6%D0%B4%D1%91%D0%BD%2C%20%D1%87%D1%82%D0%BE%20%D1%8D%D1%82%D0%BE%20%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B0%D1%8F%20%D0%B8%D0%B4%D0%B5%D1%8F.)
^ru-Q0277-answer

**ru-Q0278** — Том был убеждён, что это хорошая идея.

Tom was convinced it was a good idea.

Expected form: **хорошая**

Why: Adjective agreement. [[Russian#^ru-Q0278|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B1%D1%8B%D0%BB%20%D1%83%D0%B1%D0%B5%D0%B6%D0%B4%D1%91%D0%BD%2C%20%D1%87%D1%82%D0%BE%20%D1%8D%D1%82%D0%BE%20%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B0%D1%8F%20%D0%B8%D0%B4%D0%B5%D1%8F.)
^ru-Q0278-answer

**ru-Q0279** — Тому очень нравится новая работа.

Tom really likes his new job

Expected form: **новая**

Why: Adjective agreement. [[Russian#^ru-Q0279|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%D1%83%20%D0%BE%D1%87%D0%B5%D0%BD%D1%8C%20%D0%BD%D1%80%D0%B0%D0%B2%D0%B8%D1%82%D1%81%D1%8F%20%D0%BD%D0%BE%D0%B2%D0%B0%D1%8F%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B0.)
^ru-Q0279-answer

**ru-Q0280** — Тому очень нравится новая работа.

Tom really likes his new job

Why: Adjective agreement. [[Russian#^ru-Q0280|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%D1%83%20%D0%BE%D1%87%D0%B5%D0%BD%D1%8C%20%D0%BD%D1%80%D0%B0%D0%B2%D0%B8%D1%82%D1%81%D1%8F%20%D0%BD%D0%BE%D0%B2%D0%B0%D1%8F%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B0.)
^ru-Q0280-answer

**ru-Q0281** — У тебя большой рот.

You've got a big mouth.

Why: Adjective agreement. [[Russian#^ru-Q0281|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%20%D1%82%D0%B5%D0%B1%D1%8F%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%BE%D0%B9%20%D1%80%D0%BE%D1%82.)
^ru-Q0281-answer

**ru-Q0282** — У тебя большой рот.

You've got a big mouth.

Adjectives agree with the noun in gender, number and case. Short and long adjective forms have distinct distributions and meanings. Learn a full phrase, not an isolated ending.

Why: Adjective agreement. [[Russian#^ru-Q0282|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%20%D1%82%D0%B5%D0%B1%D1%8F%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%BE%D0%B9%20%D1%80%D0%BE%D1%82.)
^ru-Q0282-answer

**ru-Q0283** — Большой разницы нет.

There's not a big difference.

Expected form: **Большой**

Why: Adjective agreement. [[Russian#^ru-Q0283|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%91%D0%BE%D0%BB%D1%8C%D1%88%D0%BE%D0%B9%20%D1%80%D0%B0%D0%B7%D0%BD%D0%B8%D1%86%D1%8B%20%D0%BD%D0%B5%D1%82.)
^ru-Q0283-answer

**ru-Q0284** — Большой разницы нет.

There's not a big difference.

Expected form: **Большой**

Why: Adjective agreement. [[Russian#^ru-Q0284|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%91%D0%BE%D0%BB%D1%8C%D1%88%D0%BE%D0%B9%20%D1%80%D0%B0%D0%B7%D0%BD%D0%B8%D1%86%D1%8B%20%D0%BD%D0%B5%D1%82.)
^ru-Q0284-answer

**ru-Q0285** — Новый дом мне нравится больше, чем старый.

I like the new house more than the old one.

Expected form: **Новый**

Why: Adjective agreement. [[Russian#^ru-Q0285|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%BE%D0%B2%D1%8B%D0%B9%20%D0%B4%D0%BE%D0%BC%20%D0%BC%D0%BD%D0%B5%20%D0%BD%D1%80%D0%B0%D0%B2%D0%B8%D1%82%D1%81%D1%8F%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%2C%20%D1%87%D0%B5%D0%BC%20%D1%81%D1%82%D0%B0%D1%80%D1%8B%D0%B9.)
^ru-Q0285-answer

**ru-Q0286** — Новый дом мне нравится больше, чем старый.

I like the new house more than the old one.

Why: Adjective agreement. [[Russian#^ru-Q0286|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%BE%D0%B2%D1%8B%D0%B9%20%D0%B4%D0%BE%D0%BC%20%D0%BC%D0%BD%D0%B5%20%D0%BD%D1%80%D0%B0%D0%B2%D0%B8%D1%82%D1%81%D1%8F%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%2C%20%D1%87%D0%B5%D0%BC%20%D1%81%D1%82%D0%B0%D1%80%D1%8B%D0%B9.)
^ru-Q0286-answer

**ru-Q0287** — Его дом не такой большой, как мой.

His house is not as large as my house.

Why: Adjective agreement. [[Russian#^ru-Q0287|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D0%B3%D0%BE%20%D0%B4%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D1%82%D0%B0%D0%BA%D0%BE%D0%B9%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%BE%D0%B9%2C%20%D0%BA%D0%B0%D0%BA%20%D0%BC%D0%BE%D0%B9.)
^ru-Q0287-answer

**ru-Q0288** — Его дом не такой большой, как мой.

His house is not as large as my house.

Adjectives agree with the noun in gender, number and case. Short and long adjective forms have distinct distributions and meanings. Learn a full phrase, not an isolated ending.

Why: Adjective agreement. [[Russian#^ru-Q0288|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D0%B3%D0%BE%20%D0%B4%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D1%82%D0%B0%D0%BA%D0%BE%D0%B9%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%BE%D0%B9%2C%20%D0%BA%D0%B0%D0%BA%20%D0%BC%D0%BE%D0%B9.)
^ru-Q0288-answer

**ru-Q0289** — Том - хороший бегун.

Tom is a good runner.

Expected form: **хороший**

Why: Adjective agreement. [[Russian#^ru-Q0289|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20-%20%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B8%D0%B9%20%D0%B1%D0%B5%D0%B3%D1%83%D0%BD.)
^ru-Q0289-answer

**ru-Q0290** — Том - хороший бегун.

Tom is a good runner.

Expected form: **хороший**

Why: Adjective agreement. [[Russian#^ru-Q0290|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20-%20%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B8%D0%B9%20%D0%B1%D0%B5%D0%B3%D1%83%D0%BD.)
^ru-Q0290-answer

**ru-Q0291** — Я купила хороший фотоаппарат.

I bought a good camera.

Expected form: **хороший**

Why: Adjective agreement. [[Russian#^ru-Q0291|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BA%D1%83%D0%BF%D0%B8%D0%BB%D0%B0%20%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B8%D0%B9%20%D1%84%D0%BE%D1%82%D0%BE%D0%B0%D0%BF%D0%BF%D0%B0%D1%80%D0%B0%D1%82.)
^ru-Q0291-answer

**ru-Q0292** — Я купила хороший фотоаппарат.

I bought a good camera.

Why: Adjective agreement. [[Russian#^ru-Q0292|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BA%D1%83%D0%BF%D0%B8%D0%BB%D0%B0%20%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B8%D0%B9%20%D1%84%D0%BE%D1%82%D0%BE%D0%B0%D0%BF%D0%BF%D0%B0%D1%80%D0%B0%D1%82.)
^ru-Q0292-answer

**ru-Q0293** — В нашем саду есть маленький пруд.

There is a small pond in our garden.

Why: Adjective agreement. [[Russian#^ru-Q0293|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%20%D0%BD%D0%B0%D1%88%D0%B5%D0%BC%20%D1%81%D0%B0%D0%B4%D1%83%20%D0%B5%D1%81%D1%82%D1%8C%20%D0%BC%D0%B0%D0%BB%D0%B5%D0%BD%D1%8C%D0%BA%D0%B8%D0%B9%20%D0%BF%D1%80%D1%83%D0%B4.)
^ru-Q0293-answer

**ru-Q0294** — В нашем саду есть маленький пруд.

There is a small pond in our garden.

Adjectives agree with the noun in gender, number and case. Short and long adjective forms have distinct distributions and meanings. Learn a full phrase, not an isolated ending.

Why: Adjective agreement. [[Russian#^ru-Q0294|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%20%D0%BD%D0%B0%D1%88%D0%B5%D0%BC%20%D1%81%D0%B0%D0%B4%D1%83%20%D0%B5%D1%81%D1%82%D1%8C%20%D0%BC%D0%B0%D0%BB%D0%B5%D0%BD%D1%8C%D0%BA%D0%B8%D0%B9%20%D0%BF%D1%80%D1%83%D0%B4.)
^ru-Q0294-answer

**ru-Q0295** — Она улыбнулась и приняла мой маленький подарок.

She smiled and accepted my little present.

Expected form: **маленький**

Why: Adjective agreement. [[Russian#^ru-Q0295|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D1%83%D0%BB%D1%8B%D0%B1%D0%BD%D1%83%D0%BB%D0%B0%D1%81%D1%8C%20%D0%B8%20%D0%BF%D1%80%D0%B8%D0%BD%D1%8F%D0%BB%D0%B0%20%D0%BC%D0%BE%D0%B9%20%D0%BC%D0%B0%D0%BB%D0%B5%D0%BD%D1%8C%D0%BA%D0%B8%D0%B9%20%D0%BF%D0%BE%D0%B4%D0%B0%D1%80%D0%BE%D0%BA.)
^ru-Q0295-answer

**ru-Q0296** — Она улыбнулась и приняла мой маленький подарок.

She smiled and accepted my little present.

Expected form: **маленький**

Why: Adjective agreement. [[Russian#^ru-Q0296|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D1%83%D0%BB%D1%8B%D0%B1%D0%BD%D1%83%D0%BB%D0%B0%D1%81%D1%8C%20%D0%B8%20%D0%BF%D1%80%D0%B8%D0%BD%D1%8F%D0%BB%D0%B0%20%D0%BC%D0%BE%D0%B9%20%D0%BC%D0%B0%D0%BB%D0%B5%D0%BD%D1%8C%D0%BA%D0%B8%D0%B9%20%D0%BF%D0%BE%D0%B4%D0%B0%D1%80%D0%BE%D0%BA.)
^ru-Q0296-answer

**ru-Q0297** — Думаю, это хорошая идея.

I think it's a good idea.

Expected form: **хорошая**

Why: Adjective agreement. [[Russian#^ru-Q0297|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D1%83%D0%BC%D0%B0%D1%8E%2C%20%D1%8D%D1%82%D0%BE%20%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B0%D1%8F%20%D0%B8%D0%B4%D0%B5%D1%8F.)
^ru-Q0297-answer

**ru-Q0298** — Думаю, это хорошая идея.

I think it's a good idea.

Why: Adjective agreement. [[Russian#^ru-Q0298|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D1%83%D0%BC%D0%B0%D1%8E%2C%20%D1%8D%D1%82%D0%BE%20%D1%85%D0%BE%D1%80%D0%BE%D1%88%D0%B0%D1%8F%20%D0%B8%D0%B4%D0%B5%D1%8F.)
^ru-Q0298-answer

**ru-Q0299** — У Тома новый номер.

Tom has a new number.

Why: Adjective agreement. [[Russian#^ru-Q0299|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%20%D0%A2%D0%BE%D0%BC%D0%B0%20%D0%BD%D0%BE%D0%B2%D1%8B%D0%B9%20%D0%BD%D0%BE%D0%BC%D0%B5%D1%80.)
^ru-Q0299-answer

**ru-Q0300** — У Тома новый номер.

Tom has a new number.

Adjectives agree with the noun in gender, number and case. Short and long adjective forms have distinct distributions and meanings. Learn a full phrase, not an isolated ending.

Why: Adjective agreement. [[Russian#^ru-Q0300|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%20%D0%A2%D0%BE%D0%BC%D0%B0%20%D0%BD%D0%BE%D0%B2%D1%8B%D0%B9%20%D0%BD%D0%BE%D0%BC%D0%B5%D1%80.)
^ru-Q0300-answer


### Answers 301–350

**ru-Q0301** — Том был напуган до смерти.

Tom was scared to death.

Expected form: **был**

Why: Past forms of быть. [[Russian#^ru-Q0301|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B1%D1%8B%D0%BB%20%D0%BD%D0%B0%D0%BF%D1%83%D0%B3%D0%B0%D0%BD%20%D0%B4%D0%BE%20%D1%81%D0%BC%D0%B5%D1%80%D1%82%D0%B8.)
^ru-Q0301-answer

**ru-Q0302** — Том был напуган до смерти.

Tom was scared to death.

Expected form: **был**

Why: Past forms of быть. [[Russian#^ru-Q0302|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B1%D1%8B%D0%BB%20%D0%BD%D0%B0%D0%BF%D1%83%D0%B3%D0%B0%D0%BD%20%D0%B4%D0%BE%20%D1%81%D0%BC%D0%B5%D1%80%D1%82%D0%B8.)
^ru-Q0302-answer

**ru-Q0303** — Том тоже был сильно голоден.

Tom also was very hungry.

Expected form: **был**

Why: Past forms of быть. [[Russian#^ru-Q0303|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%82%D0%BE%D0%B6%D0%B5%20%D0%B1%D1%8B%D0%BB%20%D1%81%D0%B8%D0%BB%D1%8C%D0%BD%D0%BE%20%D0%B3%D0%BE%D0%BB%D0%BE%D0%B4%D0%B5%D0%BD.)
^ru-Q0303-answer

**ru-Q0304** — Том тоже был сильно голоден.

Tom also was very hungry.

Why: Past forms of быть. [[Russian#^ru-Q0304|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%82%D0%BE%D0%B6%D0%B5%20%D0%B1%D1%8B%D0%BB%20%D1%81%D0%B8%D0%BB%D1%8C%D0%BD%D0%BE%20%D0%B3%D0%BE%D0%BB%D0%BE%D0%B4%D0%B5%D0%BD.)
^ru-Q0304-answer

**ru-Q0305** — Думаю, ты была права.

I think you were right.

Why: Past forms of быть. [[Russian#^ru-Q0305|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D1%83%D0%BC%D0%B0%D1%8E%2C%20%D1%82%D1%8B%20%D0%B1%D1%8B%D0%BB%D0%B0%20%D0%BF%D1%80%D0%B0%D0%B2%D0%B0.)
^ru-Q0305-answer

**ru-Q0306** — Думаю, ты была права.

I think you were right.

Russian past tense generally agrees in gender and number rather than person. Был/была/было/были are forms of be and can establish a past state or accompany another construction.

Why: Past forms of быть. [[Russian#^ru-Q0306|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D1%83%D0%BC%D0%B0%D1%8E%2C%20%D1%82%D1%8B%20%D0%B1%D1%8B%D0%BB%D0%B0%20%D0%BF%D1%80%D0%B0%D0%B2%D0%B0.)
^ru-Q0306-answer

**ru-Q0307** — Это была ложная тревога.

It was a false alarm.

Expected form: **была**

Why: Past forms of быть. [[Russian#^ru-Q0307|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D1%82%D0%BE%20%D0%B1%D1%8B%D0%BB%D0%B0%20%D0%BB%D0%BE%D0%B6%D0%BD%D0%B0%D1%8F%20%D1%82%D1%80%D0%B5%D0%B2%D0%BE%D0%B3%D0%B0.)
^ru-Q0307-answer

**ru-Q0308** — Это была ложная тревога.

It was a false alarm.

Expected form: **была**

Why: Past forms of быть. [[Russian#^ru-Q0308|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D1%82%D0%BE%20%D0%B1%D1%8B%D0%BB%D0%B0%20%D0%BB%D0%BE%D0%B6%D0%BD%D0%B0%D1%8F%20%D1%82%D1%80%D0%B5%D0%B2%D0%BE%D0%B3%D0%B0.)
^ru-Q0308-answer

**ru-Q0309** — Мария была разочарована.

Mary was disappointed.

Expected form: **была**

Why: Past forms of быть. [[Russian#^ru-Q0309|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%B0%D1%80%D0%B8%D1%8F%20%D0%B1%D1%8B%D0%BB%D0%B0%20%D1%80%D0%B0%D0%B7%D0%BE%D1%87%D0%B0%D1%80%D0%BE%D0%B2%D0%B0%D0%BD%D0%B0.)
^ru-Q0309-answer

**ru-Q0310** — Мария была разочарована.

Mary was disappointed.

Why: Past forms of быть. [[Russian#^ru-Q0310|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%B0%D1%80%D0%B8%D1%8F%20%D0%B1%D1%8B%D0%BB%D0%B0%20%D1%80%D0%B0%D0%B7%D0%BE%D1%87%D0%B0%D1%80%D0%BE%D0%B2%D0%B0%D0%BD%D0%B0.)
^ru-Q0310-answer

**ru-Q0311** — Он был дважды женат, и у него было более двадцати детей.

He married twice and had more than 20 children.

Why: Past forms of быть. [[Russian#^ru-Q0311|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D0%B1%D1%8B%D0%BB%20%D0%B4%D0%B2%D0%B0%D0%B6%D0%B4%D1%8B%20%D0%B6%D0%B5%D0%BD%D0%B0%D1%82%2C%20%D0%B8%20%D1%83%20%D0%BD%D0%B5%D0%B3%D0%BE%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D0%B1%D0%BE%D0%BB%D0%B5%D0%B5%20%D0%B4%D0%B2%D0%B0%D0%B4%D1%86%D0%B0%D1%82%D0%B8%20%D0%B4%D0%B5%D1%82%D0%B5%D0%B9.)
^ru-Q0311-answer

**ru-Q0312** — Он был дважды женат, и у него было более двадцати детей.

He married twice and had more than 20 children.

Russian past tense generally agrees in gender and number rather than person. Был/была/было/были are forms of be and can establish a past state or accompany another construction.

Why: Past forms of быть. [[Russian#^ru-Q0312|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D0%B1%D1%8B%D0%BB%20%D0%B4%D0%B2%D0%B0%D0%B6%D0%B4%D1%8B%20%D0%B6%D0%B5%D0%BD%D0%B0%D1%82%2C%20%D0%B8%20%D1%83%20%D0%BD%D0%B5%D0%B3%D0%BE%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D0%B1%D0%BE%D0%BB%D0%B5%D0%B5%20%D0%B4%D0%B2%D0%B0%D0%B4%D1%86%D0%B0%D1%82%D0%B8%20%D0%B4%D0%B5%D1%82%D0%B5%D0%B9.)
^ru-Q0312-answer

**ru-Q0313** — У нас в последнее время было много дождей.

We've had a lot of rain recently.

Expected form: **было**

Why: Past forms of быть. [[Russian#^ru-Q0313|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%20%D0%BD%D0%B0%D1%81%20%D0%B2%20%D0%BF%D0%BE%D1%81%D0%BB%D0%B5%D0%B4%D0%BD%D0%B5%D0%B5%20%D0%B2%D1%80%D0%B5%D0%BC%D1%8F%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D0%BC%D0%BD%D0%BE%D0%B3%D0%BE%20%D0%B4%D0%BE%D0%B6%D0%B4%D0%B5%D0%B9.)
^ru-Q0313-answer

**ru-Q0314** — У нас в последнее время было много дождей.

We've had a lot of rain recently.

Expected form: **было**

Why: Past forms of быть. [[Russian#^ru-Q0314|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%20%D0%BD%D0%B0%D1%81%20%D0%B2%20%D0%BF%D0%BE%D1%81%D0%BB%D0%B5%D0%B4%D0%BD%D0%B5%D0%B5%20%D0%B2%D1%80%D0%B5%D0%BC%D1%8F%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D0%BC%D0%BD%D0%BE%D0%B3%D0%BE%20%D0%B4%D0%BE%D0%B6%D0%B4%D0%B5%D0%B9.)
^ru-Q0314-answer

**ru-Q0315** — Я был в ужасе.

I was horrified.

Expected form: **был**

Why: Past forms of быть. [[Russian#^ru-Q0315|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%8B%D0%BB%20%D0%B2%20%D1%83%D0%B6%D0%B0%D1%81%D0%B5.)
^ru-Q0315-answer

**ru-Q0316** — Я был в ужасе.

I was horrified.

Why: Past forms of быть. [[Russian#^ru-Q0316|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%8B%D0%BB%20%D0%B2%20%D1%83%D0%B6%D0%B0%D1%81%D0%B5.)
^ru-Q0316-answer

**ru-Q0317** — Одна студентка была арестована.

One student was arrested.

Why: Past forms of быть. [[Russian#^ru-Q0317|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%B4%D0%BD%D0%B0%20%D1%81%D1%82%D1%83%D0%B4%D0%B5%D0%BD%D1%82%D0%BA%D0%B0%20%D0%B1%D1%8B%D0%BB%D0%B0%20%D0%B0%D1%80%D0%B5%D1%81%D1%82%D0%BE%D0%B2%D0%B0%D0%BD%D0%B0.)
^ru-Q0317-answer

**ru-Q0318** — Одна студентка была арестована.

One student was arrested.

Russian past tense generally agrees in gender and number rather than person. Был/была/было/были are forms of be and can establish a past state or accompany another construction.

Why: Past forms of быть. [[Russian#^ru-Q0318|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%B4%D0%BD%D0%B0%20%D1%81%D1%82%D1%83%D0%B4%D0%B5%D0%BD%D1%82%D0%BA%D0%B0%20%D0%B1%D1%8B%D0%BB%D0%B0%20%D0%B0%D1%80%D0%B5%D1%81%D1%82%D0%BE%D0%B2%D0%B0%D0%BD%D0%B0.)
^ru-Q0318-answer

**ru-Q0319** — Её не было в школе, потому что она болела.

She was absent from school because she was sick.

Expected form: **было**

Why: Past forms of быть. [[Russian#^ru-Q0319|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%91%20%D0%BD%D0%B5%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D0%B2%20%D1%88%D0%BA%D0%BE%D0%BB%D0%B5%2C%20%D0%BF%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE%20%D0%BE%D0%BD%D0%B0%20%D0%B1%D0%BE%D0%BB%D0%B5%D0%BB%D0%B0.)
^ru-Q0319-answer

**ru-Q0320** — Её не было в школе, потому что она болела.

She was absent from school because she was sick.

Expected form: **было**

Why: Past forms of быть. [[Russian#^ru-Q0320|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%91%20%D0%BD%D0%B5%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D0%B2%20%D1%88%D0%BA%D0%BE%D0%BB%D0%B5%2C%20%D0%BF%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE%20%D0%BE%D0%BD%D0%B0%20%D0%B1%D0%BE%D0%BB%D0%B5%D0%BB%D0%B0.)
^ru-Q0320-answer

**ru-Q0321** — Они были солдатами.

They were soldiers.

Expected form: **были**

Why: Past forms of быть. [[Russian#^ru-Q0321|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B8%20%D0%B1%D1%8B%D0%BB%D0%B8%20%D1%81%D0%BE%D0%BB%D0%B4%D0%B0%D1%82%D0%B0%D0%BC%D0%B8.)
^ru-Q0321-answer

**ru-Q0322** — Они были солдатами.

They were soldiers.

Why: Past forms of быть. [[Russian#^ru-Q0322|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B8%20%D0%B1%D1%8B%D0%BB%D0%B8%20%D1%81%D0%BE%D0%BB%D0%B4%D0%B0%D1%82%D0%B0%D0%BC%D0%B8.)
^ru-Q0322-answer

**ru-Q0323** — Нам не надо было вас отпускать.

We shouldn't have let you go.

Why: Past forms of быть. [[Russian#^ru-Q0323|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%D0%BC%20%D0%BD%D0%B5%20%D0%BD%D0%B0%D0%B4%D0%BE%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D0%B2%D0%B0%D1%81%20%D0%BE%D1%82%D0%BF%D1%83%D1%81%D0%BA%D0%B0%D1%82%D1%8C.)
^ru-Q0323-answer

**ru-Q0324** — Нам не надо было вас отпускать.

We shouldn't have let you go.

Russian past tense generally agrees in gender and number rather than person. Был/была/было/были are forms of be and can establish a past state or accompany another construction.

Why: Past forms of быть. [[Russian#^ru-Q0324|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%D0%BC%20%D0%BD%D0%B5%20%D0%BD%D0%B0%D0%B4%D0%BE%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D0%B2%D0%B0%D1%81%20%D0%BE%D1%82%D0%BF%D1%83%D1%81%D0%BA%D0%B0%D1%82%D1%8C.)
^ru-Q0324-answer

**ru-Q0325** — У него ничего не было.

He had nothing.

Expected form: **было**

Why: Past forms of быть. [[Russian#^ru-Q0325|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%20%D0%BD%D0%B5%D0%B3%D0%BE%20%D0%BD%D0%B8%D1%87%D0%B5%D0%B3%D0%BE%20%D0%BD%D0%B5%20%D0%B1%D1%8B%D0%BB%D0%BE.)
^ru-Q0325-answer

**ru-Q0326** — У него ничего не было.

He had nothing.

Expected form: **было**

Why: Past forms of быть. [[Russian#^ru-Q0326|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%20%D0%BD%D0%B5%D0%B3%D0%BE%20%D0%BD%D0%B8%D1%87%D0%B5%D0%B3%D0%BE%20%D0%BD%D0%B5%20%D0%B1%D1%8B%D0%BB%D0%BE.)
^ru-Q0326-answer

**ru-Q0327** — Их глубокая любовь к друг другу была однозначна.

Their deep love for each other was unequivocal.

Expected form: **была**

Why: Past forms of быть. [[Russian#^ru-Q0327|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%98%D1%85%20%D0%B3%D0%BB%D1%83%D0%B1%D0%BE%D0%BA%D0%B0%D1%8F%20%D0%BB%D1%8E%D0%B1%D0%BE%D0%B2%D1%8C%20%D0%BA%20%D0%B4%D1%80%D1%83%D0%B3%20%D0%B4%D1%80%D1%83%D0%B3%D1%83%20%D0%B1%D1%8B%D0%BB%D0%B0%20%D0%BE%D0%B4%D0%BD%D0%BE%D0%B7%D0%BD%D0%B0%D1%87%D0%BD%D0%B0.)
^ru-Q0327-answer

**ru-Q0328** — Их глубокая любовь к друг другу была однозначна.

Their deep love for each other was unequivocal.

Why: Past forms of быть. [[Russian#^ru-Q0328|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%98%D1%85%20%D0%B3%D0%BB%D1%83%D0%B1%D0%BE%D0%BA%D0%B0%D1%8F%20%D0%BB%D1%8E%D0%B1%D0%BE%D0%B2%D1%8C%20%D0%BA%20%D0%B4%D1%80%D1%83%D0%B3%20%D0%B4%D1%80%D1%83%D0%B3%D1%83%20%D0%B1%D1%8B%D0%BB%D0%B0%20%D0%BE%D0%B4%D0%BD%D0%BE%D0%B7%D0%BD%D0%B0%D1%87%D0%BD%D0%B0.)
^ru-Q0328-answer

**ru-Q0329** — Вы помните, какой медленный был Интернет?

Do you remember how slow the Internet was?

Why: Past forms of быть. [[Russian#^ru-Q0329|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D0%BF%D0%BE%D0%BC%D0%BD%D0%B8%D1%82%D0%B5%2C%20%D0%BA%D0%B0%D0%BA%D0%BE%D0%B9%20%D0%BC%D0%B5%D0%B4%D0%BB%D0%B5%D0%BD%D0%BD%D1%8B%D0%B9%20%D0%B1%D1%8B%D0%BB%20%D0%98%D0%BD%D1%82%D0%B5%D1%80%D0%BD%D0%B5%D1%82%3F)
^ru-Q0329-answer

**ru-Q0330** — Вы помните, какой медленный был Интернет?

Do you remember how slow the Internet was?

Russian past tense generally agrees in gender and number rather than person. Был/была/было/были are forms of be and can establish a past state or accompany another construction.

Why: Past forms of быть. [[Russian#^ru-Q0330|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D0%BF%D0%BE%D0%BC%D0%BD%D0%B8%D1%82%D0%B5%2C%20%D0%BA%D0%B0%D0%BA%D0%BE%D0%B9%20%D0%BC%D0%B5%D0%B4%D0%BB%D0%B5%D0%BD%D0%BD%D1%8B%D0%B9%20%D0%B1%D1%8B%D0%BB%20%D0%98%D0%BD%D1%82%D0%B5%D1%80%D0%BD%D0%B5%D1%82%3F)
^ru-Q0330-answer

**ru-Q0331** — Мне было очень интересно.

I was very interested.

Expected form: **было**

Why: Past forms of быть. [[Russian#^ru-Q0331|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BD%D0%B5%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D0%BE%D1%87%D0%B5%D0%BD%D1%8C%20%D0%B8%D0%BD%D1%82%D0%B5%D1%80%D0%B5%D1%81%D0%BD%D0%BE.)
^ru-Q0331-answer

**ru-Q0332** — Мне было очень интересно.

I was very interested.

Expected form: **было**

Why: Past forms of быть. [[Russian#^ru-Q0332|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BD%D0%B5%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D0%BE%D1%87%D0%B5%D0%BD%D1%8C%20%D0%B8%D0%BD%D1%82%D0%B5%D1%80%D0%B5%D1%81%D0%BD%D0%BE.)
^ru-Q0332-answer

**ru-Q0333** — Том был успешным предпринимателем.

Tom was a successful businessman.

Expected form: **был**

Why: Past forms of быть. [[Russian#^ru-Q0333|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B1%D1%8B%D0%BB%20%D1%83%D1%81%D0%BF%D0%B5%D1%88%D0%BD%D1%8B%D0%BC%20%D0%BF%D1%80%D0%B5%D0%B4%D0%BF%D1%80%D0%B8%D0%BD%D0%B8%D0%BC%D0%B0%D1%82%D0%B5%D0%BB%D0%B5%D0%BC.)
^ru-Q0333-answer

**ru-Q0334** — Том был успешным предпринимателем.

Tom was a successful businessman.

Why: Past forms of быть. [[Russian#^ru-Q0334|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B1%D1%8B%D0%BB%20%D1%83%D1%81%D0%BF%D0%B5%D1%88%D0%BD%D1%8B%D0%BC%20%D0%BF%D1%80%D0%B5%D0%B4%D0%BF%D1%80%D0%B8%D0%BD%D0%B8%D0%BC%D0%B0%D1%82%D0%B5%D0%BB%D0%B5%D0%BC.)
^ru-Q0334-answer

**ru-Q0335** — Посол был отозван из Варшавы.

The ambassador was recalled from Warsaw.

Why: Past forms of быть. [[Russian#^ru-Q0335|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%81%D0%BE%D0%BB%20%D0%B1%D1%8B%D0%BB%20%D0%BE%D1%82%D0%BE%D0%B7%D0%B2%D0%B0%D0%BD%20%D0%B8%D0%B7%20%D0%92%D0%B0%D1%80%D1%88%D0%B0%D0%B2%D1%8B.)
^ru-Q0335-answer

**ru-Q0336** — Посол был отозван из Варшавы.

The ambassador was recalled from Warsaw.

Russian past tense generally agrees in gender and number rather than person. Был/была/было/были are forms of be and can establish a past state or accompany another construction.

Why: Past forms of быть. [[Russian#^ru-Q0336|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%81%D0%BE%D0%BB%20%D0%B1%D1%8B%D0%BB%20%D0%BE%D1%82%D0%BE%D0%B7%D0%B2%D0%B0%D0%BD%20%D0%B8%D0%B7%20%D0%92%D0%B0%D1%80%D1%88%D0%B0%D0%B2%D1%8B.)
^ru-Q0336-answer

**ru-Q0337** — Тебе надо было попросить у Тома прощения.

You should've apologized to Tom.

Expected form: **было**

Why: Past forms of быть. [[Russian#^ru-Q0337|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%B5%D0%B1%D0%B5%20%D0%BD%D0%B0%D0%B4%D0%BE%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D0%BF%D0%BE%D0%BF%D1%80%D0%BE%D1%81%D0%B8%D1%82%D1%8C%20%D1%83%20%D0%A2%D0%BE%D0%BC%D0%B0%20%D0%BF%D1%80%D0%BE%D1%89%D0%B5%D0%BD%D0%B8%D1%8F.)
^ru-Q0337-answer

**ru-Q0338** — Тебе надо было попросить у Тома прощения.

You should've apologized to Tom.

Expected form: **было**

Why: Past forms of быть. [[Russian#^ru-Q0338|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%B5%D0%B1%D0%B5%20%D0%BD%D0%B0%D0%B4%D0%BE%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D0%BF%D0%BE%D0%BF%D1%80%D0%BE%D1%81%D0%B8%D1%82%D1%8C%20%D1%83%20%D0%A2%D0%BE%D0%BC%D0%B0%20%D0%BF%D1%80%D0%BE%D1%89%D0%B5%D0%BD%D0%B8%D1%8F.)
^ru-Q0338-answer

**ru-Q0339** — Она была очаровательной женщиной.

She was a charming woman.

Expected form: **была**

Why: Past forms of быть. [[Russian#^ru-Q0339|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D0%B1%D1%8B%D0%BB%D0%B0%20%D0%BE%D1%87%D0%B0%D1%80%D0%BE%D0%B2%D0%B0%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE%D0%B9%20%D0%B6%D0%B5%D0%BD%D1%89%D0%B8%D0%BD%D0%BE%D0%B9.)
^ru-Q0339-answer

**ru-Q0340** — Она была очаровательной женщиной.

She was a charming woman.

Why: Past forms of быть. [[Russian#^ru-Q0340|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D0%B1%D1%8B%D0%BB%D0%B0%20%D0%BE%D1%87%D0%B0%D1%80%D0%BE%D0%B2%D0%B0%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE%D0%B9%20%D0%B6%D0%B5%D0%BD%D1%89%D0%B8%D0%BD%D0%BE%D0%B9.)
^ru-Q0340-answer

**ru-Q0341** — На прошлой неделе ты был занят.

You were busy last week.

Why: Past forms of быть. [[Russian#^ru-Q0341|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%20%D0%BF%D1%80%D0%BE%D1%88%D0%BB%D0%BE%D0%B9%20%D0%BD%D0%B5%D0%B4%D0%B5%D0%BB%D0%B5%20%D1%82%D1%8B%20%D0%B1%D1%8B%D0%BB%20%D0%B7%D0%B0%D0%BD%D1%8F%D1%82.)
^ru-Q0341-answer

**ru-Q0342** — На прошлой неделе ты был занят.

You were busy last week.

Russian past tense generally agrees in gender and number rather than person. Был/была/было/были are forms of be and can establish a past state or accompany another construction.

Why: Past forms of быть. [[Russian#^ru-Q0342|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%20%D0%BF%D1%80%D0%BE%D1%88%D0%BB%D0%BE%D0%B9%20%D0%BD%D0%B5%D0%B4%D0%B5%D0%BB%D0%B5%20%D1%82%D1%8B%20%D0%B1%D1%8B%D0%BB%20%D0%B7%D0%B0%D0%BD%D1%8F%D1%82.)
^ru-Q0342-answer

**ru-Q0343** — Он был с ним знаком?

Did he know him?

Expected form: **был**

Why: Past forms of быть. [[Russian#^ru-Q0343|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D0%B1%D1%8B%D0%BB%20%D1%81%20%D0%BD%D0%B8%D0%BC%20%D0%B7%D0%BD%D0%B0%D0%BA%D0%BE%D0%BC%3F)
^ru-Q0343-answer

**ru-Q0344** — Он был с ним знаком?

Did he know him?

Expected form: **был**

Why: Past forms of быть. [[Russian#^ru-Q0344|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D0%B1%D1%8B%D0%BB%20%D1%81%20%D0%BD%D0%B8%D0%BC%20%D0%B7%D0%BD%D0%B0%D0%BA%D0%BE%D0%BC%3F)
^ru-Q0344-answer

**ru-Q0345** — Я ни в одном из тех ресторанов не был.

I haven't been to either of those restaurants.

Expected form: **был**

Why: Past forms of быть. [[Russian#^ru-Q0345|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B8%20%D0%B2%20%D0%BE%D0%B4%D0%BD%D0%BE%D0%BC%20%D0%B8%D0%B7%20%D1%82%D0%B5%D1%85%20%D1%80%D0%B5%D1%81%D1%82%D0%BE%D1%80%D0%B0%D0%BD%D0%BE%D0%B2%20%D0%BD%D0%B5%20%D0%B1%D1%8B%D0%BB.)
^ru-Q0345-answer

**ru-Q0346** — Я ни в одном из тех ресторанов не был.

I haven't been to either of those restaurants.

Why: Past forms of быть. [[Russian#^ru-Q0346|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B8%20%D0%B2%20%D0%BE%D0%B4%D0%BD%D0%BE%D0%BC%20%D0%B8%D0%B7%20%D1%82%D0%B5%D1%85%20%D1%80%D0%B5%D1%81%D1%82%D0%BE%D1%80%D0%B0%D0%BD%D0%BE%D0%B2%20%D0%BD%D0%B5%20%D0%B1%D1%8B%D0%BB.)
^ru-Q0346-answer

**ru-Q0347** — Том был моим помощником.

Tom was my assistant.

Why: Past forms of быть. [[Russian#^ru-Q0347|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B1%D1%8B%D0%BB%20%D0%BC%D0%BE%D0%B8%D0%BC%20%D0%BF%D0%BE%D0%BC%D0%BE%D1%89%D0%BD%D0%B8%D0%BA%D0%BE%D0%BC.)
^ru-Q0347-answer

**ru-Q0348** — Том был моим помощником.

Tom was my assistant.

Russian past tense generally agrees in gender and number rather than person. Был/была/было/были are forms of be and can establish a past state or accompany another construction.

Why: Past forms of быть. [[Russian#^ru-Q0348|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B1%D1%8B%D0%BB%20%D0%BC%D0%BE%D0%B8%D0%BC%20%D0%BF%D0%BE%D0%BC%D0%BE%D1%89%D0%BD%D0%B8%D0%BA%D0%BE%D0%BC.)
^ru-Q0348-answer

**ru-Q0349** — Том был бездомным.

Tom was homeless.

Expected form: **был**

Why: Past forms of быть. [[Russian#^ru-Q0349|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B1%D1%8B%D0%BB%20%D0%B1%D0%B5%D0%B7%D0%B4%D0%BE%D0%BC%D0%BD%D1%8B%D0%BC.)
^ru-Q0349-answer

**ru-Q0350** — Том был бездомным.

Tom was homeless.

Expected form: **был**

Why: Past forms of быть. [[Russian#^ru-Q0350|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B1%D1%8B%D0%BB%20%D0%B1%D0%B5%D0%B7%D0%B4%D0%BE%D0%BC%D0%BD%D1%8B%D0%BC.)
^ru-Q0350-answer


### Answers 351–400

**ru-Q0351** — Думаю, когда-нибудь это произойдёт.

I think that'll happen someday.

Expected form: **Думаю**

Why: Common present verbs. [[Russian#^ru-Q0351|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D1%83%D0%BC%D0%B0%D1%8E%2C%20%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0-%D0%BD%D0%B8%D0%B1%D1%83%D0%B4%D1%8C%20%D1%8D%D1%82%D0%BE%20%D0%BF%D1%80%D0%BE%D0%B8%D0%B7%D0%BE%D0%B9%D0%B4%D1%91%D1%82.)
^ru-Q0351-answer

**ru-Q0352** — Думаю, когда-нибудь это произойдёт.

I think that'll happen someday.

Why: Common present verbs. [[Russian#^ru-Q0352|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D1%83%D0%BC%D0%B0%D1%8E%2C%20%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0-%D0%BD%D0%B8%D0%B1%D1%83%D0%B4%D1%8C%20%D1%8D%D1%82%D0%BE%20%D0%BF%D1%80%D0%BE%D0%B8%D0%B7%D0%BE%D0%B9%D0%B4%D1%91%D1%82.)
^ru-Q0352-answer

**ru-Q0353** — Том мало что знает.

Tom doesn't know much.

Why: Common present verbs. [[Russian#^ru-Q0353|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BC%D0%B0%D0%BB%D0%BE%20%D1%87%D1%82%D0%BE%20%D0%B7%D0%BD%D0%B0%D0%B5%D1%82.)
^ru-Q0353-answer

**ru-Q0354** — Том мало что знает.

Tom doesn't know much.

Present forms agree with person and number. Ordinary present-time activity uses an imperfective verb. Perfective forms with similar endings normally refer to future events.

Why: Common present verbs. [[Russian#^ru-Q0354|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BC%D0%B0%D0%BB%D0%BE%20%D1%87%D1%82%D0%BE%20%D0%B7%D0%BD%D0%B0%D0%B5%D1%82.)
^ru-Q0354-answer

**ru-Q0355** — Том никогда не думает о других.

Tom never thinks about others.

Expected form: **думает**

Why: Common present verbs. [[Russian#^ru-Q0355|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B8%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%BD%D0%B5%20%D0%B4%D1%83%D0%BC%D0%B0%D0%B5%D1%82%20%D0%BE%20%D0%B4%D1%80%D1%83%D0%B3%D0%B8%D1%85.)
^ru-Q0355-answer

**ru-Q0356** — Том никогда не думает о других.

Tom never thinks about others.

Expected form: **думает**

Why: Common present verbs. [[Russian#^ru-Q0356|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B8%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%BD%D0%B5%20%D0%B4%D1%83%D0%BC%D0%B0%D0%B5%D1%82%20%D0%BE%20%D0%B4%D1%80%D1%83%D0%B3%D0%B8%D1%85.)
^ru-Q0356-answer

**ru-Q0357** — Я думаю, что пора идти.

I suppose it's time to go.

Expected form: **думаю**

Why: Common present verbs. [[Russian#^ru-Q0357|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B4%D1%83%D0%BC%D0%B0%D1%8E%2C%20%D1%87%D1%82%D0%BE%20%D0%BF%D0%BE%D1%80%D0%B0%20%D0%B8%D0%B4%D1%82%D0%B8.)
^ru-Q0357-answer

**ru-Q0358** — Я думаю, что пора идти.

I suppose it's time to go.

Why: Common present verbs. [[Russian#^ru-Q0358|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B4%D1%83%D0%BC%D0%B0%D1%8E%2C%20%D1%87%D1%82%D0%BE%20%D0%BF%D0%BE%D1%80%D0%B0%20%D0%B8%D0%B4%D1%82%D0%B8.)
^ru-Q0358-answer

**ru-Q0359** — Думаю, тебе понадобится кредит.

I think you'll need a loan.

Why: Common present verbs. [[Russian#^ru-Q0359|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D1%83%D0%BC%D0%B0%D1%8E%2C%20%D1%82%D0%B5%D0%B1%D0%B5%20%D0%BF%D0%BE%D0%BD%D0%B0%D0%B4%D0%BE%D0%B1%D0%B8%D1%82%D1%81%D1%8F%20%D0%BA%D1%80%D0%B5%D0%B4%D0%B8%D1%82.)
^ru-Q0359-answer

**ru-Q0360** — Думаю, тебе понадобится кредит.

I think you'll need a loan.

Present forms agree with person and number. Ordinary present-time activity uses an imperfective verb. Perfective forms with similar endings normally refer to future events.

Why: Common present verbs. [[Russian#^ru-Q0360|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D1%83%D0%BC%D0%B0%D1%8E%2C%20%D1%82%D0%B5%D0%B1%D0%B5%20%D0%BF%D0%BE%D0%BD%D0%B0%D0%B4%D0%BE%D0%B1%D0%B8%D1%82%D1%81%D1%8F%20%D0%BA%D1%80%D0%B5%D0%B4%D0%B8%D1%82.)
^ru-Q0360-answer

**ru-Q0361** — Всё, что он говорит, — правда.

All that he says is true.

Expected form: **говорит**

Why: Common present verbs. [[Russian#^ru-Q0361|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%81%D1%91%2C%20%D1%87%D1%82%D0%BE%20%D0%BE%D0%BD%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%2C%20%E2%80%94%20%D0%BF%D1%80%D0%B0%D0%B2%D0%B4%D0%B0.)
^ru-Q0361-answer

**ru-Q0362** — Всё, что он говорит, — правда.

All that he says is true.

Expected form: **говорит**

Why: Common present verbs. [[Russian#^ru-Q0362|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%81%D1%91%2C%20%D1%87%D1%82%D0%BE%20%D0%BE%D0%BD%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%2C%20%E2%80%94%20%D0%BF%D1%80%D0%B0%D0%B2%D0%B4%D0%B0.)
^ru-Q0362-answer

**ru-Q0363** — Она говорит, что здорова.

She says that she's healthy.

Expected form: **говорит**

Why: Common present verbs. [[Russian#^ru-Q0363|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%2C%20%D1%87%D1%82%D0%BE%20%D0%B7%D0%B4%D0%BE%D1%80%D0%BE%D0%B2%D0%B0.)
^ru-Q0363-answer

**ru-Q0364** — Она говорит, что здорова.

She says that she's healthy.

Why: Common present verbs. [[Russian#^ru-Q0364|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%2C%20%D1%87%D1%82%D0%BE%20%D0%B7%D0%B4%D0%BE%D1%80%D0%BE%D0%B2%D0%B0.)
^ru-Q0364-answer

**ru-Q0365** — Не думаю, что это нас касается.

I don't think it affects us.

Why: Common present verbs. [[Russian#^ru-Q0365|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%20%D0%B4%D1%83%D0%BC%D0%B0%D1%8E%2C%20%D1%87%D1%82%D0%BE%20%D1%8D%D1%82%D0%BE%20%D0%BD%D0%B0%D1%81%20%D0%BA%D0%B0%D1%81%D0%B0%D0%B5%D1%82%D1%81%D1%8F.)
^ru-Q0365-answer

**ru-Q0366** — Не думаю, что это нас касается.

I don't think it affects us.

Present forms agree with person and number. Ordinary present-time activity uses an imperfective verb. Perfective forms with similar endings normally refer to future events.

Why: Common present verbs. [[Russian#^ru-Q0366|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%20%D0%B4%D1%83%D0%BC%D0%B0%D1%8E%2C%20%D1%87%D1%82%D0%BE%20%D1%8D%D1%82%D0%BE%20%D0%BD%D0%B0%D1%81%20%D0%BA%D0%B0%D1%81%D0%B0%D0%B5%D1%82%D1%81%D1%8F.)
^ru-Q0366-answer

**ru-Q0367** — Не думаю, что здесь это разрешено.

I don't think that's allowed here.

Expected form: **думаю**

Why: Common present verbs. [[Russian#^ru-Q0367|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%20%D0%B4%D1%83%D0%BC%D0%B0%D1%8E%2C%20%D1%87%D1%82%D0%BE%20%D0%B7%D0%B4%D0%B5%D1%81%D1%8C%20%D1%8D%D1%82%D0%BE%20%D1%80%D0%B0%D0%B7%D1%80%D0%B5%D1%88%D0%B5%D0%BD%D0%BE.)
^ru-Q0367-answer

**ru-Q0368** — Не думаю, что здесь это разрешено.

I don't think that's allowed here.

Expected form: **думаю**

Why: Common present verbs. [[Russian#^ru-Q0368|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%20%D0%B4%D1%83%D0%BC%D0%B0%D1%8E%2C%20%D1%87%D1%82%D0%BE%20%D0%B7%D0%B4%D0%B5%D1%81%D1%8C%20%D1%8D%D1%82%D0%BE%20%D1%80%D0%B0%D0%B7%D1%80%D0%B5%D1%88%D0%B5%D0%BD%D0%BE.)
^ru-Q0368-answer

**ru-Q0369** — Он говорит так, словно знал преступника.

He speaks as if he knew the criminal.

Expected form: **говорит**

Why: Common present verbs. [[Russian#^ru-Q0369|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%20%D1%82%D0%B0%D0%BA%2C%20%D1%81%D0%BB%D0%BE%D0%B2%D0%BD%D0%BE%20%D0%B7%D0%BD%D0%B0%D0%BB%20%D0%BF%D1%80%D0%B5%D1%81%D1%82%D1%83%D0%BF%D0%BD%D0%B8%D0%BA%D0%B0.)
^ru-Q0369-answer

**ru-Q0370** — Он говорит так, словно знал преступника.

He speaks as if he knew the criminal.

Why: Common present verbs. [[Russian#^ru-Q0370|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%20%D1%82%D0%B0%D0%BA%2C%20%D1%81%D0%BB%D0%BE%D0%B2%D0%BD%D0%BE%20%D0%B7%D0%BD%D0%B0%D0%BB%20%D0%BF%D1%80%D0%B5%D1%81%D1%82%D1%83%D0%BF%D0%BD%D0%B8%D0%BA%D0%B0.)
^ru-Q0370-answer

**ru-Q0371** — Ты знаешь, где это?

Do you know where it is?

Why: Common present verbs. [[Russian#^ru-Q0371|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%B7%D0%BD%D0%B0%D0%B5%D1%88%D1%8C%2C%20%D0%B3%D0%B4%D0%B5%20%D1%8D%D1%82%D0%BE%3F)
^ru-Q0371-answer

**ru-Q0372** — Ты знаешь, где это?

Do you know where it is?

Present forms agree with person and number. Ordinary present-time activity uses an imperfective verb. Perfective forms with similar endings normally refer to future events.

Why: Common present verbs. [[Russian#^ru-Q0372|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%B7%D0%BD%D0%B0%D0%B5%D1%88%D1%8C%2C%20%D0%B3%D0%B4%D0%B5%20%D1%8D%D1%82%D0%BE%3F)
^ru-Q0372-answer

**ru-Q0373** — Ты знаешь английский?

Do you know how to speak English?

Expected form: **знаешь**

Why: Common present verbs. [[Russian#^ru-Q0373|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%B7%D0%BD%D0%B0%D0%B5%D1%88%D1%8C%20%D0%B0%D0%BD%D0%B3%D0%BB%D0%B8%D0%B9%D1%81%D0%BA%D0%B8%D0%B9%3F)
^ru-Q0373-answer

**ru-Q0374** — Ты знаешь английский?

Do you know how to speak English?

Expected form: **знаешь**

Why: Common present verbs. [[Russian#^ru-Q0374|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%B7%D0%BD%D0%B0%D0%B5%D1%88%D1%8C%20%D0%B0%D0%BD%D0%B3%D0%BB%D0%B8%D0%B9%D1%81%D0%BA%D0%B8%D0%B9%3F)
^ru-Q0374-answer

**ru-Q0375** — Том об этом знает.

Tom knows about that.

Expected form: **знает**

Why: Common present verbs. [[Russian#^ru-Q0375|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BE%D0%B1%20%D1%8D%D1%82%D0%BE%D0%BC%20%D0%B7%D0%BD%D0%B0%D0%B5%D1%82.)
^ru-Q0375-answer

**ru-Q0376** — Том об этом знает.

Tom knows about that.

Why: Common present verbs. [[Russian#^ru-Q0376|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BE%D0%B1%20%D1%8D%D1%82%D0%BE%D0%BC%20%D0%B7%D0%BD%D0%B0%D0%B5%D1%82.)
^ru-Q0376-answer

**ru-Q0377** — Я знаю, что Том хочет, чтобы мы ему помогли.

I know Tom wants us to help him.

Why: Common present verbs. [[Russian#^ru-Q0377|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B7%D0%BD%D0%B0%D1%8E%2C%20%D1%87%D1%82%D0%BE%20%D0%A2%D0%BE%D0%BC%20%D1%85%D0%BE%D1%87%D0%B5%D1%82%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D0%BC%D1%8B%20%D0%B5%D0%BC%D1%83%20%D0%BF%D0%BE%D0%BC%D0%BE%D0%B3%D0%BB%D0%B8.)
^ru-Q0377-answer

**ru-Q0378** — Я знаю, что Том хочет, чтобы мы ему помогли.

I know Tom wants us to help him.

Present forms agree with person and number. Ordinary present-time activity uses an imperfective verb. Perfective forms with similar endings normally refer to future events.

Why: Common present verbs. [[Russian#^ru-Q0378|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B7%D0%BD%D0%B0%D1%8E%2C%20%D1%87%D1%82%D0%BE%20%D0%A2%D0%BE%D0%BC%20%D1%85%D0%BE%D1%87%D0%B5%D1%82%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D0%BC%D1%8B%20%D0%B5%D0%BC%D1%83%20%D0%BF%D0%BE%D0%BC%D0%BE%D0%B3%D0%BB%D0%B8.)
^ru-Q0378-answer

**ru-Q0379** — Я знаю, что Том сделал это один.

I know that Tom did that alone.

Expected form: **знаю**

Why: Common present verbs. [[Russian#^ru-Q0379|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B7%D0%BD%D0%B0%D1%8E%2C%20%D1%87%D1%82%D0%BE%20%D0%A2%D0%BE%D0%BC%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D0%BB%20%D1%8D%D1%82%D0%BE%20%D0%BE%D0%B4%D0%B8%D0%BD.)
^ru-Q0379-answer

**ru-Q0380** — Я знаю, что Том сделал это один.

I know that Tom did that alone.

Expected form: **знаю**

Why: Common present verbs. [[Russian#^ru-Q0380|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B7%D0%BD%D0%B0%D1%8E%2C%20%D1%87%D1%82%D0%BE%20%D0%A2%D0%BE%D0%BC%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D0%BB%20%D1%8D%D1%82%D0%BE%20%D0%BE%D0%B4%D0%B8%D0%BD.)
^ru-Q0380-answer

**ru-Q0381** — Думаю, я нашёл способ помочь вам.

I think I've found a way to help you.

Expected form: **Думаю**

Why: Common present verbs. [[Russian#^ru-Q0381|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D1%83%D0%BC%D0%B0%D1%8E%2C%20%D1%8F%20%D0%BD%D0%B0%D1%88%D1%91%D0%BB%20%D1%81%D0%BF%D0%BE%D1%81%D0%BE%D0%B1%20%D0%BF%D0%BE%D0%BC%D0%BE%D1%87%D1%8C%20%D0%B2%D0%B0%D0%BC.)
^ru-Q0381-answer

**ru-Q0382** — Думаю, я нашёл способ помочь вам.

I think I've found a way to help you.

Why: Common present verbs. [[Russian#^ru-Q0382|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D1%83%D0%BC%D0%B0%D1%8E%2C%20%D1%8F%20%D0%BD%D0%B0%D1%88%D1%91%D0%BB%20%D1%81%D0%BF%D0%BE%D1%81%D0%BE%D0%B1%20%D0%BF%D0%BE%D0%BC%D0%BE%D1%87%D1%8C%20%D0%B2%D0%B0%D0%BC.)
^ru-Q0382-answer

**ru-Q0383** — Я не знаю, какой хочу.

I don't know which one I want.

Why: Common present verbs. [[Russian#^ru-Q0383|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D0%B7%D0%BD%D0%B0%D1%8E%2C%20%D0%BA%D0%B0%D0%BA%D0%BE%D0%B9%20%D1%85%D0%BE%D1%87%D1%83.)
^ru-Q0383-answer

**ru-Q0384** — Я не знаю, какой хочу.

I don't know which one I want.

Present forms agree with person and number. Ordinary present-time activity uses an imperfective verb. Perfective forms with similar endings normally refer to future events.

Why: Common present verbs. [[Russian#^ru-Q0384|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D0%B7%D0%BD%D0%B0%D1%8E%2C%20%D0%BA%D0%B0%D0%BA%D0%BE%D0%B9%20%D1%85%D0%BE%D1%87%D1%83.)
^ru-Q0384-answer

**ru-Q0385** — Том совершенно не представляет, о чём сейчас думает Маша.

Tom doesn't have any idea what Mary is thinking.

Expected form: **думает**

Why: Common present verbs. [[Russian#^ru-Q0385|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%81%D0%BE%D0%B2%D0%B5%D1%80%D1%88%D0%B5%D0%BD%D0%BD%D0%BE%20%D0%BD%D0%B5%20%D0%BF%D1%80%D0%B5%D0%B4%D1%81%D1%82%D0%B0%D0%B2%D0%BB%D1%8F%D0%B5%D1%82%2C%20%D0%BE%20%D1%87%D1%91%D0%BC%20%D1%81%D0%B5%D0%B9%D1%87%D0%B0%D1%81%20%D0%B4%D1%83%D0%BC%D0%B0%D0%B5%D1%82%20%D0%9C%D0%B0%D1%88%D0%B0.)
^ru-Q0385-answer

**ru-Q0386** — Том совершенно не представляет, о чём сейчас думает Маша.

Tom doesn't have any idea what Mary is thinking.

Expected form: **думает**

Why: Common present verbs. [[Russian#^ru-Q0386|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%81%D0%BE%D0%B2%D0%B5%D1%80%D1%88%D0%B5%D0%BD%D0%BD%D0%BE%20%D0%BD%D0%B5%20%D0%BF%D1%80%D0%B5%D0%B4%D1%81%D1%82%D0%B0%D0%B2%D0%BB%D1%8F%D0%B5%D1%82%2C%20%D0%BE%20%D1%87%D1%91%D0%BC%20%D1%81%D0%B5%D0%B9%D1%87%D0%B0%D1%81%20%D0%B4%D1%83%D0%BC%D0%B0%D0%B5%D1%82%20%D0%9C%D0%B0%D1%88%D0%B0.)
^ru-Q0386-answer

**ru-Q0387** — Я не понимаю, что она говорит.

I can't understand what she says.

Expected form: **говорит**

Why: Common present verbs. [[Russian#^ru-Q0387|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D0%BF%D0%BE%D0%BD%D0%B8%D0%BC%D0%B0%D1%8E%2C%20%D1%87%D1%82%D0%BE%20%D0%BE%D0%BD%D0%B0%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82.)
^ru-Q0387-answer

**ru-Q0388** — Я не понимаю, что она говорит.

I can't understand what she says.

Why: Common present verbs. [[Russian#^ru-Q0388|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D0%BF%D0%BE%D0%BD%D0%B8%D0%BC%D0%B0%D1%8E%2C%20%D1%87%D1%82%D0%BE%20%D0%BE%D0%BD%D0%B0%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82.)
^ru-Q0388-answer

**ru-Q0389** — Я знаю, что Вы не врач.

I know you're not a doctor.

Why: Common present verbs. [[Russian#^ru-Q0389|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B7%D0%BD%D0%B0%D1%8E%2C%20%D1%87%D1%82%D0%BE%20%D0%92%D1%8B%20%D0%BD%D0%B5%20%D0%B2%D1%80%D0%B0%D1%87.)
^ru-Q0389-answer

**ru-Q0390** — Я знаю, что Вы не врач.

I know you're not a doctor.

Present forms agree with person and number. Ordinary present-time activity uses an imperfective verb. Perfective forms with similar endings normally refer to future events.

Why: Common present verbs. [[Russian#^ru-Q0390|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B7%D0%BD%D0%B0%D1%8E%2C%20%D1%87%D1%82%D0%BE%20%D0%92%D1%8B%20%D0%BD%D0%B5%20%D0%B2%D1%80%D0%B0%D1%87.)
^ru-Q0390-answer

**ru-Q0391** — Мэри говорит, что не останется.

Mary says she won't stay.

Expected form: **говорит**

Why: Common present verbs. [[Russian#^ru-Q0391|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8D%D1%80%D0%B8%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%2C%20%D1%87%D1%82%D0%BE%20%D0%BD%D0%B5%20%D0%BE%D1%81%D1%82%D0%B0%D0%BD%D0%B5%D1%82%D1%81%D1%8F.)
^ru-Q0391-answer

**ru-Q0392** — Мэри говорит, что не останется.

Mary says she won't stay.

Expected form: **говорит**

Why: Common present verbs. [[Russian#^ru-Q0392|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8D%D1%80%D0%B8%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%2C%20%D1%87%D1%82%D0%BE%20%D0%BD%D0%B5%20%D0%BE%D1%81%D1%82%D0%B0%D0%BD%D0%B5%D1%82%D1%81%D1%8F.)
^ru-Q0392-answer

**ru-Q0393** — Я знаю, что вам нужно было это сделать.

I know you needed to do that.

Expected form: **знаю**

Why: Common present verbs. [[Russian#^ru-Q0393|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B7%D0%BD%D0%B0%D1%8E%2C%20%D1%87%D1%82%D0%BE%20%D0%B2%D0%B0%D0%BC%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D1%8D%D1%82%D0%BE%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C.)
^ru-Q0393-answer

**ru-Q0394** — Я знаю, что вам нужно было это сделать.

I know you needed to do that.

Why: Common present verbs. [[Russian#^ru-Q0394|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B7%D0%BD%D0%B0%D1%8E%2C%20%D1%87%D1%82%D0%BE%20%D0%B2%D0%B0%D0%BC%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D1%8D%D1%82%D0%BE%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C.)
^ru-Q0394-answer

**ru-Q0395** — Я понимаю, что Вы имеете в виду, но точно не знаю, как это перевести.

I understand what you mean, but I'm not sure how to translate it.

Why: Common present verbs. [[Russian#^ru-Q0395|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BF%D0%BE%D0%BD%D0%B8%D0%BC%D0%B0%D1%8E%2C%20%D1%87%D1%82%D0%BE%20%D0%92%D1%8B%20%D0%B8%D0%BC%D0%B5%D0%B5%D1%82%D0%B5%20%D0%B2%20%D0%B2%D0%B8%D0%B4%D1%83%2C%20%D0%BD%D0%BE%20%D1%82%D0%BE%D1%87%D0%BD%D0%BE%20%D0%BD%D0%B5%20%D0%B7%D0%BD%D0%B0%D1%8E%2C%20%D0%BA%D0%B0%D0%BA%20%D1%8D%D1%82%D0%BE%20%D0%BF%D0%B5%D1%80%D0%B5%D0%B2%D0%B5%D1%81%D1%82%D0%B8.)
^ru-Q0395-answer

**ru-Q0396** — Я понимаю, что Вы имеете в виду, но точно не знаю, как это перевести.

I understand what you mean, but I'm not sure how to translate it.

Present forms agree with person and number. Ordinary present-time activity uses an imperfective verb. Perfective forms with similar endings normally refer to future events.

Why: Common present verbs. [[Russian#^ru-Q0396|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BF%D0%BE%D0%BD%D0%B8%D0%BC%D0%B0%D1%8E%2C%20%D1%87%D1%82%D0%BE%20%D0%92%D1%8B%20%D0%B8%D0%BC%D0%B5%D0%B5%D1%82%D0%B5%20%D0%B2%20%D0%B2%D0%B8%D0%B4%D1%83%2C%20%D0%BD%D0%BE%20%D1%82%D0%BE%D1%87%D0%BD%D0%BE%20%D0%BD%D0%B5%20%D0%B7%D0%BD%D0%B0%D1%8E%2C%20%D0%BA%D0%B0%D0%BA%20%D1%8D%D1%82%D0%BE%20%D0%BF%D0%B5%D1%80%D0%B5%D0%B2%D0%B5%D1%81%D1%82%D0%B8.)
^ru-Q0396-answer

**ru-Q0397** — Мы знаем, что ты трус.

We know you're a coward.

Expected form: **знаем**

Why: Common present verbs. [[Russian#^ru-Q0397|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%B7%D0%BD%D0%B0%D0%B5%D0%BC%2C%20%D1%87%D1%82%D0%BE%20%D1%82%D1%8B%20%D1%82%D1%80%D1%83%D1%81.)
^ru-Q0397-answer

**ru-Q0398** — Мы знаем, что ты трус.

We know you're a coward.

Expected form: **знаем**

Why: Common present verbs. [[Russian#^ru-Q0398|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%B7%D0%BD%D0%B0%D0%B5%D0%BC%2C%20%D1%87%D1%82%D0%BE%20%D1%82%D1%8B%20%D1%82%D1%80%D1%83%D1%81.)
^ru-Q0398-answer

**ru-Q0399** — Не знаю, почему я сегодня такая счастливая.

I don't know why I'm so happy today.

Expected form: **знаю**

Why: Common present verbs. [[Russian#^ru-Q0399|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%20%D0%B7%D0%BD%D0%B0%D1%8E%2C%20%D0%BF%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D1%8F%20%D1%81%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F%20%D1%82%D0%B0%D0%BA%D0%B0%D1%8F%20%D1%81%D1%87%D0%B0%D1%81%D1%82%D0%BB%D0%B8%D0%B2%D0%B0%D1%8F.)
^ru-Q0399-answer

**ru-Q0400** — Не знаю, почему я сегодня такая счастливая.

I don't know why I'm so happy today.

Why: Common present verbs. [[Russian#^ru-Q0400|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%20%D0%B7%D0%BD%D0%B0%D1%8E%2C%20%D0%BF%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D1%8F%20%D1%81%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F%20%D1%82%D0%B0%D0%BA%D0%B0%D1%8F%20%D1%81%D1%87%D0%B0%D1%81%D1%82%D0%BB%D0%B8%D0%B2%D0%B0%D1%8F.)
^ru-Q0400-answer


### Answers 401–450

**ru-Q0401** — Она сказала, что не будет ждать.

She said she wouldn't wait.

Why: Bounded past and aspect. [[Russian#^ru-Q0401|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%D0%B0%2C%20%D1%87%D1%82%D0%BE%20%D0%BD%D0%B5%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D0%B6%D0%B4%D0%B0%D1%82%D1%8C.)
^ru-Q0401-answer

**ru-Q0402** — Она сказала, что не будет ждать.

She said she wouldn't wait.

These common perfective past forms present a bounded event in suitable contexts. Aspect is lexical and interacts with negation and discourse; a prefix is not always a simple completion switch.

Why: Bounded past and aspect. [[Russian#^ru-Q0402|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%D0%B0%2C%20%D1%87%D1%82%D0%BE%20%D0%BD%D0%B5%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D0%B6%D0%B4%D0%B0%D1%82%D1%8C.)
^ru-Q0402-answer

**ru-Q0403** — Даже Том такого бы не сделал.

Even Tom wouldn't do that.

Expected form: **сделал**

Why: Bounded past and aspect. [[Russian#^ru-Q0403|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D0%B0%D0%B6%D0%B5%20%D0%A2%D0%BE%D0%BC%20%D1%82%D0%B0%D0%BA%D0%BE%D0%B3%D0%BE%20%D0%B1%D1%8B%20%D0%BD%D0%B5%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D0%BB.)
^ru-Q0403-answer

**ru-Q0404** — Даже Том такого бы не сделал.

Even Tom wouldn't do that.

Expected form: **сделал**

Why: Bounded past and aspect. [[Russian#^ru-Q0404|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D0%B0%D0%B6%D0%B5%20%D0%A2%D0%BE%D0%BC%20%D1%82%D0%B0%D0%BA%D0%BE%D0%B3%D0%BE%20%D0%B1%D1%8B%20%D0%BD%D0%B5%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D0%BB.)
^ru-Q0404-answer

**ru-Q0405** — Ты не в ответе за то, что сделал Том.

You aren't responsible for what Tom did.

Expected form: **сделал**

Why: Bounded past and aspect. [[Russian#^ru-Q0405|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%BD%D0%B5%20%D0%B2%20%D0%BE%D1%82%D0%B2%D0%B5%D1%82%D0%B5%20%D0%B7%D0%B0%20%D1%82%D0%BE%2C%20%D1%87%D1%82%D0%BE%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D0%BB%20%D0%A2%D0%BE%D0%BC.)
^ru-Q0405-answer

**ru-Q0406** — Ты не в ответе за то, что сделал Том.

You aren't responsible for what Tom did.

Why: Bounded past and aspect. [[Russian#^ru-Q0406|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%BD%D0%B5%20%D0%B2%20%D0%BE%D1%82%D0%B2%D0%B5%D1%82%D0%B5%20%D0%B7%D0%B0%20%D1%82%D0%BE%2C%20%D1%87%D1%82%D0%BE%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D0%BB%20%D0%A2%D0%BE%D0%BC.)
^ru-Q0406-answer

**ru-Q0407** — Том сказал, что вы говорите по-французски лучше Мэри.

Tom said you speak French better than Mary.

Why: Bounded past and aspect. [[Russian#^ru-Q0407|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%B2%D1%8B%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D0%B5%20%D0%BF%D0%BE-%D1%84%D1%80%D0%B0%D0%BD%D1%86%D1%83%D0%B7%D1%81%D0%BA%D0%B8%20%D0%BB%D1%83%D1%87%D1%88%D0%B5%20%D0%9C%D1%8D%D1%80%D0%B8.)
^ru-Q0407-answer

**ru-Q0408** — Том сказал, что вы говорите по-французски лучше Мэри.

Tom said you speak French better than Mary.

These common perfective past forms present a bounded event in suitable contexts. Aspect is lexical and interacts with negation and discourse; a prefix is not always a simple completion switch.

Why: Bounded past and aspect. [[Russian#^ru-Q0408|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%B2%D1%8B%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D0%B5%20%D0%BF%D0%BE-%D1%84%D1%80%D0%B0%D0%BD%D1%86%D1%83%D0%B7%D1%81%D0%BA%D0%B8%20%D0%BB%D1%83%D1%87%D1%88%D0%B5%20%D0%9C%D1%8D%D1%80%D0%B8.)
^ru-Q0408-answer

**ru-Q0409** — Том сказал мне, что ты счастлив.

Tom told me you were happy.

Expected form: **сказал**

Why: Bounded past and aspect. [[Russian#^ru-Q0409|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%20%D0%BC%D0%BD%D0%B5%2C%20%D1%87%D1%82%D0%BE%20%D1%82%D1%8B%20%D1%81%D1%87%D0%B0%D1%81%D1%82%D0%BB%D0%B8%D0%B2.)
^ru-Q0409-answer

**ru-Q0410** — Том сказал мне, что ты счастлив.

Tom told me you were happy.

Expected form: **сказал**

Why: Bounded past and aspect. [[Russian#^ru-Q0410|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%20%D0%BC%D0%BD%D0%B5%2C%20%D1%87%D1%82%D0%BE%20%D1%82%D1%8B%20%D1%81%D1%87%D0%B0%D1%81%D1%82%D0%BB%D0%B8%D0%B2.)
^ru-Q0410-answer

**ru-Q0411** — Том сказал, что надеется, что Мэри не опоздает.

Tom said he hopes Mary won't be late.

Expected form: **сказал**

Why: Bounded past and aspect. [[Russian#^ru-Q0411|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%BD%D0%B0%D0%B4%D0%B5%D0%B5%D1%82%D1%81%D1%8F%2C%20%D1%87%D1%82%D0%BE%20%D0%9C%D1%8D%D1%80%D0%B8%20%D0%BD%D0%B5%20%D0%BE%D0%BF%D0%BE%D0%B7%D0%B4%D0%B0%D0%B5%D1%82.)
^ru-Q0411-answer

**ru-Q0412** — Том сказал, что надеется, что Мэри не опоздает.

Tom said he hopes Mary won't be late.

Why: Bounded past and aspect. [[Russian#^ru-Q0412|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%BD%D0%B0%D0%B4%D0%B5%D0%B5%D1%82%D1%81%D1%8F%2C%20%D1%87%D1%82%D0%BE%20%D0%9C%D1%8D%D1%80%D0%B8%20%D0%BD%D0%B5%20%D0%BE%D0%BF%D0%BE%D0%B7%D0%B4%D0%B0%D0%B5%D1%82.)
^ru-Q0412-answer

**ru-Q0413** — Том внимательно прочитал меню.

Tom perused the menu.

Why: Bounded past and aspect. [[Russian#^ru-Q0413|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B2%D0%BD%D0%B8%D0%BC%D0%B0%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE%20%D0%BF%D1%80%D0%BE%D1%87%D0%B8%D1%82%D0%B0%D0%BB%20%D0%BC%D0%B5%D0%BD%D1%8E.)
^ru-Q0413-answer

**ru-Q0414** — Том внимательно прочитал меню.

Tom perused the menu.

These common perfective past forms present a bounded event in suitable contexts. Aspect is lexical and interacts with negation and discourse; a prefix is not always a simple completion switch.

Why: Bounded past and aspect. [[Russian#^ru-Q0414|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B2%D0%BD%D0%B8%D0%BC%D0%B0%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE%20%D0%BF%D1%80%D0%BE%D1%87%D0%B8%D1%82%D0%B0%D0%BB%20%D0%BC%D0%B5%D0%BD%D1%8E.)
^ru-Q0414-answer

**ru-Q0415** — Не забудь, что я сказал.

Don't forget what I said.

Expected form: **сказал**

Why: Bounded past and aspect. [[Russian#^ru-Q0415|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%20%D0%B7%D0%B0%D0%B1%D1%83%D0%B4%D1%8C%2C%20%D1%87%D1%82%D0%BE%20%D1%8F%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB.)
^ru-Q0415-answer

**ru-Q0416** — Не забудь, что я сказал.

Don't forget what I said.

Expected form: **сказал**

Why: Bounded past and aspect. [[Russian#^ru-Q0416|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%20%D0%B7%D0%B0%D0%B1%D1%83%D0%B4%D1%8C%2C%20%D1%87%D1%82%D0%BE%20%D1%8F%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB.)
^ru-Q0416-answer

**ru-Q0417** — Если бы я знала ее адрес, я бы написала ей.

If I had known her address, I would have written to her.

Expected form: **написала**

Why: Bounded past and aspect. [[Russian#^ru-Q0417|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D0%BB%D0%B8%20%D0%B1%D1%8B%20%D1%8F%20%D0%B7%D0%BD%D0%B0%D0%BB%D0%B0%20%D0%B5%D0%B5%20%D0%B0%D0%B4%D1%80%D0%B5%D1%81%2C%20%D1%8F%20%D0%B1%D1%8B%20%D0%BD%D0%B0%D0%BF%D0%B8%D1%81%D0%B0%D0%BB%D0%B0%20%D0%B5%D0%B9.)
^ru-Q0417-answer

**ru-Q0418** — Если бы я знала ее адрес, я бы написала ей.

If I had known her address, I would have written to her.

Why: Bounded past and aspect. [[Russian#^ru-Q0418|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D0%BB%D0%B8%20%D0%B1%D1%8B%20%D1%8F%20%D0%B7%D0%BD%D0%B0%D0%BB%D0%B0%20%D0%B5%D0%B5%20%D0%B0%D0%B4%D1%80%D0%B5%D1%81%2C%20%D1%8F%20%D0%B1%D1%8B%20%D0%BD%D0%B0%D0%BF%D0%B8%D1%81%D0%B0%D0%BB%D0%B0%20%D0%B5%D0%B9.)
^ru-Q0418-answer

**ru-Q0419** — Я скажу, что я сделал это.

I'll say I did it.

Why: Bounded past and aspect. [[Russian#^ru-Q0419|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%81%D0%BA%D0%B0%D0%B6%D1%83%2C%20%D1%87%D1%82%D0%BE%20%D1%8F%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D0%BB%20%D1%8D%D1%82%D0%BE.)
^ru-Q0419-answer

**ru-Q0420** — Я скажу, что я сделал это.

I'll say I did it.

These common perfective past forms present a bounded event in suitable contexts. Aspect is lexical and interacts with negation and discourse; a prefix is not always a simple completion switch.

Why: Bounded past and aspect. [[Russian#^ru-Q0420|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%81%D0%BA%D0%B0%D0%B6%D1%83%2C%20%D1%87%D1%82%D0%BE%20%D1%8F%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D0%BB%20%D1%8D%D1%82%D0%BE.)
^ru-Q0420-answer

**ru-Q0421** — Ты ведь специально это сделал?

You did that intentionally, didn't you?

Expected form: **сделал**

Why: Bounded past and aspect. [[Russian#^ru-Q0421|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%B2%D0%B5%D0%B4%D1%8C%20%D1%81%D0%BF%D0%B5%D1%86%D0%B8%D0%B0%D0%BB%D1%8C%D0%BD%D0%BE%20%D1%8D%D1%82%D0%BE%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D0%BB%3F)
^ru-Q0421-answer

**ru-Q0422** — Ты ведь специально это сделал?

You did that intentionally, didn't you?

Expected form: **сделал**

Why: Bounded past and aspect. [[Russian#^ru-Q0422|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%B2%D0%B5%D0%B4%D1%8C%20%D1%81%D0%BF%D0%B5%D1%86%D0%B8%D0%B0%D0%BB%D1%8C%D0%BD%D0%BE%20%D1%8D%D1%82%D0%BE%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D0%BB%3F)
^ru-Q0422-answer

**ru-Q0423** — Том сказал, что хочет немного посмотреть телевизор.

Tom said he wanted to watch a little TV.

Expected form: **сказал**

Why: Bounded past and aspect. [[Russian#^ru-Q0423|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D1%85%D0%BE%D1%87%D0%B5%D1%82%20%D0%BD%D0%B5%D0%BC%D0%BD%D0%BE%D0%B3%D0%BE%20%D0%BF%D0%BE%D1%81%D0%BC%D0%BE%D1%82%D1%80%D0%B5%D1%82%D1%8C%20%D1%82%D0%B5%D0%BB%D0%B5%D0%B2%D0%B8%D0%B7%D0%BE%D1%80.)
^ru-Q0423-answer

**ru-Q0424** — Том сказал, что хочет немного посмотреть телевизор.

Tom said he wanted to watch a little TV.

Why: Bounded past and aspect. [[Russian#^ru-Q0424|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D1%85%D0%BE%D1%87%D0%B5%D1%82%20%D0%BD%D0%B5%D0%BC%D0%BD%D0%BE%D0%B3%D0%BE%20%D0%BF%D0%BE%D1%81%D0%BC%D0%BE%D1%82%D1%80%D0%B5%D1%82%D1%8C%20%D1%82%D0%B5%D0%BB%D0%B5%D0%B2%D0%B8%D0%B7%D0%BE%D1%80.)
^ru-Q0424-answer

**ru-Q0425** — Я увидела хвост кита сегодня.

I saw a whale tail today.

Why: Bounded past and aspect. [[Russian#^ru-Q0425|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%83%D0%B2%D0%B8%D0%B4%D0%B5%D0%BB%D0%B0%20%D1%85%D0%B2%D0%BE%D1%81%D1%82%20%D0%BA%D0%B8%D1%82%D0%B0%20%D1%81%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F.)
^ru-Q0425-answer

**ru-Q0426** — Я увидела хвост кита сегодня.

I saw a whale tail today.

These common perfective past forms present a bounded event in suitable contexts. Aspect is lexical and interacts with negation and discourse; a prefix is not always a simple completion switch.

Why: Bounded past and aspect. [[Russian#^ru-Q0426|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%83%D0%B2%D0%B8%D0%B4%D0%B5%D0%BB%D0%B0%20%D1%85%D0%B2%D0%BE%D1%81%D1%82%20%D0%BA%D0%B8%D1%82%D0%B0%20%D1%81%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F.)
^ru-Q0426-answer

**ru-Q0427** — Том сказал, что опаздывает.

Tom said he was going to be late.

Expected form: **сказал**

Why: Bounded past and aspect. [[Russian#^ru-Q0427|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%BE%D0%BF%D0%B0%D0%B7%D0%B4%D1%8B%D0%B2%D0%B0%D0%B5%D1%82.)
^ru-Q0427-answer

**ru-Q0428** — Том сказал, что опаздывает.

Tom said he was going to be late.

Expected form: **сказал**

Why: Bounded past and aspect. [[Russian#^ru-Q0428|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%BE%D0%BF%D0%B0%D0%B7%D0%B4%D1%8B%D0%B2%D0%B0%D0%B5%D1%82.)
^ru-Q0428-answer

**ru-Q0429** — Кто написал ей?

Who wrote to her?

Expected form: **написал**

Why: Bounded past and aspect. [[Russian#^ru-Q0429|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D1%82%D0%BE%20%D0%BD%D0%B0%D0%BF%D0%B8%D1%81%D0%B0%D0%BB%20%D0%B5%D0%B9%3F)
^ru-Q0429-answer

**ru-Q0430** — Кто написал ей?

Who wrote to her?

Why: Bounded past and aspect. [[Russian#^ru-Q0430|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D1%82%D0%BE%20%D0%BD%D0%B0%D0%BF%D0%B8%D1%81%D0%B0%D0%BB%20%D0%B5%D0%B9%3F)
^ru-Q0430-answer

**ru-Q0431** — Я уже сказал твоим родителям.

I already told your parents.

Why: Bounded past and aspect. [[Russian#^ru-Q0431|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%83%D0%B6%D0%B5%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%20%D1%82%D0%B2%D0%BE%D0%B8%D0%BC%20%D1%80%D0%BE%D0%B4%D0%B8%D1%82%D0%B5%D0%BB%D1%8F%D0%BC.)
^ru-Q0431-answer

**ru-Q0432** — Я уже сказал твоим родителям.

I already told your parents.

These common perfective past forms present a bounded event in suitable contexts. Aspect is lexical and interacts with negation and discourse; a prefix is not always a simple completion switch.

Why: Bounded past and aspect. [[Russian#^ru-Q0432|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%83%D0%B6%D0%B5%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%20%D1%82%D0%B2%D0%BE%D0%B8%D0%BC%20%D1%80%D0%BE%D0%B4%D0%B8%D1%82%D0%B5%D0%BB%D1%8F%D0%BC.)
^ru-Q0432-answer

**ru-Q0433** — Что ты сказал полиции?

What did you tell the police?

Expected form: **сказал**

Why: Bounded past and aspect. [[Russian#^ru-Q0433|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A7%D1%82%D0%BE%20%D1%82%D1%8B%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%20%D0%BF%D0%BE%D0%BB%D0%B8%D1%86%D0%B8%D0%B8%3F)
^ru-Q0433-answer

**ru-Q0434** — Что ты сказал полиции?

What did you tell the police?

Expected form: **сказал**

Why: Bounded past and aspect. [[Russian#^ru-Q0434|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A7%D1%82%D0%BE%20%D1%82%D1%8B%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%20%D0%BF%D0%BE%D0%BB%D0%B8%D1%86%D0%B8%D0%B8%3F)
^ru-Q0434-answer

**ru-Q0435** — Пожалуйста, не говорите никому то, что я вам только что сказал.

Please don't tell anybody what I just told you.

Expected form: **сказал**

Why: Bounded past and aspect. [[Russian#^ru-Q0435|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%BD%D0%B5%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D0%B5%20%D0%BD%D0%B8%D0%BA%D0%BE%D0%BC%D1%83%20%D1%82%D0%BE%2C%20%D1%87%D1%82%D0%BE%20%D1%8F%20%D0%B2%D0%B0%D0%BC%20%D1%82%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE%20%D1%87%D1%82%D0%BE%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB.)
^ru-Q0435-answer

**ru-Q0436** — Пожалуйста, не говорите никому то, что я вам только что сказал.

Please don't tell anybody what I just told you.

Why: Bounded past and aspect. [[Russian#^ru-Q0436|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%BD%D0%B5%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D0%B5%20%D0%BD%D0%B8%D0%BA%D0%BE%D0%BC%D1%83%20%D1%82%D0%BE%2C%20%D1%87%D1%82%D0%BE%20%D1%8F%20%D0%B2%D0%B0%D0%BC%20%D1%82%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE%20%D1%87%D1%82%D0%BE%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB.)
^ru-Q0436-answer

**ru-Q0437** — Я увидела тебя вчера на похоронах.

I saw you yesterday at the funeral.

Why: Bounded past and aspect. [[Russian#^ru-Q0437|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%83%D0%B2%D0%B8%D0%B4%D0%B5%D0%BB%D0%B0%20%D1%82%D0%B5%D0%B1%D1%8F%20%D0%B2%D1%87%D0%B5%D1%80%D0%B0%20%D0%BD%D0%B0%20%D0%BF%D0%BE%D1%85%D0%BE%D1%80%D0%BE%D0%BD%D0%B0%D1%85.)
^ru-Q0437-answer

**ru-Q0438** — Я увидела тебя вчера на похоронах.

I saw you yesterday at the funeral.

These common perfective past forms present a bounded event in suitable contexts. Aspect is lexical and interacts with negation and discourse; a prefix is not always a simple completion switch.

Why: Bounded past and aspect. [[Russian#^ru-Q0438|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%83%D0%B2%D0%B8%D0%B4%D0%B5%D0%BB%D0%B0%20%D1%82%D0%B5%D0%B1%D1%8F%20%D0%B2%D1%87%D0%B5%D1%80%D0%B0%20%D0%BD%D0%B0%20%D0%BF%D0%BE%D1%85%D0%BE%D1%80%D0%BE%D0%BD%D0%B0%D1%85.)
^ru-Q0438-answer

**ru-Q0439** — Мэри сказала, что не верит этому.

Mary said she didn't believe it.

Expected form: **сказала**

Why: Bounded past and aspect. [[Russian#^ru-Q0439|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8D%D1%80%D0%B8%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%D0%B0%2C%20%D1%87%D1%82%D0%BE%20%D0%BD%D0%B5%20%D0%B2%D0%B5%D1%80%D0%B8%D1%82%20%D1%8D%D1%82%D0%BE%D0%BC%D1%83.)
^ru-Q0439-answer

**ru-Q0440** — Мэри сказала, что не верит этому.

Mary said she didn't believe it.

Expected form: **сказала**

Why: Bounded past and aspect. [[Russian#^ru-Q0440|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8D%D1%80%D0%B8%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%D0%B0%2C%20%D1%87%D1%82%D0%BE%20%D0%BD%D0%B5%20%D0%B2%D0%B5%D1%80%D0%B8%D1%82%20%D1%8D%D1%82%D0%BE%D0%BC%D1%83.)
^ru-Q0440-answer

**ru-Q0441** — Мэри сказала мне, что поедет в Бостон в октябре.

Mary told me that she'd go to Boston in October.

Expected form: **сказала**

Why: Bounded past and aspect. [[Russian#^ru-Q0441|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8D%D1%80%D0%B8%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%D0%B0%20%D0%BC%D0%BD%D0%B5%2C%20%D1%87%D1%82%D0%BE%20%D0%BF%D0%BE%D0%B5%D0%B4%D0%B5%D1%82%20%D0%B2%20%D0%91%D0%BE%D1%81%D1%82%D0%BE%D0%BD%20%D0%B2%20%D0%BE%D0%BA%D1%82%D1%8F%D0%B1%D1%80%D0%B5.)
^ru-Q0441-answer

**ru-Q0442** — Мэри сказала мне, что поедет в Бостон в октябре.

Mary told me that she'd go to Boston in October.

Why: Bounded past and aspect. [[Russian#^ru-Q0442|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8D%D1%80%D0%B8%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%D0%B0%20%D0%BC%D0%BD%D0%B5%2C%20%D1%87%D1%82%D0%BE%20%D0%BF%D0%BE%D0%B5%D0%B4%D0%B5%D1%82%20%D0%B2%20%D0%91%D0%BE%D1%81%D1%82%D0%BE%D0%BD%20%D0%B2%20%D0%BE%D0%BA%D1%82%D1%8F%D0%B1%D1%80%D0%B5.)
^ru-Q0442-answer

**ru-Q0443** — Я бы сказал Тому, если бы знал.

I would've told Tom if I had known.

Why: Bounded past and aspect. [[Russian#^ru-Q0443|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%8B%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%20%D0%A2%D0%BE%D0%BC%D1%83%2C%20%D0%B5%D1%81%D0%BB%D0%B8%20%D0%B1%D1%8B%20%D0%B7%D0%BD%D0%B0%D0%BB.)
^ru-Q0443-answer

**ru-Q0444** — Я бы сказал Тому, если бы знал.

I would've told Tom if I had known.

These common perfective past forms present a bounded event in suitable contexts. Aspect is lexical and interacts with negation and discourse; a prefix is not always a simple completion switch.

Why: Bounded past and aspect. [[Russian#^ru-Q0444|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%8B%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%20%D0%A2%D0%BE%D0%BC%D1%83%2C%20%D0%B5%D1%81%D0%BB%D0%B8%20%D0%B1%D1%8B%20%D0%B7%D0%BD%D0%B0%D0%BB.)
^ru-Q0444-answer

**ru-Q0445** — Том сказал, что Мэри настроена скептически.

Tom said Mary was skeptical.

Expected form: **сказал**

Why: Bounded past and aspect. [[Russian#^ru-Q0445|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%9C%D1%8D%D1%80%D0%B8%20%D0%BD%D0%B0%D1%81%D1%82%D1%80%D0%BE%D0%B5%D0%BD%D0%B0%20%D1%81%D0%BA%D0%B5%D0%BF%D1%82%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B8.)
^ru-Q0445-answer

**ru-Q0446** — Том сказал, что Мэри настроена скептически.

Tom said Mary was skeptical.

Expected form: **сказал**

Why: Bounded past and aspect. [[Russian#^ru-Q0446|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%9C%D1%8D%D1%80%D0%B8%20%D0%BD%D0%B0%D1%81%D1%82%D1%80%D0%BE%D0%B5%D0%BD%D0%B0%20%D1%81%D0%BA%D0%B5%D0%BF%D1%82%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B8.)
^ru-Q0446-answer

**ru-Q0447** — «Что в лоб, что по лбу», — сказал он.

"Same difference", he said.

Expected form: **сказал**

Why: Bounded past and aspect. [[Russian#^ru-Q0447|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%C2%AB%D0%A7%D1%82%D0%BE%20%D0%B2%20%D0%BB%D0%BE%D0%B1%2C%20%D1%87%D1%82%D0%BE%20%D0%BF%D0%BE%20%D0%BB%D0%B1%D1%83%C2%BB%2C%20%E2%80%94%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%20%D0%BE%D0%BD.)
^ru-Q0447-answer

**ru-Q0448** — «Что в лоб, что по лбу», — сказал он.

"Same difference", he said.

Why: Bounded past and aspect. [[Russian#^ru-Q0448|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%C2%AB%D0%A7%D1%82%D0%BE%20%D0%B2%20%D0%BB%D0%BE%D0%B1%2C%20%D1%87%D1%82%D0%BE%20%D0%BF%D0%BE%20%D0%BB%D0%B1%D1%83%C2%BB%2C%20%E2%80%94%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%20%D0%BE%D0%BD.)
^ru-Q0448-answer

**ru-Q0449** — Я ему не это сказал.

That's not what I told him.

Why: Bounded past and aspect. [[Russian#^ru-Q0449|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B5%D0%BC%D1%83%20%D0%BD%D0%B5%20%D1%8D%D1%82%D0%BE%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB.)
^ru-Q0449-answer

**ru-Q0450** — Я ему не это сказал.

That's not what I told him.

These common perfective past forms present a bounded event in suitable contexts. Aspect is lexical and interacts with negation and discourse; a prefix is not always a simple completion switch.

Why: Bounded past and aspect. [[Russian#^ru-Q0450|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B5%D0%BC%D1%83%20%D0%BD%D0%B5%20%D1%8D%D1%82%D0%BE%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB.)
^ru-Q0450-answer


### Answers 451–500

**ru-Q0451** — Буду держать кулачки.

I'll keep my fingers crossed.

Expected form: **Буду**

Why: Future constructions. [[Russian#^ru-Q0451|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%91%D1%83%D0%B4%D1%83%20%D0%B4%D0%B5%D1%80%D0%B6%D0%B0%D1%82%D1%8C%20%D0%BA%D1%83%D0%BB%D0%B0%D1%87%D0%BA%D0%B8.)
^ru-Q0451-answer

**ru-Q0452** — Буду держать кулачки.

I'll keep my fingers crossed.

Expected form: **Буду**

Why: Future constructions. [[Russian#^ru-Q0452|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%91%D1%83%D0%B4%D1%83%20%D0%B4%D0%B5%D1%80%D0%B6%D0%B0%D1%82%D1%8C%20%D0%BA%D1%83%D0%BB%D0%B0%D1%87%D0%BA%D0%B8.)
^ru-Q0452-answer

**ru-Q0453** — "На пикнике будет живая музыка". - "Что за музыка?"

"There will be live music at the picnic." "What kind of music?"

Expected form: **будет**

Why: Future constructions. [[Russian#^ru-Q0453|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%22%D0%9D%D0%B0%20%D0%BF%D0%B8%D0%BA%D0%BD%D0%B8%D0%BA%D0%B5%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D0%B6%D0%B8%D0%B2%D0%B0%D1%8F%20%D0%BC%D1%83%D0%B7%D1%8B%D0%BA%D0%B0%22.%20-%20%22%D0%A7%D1%82%D0%BE%20%D0%B7%D0%B0%20%D0%BC%D1%83%D0%B7%D1%8B%D0%BA%D0%B0%3F%22)
^ru-Q0453-answer

**ru-Q0454** — "На пикнике будет живая музыка". - "Что за музыка?"

"There will be live music at the picnic." "What kind of music?"

Why: Future constructions. [[Russian#^ru-Q0454|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%22%D0%9D%D0%B0%20%D0%BF%D0%B8%D0%BA%D0%BD%D0%B8%D0%BA%D0%B5%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D0%B6%D0%B8%D0%B2%D0%B0%D1%8F%20%D0%BC%D1%83%D0%B7%D1%8B%D0%BA%D0%B0%22.%20-%20%22%D0%A7%D1%82%D0%BE%20%D0%B7%D0%B0%20%D0%BC%D1%83%D0%B7%D1%8B%D0%BA%D0%B0%3F%22)
^ru-Q0454-answer

**ru-Q0455** — Я буду очень осторожен.

I will be very careful.

Why: Future constructions. [[Russian#^ru-Q0455|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%83%D0%B4%D1%83%20%D0%BE%D1%87%D0%B5%D0%BD%D1%8C%20%D0%BE%D1%81%D1%82%D0%BE%D1%80%D0%BE%D0%B6%D0%B5%D0%BD.)
^ru-Q0455-answer

**ru-Q0456** — Я буду очень осторожен.

I will be very careful.

Буду plus an imperfective infinitive expresses future activity. A perfective verb can form its future without буду. Буду alone can also mean will be.

Why: Future constructions. [[Russian#^ru-Q0456|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%83%D0%B4%D1%83%20%D0%BE%D1%87%D0%B5%D0%BD%D1%8C%20%D0%BE%D1%81%D1%82%D0%BE%D1%80%D0%BE%D0%B6%D0%B5%D0%BD.)
^ru-Q0456-answer

**ru-Q0457** — Друзья будут по вам скучать, когда вы уедете.

You will be missed by your friends when you're gone.

Expected form: **будут**

Why: Future constructions. [[Russian#^ru-Q0457|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D1%80%D1%83%D0%B7%D1%8C%D1%8F%20%D0%B1%D1%83%D0%B4%D1%83%D1%82%20%D0%BF%D0%BE%20%D0%B2%D0%B0%D0%BC%20%D1%81%D0%BA%D1%83%D1%87%D0%B0%D1%82%D1%8C%2C%20%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%B2%D1%8B%20%D1%83%D0%B5%D0%B4%D0%B5%D1%82%D0%B5.)
^ru-Q0457-answer

**ru-Q0458** — Друзья будут по вам скучать, когда вы уедете.

You will be missed by your friends when you're gone.

Expected form: **будут**

Why: Future constructions. [[Russian#^ru-Q0458|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D1%80%D1%83%D0%B7%D1%8C%D1%8F%20%D0%B1%D1%83%D0%B4%D1%83%D1%82%20%D0%BF%D0%BE%20%D0%B2%D0%B0%D0%BC%20%D1%81%D0%BA%D1%83%D1%87%D0%B0%D1%82%D1%8C%2C%20%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%B2%D1%8B%20%D1%83%D0%B5%D0%B4%D0%B5%D1%82%D0%B5.)
^ru-Q0458-answer

**ru-Q0459** — Я буду там к концу недели.

I'll be there by the end of the week.

Expected form: **буду**

Why: Future constructions. [[Russian#^ru-Q0459|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%83%D0%B4%D1%83%20%D1%82%D0%B0%D0%BC%20%D0%BA%20%D0%BA%D0%BE%D0%BD%D1%86%D1%83%20%D0%BD%D0%B5%D0%B4%D0%B5%D0%BB%D0%B8.)
^ru-Q0459-answer

**ru-Q0460** — Я буду там к концу недели.

I'll be there by the end of the week.

Why: Future constructions. [[Russian#^ru-Q0460|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%83%D0%B4%D1%83%20%D1%82%D0%B0%D0%BC%20%D0%BA%20%D0%BA%D0%BE%D0%BD%D1%86%D1%83%20%D0%BD%D0%B5%D0%B4%D0%B5%D0%BB%D0%B8.)
^ru-Q0460-answer

**ru-Q0461** — Если будет идти дождь, мы отменим тренировку.

If it rains, we will put off our practice match.

Why: Future constructions. [[Russian#^ru-Q0461|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D0%BB%D0%B8%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D0%B8%D0%B4%D1%82%D0%B8%20%D0%B4%D0%BE%D0%B6%D0%B4%D1%8C%2C%20%D0%BC%D1%8B%20%D0%BE%D1%82%D0%BC%D0%B5%D0%BD%D0%B8%D0%BC%20%D1%82%D1%80%D0%B5%D0%BD%D0%B8%D1%80%D0%BE%D0%B2%D0%BA%D1%83.)
^ru-Q0461-answer

**ru-Q0462** — Если будет идти дождь, мы отменим тренировку.

If it rains, we will put off our practice match.

Буду plus an imperfective infinitive expresses future activity. A perfective verb can form its future without буду. Буду alone can also mean will be.

Why: Future constructions. [[Russian#^ru-Q0462|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D0%BB%D0%B8%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D0%B8%D0%B4%D1%82%D0%B8%20%D0%B4%D0%BE%D0%B6%D0%B4%D1%8C%2C%20%D0%BC%D1%8B%20%D0%BE%D1%82%D0%BC%D0%B5%D0%BD%D0%B8%D0%BC%20%D1%82%D1%80%D0%B5%D0%BD%D0%B8%D1%80%D0%BE%D0%B2%D0%BA%D1%83.)
^ru-Q0462-answer

**ru-Q0463** — Если тебе когда-нибудь нужно будет с кем-то поговорить, не стесняйся - звони мне.

If you ever need anyone to talk to, feel free to call me.

Expected form: **будет**

Why: Future constructions. [[Russian#^ru-Q0463|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D0%BB%D0%B8%20%D1%82%D0%B5%D0%B1%D0%B5%20%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0-%D0%BD%D0%B8%D0%B1%D1%83%D0%B4%D1%8C%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D1%81%20%D0%BA%D0%B5%D0%BC-%D1%82%D0%BE%20%D0%BF%D0%BE%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D1%8C%2C%20%D0%BD%D0%B5%20%D1%81%D1%82%D0%B5%D1%81%D0%BD%D1%8F%D0%B9%D1%81%D1%8F%20-%20%D0%B7%D0%B2%D0%BE%D0%BD%D0%B8%20%D0%BC%D0%BD%D0%B5.)
^ru-Q0463-answer

**ru-Q0464** — Если тебе когда-нибудь нужно будет с кем-то поговорить, не стесняйся - звони мне.

If you ever need anyone to talk to, feel free to call me.

Expected form: **будет**

Why: Future constructions. [[Russian#^ru-Q0464|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D0%BB%D0%B8%20%D1%82%D0%B5%D0%B1%D0%B5%20%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0-%D0%BD%D0%B8%D0%B1%D1%83%D0%B4%D1%8C%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D1%81%20%D0%BA%D0%B5%D0%BC-%D1%82%D0%BE%20%D0%BF%D0%BE%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D1%8C%2C%20%D0%BD%D0%B5%20%D1%81%D1%82%D0%B5%D1%81%D0%BD%D1%8F%D0%B9%D1%81%D1%8F%20-%20%D0%B7%D0%B2%D0%BE%D0%BD%D0%B8%20%D0%BC%D0%BD%D0%B5.)
^ru-Q0464-answer

**ru-Q0465** — Нам будет очень весело.

We'll have a lot of fun.

Expected form: **будет**

Why: Future constructions. [[Russian#^ru-Q0465|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%D0%BC%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D0%BE%D1%87%D0%B5%D0%BD%D1%8C%20%D0%B2%D0%B5%D1%81%D0%B5%D0%BB%D0%BE.)
^ru-Q0465-answer

**ru-Q0466** — Нам будет очень весело.

We'll have a lot of fun.

Why: Future constructions. [[Russian#^ru-Q0466|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%D0%BC%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D0%BE%D1%87%D0%B5%D0%BD%D1%8C%20%D0%B2%D0%B5%D1%81%D0%B5%D0%BB%D0%BE.)
^ru-Q0466-answer

**ru-Q0467** — Он поклялся, что не будет больше пить.

He swore that he would no longer drink.

Why: Future constructions. [[Russian#^ru-Q0467|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D0%BF%D0%BE%D0%BA%D0%BB%D1%8F%D0%BB%D1%81%D1%8F%2C%20%D1%87%D1%82%D0%BE%20%D0%BD%D0%B5%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BF%D0%B8%D1%82%D1%8C.)
^ru-Q0467-answer

**ru-Q0468** — Он поклялся, что не будет больше пить.

He swore that he would no longer drink.

Буду plus an imperfective infinitive expresses future activity. A perfective verb can form its future without буду. Буду alone can also mean will be.

Why: Future constructions. [[Russian#^ru-Q0468|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D0%BF%D0%BE%D0%BA%D0%BB%D1%8F%D0%BB%D1%81%D1%8F%2C%20%D1%87%D1%82%D0%BE%20%D0%BD%D0%B5%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BF%D0%B8%D1%82%D1%8C.)
^ru-Q0468-answer

**ru-Q0469** — Том обязательно там будет.

Tom will definitely be there.

Expected form: **будет**

Why: Future constructions. [[Russian#^ru-Q0469|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BE%D0%B1%D1%8F%D0%B7%D0%B0%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE%20%D1%82%D0%B0%D0%BC%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82.)
^ru-Q0469-answer

**ru-Q0470** — Том обязательно там будет.

Tom will definitely be there.

Expected form: **будет**

Why: Future constructions. [[Russian#^ru-Q0470|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BE%D0%B1%D1%8F%D0%B7%D0%B0%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE%20%D1%82%D0%B0%D0%BC%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82.)
^ru-Q0470-answer

**ru-Q0471** — Это будет стоить около десяти тысяч иен.

It will cost around 10,000 yen.

Expected form: **будет**

Why: Future constructions. [[Russian#^ru-Q0471|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D1%82%D0%BE%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D1%81%D1%82%D0%BE%D0%B8%D1%82%D1%8C%20%D0%BE%D0%BA%D0%BE%D0%BB%D0%BE%20%D0%B4%D0%B5%D1%81%D1%8F%D1%82%D0%B8%20%D1%82%D1%8B%D1%81%D1%8F%D1%87%20%D0%B8%D0%B5%D0%BD.)
^ru-Q0471-answer

**ru-Q0472** — Это будет стоить около десяти тысяч иен.

It will cost around 10,000 yen.

Why: Future constructions. [[Russian#^ru-Q0472|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D1%82%D0%BE%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D1%81%D1%82%D0%BE%D0%B8%D1%82%D1%8C%20%D0%BE%D0%BA%D0%BE%D0%BB%D0%BE%20%D0%B4%D0%B5%D1%81%D1%8F%D1%82%D0%B8%20%D1%82%D1%8B%D1%81%D1%8F%D1%87%20%D0%B8%D0%B5%D0%BD.)
^ru-Q0472-answer

**ru-Q0473** — Я просто буду очень осторожен.

I'll just be extra careful.

Why: Future constructions. [[Russian#^ru-Q0473|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BF%D1%80%D0%BE%D1%81%D1%82%D0%BE%20%D0%B1%D1%83%D0%B4%D1%83%20%D0%BE%D1%87%D0%B5%D0%BD%D1%8C%20%D0%BE%D1%81%D1%82%D0%BE%D1%80%D0%BE%D0%B6%D0%B5%D0%BD.)
^ru-Q0473-answer

**ru-Q0474** — Я просто буду очень осторожен.

I'll just be extra careful.

Буду plus an imperfective infinitive expresses future activity. A perfective verb can form its future without буду. Буду alone can also mean will be.

Why: Future constructions. [[Russian#^ru-Q0474|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BF%D1%80%D0%BE%D1%81%D1%82%D0%BE%20%D0%B1%D1%83%D0%B4%D1%83%20%D0%BE%D1%87%D0%B5%D0%BD%D1%8C%20%D0%BE%D1%81%D1%82%D0%BE%D1%80%D0%BE%D0%B6%D0%B5%D0%BD.)
^ru-Q0474-answer

**ru-Q0475** — Том будет по мне скучать.

Tom will miss me.

Expected form: **будет**

Why: Future constructions. [[Russian#^ru-Q0475|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D0%BF%D0%BE%20%D0%BC%D0%BD%D0%B5%20%D1%81%D0%BA%D1%83%D1%87%D0%B0%D1%82%D1%8C.)
^ru-Q0475-answer

**ru-Q0476** — Том будет по мне скучать.

Tom will miss me.

Expected form: **будет**

Why: Future constructions. [[Russian#^ru-Q0476|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D0%BF%D0%BE%20%D0%BC%D0%BD%D0%B5%20%D1%81%D0%BA%D1%83%D1%87%D0%B0%D1%82%D1%8C.)
^ru-Q0476-answer

**ru-Q0477** — Интересно, что будет.

I wonder what will happen.

Expected form: **будет**

Why: Future constructions. [[Russian#^ru-Q0477|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%98%D0%BD%D1%82%D0%B5%D1%80%D0%B5%D1%81%D0%BD%D0%BE%2C%20%D1%87%D1%82%D0%BE%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82.)
^ru-Q0477-answer

**ru-Q0478** — Интересно, что будет.

I wonder what will happen.

Why: Future constructions. [[Russian#^ru-Q0478|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%98%D0%BD%D1%82%D0%B5%D1%80%D0%B5%D1%81%D0%BD%D0%BE%2C%20%D1%87%D1%82%D0%BE%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82.)
^ru-Q0478-answer

**ru-Q0479** — Я буду любить тебя вечно.

I will love you forever.

Why: Future constructions. [[Russian#^ru-Q0479|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%83%D0%B4%D1%83%20%D0%BB%D1%8E%D0%B1%D0%B8%D1%82%D1%8C%20%D1%82%D0%B5%D0%B1%D1%8F%20%D0%B2%D0%B5%D1%87%D0%BD%D0%BE.)
^ru-Q0479-answer

**ru-Q0480** — Я буду любить тебя вечно.

I will love you forever.

Буду plus an imperfective infinitive expresses future activity. A perfective verb can form its future without буду. Буду alone can also mean will be.

Why: Future constructions. [[Russian#^ru-Q0480|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%83%D0%B4%D1%83%20%D0%BB%D1%8E%D0%B1%D0%B8%D1%82%D1%8C%20%D1%82%D0%B5%D0%B1%D1%8F%20%D0%B2%D0%B5%D1%87%D0%BD%D0%BE.)
^ru-Q0480-answer

**ru-Q0481** — Ты будешь по мне скучать?

Will you miss me?

Expected form: **будешь**

Why: Future constructions. [[Russian#^ru-Q0481|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%B1%D1%83%D0%B4%D0%B5%D1%88%D1%8C%20%D0%BF%D0%BE%20%D0%BC%D0%BD%D0%B5%20%D1%81%D0%BA%D1%83%D1%87%D0%B0%D1%82%D1%8C%3F)
^ru-Q0481-answer

**ru-Q0482** — Ты будешь по мне скучать?

Will you miss me?

Expected form: **будешь**

Why: Future constructions. [[Russian#^ru-Q0482|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%B1%D1%83%D0%B4%D0%B5%D1%88%D1%8C%20%D0%BF%D0%BE%20%D0%BC%D0%BD%D0%B5%20%D1%81%D0%BA%D1%83%D1%87%D0%B0%D1%82%D1%8C%3F)
^ru-Q0482-answer

**ru-Q0483** — Том знал, что ему надо будет это сделать.

Tom knew he'd have to do that.

Expected form: **будет**

Why: Future constructions. [[Russian#^ru-Q0483|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B7%D0%BD%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%B5%D0%BC%D1%83%20%D0%BD%D0%B0%D0%B4%D0%BE%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D1%8D%D1%82%D0%BE%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C.)
^ru-Q0483-answer

**ru-Q0484** — Том знал, что ему надо будет это сделать.

Tom knew he'd have to do that.

Why: Future constructions. [[Russian#^ru-Q0484|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B7%D0%BD%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%B5%D0%BC%D1%83%20%D0%BD%D0%B0%D0%B4%D0%BE%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D1%8D%D1%82%D0%BE%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C.)
^ru-Q0484-answer

**ru-Q0485** — Он будет готов.

He will be ready.

Why: Future constructions. [[Russian#^ru-Q0485|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D0%B3%D0%BE%D1%82%D0%BE%D0%B2.)
^ru-Q0485-answer

**ru-Q0486** — Он будет готов.

He will be ready.

Буду plus an imperfective infinitive expresses future activity. A perfective verb can form its future without буду. Буду alone can also mean will be.

Why: Future constructions. [[Russian#^ru-Q0486|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D0%B3%D0%BE%D1%82%D0%BE%D0%B2.)
^ru-Q0486-answer

**ru-Q0487** — Я думаю, вы знаете, что сделать это будет невозможно.

I think you know that'll be impossible to do.

Expected form: **будет**

Why: Future constructions. [[Russian#^ru-Q0487|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B4%D1%83%D0%BC%D0%B0%D1%8E%2C%20%D0%B2%D1%8B%20%D0%B7%D0%BD%D0%B0%D0%B5%D1%82%D0%B5%2C%20%D1%87%D1%82%D0%BE%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C%20%D1%8D%D1%82%D0%BE%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D0%BD%D0%B5%D0%B2%D0%BE%D0%B7%D0%BC%D0%BE%D0%B6%D0%BD%D0%BE.)
^ru-Q0487-answer

**ru-Q0488** — Я думаю, вы знаете, что сделать это будет невозможно.

I think you know that'll be impossible to do.

Expected form: **будет**

Why: Future constructions. [[Russian#^ru-Q0488|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B4%D1%83%D0%BC%D0%B0%D1%8E%2C%20%D0%B2%D1%8B%20%D0%B7%D0%BD%D0%B0%D0%B5%D1%82%D0%B5%2C%20%D1%87%D1%82%D0%BE%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C%20%D1%8D%D1%82%D0%BE%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82%20%D0%BD%D0%B5%D0%B2%D0%BE%D0%B7%D0%BC%D0%BE%D0%B6%D0%BD%D0%BE.)
^ru-Q0488-answer

**ru-Q0489** — Сколько верёвочке ни виться, всё равно конец будет.

Sooner or later secrets become widely known.

Expected form: **будет**

Why: Future constructions. [[Russian#^ru-Q0489|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BA%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE%20%D0%B2%D0%B5%D1%80%D1%91%D0%B2%D0%BE%D1%87%D0%BA%D0%B5%20%D0%BD%D0%B8%20%D0%B2%D0%B8%D1%82%D1%8C%D1%81%D1%8F%2C%20%D0%B2%D1%81%D1%91%20%D1%80%D0%B0%D0%B2%D0%BD%D0%BE%20%D0%BA%D0%BE%D0%BD%D0%B5%D1%86%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82.)
^ru-Q0489-answer

**ru-Q0490** — Сколько верёвочке ни виться, всё равно конец будет.

Sooner or later secrets become widely known.

Why: Future constructions. [[Russian#^ru-Q0490|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BA%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE%20%D0%B2%D0%B5%D1%80%D1%91%D0%B2%D0%BE%D1%87%D0%BA%D0%B5%20%D0%BD%D0%B8%20%D0%B2%D0%B8%D1%82%D1%8C%D1%81%D1%8F%2C%20%D0%B2%D1%81%D1%91%20%D1%80%D0%B0%D0%B2%D0%BD%D0%BE%20%D0%BA%D0%BE%D0%BD%D0%B5%D1%86%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82.)
^ru-Q0490-answer

**ru-Q0491** — Я знал, что вас там не будет.

I knew you wouldn't be there.

Why: Future constructions. [[Russian#^ru-Q0491|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B7%D0%BD%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%B2%D0%B0%D1%81%20%D1%82%D0%B0%D0%BC%20%D0%BD%D0%B5%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82.)
^ru-Q0491-answer

**ru-Q0492** — Я знал, что вас там не будет.

I knew you wouldn't be there.

Буду plus an imperfective infinitive expresses future activity. A perfective verb can form its future without буду. Буду alone can also mean will be.

Why: Future constructions. [[Russian#^ru-Q0492|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B7%D0%BD%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%B2%D0%B0%D1%81%20%D1%82%D0%B0%D0%BC%20%D0%BD%D0%B5%20%D0%B1%D1%83%D0%B4%D0%B5%D1%82.)
^ru-Q0492-answer

**ru-Q0493** — Я решил, что не буду этого делать.

I decided I wouldn't do that.

Expected form: **буду**

Why: Future constructions. [[Russian#^ru-Q0493|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%80%D0%B5%D1%88%D0%B8%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%BD%D0%B5%20%D0%B1%D1%83%D0%B4%D1%83%20%D1%8D%D1%82%D0%BE%D0%B3%D0%BE%20%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C.)
^ru-Q0493-answer

**ru-Q0494** — Я решил, что не буду этого делать.

I decided I wouldn't do that.

Expected form: **буду**

Why: Future constructions. [[Russian#^ru-Q0494|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%80%D0%B5%D1%88%D0%B8%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%BD%D0%B5%20%D0%B1%D1%83%D0%B4%D1%83%20%D1%8D%D1%82%D0%BE%D0%B3%D0%BE%20%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C.)
^ru-Q0494-answer

**ru-Q0495** — Я даже не буду пытаться Тома от этого отговаривать.

I'm not even going to try to talk Tom out of doing that.

Expected form: **буду**

Why: Future constructions. [[Russian#^ru-Q0495|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B4%D0%B0%D0%B6%D0%B5%20%D0%BD%D0%B5%20%D0%B1%D1%83%D0%B4%D1%83%20%D0%BF%D1%8B%D1%82%D0%B0%D1%82%D1%8C%D1%81%D1%8F%20%D0%A2%D0%BE%D0%BC%D0%B0%20%D0%BE%D1%82%20%D1%8D%D1%82%D0%BE%D0%B3%D0%BE%20%D0%BE%D1%82%D0%B3%D0%BE%D0%B2%D0%B0%D1%80%D0%B8%D0%B2%D0%B0%D1%82%D1%8C.)
^ru-Q0495-answer

**ru-Q0496** — Я даже не буду пытаться Тома от этого отговаривать.

I'm not even going to try to talk Tom out of doing that.

Why: Future constructions. [[Russian#^ru-Q0496|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B4%D0%B0%D0%B6%D0%B5%20%D0%BD%D0%B5%20%D0%B1%D1%83%D0%B4%D1%83%20%D0%BF%D1%8B%D1%82%D0%B0%D1%82%D1%8C%D1%81%D1%8F%20%D0%A2%D0%BE%D0%BC%D0%B0%20%D0%BE%D1%82%20%D1%8D%D1%82%D0%BE%D0%B3%D0%BE%20%D0%BE%D1%82%D0%B3%D0%BE%D0%B2%D0%B0%D1%80%D0%B8%D0%B2%D0%B0%D1%82%D1%8C.)
^ru-Q0496-answer

**ru-Q0497** — Я буду занят всю неделю.

I'll be busy all week.

Why: Future constructions. [[Russian#^ru-Q0497|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%83%D0%B4%D1%83%20%D0%B7%D0%B0%D0%BD%D1%8F%D1%82%20%D0%B2%D1%81%D1%8E%20%D0%BD%D0%B5%D0%B4%D0%B5%D0%BB%D1%8E.)
^ru-Q0497-answer

**ru-Q0498** — Я буду занят всю неделю.

I'll be busy all week.

Буду plus an imperfective infinitive expresses future activity. A perfective verb can form its future without буду. Буду alone can also mean will be.

Why: Future constructions. [[Russian#^ru-Q0498|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%83%D0%B4%D1%83%20%D0%B7%D0%B0%D0%BD%D1%8F%D1%82%20%D0%B2%D1%81%D1%8E%20%D0%BD%D0%B5%D0%B4%D0%B5%D0%BB%D1%8E.)
^ru-Q0498-answer

**ru-Q0499** — Мы будем скучать по Тому.

We'll miss Tom.

Expected form: **будем**

Why: Future constructions. [[Russian#^ru-Q0499|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%B1%D1%83%D0%B4%D0%B5%D0%BC%20%D1%81%D0%BA%D1%83%D1%87%D0%B0%D1%82%D1%8C%20%D0%BF%D0%BE%20%D0%A2%D0%BE%D0%BC%D1%83.)
^ru-Q0499-answer

**ru-Q0500** — Мы будем скучать по Тому.

We'll miss Tom.

Expected form: **будем**

Why: Future constructions. [[Russian#^ru-Q0500|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%B1%D1%83%D0%B4%D0%B5%D0%BC%20%D1%81%D0%BA%D1%83%D1%87%D0%B0%D1%82%D1%8C%20%D0%BF%D0%BE%20%D0%A2%D0%BE%D0%BC%D1%83.)
^ru-Q0500-answer


### Answers 501–550

**ru-Q0501** — Он пошёл домой через три часа.

He went home three hours later.

Expected form: **пошёл**

Why: Motion forms. [[Russian#^ru-Q0501|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D0%BF%D0%BE%D1%88%D1%91%D0%BB%20%D0%B4%D0%BE%D0%BC%D0%BE%D0%B9%20%D1%87%D0%B5%D1%80%D0%B5%D0%B7%20%D1%82%D1%80%D0%B8%20%D1%87%D0%B0%D1%81%D0%B0.)
^ru-Q0501-answer

**ru-Q0502** — Он пошёл домой через три часа.

He went home three hours later.

Why: Motion forms. [[Russian#^ru-Q0502|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D0%BF%D0%BE%D1%88%D1%91%D0%BB%20%D0%B4%D0%BE%D0%BC%D0%BE%D0%B9%20%D1%87%D0%B5%D1%80%D0%B5%D0%B7%20%D1%82%D1%80%D0%B8%20%D1%87%D0%B0%D1%81%D0%B0.)
^ru-Q0502-answer

**ru-Q0503** — Я ехал домой.

I was on my way home.

Why: Motion forms. [[Russian#^ru-Q0503|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B5%D1%85%D0%B0%D0%BB%20%D0%B4%D0%BE%D0%BC%D0%BE%D0%B9.)
^ru-Q0503-answer

**ru-Q0504** — Я ехал домой.

I was on my way home.

Motion verbs distinguish travel on foot/vehicle and directed versus multidirectional/habitual patterns. Prefixes add direction and other meanings. The English verb go hides distinctions Russian expresses.

Why: Motion forms. [[Russian#^ru-Q0504|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B5%D1%85%D0%B0%D0%BB%20%D0%B4%D0%BE%D0%BC%D0%BE%D0%B9.)
^ru-Q0504-answer

**ru-Q0505** — Дома я хожу без обуви.

I don't wear shoes in my house.

Expected form: **хожу**

Why: Motion forms. [[Russian#^ru-Q0505|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D0%BE%D0%BC%D0%B0%20%D1%8F%20%D1%85%D0%BE%D0%B6%D1%83%20%D0%B1%D0%B5%D0%B7%20%D0%BE%D0%B1%D1%83%D0%B2%D0%B8.)
^ru-Q0505-answer

**ru-Q0506** — Дома я хожу без обуви.

I don't wear shoes in my house.

Expected form: **хожу**

Why: Motion forms. [[Russian#^ru-Q0506|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D0%BE%D0%BC%D0%B0%20%D1%8F%20%D1%85%D0%BE%D0%B6%D1%83%20%D0%B1%D0%B5%D0%B7%20%D0%BE%D0%B1%D1%83%D0%B2%D0%B8.)
^ru-Q0506-answer

**ru-Q0507** — Я ни иду, ни бегу.

I neither walk nor run.

Expected form: **иду**

Why: Motion forms. [[Russian#^ru-Q0507|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B8%20%D0%B8%D0%B4%D1%83%2C%20%D0%BD%D0%B8%20%D0%B1%D0%B5%D0%B3%D1%83.)
^ru-Q0507-answer

**ru-Q0508** — Я ни иду, ни бегу.

I neither walk nor run.

Why: Motion forms. [[Russian#^ru-Q0508|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B8%20%D0%B8%D0%B4%D1%83%2C%20%D0%BD%D0%B8%20%D0%B1%D0%B5%D0%B3%D1%83.)
^ru-Q0508-answer

**ru-Q0509** — Я хожу в университет.

I go to university.

Why: Motion forms. [[Russian#^ru-Q0509|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%85%D0%BE%D0%B6%D1%83%20%D0%B2%20%D1%83%D0%BD%D0%B8%D0%B2%D0%B5%D1%80%D1%81%D0%B8%D1%82%D0%B5%D1%82.)
^ru-Q0509-answer

**ru-Q0510** — Я хожу в университет.

I go to university.

Motion verbs distinguish travel on foot/vehicle and directed versus multidirectional/habitual patterns. Prefixes add direction and other meanings. The English verb go hides distinctions Russian expresses.

Why: Motion forms. [[Russian#^ru-Q0510|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%85%D0%BE%D0%B6%D1%83%20%D0%B2%20%D1%83%D0%BD%D0%B8%D0%B2%D0%B5%D1%80%D1%81%D0%B8%D1%82%D0%B5%D1%82.)
^ru-Q0510-answer

**ru-Q0511** — Пусть Том идёт домой один.

Let Tom go home by himself.

Expected form: **идёт**

Why: Motion forms. [[Russian#^ru-Q0511|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D1%83%D1%81%D1%82%D1%8C%20%D0%A2%D0%BE%D0%BC%20%D0%B8%D0%B4%D1%91%D1%82%20%D0%B4%D0%BE%D0%BC%D0%BE%D0%B9%20%D0%BE%D0%B4%D0%B8%D0%BD.)
^ru-Q0511-answer

**ru-Q0512** — Пусть Том идёт домой один.

Let Tom go home by himself.

Expected form: **идёт**

Why: Motion forms. [[Russian#^ru-Q0512|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D1%83%D1%81%D1%82%D1%8C%20%D0%A2%D0%BE%D0%BC%20%D0%B8%D0%B4%D1%91%D1%82%20%D0%B4%D0%BE%D0%BC%D0%BE%D0%B9%20%D0%BE%D0%B4%D0%B8%D0%BD.)
^ru-Q0512-answer

**ru-Q0513** — Я пошёл в парк поиграть.

I went to the park to play.

Expected form: **пошёл**

Why: Motion forms. [[Russian#^ru-Q0513|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BF%D0%BE%D1%88%D1%91%D0%BB%20%D0%B2%20%D0%BF%D0%B0%D1%80%D0%BA%20%D0%BF%D0%BE%D0%B8%D0%B3%D1%80%D0%B0%D1%82%D1%8C.)
^ru-Q0513-answer

**ru-Q0514** — Я пошёл в парк поиграть.

I went to the park to play.

Why: Motion forms. [[Russian#^ru-Q0514|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BF%D0%BE%D1%88%D1%91%D0%BB%20%D0%B2%20%D0%BF%D0%B0%D1%80%D0%BA%20%D0%BF%D0%BE%D0%B8%D0%B3%D1%80%D0%B0%D1%82%D1%8C.)
^ru-Q0514-answer

**ru-Q0515** — Она ходит в вечернюю школу.

She goes to night school.

Why: Motion forms. [[Russian#^ru-Q0515|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D1%85%D0%BE%D0%B4%D0%B8%D1%82%20%D0%B2%20%D0%B2%D0%B5%D1%87%D0%B5%D1%80%D0%BD%D1%8E%D1%8E%20%D1%88%D0%BA%D0%BE%D0%BB%D1%83.)
^ru-Q0515-answer

**ru-Q0516** — Она ходит в вечернюю школу.

She goes to night school.

Motion verbs distinguish travel on foot/vehicle and directed versus multidirectional/habitual patterns. Prefixes add direction and other meanings. The English verb go hides distinctions Russian expresses.

Why: Motion forms. [[Russian#^ru-Q0516|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D1%85%D0%BE%D0%B4%D0%B8%D1%82%20%D0%B2%20%D0%B2%D0%B5%D1%87%D0%B5%D1%80%D0%BD%D1%8E%D1%8E%20%D1%88%D0%BA%D0%BE%D0%BB%D1%83.)
^ru-Q0516-answer

**ru-Q0517** — Я правильно иду?

Am I on the right road?

Expected form: **иду**

Why: Motion forms. [[Russian#^ru-Q0517|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BF%D1%80%D0%B0%D0%B2%D0%B8%D0%BB%D1%8C%D0%BD%D0%BE%20%D0%B8%D0%B4%D1%83%3F)
^ru-Q0517-answer

**ru-Q0518** — Я правильно иду?

Am I on the right road?

Expected form: **иду**

Why: Motion forms. [[Russian#^ru-Q0518|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BF%D1%80%D0%B0%D0%B2%D0%B8%D0%BB%D1%8C%D0%BD%D0%BE%20%D0%B8%D0%B4%D1%83%3F)
^ru-Q0518-answer

**ru-Q0519** — Я нечасто хожу в вельветовых брюках.

I don't often wear corduroys.

Expected form: **хожу**

Why: Motion forms. [[Russian#^ru-Q0519|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%D1%87%D0%B0%D1%81%D1%82%D0%BE%20%D1%85%D0%BE%D0%B6%D1%83%20%D0%B2%20%D0%B2%D0%B5%D0%BB%D1%8C%D0%B2%D0%B5%D1%82%D0%BE%D0%B2%D1%8B%D1%85%20%D0%B1%D1%80%D1%8E%D0%BA%D0%B0%D1%85.)
^ru-Q0519-answer

**ru-Q0520** — Я нечасто хожу в вельветовых брюках.

I don't often wear corduroys.

Why: Motion forms. [[Russian#^ru-Q0520|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%D1%87%D0%B0%D1%81%D1%82%D0%BE%20%D1%85%D0%BE%D0%B6%D1%83%20%D0%B2%20%D0%B2%D0%B5%D0%BB%D1%8C%D0%B2%D0%B5%D1%82%D0%BE%D0%B2%D1%8B%D1%85%20%D0%B1%D1%80%D1%8E%D0%BA%D0%B0%D1%85.)
^ru-Q0520-answer

**ru-Q0521** — Он не пошел туда.

He didn't go there.

Why: Motion forms. [[Russian#^ru-Q0521|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D0%BD%D0%B5%20%D0%BF%D0%BE%D1%88%D0%B5%D0%BB%20%D1%82%D1%83%D0%B4%D0%B0.)
^ru-Q0521-answer

**ru-Q0522** — Он не пошел туда.

He didn't go there.

Motion verbs distinguish travel on foot/vehicle and directed versus multidirectional/habitual patterns. Prefixes add direction and other meanings. The English verb go hides distinctions Russian expresses.

Why: Motion forms. [[Russian#^ru-Q0522|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D0%BD%D0%B5%20%D0%BF%D0%BE%D1%88%D0%B5%D0%BB%20%D1%82%D1%83%D0%B4%D0%B0.)
^ru-Q0522-answer

**ru-Q0523** — Он жаловался на еду.

He complained about the food.

Expected form: **еду**

Why: Motion forms. [[Russian#^ru-Q0523|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D0%B6%D0%B0%D0%BB%D0%BE%D0%B2%D0%B0%D0%BB%D1%81%D1%8F%20%D0%BD%D0%B0%20%D0%B5%D0%B4%D1%83.)
^ru-Q0523-answer

**ru-Q0524** — Он жаловался на еду.

He complained about the food.

Expected form: **еду**

Why: Motion forms. [[Russian#^ru-Q0524|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D0%B6%D0%B0%D0%BB%D0%BE%D0%B2%D0%B0%D0%BB%D1%81%D1%8F%20%D0%BD%D0%B0%20%D0%B5%D0%B4%D1%83.)
^ru-Q0524-answer

**ru-Q0525** — Он ходит в библиотеку читать книги.

He goes to the library to read books.

Expected form: **ходит**

Why: Motion forms. [[Russian#^ru-Q0525|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D1%85%D0%BE%D0%B4%D0%B8%D1%82%20%D0%B2%20%D0%B1%D0%B8%D0%B1%D0%BB%D0%B8%D0%BE%D1%82%D0%B5%D0%BA%D1%83%20%D1%87%D0%B8%D1%82%D0%B0%D1%82%D1%8C%20%D0%BA%D0%BD%D0%B8%D0%B3%D0%B8.)
^ru-Q0525-answer

**ru-Q0526** — Он ходит в библиотеку читать книги.

He goes to the library to read books.

Why: Motion forms. [[Russian#^ru-Q0526|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D1%85%D0%BE%D0%B4%D0%B8%D1%82%20%D0%B2%20%D0%B1%D0%B8%D0%B1%D0%BB%D0%B8%D0%BE%D1%82%D0%B5%D0%BA%D1%83%20%D1%87%D0%B8%D1%82%D0%B0%D1%82%D1%8C%20%D0%BA%D0%BD%D0%B8%D0%B3%D0%B8.)
^ru-Q0526-answer

**ru-Q0527** — Какую еду ты ел?

What kind of meal did you eat?

Why: Motion forms. [[Russian#^ru-Q0527|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%B0%D0%BA%D1%83%D1%8E%20%D0%B5%D0%B4%D1%83%20%D1%82%D1%8B%20%D0%B5%D0%BB%3F)
^ru-Q0527-answer

**ru-Q0528** — Какую еду ты ел?

What kind of meal did you eat?

Motion verbs distinguish travel on foot/vehicle and directed versus multidirectional/habitual patterns. Prefixes add direction and other meanings. The English verb go hides distinctions Russian expresses.

Why: Motion forms. [[Russian#^ru-Q0528|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%B0%D0%BA%D1%83%D1%8E%20%D0%B5%D0%B4%D1%83%20%D1%82%D1%8B%20%D0%B5%D0%BB%3F)
^ru-Q0528-answer

**ru-Q0529** — Я хожу в ресторан раз в пятилетку.

I go to a restaurant once in a blue moon.

Expected form: **хожу**

Why: Motion forms. [[Russian#^ru-Q0529|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%85%D0%BE%D0%B6%D1%83%20%D0%B2%20%D1%80%D0%B5%D1%81%D1%82%D0%BE%D1%80%D0%B0%D0%BD%20%D1%80%D0%B0%D0%B7%20%D0%B2%20%D0%BF%D1%8F%D1%82%D0%B8%D0%BB%D0%B5%D1%82%D0%BA%D1%83.)
^ru-Q0529-answer

**ru-Q0530** — Я хожу в ресторан раз в пятилетку.

I go to a restaurant once in a blue moon.

Expected form: **хожу**

Why: Motion forms. [[Russian#^ru-Q0530|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%85%D0%BE%D0%B6%D1%83%20%D0%B2%20%D1%80%D0%B5%D1%81%D1%82%D0%BE%D1%80%D0%B0%D0%BD%20%D1%80%D0%B0%D0%B7%20%D0%B2%20%D0%BF%D1%8F%D1%82%D0%B8%D0%BB%D0%B5%D1%82%D0%BA%D1%83.)
^ru-Q0530-answer

**ru-Q0531** — Том пошёл на кухню, чтобы помыть руки.

Tom went to the kitchen to wash his hands.

Expected form: **пошёл**

Why: Motion forms. [[Russian#^ru-Q0531|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BF%D0%BE%D1%88%D1%91%D0%BB%20%D0%BD%D0%B0%20%D0%BA%D1%83%D1%85%D0%BD%D1%8E%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D0%BF%D0%BE%D0%BC%D1%8B%D1%82%D1%8C%20%D1%80%D1%83%D0%BA%D0%B8.)
^ru-Q0531-answer

**ru-Q0532** — Том пошёл на кухню, чтобы помыть руки.

Tom went to the kitchen to wash his hands.

Why: Motion forms. [[Russian#^ru-Q0532|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BF%D0%BE%D1%88%D1%91%D0%BB%20%D0%BD%D0%B0%20%D0%BA%D1%83%D1%85%D0%BD%D1%8E%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D0%BF%D0%BE%D0%BC%D1%8B%D1%82%D1%8C%20%D1%80%D1%83%D0%BA%D0%B8.)
^ru-Q0532-answer

**ru-Q0533** — Собака ест свою еду.

The dog is eating its food.

Why: Motion forms. [[Russian#^ru-Q0533|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BE%D0%B1%D0%B0%D0%BA%D0%B0%20%D0%B5%D1%81%D1%82%20%D1%81%D0%B2%D0%BE%D1%8E%20%D0%B5%D0%B4%D1%83.)
^ru-Q0533-answer

**ru-Q0534** — Собака ест свою еду.

The dog is eating its food.

Motion verbs distinguish travel on foot/vehicle and directed versus multidirectional/habitual patterns. Prefixes add direction and other meanings. The English verb go hides distinctions Russian expresses.

Why: Motion forms. [[Russian#^ru-Q0534|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BE%D0%B1%D0%B0%D0%BA%D0%B0%20%D0%B5%D1%81%D1%82%20%D1%81%D0%B2%D0%BE%D1%8E%20%D0%B5%D0%B4%D1%83.)
^ru-Q0534-answer

**ru-Q0535** — Моя бабушка по вечерам ходит гулять.

My grandmother goes for a walk in the evening.

Expected form: **ходит**

Why: Motion forms. [[Russian#^ru-Q0535|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D1%8F%20%D0%B1%D0%B0%D0%B1%D1%83%D1%88%D0%BA%D0%B0%20%D0%BF%D0%BE%20%D0%B2%D0%B5%D1%87%D0%B5%D1%80%D0%B0%D0%BC%20%D1%85%D0%BE%D0%B4%D0%B8%D1%82%20%D0%B3%D1%83%D0%BB%D1%8F%D1%82%D1%8C.)
^ru-Q0535-answer

**ru-Q0536** — Моя бабушка по вечерам ходит гулять.

My grandmother goes for a walk in the evening.

Expected form: **ходит**

Why: Motion forms. [[Russian#^ru-Q0536|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D1%8F%20%D0%B1%D0%B0%D0%B1%D1%83%D1%88%D0%BA%D0%B0%20%D0%BF%D0%BE%20%D0%B2%D0%B5%D1%87%D0%B5%D1%80%D0%B0%D0%BC%20%D1%85%D0%BE%D0%B4%D0%B8%D1%82%20%D0%B3%D1%83%D0%BB%D1%8F%D1%82%D1%8C.)
^ru-Q0536-answer

**ru-Q0537** — Том не солит еду, которую готовит.

Tom doesn't use salt in his cooking.

Expected form: **еду**

Why: Motion forms. [[Russian#^ru-Q0537|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D1%81%D0%BE%D0%BB%D0%B8%D1%82%20%D0%B5%D0%B4%D1%83%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%83%D1%8E%20%D0%B3%D0%BE%D1%82%D0%BE%D0%B2%D0%B8%D1%82.)
^ru-Q0537-answer

**ru-Q0538** — Том не солит еду, которую готовит.

Tom doesn't use salt in his cooking.

Why: Motion forms. [[Russian#^ru-Q0538|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D1%81%D0%BE%D0%BB%D0%B8%D1%82%20%D0%B5%D0%B4%D1%83%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%83%D1%8E%20%D0%B3%D0%BE%D1%82%D0%BE%D0%B2%D0%B8%D1%82.)
^ru-Q0538-answer

**ru-Q0539** — Я иду в школу пешком.

I'm walking to school.

Why: Motion forms. [[Russian#^ru-Q0539|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B8%D0%B4%D1%83%20%D0%B2%20%D1%88%D0%BA%D0%BE%D0%BB%D1%83%20%D0%BF%D0%B5%D1%88%D0%BA%D0%BE%D0%BC.)
^ru-Q0539-answer

**ru-Q0540** — Я иду в школу пешком.

I'm walking to school.

Motion verbs distinguish travel on foot/vehicle and directed versus multidirectional/habitual patterns. Prefixes add direction and other meanings. The English verb go hides distinctions Russian expresses.

Why: Motion forms. [[Russian#^ru-Q0540|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B8%D0%B4%D1%83%20%D0%B2%20%D1%88%D0%BA%D0%BE%D0%BB%D1%83%20%D0%BF%D0%B5%D1%88%D0%BA%D0%BE%D0%BC.)
^ru-Q0540-answer

**ru-Q0541** — Как всегда, он пошёл на работу небритый.

As always, he went to work without shaving.

Expected form: **пошёл**

Why: Motion forms. [[Russian#^ru-Q0541|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%B0%D0%BA%20%D0%B2%D1%81%D0%B5%D0%B3%D0%B4%D0%B0%2C%20%D0%BE%D0%BD%20%D0%BF%D0%BE%D1%88%D1%91%D0%BB%20%D0%BD%D0%B0%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%83%20%D0%BD%D0%B5%D0%B1%D1%80%D0%B8%D1%82%D1%8B%D0%B9.)
^ru-Q0541-answer

**ru-Q0542** — Как всегда, он пошёл на работу небритый.

As always, he went to work without shaving.

Expected form: **пошёл**

Why: Motion forms. [[Russian#^ru-Q0542|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%B0%D0%BA%20%D0%B2%D1%81%D0%B5%D0%B3%D0%B4%D0%B0%2C%20%D0%BE%D0%BD%20%D0%BF%D0%BE%D1%88%D1%91%D0%BB%20%D0%BD%D0%B0%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%83%20%D0%BD%D0%B5%D0%B1%D1%80%D0%B8%D1%82%D1%8B%D0%B9.)
^ru-Q0542-answer

**ru-Q0543** — Мы как раз собирались выходить, когда пошёл дождь.

We were just about to leave when it started to rain.

Expected form: **пошёл**

Why: Motion forms. [[Russian#^ru-Q0543|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%BA%D0%B0%D0%BA%20%D1%80%D0%B0%D0%B7%20%D1%81%D0%BE%D0%B1%D0%B8%D1%80%D0%B0%D0%BB%D0%B8%D1%81%D1%8C%20%D0%B2%D1%8B%D1%85%D0%BE%D0%B4%D0%B8%D1%82%D1%8C%2C%20%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%BF%D0%BE%D1%88%D1%91%D0%BB%20%D0%B4%D0%BE%D0%B6%D0%B4%D1%8C.)
^ru-Q0543-answer

**ru-Q0544** — Мы как раз собирались выходить, когда пошёл дождь.

We were just about to leave when it started to rain.

Why: Motion forms. [[Russian#^ru-Q0544|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%BA%D0%B0%D0%BA%20%D1%80%D0%B0%D0%B7%20%D1%81%D0%BE%D0%B1%D0%B8%D1%80%D0%B0%D0%BB%D0%B8%D1%81%D1%8C%20%D0%B2%D1%8B%D1%85%D0%BE%D0%B4%D0%B8%D1%82%D1%8C%2C%20%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%BF%D0%BE%D1%88%D1%91%D0%BB%20%D0%B4%D0%BE%D0%B6%D0%B4%D1%8C.)
^ru-Q0544-answer

**ru-Q0545** — Этот цвет тебе не идёт.

This color doesn't suit you.

Why: Motion forms. [[Russian#^ru-Q0545|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D1%82%D0%BE%D1%82%20%D1%86%D0%B2%D0%B5%D1%82%20%D1%82%D0%B5%D0%B1%D0%B5%20%D0%BD%D0%B5%20%D0%B8%D0%B4%D1%91%D1%82.)
^ru-Q0545-answer

**ru-Q0546** — Этот цвет тебе не идёт.

This color doesn't suit you.

Motion verbs distinguish travel on foot/vehicle and directed versus multidirectional/habitual patterns. Prefixes add direction and other meanings. The English verb go hides distinctions Russian expresses.

Why: Motion forms. [[Russian#^ru-Q0546|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D1%82%D0%BE%D1%82%20%D1%86%D0%B2%D0%B5%D1%82%20%D1%82%D0%B5%D0%B1%D0%B5%20%D0%BD%D0%B5%20%D0%B8%D0%B4%D1%91%D1%82.)
^ru-Q0546-answer

**ru-Q0547** — Я еду с ним в Бостон.

I'm going with him to Boston.

Expected form: **еду**

Why: Motion forms. [[Russian#^ru-Q0547|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B5%D0%B4%D1%83%20%D1%81%20%D0%BD%D0%B8%D0%BC%20%D0%B2%20%D0%91%D0%BE%D1%81%D1%82%D0%BE%D0%BD.)
^ru-Q0547-answer

**ru-Q0548** — Я еду с ним в Бостон.

I'm going with him to Boston.

Expected form: **еду**

Why: Motion forms. [[Russian#^ru-Q0548|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B5%D0%B4%D1%83%20%D1%81%20%D0%BD%D0%B8%D0%BC%20%D0%B2%20%D0%91%D0%BE%D1%81%D1%82%D0%BE%D0%BD.)
^ru-Q0548-answer

**ru-Q0549** — Она едет во Францию на следующей неделе.

She is going to France next week.

Expected form: **едет**

Why: Motion forms. [[Russian#^ru-Q0549|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D0%B5%D0%B4%D0%B5%D1%82%20%D0%B2%D0%BE%20%D0%A4%D1%80%D0%B0%D0%BD%D1%86%D0%B8%D1%8E%20%D0%BD%D0%B0%20%D1%81%D0%BB%D0%B5%D0%B4%D1%83%D1%8E%D1%89%D0%B5%D0%B9%20%D0%BD%D0%B5%D0%B4%D0%B5%D0%BB%D0%B5.)
^ru-Q0549-answer

**ru-Q0550** — Она едет во Францию на следующей неделе.

She is going to France next week.

Why: Motion forms. [[Russian#^ru-Q0550|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D0%B5%D0%B4%D0%B5%D1%82%20%D0%B2%D0%BE%20%D0%A4%D1%80%D0%B0%D0%BD%D1%86%D0%B8%D1%8E%20%D0%BD%D0%B0%20%D1%81%D0%BB%D0%B5%D0%B4%D1%83%D1%8E%D1%89%D0%B5%D0%B9%20%D0%BD%D0%B5%D0%B4%D0%B5%D0%BB%D0%B5.)
^ru-Q0550-answer


### Answers 551–600

**ru-Q0551** — Рыбы не любят солнечный свет.

Fish don't like sunlight.

Why: Negation. [[Russian#^ru-Q0551|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A0%D1%8B%D0%B1%D1%8B%20%D0%BD%D0%B5%20%D0%BB%D1%8E%D0%B1%D1%8F%D1%82%20%D1%81%D0%BE%D0%BB%D0%BD%D0%B5%D1%87%D0%BD%D1%8B%D0%B9%20%D1%81%D0%B2%D0%B5%D1%82.)
^ru-Q0551-answer

**ru-Q0552** — Рыбы не любят солнечный свет.

Fish don't like sunlight.

Не negates a predicate or constituent; нет states absence/existence negation and commonly governs genitive. Negative pronouns can participate in negative concord. Нельзя can express prohibition or impossibility.

Why: Negation. [[Russian#^ru-Q0552|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A0%D1%8B%D0%B1%D1%8B%20%D0%BD%D0%B5%20%D0%BB%D1%8E%D0%B1%D1%8F%D1%82%20%D1%81%D0%BE%D0%BB%D0%BD%D0%B5%D1%87%D0%BD%D1%8B%D0%B9%20%D1%81%D0%B2%D0%B5%D1%82.)
^ru-Q0552-answer

**ru-Q0553** — Тому не пришлось ничего объяснять.

Tom didn't have to explain anything.

Expected form: **не**

Why: Negation. [[Russian#^ru-Q0553|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%D1%83%20%D0%BD%D0%B5%20%D0%BF%D1%80%D0%B8%D1%88%D0%BB%D0%BE%D1%81%D1%8C%20%D0%BD%D0%B8%D1%87%D0%B5%D0%B3%D0%BE%20%D0%BE%D0%B1%D1%8A%D1%8F%D1%81%D0%BD%D1%8F%D1%82%D1%8C.)
^ru-Q0553-answer

**ru-Q0554** — Тому не пришлось ничего объяснять.

Tom didn't have to explain anything.

Expected form: **не**

Why: Negation. [[Russian#^ru-Q0554|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%D1%83%20%D0%BD%D0%B5%20%D0%BF%D1%80%D0%B8%D1%88%D0%BB%D0%BE%D1%81%D1%8C%20%D0%BD%D0%B8%D1%87%D0%B5%D0%B3%D0%BE%20%D0%BE%D0%B1%D1%8A%D1%8F%D1%81%D0%BD%D1%8F%D1%82%D1%8C.)
^ru-Q0554-answer

**ru-Q0555** — Том не лентяй.

Tom isn't lazy.

Expected form: **не**

Why: Negation. [[Russian#^ru-Q0555|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D0%BB%D0%B5%D0%BD%D1%82%D1%8F%D0%B9.)
^ru-Q0555-answer

**ru-Q0556** — Том не лентяй.

Tom isn't lazy.

Why: Negation. [[Russian#^ru-Q0556|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D0%BB%D0%B5%D0%BD%D1%82%D1%8F%D0%B9.)
^ru-Q0556-answer

**ru-Q0557** — Я не смотрел.

I didn't look.

Why: Negation. [[Russian#^ru-Q0557|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D1%81%D0%BC%D0%BE%D1%82%D1%80%D0%B5%D0%BB.)
^ru-Q0557-answer

**ru-Q0558** — Я не смотрел.

I didn't look.

Не negates a predicate or constituent; нет states absence/existence negation and commonly governs genitive. Negative pronouns can participate in negative concord. Нельзя can express prohibition or impossibility.

Why: Negation. [[Russian#^ru-Q0558|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D1%81%D0%BC%D0%BE%D1%82%D1%80%D0%B5%D0%BB.)
^ru-Q0558-answer

**ru-Q0559** — Тут ничего нет.

There's nothing in here.

Expected form: **ничего**

Why: Negation. [[Russian#^ru-Q0559|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%83%D1%82%20%D0%BD%D0%B8%D1%87%D0%B5%D0%B3%D0%BE%20%D0%BD%D0%B5%D1%82.)
^ru-Q0559-answer

**ru-Q0560** — Тут ничего нет.

There's nothing in here.

Expected form: **ничего**

Why: Negation. [[Russian#^ru-Q0560|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%83%D1%82%20%D0%BD%D0%B8%D1%87%D0%B5%D0%B3%D0%BE%20%D0%BD%D0%B5%D1%82.)
^ru-Q0560-answer

**ru-Q0561** — Я не люблю горячую пищу.

I don't like hot food.

Expected form: **не**

Why: Negation. [[Russian#^ru-Q0561|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D0%BB%D1%8E%D0%B1%D0%BB%D1%8E%20%D0%B3%D0%BE%D1%80%D1%8F%D1%87%D1%83%D1%8E%20%D0%BF%D0%B8%D1%89%D1%83.)
^ru-Q0561-answer

**ru-Q0562** — Я не люблю горячую пищу.

I don't like hot food.

Why: Negation. [[Russian#^ru-Q0562|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D0%BB%D1%8E%D0%B1%D0%BB%D1%8E%20%D0%B3%D0%BE%D1%80%D1%8F%D1%87%D1%83%D1%8E%20%D0%BF%D0%B8%D1%89%D1%83.)
^ru-Q0562-answer

**ru-Q0563** — Том не такой умный, как ты.

Tom isn't as intelligent as you.

Why: Negation. [[Russian#^ru-Q0563|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D1%82%D0%B0%D0%BA%D0%BE%D0%B9%20%D1%83%D0%BC%D0%BD%D1%8B%D0%B9%2C%20%D0%BA%D0%B0%D0%BA%20%D1%82%D1%8B.)
^ru-Q0563-answer

**ru-Q0564** — Том не такой умный, как ты.

Tom isn't as intelligent as you.

Не negates a predicate or constituent; нет states absence/existence negation and commonly governs genitive. Negative pronouns can participate in negative concord. Нельзя can express prohibition or impossibility.

Why: Negation. [[Russian#^ru-Q0564|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D1%82%D0%B0%D0%BA%D0%BE%D0%B9%20%D1%83%D0%BC%D0%BD%D1%8B%D0%B9%2C%20%D0%BA%D0%B0%D0%BA%20%D1%82%D1%8B.)
^ru-Q0564-answer

**ru-Q0565** — Я не знал, что она там.

I didn't know it was there.

Expected form: **не**

Why: Negation. [[Russian#^ru-Q0565|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D0%B7%D0%BD%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%BE%D0%BD%D0%B0%20%D1%82%D0%B0%D0%BC.)
^ru-Q0565-answer

**ru-Q0566** — Я не знал, что она там.

I didn't know it was there.

Expected form: **не**

Why: Negation. [[Russian#^ru-Q0566|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D0%B7%D0%BD%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%BE%D0%BD%D0%B0%20%D1%82%D0%B0%D0%BC.)
^ru-Q0566-answer

**ru-Q0567** — Я просто не люблю жену.

I just don't love my wife.

Expected form: **не**

Why: Negation. [[Russian#^ru-Q0567|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BF%D1%80%D0%BE%D1%81%D1%82%D0%BE%20%D0%BD%D0%B5%20%D0%BB%D1%8E%D0%B1%D0%BB%D1%8E%20%D0%B6%D0%B5%D0%BD%D1%83.)
^ru-Q0567-answer

**ru-Q0568** — Я просто не люблю жену.

I just don't love my wife.

Why: Negation. [[Russian#^ru-Q0568|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BF%D1%80%D0%BE%D1%81%D1%82%D0%BE%20%D0%BD%D0%B5%20%D0%BB%D1%8E%D0%B1%D0%BB%D1%8E%20%D0%B6%D0%B5%D0%BD%D1%83.)
^ru-Q0568-answer

**ru-Q0569** — Ты не мог бы подождать снаружи?

Could you wait outside?

Why: Negation. [[Russian#^ru-Q0569|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%BD%D0%B5%20%D0%BC%D0%BE%D0%B3%20%D0%B1%D1%8B%20%D0%BF%D0%BE%D0%B4%D0%BE%D0%B6%D0%B4%D0%B0%D1%82%D1%8C%20%D1%81%D0%BD%D0%B0%D1%80%D1%83%D0%B6%D0%B8%3F)
^ru-Q0569-answer

**ru-Q0570** — Ты не мог бы подождать снаружи?

Could you wait outside?

Не negates a predicate or constituent; нет states absence/existence negation and commonly governs genitive. Negative pronouns can participate in negative concord. Нельзя can express prohibition or impossibility.

Why: Negation. [[Russian#^ru-Q0570|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%BD%D0%B5%20%D0%BC%D0%BE%D0%B3%20%D0%B1%D1%8B%20%D0%BF%D0%BE%D0%B4%D0%BE%D0%B6%D0%B4%D0%B0%D1%82%D1%8C%20%D1%81%D0%BD%D0%B0%D1%80%D1%83%D0%B6%D0%B8%3F)
^ru-Q0570-answer

**ru-Q0571** — Не путай кометы и астероиды.

Don't confuse comets and asteroids.

Expected form: **Не**

Why: Negation. [[Russian#^ru-Q0571|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%20%D0%BF%D1%83%D1%82%D0%B0%D0%B9%20%D0%BA%D0%BE%D0%BC%D0%B5%D1%82%D1%8B%20%D0%B8%20%D0%B0%D1%81%D1%82%D0%B5%D1%80%D0%BE%D0%B8%D0%B4%D1%8B.)
^ru-Q0571-answer

**ru-Q0572** — Не путай кометы и астероиды.

Don't confuse comets and asteroids.

Expected form: **Не**

Why: Negation. [[Russian#^ru-Q0572|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%20%D0%BF%D1%83%D1%82%D0%B0%D0%B9%20%D0%BA%D0%BE%D0%BC%D0%B5%D1%82%D1%8B%20%D0%B8%20%D0%B0%D1%81%D1%82%D0%B5%D1%80%D0%BE%D0%B8%D0%B4%D1%8B.)
^ru-Q0572-answer

**ru-Q0573** — Я не хочу давать свой ключ Тому.

I don't want to give Tom my key.

Expected form: **не**

Why: Negation. [[Russian#^ru-Q0573|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D1%85%D0%BE%D1%87%D1%83%20%D0%B4%D0%B0%D0%B2%D0%B0%D1%82%D1%8C%20%D1%81%D0%B2%D0%BE%D0%B9%20%D0%BA%D0%BB%D1%8E%D1%87%20%D0%A2%D0%BE%D0%BC%D1%83.)
^ru-Q0573-answer

**ru-Q0574** — Я не хочу давать свой ключ Тому.

I don't want to give Tom my key.

Why: Negation. [[Russian#^ru-Q0574|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D1%85%D0%BE%D1%87%D1%83%20%D0%B4%D0%B0%D0%B2%D0%B0%D1%82%D1%8C%20%D1%81%D0%B2%D0%BE%D0%B9%20%D0%BA%D0%BB%D1%8E%D1%87%20%D0%A2%D0%BE%D0%BC%D1%83.)
^ru-Q0574-answer

**ru-Q0575** — Пожалуйста, не говори моей жене.

Please don't tell my wife.

Why: Negation. [[Russian#^ru-Q0575|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%BD%D0%B5%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%20%D0%BC%D0%BE%D0%B5%D0%B9%20%D0%B6%D0%B5%D0%BD%D0%B5.)
^ru-Q0575-answer

**ru-Q0576** — Пожалуйста, не говори моей жене.

Please don't tell my wife.

Не negates a predicate or constituent; нет states absence/existence negation and commonly governs genitive. Negative pronouns can participate in negative concord. Нельзя can express prohibition or impossibility.

Why: Negation. [[Russian#^ru-Q0576|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%BD%D0%B5%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%20%D0%BC%D0%BE%D0%B5%D0%B9%20%D0%B6%D0%B5%D0%BD%D0%B5.)
^ru-Q0576-answer

**ru-Q0577** — Ты раньше никогда этого не делала?

Haven't you ever done this before?

Expected form: **никогда**

Why: Negation. [[Russian#^ru-Q0577|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D1%80%D0%B0%D0%BD%D1%8C%D1%88%D0%B5%20%D0%BD%D0%B8%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D1%8D%D1%82%D0%BE%D0%B3%D0%BE%20%D0%BD%D0%B5%20%D0%B4%D0%B5%D0%BB%D0%B0%D0%BB%D0%B0%3F)
^ru-Q0577-answer

**ru-Q0578** — Ты раньше никогда этого не делала?

Haven't you ever done this before?

Expected form: **никогда**

Why: Negation. [[Russian#^ru-Q0578|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D1%80%D0%B0%D0%BD%D1%8C%D1%88%D0%B5%20%D0%BD%D0%B8%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D1%8D%D1%82%D0%BE%D0%B3%D0%BE%20%D0%BD%D0%B5%20%D0%B4%D0%B5%D0%BB%D0%B0%D0%BB%D0%B0%3F)
^ru-Q0578-answer

**ru-Q0579** — Она не хочет идти спать.

She does not want to go to bed.

Expected form: **не**

Why: Negation. [[Russian#^ru-Q0579|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D0%BD%D0%B5%20%D1%85%D0%BE%D1%87%D0%B5%D1%82%20%D0%B8%D0%B4%D1%82%D0%B8%20%D1%81%D0%BF%D0%B0%D1%82%D1%8C.)
^ru-Q0579-answer

**ru-Q0580** — Она не хочет идти спать.

She does not want to go to bed.

Why: Negation. [[Russian#^ru-Q0580|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D0%BD%D0%B5%20%D1%85%D0%BE%D1%87%D0%B5%D1%82%20%D0%B8%D0%B4%D1%82%D0%B8%20%D1%81%D0%BF%D0%B0%D1%82%D1%8C.)
^ru-Q0580-answer

**ru-Q0581** — Почему вы не послушали Тома?

Why didn't you listen to Tom?

Why: Negation. [[Russian#^ru-Q0581|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D0%B2%D1%8B%20%D0%BD%D0%B5%20%D0%BF%D0%BE%D1%81%D0%BB%D1%83%D1%88%D0%B0%D0%BB%D0%B8%20%D0%A2%D0%BE%D0%BC%D0%B0%3F)
^ru-Q0581-answer

**ru-Q0582** — Почему вы не послушали Тома?

Why didn't you listen to Tom?

Не negates a predicate or constituent; нет states absence/existence negation and commonly governs genitive. Negative pronouns can participate in negative concord. Нельзя can express prohibition or impossibility.

Why: Negation. [[Russian#^ru-Q0582|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D0%B2%D1%8B%20%D0%BD%D0%B5%20%D0%BF%D0%BE%D1%81%D0%BB%D1%83%D1%88%D0%B0%D0%BB%D0%B8%20%D0%A2%D0%BE%D0%BC%D0%B0%3F)
^ru-Q0582-answer

**ru-Q0583** — Ты уверен, что мы не можем отремонтировать этот фотоаппарат?

Are you sure we can't repair this camera?

Expected form: **не**

Why: Negation. [[Russian#^ru-Q0583|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D1%83%D0%B2%D0%B5%D1%80%D0%B5%D0%BD%2C%20%D1%87%D1%82%D0%BE%20%D0%BC%D1%8B%20%D0%BD%D0%B5%20%D0%BC%D0%BE%D0%B6%D0%B5%D0%BC%20%D0%BE%D1%82%D1%80%D0%B5%D0%BC%D0%BE%D0%BD%D1%82%D0%B8%D1%80%D0%BE%D0%B2%D0%B0%D1%82%D1%8C%20%D1%8D%D1%82%D0%BE%D1%82%20%D1%84%D0%BE%D1%82%D0%BE%D0%B0%D0%BF%D0%BF%D0%B0%D1%80%D0%B0%D1%82%3F)
^ru-Q0583-answer

**ru-Q0584** — Ты уверен, что мы не можем отремонтировать этот фотоаппарат?

Are you sure we can't repair this camera?

Expected form: **не**

Why: Negation. [[Russian#^ru-Q0584|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D1%83%D0%B2%D0%B5%D1%80%D0%B5%D0%BD%2C%20%D1%87%D1%82%D0%BE%20%D0%BC%D1%8B%20%D0%BD%D0%B5%20%D0%BC%D0%BE%D0%B6%D0%B5%D0%BC%20%D0%BE%D1%82%D1%80%D0%B5%D0%BC%D0%BE%D0%BD%D1%82%D0%B8%D1%80%D0%BE%D0%B2%D0%B0%D1%82%D1%8C%20%D1%8D%D1%82%D0%BE%D1%82%20%D1%84%D0%BE%D1%82%D0%BE%D0%B0%D0%BF%D0%BF%D0%B0%D1%80%D0%B0%D1%82%3F)
^ru-Q0584-answer

**ru-Q0585** — Том не просил Мэри, чтобы она этого не делала.

Tom didn't ask Mary not to do that.

Expected form: **не**

Why: Negation. [[Russian#^ru-Q0585|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D0%BF%D1%80%D0%BE%D1%81%D0%B8%D0%BB%20%D0%9C%D1%8D%D1%80%D0%B8%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D0%BE%D0%BD%D0%B0%20%D1%8D%D1%82%D0%BE%D0%B3%D0%BE%20%D0%BD%D0%B5%20%D0%B4%D0%B5%D0%BB%D0%B0%D0%BB%D0%B0.)
^ru-Q0585-answer

**ru-Q0586** — Том не просил Мэри, чтобы она этого не делала.

Tom didn't ask Mary not to do that.

Why: Negation. [[Russian#^ru-Q0586|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D0%BF%D1%80%D0%BE%D1%81%D0%B8%D0%BB%20%D0%9C%D1%8D%D1%80%D0%B8%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D0%BE%D0%BD%D0%B0%20%D1%8D%D1%82%D0%BE%D0%B3%D0%BE%20%D0%BD%D0%B5%20%D0%B4%D0%B5%D0%BB%D0%B0%D0%BB%D0%B0.)
^ru-Q0586-answer

**ru-Q0587** — Том не любит ходить в галстуке.

Tom doesn't like to wear ties.

Why: Negation. [[Russian#^ru-Q0587|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D0%BB%D1%8E%D0%B1%D0%B8%D1%82%20%D1%85%D0%BE%D0%B4%D0%B8%D1%82%D1%8C%20%D0%B2%20%D0%B3%D0%B0%D0%BB%D1%81%D1%82%D1%83%D0%BA%D0%B5.)
^ru-Q0587-answer

**ru-Q0588** — Том не любит ходить в галстуке.

Tom doesn't like to wear ties.

Не negates a predicate or constituent; нет states absence/existence negation and commonly governs genitive. Negative pronouns can participate in negative concord. Нельзя can express prohibition or impossibility.

Why: Negation. [[Russian#^ru-Q0588|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D0%BB%D1%8E%D0%B1%D0%B8%D1%82%20%D1%85%D0%BE%D0%B4%D0%B8%D1%82%D1%8C%20%D0%B2%20%D0%B3%D0%B0%D0%BB%D1%81%D1%82%D1%83%D0%BA%D0%B5.)
^ru-Q0588-answer

**ru-Q0589** — Том не хотел разочаровывать Мэри.

Tom didn't want to disappoint Mary.

Expected form: **не**

Why: Negation. [[Russian#^ru-Q0589|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%20%D1%80%D0%B0%D0%B7%D0%BE%D1%87%D0%B0%D1%80%D0%BE%D0%B2%D1%8B%D0%B2%D0%B0%D1%82%D1%8C%20%D0%9C%D1%8D%D1%80%D0%B8.)
^ru-Q0589-answer

**ru-Q0590** — Том не хотел разочаровывать Мэри.

Tom didn't want to disappoint Mary.

Expected form: **не**

Why: Negation. [[Russian#^ru-Q0590|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%20%D1%80%D0%B0%D0%B7%D0%BE%D1%87%D0%B0%D1%80%D0%BE%D0%B2%D1%8B%D0%B2%D0%B0%D1%82%D1%8C%20%D0%9C%D1%8D%D1%80%D0%B8.)
^ru-Q0590-answer

**ru-Q0591** — Том не тот парень, с которым стоит связываться.

Tom is the wrong guy to mess with.

Expected form: **не**

Why: Negation. [[Russian#^ru-Q0591|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D1%82%D0%BE%D1%82%20%D0%BF%D0%B0%D1%80%D0%B5%D0%BD%D1%8C%2C%20%D1%81%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%8B%D0%BC%20%D1%81%D1%82%D0%BE%D0%B8%D1%82%20%D1%81%D0%B2%D1%8F%D0%B7%D1%8B%D0%B2%D0%B0%D1%82%D1%8C%D1%81%D1%8F.)
^ru-Q0591-answer

**ru-Q0592** — Том не тот парень, с которым стоит связываться.

Tom is the wrong guy to mess with.

Why: Negation. [[Russian#^ru-Q0592|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D1%82%D0%BE%D1%82%20%D0%BF%D0%B0%D1%80%D0%B5%D0%BD%D1%8C%2C%20%D1%81%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%8B%D0%BC%20%D1%81%D1%82%D0%BE%D0%B8%D1%82%20%D1%81%D0%B2%D1%8F%D0%B7%D1%8B%D0%B2%D0%B0%D1%82%D1%8C%D1%81%D1%8F.)
^ru-Q0592-answer

**ru-Q0593** — Ты не знал, что Том хочет пойти?

Didn't you know where Tom wanted to go?

Why: Negation. [[Russian#^ru-Q0593|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%BD%D0%B5%20%D0%B7%D0%BD%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%A2%D0%BE%D0%BC%20%D1%85%D0%BE%D1%87%D0%B5%D1%82%20%D0%BF%D0%BE%D0%B9%D1%82%D0%B8%3F)
^ru-Q0593-answer

**ru-Q0594** — Ты не знал, что Том хочет пойти?

Didn't you know where Tom wanted to go?

Не negates a predicate or constituent; нет states absence/existence negation and commonly governs genitive. Negative pronouns can participate in negative concord. Нельзя can express prohibition or impossibility.

Why: Negation. [[Russian#^ru-Q0594|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%BD%D0%B5%20%D0%B7%D0%BD%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%A2%D0%BE%D0%BC%20%D1%85%D0%BE%D1%87%D0%B5%D1%82%20%D0%BF%D0%BE%D0%B9%D1%82%D0%B8%3F)
^ru-Q0594-answer

**ru-Q0595** — Я бы пришёл, даже если бы ты меня не пригласила.

I would've come even if you hadn't invited me.

Expected form: **не**

Why: Negation. [[Russian#^ru-Q0595|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%8B%20%D0%BF%D1%80%D0%B8%D1%88%D1%91%D0%BB%2C%20%D0%B4%D0%B0%D0%B6%D0%B5%20%D0%B5%D1%81%D0%BB%D0%B8%20%D0%B1%D1%8B%20%D1%82%D1%8B%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D0%BD%D0%B5%20%D0%BF%D1%80%D0%B8%D0%B3%D0%BB%D0%B0%D1%81%D0%B8%D0%BB%D0%B0.)
^ru-Q0595-answer

**ru-Q0596** — Я бы пришёл, даже если бы ты меня не пригласила.

I would've come even if you hadn't invited me.

Expected form: **не**

Why: Negation. [[Russian#^ru-Q0596|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%8B%20%D0%BF%D1%80%D0%B8%D1%88%D1%91%D0%BB%2C%20%D0%B4%D0%B0%D0%B6%D0%B5%20%D0%B5%D1%81%D0%BB%D0%B8%20%D0%B1%D1%8B%20%D1%82%D1%8B%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D0%BD%D0%B5%20%D0%BF%D1%80%D0%B8%D0%B3%D0%BB%D0%B0%D1%81%D0%B8%D0%BB%D0%B0.)
^ru-Q0596-answer

**ru-Q0597** — Есть люди, которые не любят шпинат.

There are people who don't like spinach.

Expected form: **не**

Why: Negation. [[Russian#^ru-Q0597|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D1%82%D1%8C%20%D0%BB%D1%8E%D0%B4%D0%B8%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%8B%D0%B5%20%D0%BD%D0%B5%20%D0%BB%D1%8E%D0%B1%D1%8F%D1%82%20%D1%88%D0%BF%D0%B8%D0%BD%D0%B0%D1%82.)
^ru-Q0597-answer

**ru-Q0598** — Есть люди, которые не любят шпинат.

There are people who don't like spinach.

Why: Negation. [[Russian#^ru-Q0598|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D1%82%D1%8C%20%D0%BB%D1%8E%D0%B4%D0%B8%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%8B%D0%B5%20%D0%BD%D0%B5%20%D0%BB%D1%8E%D0%B1%D1%8F%D1%82%20%D1%88%D0%BF%D0%B8%D0%BD%D0%B0%D1%82.)
^ru-Q0598-answer

**ru-Q0599** — Мы не смогли бы их убить.

We couldn't kill them.

Why: Negation. [[Russian#^ru-Q0599|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%BD%D0%B5%20%D1%81%D0%BC%D0%BE%D0%B3%D0%BB%D0%B8%20%D0%B1%D1%8B%20%D0%B8%D1%85%20%D1%83%D0%B1%D0%B8%D1%82%D1%8C.)
^ru-Q0599-answer

**ru-Q0600** — Мы не смогли бы их убить.

We couldn't kill them.

Не negates a predicate or constituent; нет states absence/existence negation and commonly governs genitive. Negative pronouns can participate in negative concord. Нельзя can express prohibition or impossibility.

Why: Negation. [[Russian#^ru-Q0600|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%BD%D0%B5%20%D1%81%D0%BC%D0%BE%D0%B3%D0%BB%D0%B8%20%D0%B1%D1%8B%20%D0%B8%D1%85%20%D1%83%D0%B1%D0%B8%D1%82%D1%8C.)
^ru-Q0600-answer


### Answers 601–650

**ru-Q0601** — Тому нужно внимание.

Tom needs attention.

Expected form: **нужно**

Why: Modal and impersonal words. [[Russian#^ru-Q0601|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%D1%83%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D0%B2%D0%BD%D0%B8%D0%BC%D0%B0%D0%BD%D0%B8%D0%B5.)
^ru-Q0601-answer

**ru-Q0602** — Тому нужно внимание.

Tom needs attention.

Expected form: **нужно**

Why: Modal and impersonal words. [[Russian#^ru-Q0602|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%D1%83%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D0%B2%D0%BD%D0%B8%D0%BC%D0%B0%D0%BD%D0%B8%D0%B5.)
^ru-Q0602-answer

**ru-Q0603** — Тому нужно, чтобы Мэри кто-нибудь помог.

Tom needs somebody to help Mary.

Expected form: **нужно**

Why: Modal and impersonal words. [[Russian#^ru-Q0603|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%D1%83%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D0%9C%D1%8D%D1%80%D0%B8%20%D0%BA%D1%82%D0%BE-%D0%BD%D0%B8%D0%B1%D1%83%D0%B4%D1%8C%20%D0%BF%D0%BE%D0%BC%D0%BE%D0%B3.)
^ru-Q0603-answer

**ru-Q0604** — Тому нужно, чтобы Мэри кто-нибудь помог.

Tom needs somebody to help Mary.

Why: Modal and impersonal words. [[Russian#^ru-Q0604|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%D1%83%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D0%9C%D1%8D%D1%80%D0%B8%20%D0%BA%D1%82%D0%BE-%D0%BD%D0%B8%D0%B1%D1%83%D0%B4%D1%8C%20%D0%BF%D0%BE%D0%BC%D0%BE%D0%B3.)
^ru-Q0604-answer

**ru-Q0605** — Я думал, может, это вы.

I thought it might be you.

Why: Modal and impersonal words. [[Russian#^ru-Q0605|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B4%D1%83%D0%BC%D0%B0%D0%BB%2C%20%D0%BC%D0%BE%D0%B6%D0%B5%D1%82%2C%20%D1%8D%D1%82%D0%BE%20%D0%B2%D1%8B.)
^ru-Q0605-answer

**ru-Q0606** — Я думал, может, это вы.

I thought it might be you.

Modality can be expressed with verbs or impersonal predicates. Нужно/надо often combine with a dative experiencer and infinitive. Может can also be a verb meaning can; context distinguishes inference.

Why: Modal and impersonal words. [[Russian#^ru-Q0606|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B4%D1%83%D0%BC%D0%B0%D0%BB%2C%20%D0%BC%D0%BE%D0%B6%D0%B5%D1%82%2C%20%D1%8D%D1%82%D0%BE%20%D0%B2%D1%8B.)
^ru-Q0606-answer

**ru-Q0607** — Тому уже нужно уезжать?

Does Tom need to leave now?

Expected form: **нужно**

Why: Modal and impersonal words. [[Russian#^ru-Q0607|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%D1%83%20%D1%83%D0%B6%D0%B5%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D1%83%D0%B5%D0%B7%D0%B6%D0%B0%D1%82%D1%8C%3F)
^ru-Q0607-answer

**ru-Q0608** — Тому уже нужно уезжать?

Does Tom need to leave now?

Expected form: **нужно**

Why: Modal and impersonal words. [[Russian#^ru-Q0608|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%D1%83%20%D1%83%D0%B6%D0%B5%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D1%83%D0%B5%D0%B7%D0%B6%D0%B0%D1%82%D1%8C%3F)
^ru-Q0608-answer

**ru-Q0609** — Чтобы сделать жизнь счастливой, надо любить повседневные мелочи.

In order to make life happy, you must love the everyday trifles.

Expected form: **надо**

Why: Modal and impersonal words. [[Russian#^ru-Q0609|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A7%D1%82%D0%BE%D0%B1%D1%8B%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C%20%D0%B6%D0%B8%D0%B7%D0%BD%D1%8C%20%D1%81%D1%87%D0%B0%D1%81%D1%82%D0%BB%D0%B8%D0%B2%D0%BE%D0%B9%2C%20%D0%BD%D0%B0%D0%B4%D0%BE%20%D0%BB%D1%8E%D0%B1%D0%B8%D1%82%D1%8C%20%D0%BF%D0%BE%D0%B2%D1%81%D0%B5%D0%B4%D0%BD%D0%B5%D0%B2%D0%BD%D1%8B%D0%B5%20%D0%BC%D0%B5%D0%BB%D0%BE%D1%87%D0%B8.)
^ru-Q0609-answer

**ru-Q0610** — Чтобы сделать жизнь счастливой, надо любить повседневные мелочи.

In order to make life happy, you must love the everyday trifles.

Why: Modal and impersonal words. [[Russian#^ru-Q0610|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A7%D1%82%D0%BE%D0%B1%D1%8B%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C%20%D0%B6%D0%B8%D0%B7%D0%BD%D1%8C%20%D1%81%D1%87%D0%B0%D1%81%D1%82%D0%BB%D0%B8%D0%B2%D0%BE%D0%B9%2C%20%D0%BD%D0%B0%D0%B4%D0%BE%20%D0%BB%D1%8E%D0%B1%D0%B8%D1%82%D1%8C%20%D0%BF%D0%BE%D0%B2%D1%81%D0%B5%D0%B4%D0%BD%D0%B5%D0%B2%D0%BD%D1%8B%D0%B5%20%D0%BC%D0%B5%D0%BB%D0%BE%D1%87%D0%B8.)
^ru-Q0610-answer

**ru-Q0611** — Я хочу увидеть лошадей.

I want to see the horses.

Why: Modal and impersonal words. [[Russian#^ru-Q0611|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%85%D0%BE%D1%87%D1%83%20%D1%83%D0%B2%D0%B8%D0%B4%D0%B5%D1%82%D1%8C%20%D0%BB%D0%BE%D1%88%D0%B0%D0%B4%D0%B5%D0%B9.)
^ru-Q0611-answer

**ru-Q0612** — Я хочу увидеть лошадей.

I want to see the horses.

Modality can be expressed with verbs or impersonal predicates. Нужно/надо often combine with a dative experiencer and infinitive. Может can also be a verb meaning can; context distinguishes inference.

Why: Modal and impersonal words. [[Russian#^ru-Q0612|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%85%D0%BE%D1%87%D1%83%20%D1%83%D0%B2%D0%B8%D0%B4%D0%B5%D1%82%D1%8C%20%D0%BB%D0%BE%D1%88%D0%B0%D0%B4%D0%B5%D0%B9.)
^ru-Q0612-answer

**ru-Q0613** — Я хочу найти для этого ящик.

I want to find a box for this.

Expected form: **хочу**

Why: Modal and impersonal words. [[Russian#^ru-Q0613|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%85%D0%BE%D1%87%D1%83%20%D0%BD%D0%B0%D0%B9%D1%82%D0%B8%20%D0%B4%D0%BB%D1%8F%20%D1%8D%D1%82%D0%BE%D0%B3%D0%BE%20%D1%8F%D1%89%D0%B8%D0%BA.)
^ru-Q0613-answer

**ru-Q0614** — Я хочу найти для этого ящик.

I want to find a box for this.

Expected form: **хочу**

Why: Modal and impersonal words. [[Russian#^ru-Q0614|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%85%D0%BE%D1%87%D1%83%20%D0%BD%D0%B0%D0%B9%D1%82%D0%B8%20%D0%B4%D0%BB%D1%8F%20%D1%8D%D1%82%D0%BE%D0%B3%D0%BE%20%D1%8F%D1%89%D0%B8%D0%BA.)
^ru-Q0614-answer

**ru-Q0615** — Том не может справиться с этой работой самостоятельно.

Tom can't handle this job on his own.

Expected form: **может**

Why: Modal and impersonal words. [[Russian#^ru-Q0615|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D0%BC%D0%BE%D0%B6%D0%B5%D1%82%20%D1%81%D0%BF%D1%80%D0%B0%D0%B2%D0%B8%D1%82%D1%8C%D1%81%D1%8F%20%D1%81%20%D1%8D%D1%82%D0%BE%D0%B9%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%BE%D0%B9%20%D1%81%D0%B0%D0%BC%D0%BE%D1%81%D1%82%D0%BE%D1%8F%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE.)
^ru-Q0615-answer

**ru-Q0616** — Том не может справиться с этой работой самостоятельно.

Tom can't handle this job on his own.

Why: Modal and impersonal words. [[Russian#^ru-Q0616|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D0%BC%D0%BE%D0%B6%D0%B5%D1%82%20%D1%81%D0%BF%D1%80%D0%B0%D0%B2%D0%B8%D1%82%D1%8C%D1%81%D1%8F%20%D1%81%20%D1%8D%D1%82%D0%BE%D0%B9%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%BE%D0%B9%20%D1%81%D0%B0%D0%BC%D0%BE%D1%81%D1%82%D0%BE%D1%8F%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE.)
^ru-Q0616-answer

**ru-Q0617** — Тебе нужно больше заниматься.

You need to exercise more.

Why: Modal and impersonal words. [[Russian#^ru-Q0617|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%B5%D0%B1%D0%B5%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%B7%D0%B0%D0%BD%D0%B8%D0%BC%D0%B0%D1%82%D1%8C%D1%81%D1%8F.)
^ru-Q0617-answer

**ru-Q0618** — Тебе нужно больше заниматься.

You need to exercise more.

Modality can be expressed with verbs or impersonal predicates. Нужно/надо often combine with a dative experiencer and infinitive. Может can also be a verb meaning can; context distinguishes inference.

Why: Modal and impersonal words. [[Russian#^ru-Q0618|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%B5%D0%B1%D0%B5%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%B7%D0%B0%D0%BD%D0%B8%D0%BC%D0%B0%D1%82%D1%8C%D1%81%D1%8F.)
^ru-Q0618-answer

**ru-Q0619** — Мне нужно с вами переговорить.

I want a word with you.

Expected form: **нужно**

Why: Modal and impersonal words. [[Russian#^ru-Q0619|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BD%D0%B5%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D1%81%20%D0%B2%D0%B0%D0%BC%D0%B8%20%D0%BF%D0%B5%D1%80%D0%B5%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D1%8C.)
^ru-Q0619-answer

**ru-Q0620** — Мне нужно с вами переговорить.

I want a word with you.

Expected form: **нужно**

Why: Modal and impersonal words. [[Russian#^ru-Q0620|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BD%D0%B5%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D1%81%20%D0%B2%D0%B0%D0%BC%D0%B8%20%D0%BF%D0%B5%D1%80%D0%B5%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D1%8C.)
^ru-Q0620-answer

**ru-Q0621** — Я хочу купить другую.

I want to buy another one.

Expected form: **хочу**

Why: Modal and impersonal words. [[Russian#^ru-Q0621|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%85%D0%BE%D1%87%D1%83%20%D0%BA%D1%83%D0%BF%D0%B8%D1%82%D1%8C%20%D0%B4%D1%80%D1%83%D0%B3%D1%83%D1%8E.)
^ru-Q0621-answer

**ru-Q0622** — Я хочу купить другую.

I want to buy another one.

Why: Modal and impersonal words. [[Russian#^ru-Q0622|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%85%D0%BE%D1%87%D1%83%20%D0%BA%D1%83%D0%BF%D0%B8%D1%82%D1%8C%20%D0%B4%D1%80%D1%83%D0%B3%D1%83%D1%8E.)
^ru-Q0622-answer

**ru-Q0623** — Я должен решить эту проблему сам.

I have to solve this problem myself.

Why: Modal and impersonal words. [[Russian#^ru-Q0623|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B4%D0%BE%D0%BB%D0%B6%D0%B5%D0%BD%20%D1%80%D0%B5%D1%88%D0%B8%D1%82%D1%8C%20%D1%8D%D1%82%D1%83%20%D0%BF%D1%80%D0%BE%D0%B1%D0%BB%D0%B5%D0%BC%D1%83%20%D1%81%D0%B0%D0%BC.)
^ru-Q0623-answer

**ru-Q0624** — Я должен решить эту проблему сам.

I have to solve this problem myself.

Modality can be expressed with verbs or impersonal predicates. Нужно/надо often combine with a dative experiencer and infinitive. Может can also be a verb meaning can; context distinguishes inference.

Why: Modal and impersonal words. [[Russian#^ru-Q0624|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B4%D0%BE%D0%BB%D0%B6%D0%B5%D0%BD%20%D1%80%D0%B5%D1%88%D0%B8%D1%82%D1%8C%20%D1%8D%D1%82%D1%83%20%D0%BF%D1%80%D0%BE%D0%B1%D0%BB%D0%B5%D0%BC%D1%83%20%D1%81%D0%B0%D0%BC.)
^ru-Q0624-answer

**ru-Q0625** — Ты должен помочь нам.

You have to help us.

Expected form: **должен**

Why: Modal and impersonal words. [[Russian#^ru-Q0625|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%B4%D0%BE%D0%BB%D0%B6%D0%B5%D0%BD%20%D0%BF%D0%BE%D0%BC%D0%BE%D1%87%D1%8C%20%D0%BD%D0%B0%D0%BC.)
^ru-Q0625-answer

**ru-Q0626** — Ты должен помочь нам.

You have to help us.

Expected form: **должен**

Why: Modal and impersonal words. [[Russian#^ru-Q0626|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%B4%D0%BE%D0%BB%D0%B6%D0%B5%D0%BD%20%D0%BF%D0%BE%D0%BC%D0%BE%D1%87%D1%8C%20%D0%BD%D0%B0%D0%BC.)
^ru-Q0626-answer

**ru-Q0627** — Далеко не всё в интернете можно найти с помощью гугла.

Not everything on the web can be found through Google.

Expected form: **можно**

Why: Modal and impersonal words. [[Russian#^ru-Q0627|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D0%B0%D0%BB%D0%B5%D0%BA%D0%BE%20%D0%BD%D0%B5%20%D0%B2%D1%81%D1%91%20%D0%B2%20%D0%B8%D0%BD%D1%82%D0%B5%D1%80%D0%BD%D0%B5%D1%82%D0%B5%20%D0%BC%D0%BE%D0%B6%D0%BD%D0%BE%20%D0%BD%D0%B0%D0%B9%D1%82%D0%B8%20%D1%81%20%D0%BF%D0%BE%D0%BC%D0%BE%D1%89%D1%8C%D1%8E%20%D0%B3%D1%83%D0%B3%D0%BB%D0%B0.)
^ru-Q0627-answer

**ru-Q0628** — Далеко не всё в интернете можно найти с помощью гугла.

Not everything on the web can be found through Google.

Why: Modal and impersonal words. [[Russian#^ru-Q0628|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D0%B0%D0%BB%D0%B5%D0%BA%D0%BE%20%D0%BD%D0%B5%20%D0%B2%D1%81%D1%91%20%D0%B2%20%D0%B8%D0%BD%D1%82%D0%B5%D1%80%D0%BD%D0%B5%D1%82%D0%B5%20%D0%BC%D0%BE%D0%B6%D0%BD%D0%BE%20%D0%BD%D0%B0%D0%B9%D1%82%D0%B8%20%D1%81%20%D0%BF%D0%BE%D0%BC%D0%BE%D1%89%D1%8C%D1%8E%20%D0%B3%D1%83%D0%B3%D0%BB%D0%B0.)
^ru-Q0628-answer

**ru-Q0629** — Если вам нужно одолжить денег, скажите.

If you need to borrow some money, let me know.

Why: Modal and impersonal words. [[Russian#^ru-Q0629|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D0%BB%D0%B8%20%D0%B2%D0%B0%D0%BC%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D0%BE%D0%B4%D0%BE%D0%BB%D0%B6%D0%B8%D1%82%D1%8C%20%D0%B4%D0%B5%D0%BD%D0%B5%D0%B3%2C%20%D1%81%D0%BA%D0%B0%D0%B6%D0%B8%D1%82%D0%B5.)
^ru-Q0629-answer

**ru-Q0630** — Если вам нужно одолжить денег, скажите.

If you need to borrow some money, let me know.

Modality can be expressed with verbs or impersonal predicates. Нужно/надо often combine with a dative experiencer and infinitive. Может can also be a verb meaning can; context distinguishes inference.

Why: Modal and impersonal words. [[Russian#^ru-Q0630|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D0%BB%D0%B8%20%D0%B2%D0%B0%D0%BC%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D0%BE%D0%B4%D0%BE%D0%BB%D0%B6%D0%B8%D1%82%D1%8C%20%D0%B4%D0%B5%D0%BD%D0%B5%D0%B3%2C%20%D1%81%D0%BA%D0%B0%D0%B6%D0%B8%D1%82%D0%B5.)
^ru-Q0630-answer

**ru-Q0631** — Мне нужно, чтобы вы помогли мне их найти.

I need you to help me find them.

Expected form: **нужно**

Why: Modal and impersonal words. [[Russian#^ru-Q0631|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BD%D0%B5%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D0%B2%D1%8B%20%D0%BF%D0%BE%D0%BC%D0%BE%D0%B3%D0%BB%D0%B8%20%D0%BC%D0%BD%D0%B5%20%D0%B8%D1%85%20%D0%BD%D0%B0%D0%B9%D1%82%D0%B8.)
^ru-Q0631-answer

**ru-Q0632** — Мне нужно, чтобы вы помогли мне их найти.

I need you to help me find them.

Expected form: **нужно**

Why: Modal and impersonal words. [[Russian#^ru-Q0632|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BD%D0%B5%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D0%B2%D1%8B%20%D0%BF%D0%BE%D0%BC%D0%BE%D0%B3%D0%BB%D0%B8%20%D0%BC%D0%BD%D0%B5%20%D0%B8%D1%85%20%D0%BD%D0%B0%D0%B9%D1%82%D0%B8.)
^ru-Q0632-answer

**ru-Q0633** — Тебе нужно лучше следить за тем, что ты говоришь.

You should pay more attention to what you say.

Expected form: **нужно**

Why: Modal and impersonal words. [[Russian#^ru-Q0633|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%B5%D0%B1%D0%B5%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D0%BB%D1%83%D1%87%D1%88%D0%B5%20%D1%81%D0%BB%D0%B5%D0%B4%D0%B8%D1%82%D1%8C%20%D0%B7%D0%B0%20%D1%82%D0%B5%D0%BC%2C%20%D1%87%D1%82%D0%BE%20%D1%82%D1%8B%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%88%D1%8C.)
^ru-Q0633-answer

**ru-Q0634** — Тебе нужно лучше следить за тем, что ты говоришь.

You should pay more attention to what you say.

Why: Modal and impersonal words. [[Russian#^ru-Q0634|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%B5%D0%B1%D0%B5%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE%20%D0%BB%D1%83%D1%87%D1%88%D0%B5%20%D1%81%D0%BB%D0%B5%D0%B4%D0%B8%D1%82%D1%8C%20%D0%B7%D0%B0%20%D1%82%D0%B5%D0%BC%2C%20%D1%87%D1%82%D0%BE%20%D1%82%D1%8B%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%88%D1%8C.)
^ru-Q0634-answer

**ru-Q0635** — Я хочу поговорить с Томом наедине.

I want to talk to Tom alone.

Why: Modal and impersonal words. [[Russian#^ru-Q0635|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%85%D0%BE%D1%87%D1%83%20%D0%BF%D0%BE%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D1%8C%20%D1%81%20%D0%A2%D0%BE%D0%BC%D0%BE%D0%BC%20%D0%BD%D0%B0%D0%B5%D0%B4%D0%B8%D0%BD%D0%B5.)
^ru-Q0635-answer

**ru-Q0636** — Я хочу поговорить с Томом наедине.

I want to talk to Tom alone.

Modality can be expressed with verbs or impersonal predicates. Нужно/надо often combine with a dative experiencer and infinitive. Может can also be a verb meaning can; context distinguishes inference.

Why: Modal and impersonal words. [[Russian#^ru-Q0636|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%85%D0%BE%D1%87%D1%83%20%D0%BF%D0%BE%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D1%8C%20%D1%81%20%D0%A2%D0%BE%D0%BC%D0%BE%D0%BC%20%D0%BD%D0%B0%D0%B5%D0%B4%D0%B8%D0%BD%D0%B5.)
^ru-Q0636-answer

**ru-Q0637** — Можно мне сесть рядом с тобой?

May I sit next to you?

Expected form: **Можно**

Why: Modal and impersonal words. [[Russian#^ru-Q0637|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D0%B6%D0%BD%D0%BE%20%D0%BC%D0%BD%D0%B5%20%D1%81%D0%B5%D1%81%D1%82%D1%8C%20%D1%80%D1%8F%D0%B4%D0%BE%D0%BC%20%D1%81%20%D1%82%D0%BE%D0%B1%D0%BE%D0%B9%3F)
^ru-Q0637-answer

**ru-Q0638** — Можно мне сесть рядом с тобой?

May I sit next to you?

Expected form: **Можно**

Why: Modal and impersonal words. [[Russian#^ru-Q0638|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D0%B6%D0%BD%D0%BE%20%D0%BC%D0%BD%D0%B5%20%D1%81%D0%B5%D1%81%D1%82%D1%8C%20%D1%80%D1%8F%D0%B4%D0%BE%D0%BC%20%D1%81%20%D1%82%D0%BE%D0%B1%D0%BE%D0%B9%3F)
^ru-Q0638-answer

**ru-Q0639** — Вы действительно думаете, что Том может выиграть?

Do you really think Tom can win?

Expected form: **может**

Why: Modal and impersonal words. [[Russian#^ru-Q0639|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D0%B4%D0%B5%D0%B9%D1%81%D1%82%D0%B2%D0%B8%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE%20%D0%B4%D1%83%D0%BC%D0%B0%D0%B5%D1%82%D0%B5%2C%20%D1%87%D1%82%D0%BE%20%D0%A2%D0%BE%D0%BC%20%D0%BC%D0%BE%D0%B6%D0%B5%D1%82%20%D0%B2%D1%8B%D0%B8%D0%B3%D1%80%D0%B0%D1%82%D1%8C%3F)
^ru-Q0639-answer

**ru-Q0640** — Вы действительно думаете, что Том может выиграть?

Do you really think Tom can win?

Why: Modal and impersonal words. [[Russian#^ru-Q0640|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D0%B4%D0%B5%D0%B9%D1%81%D1%82%D0%B2%D0%B8%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE%20%D0%B4%D1%83%D0%BC%D0%B0%D0%B5%D1%82%D0%B5%2C%20%D1%87%D1%82%D0%BE%20%D0%A2%D0%BE%D0%BC%20%D0%BC%D0%BE%D0%B6%D0%B5%D1%82%20%D0%B2%D1%8B%D0%B8%D0%B3%D1%80%D0%B0%D1%82%D1%8C%3F)
^ru-Q0640-answer

**ru-Q0641** — То же самое можно сказать и о Германии.

The same holds true for Germany.

Why: Modal and impersonal words. [[Russian#^ru-Q0641|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%20%D0%B6%D0%B5%20%D1%81%D0%B0%D0%BC%D0%BE%D0%B5%20%D0%BC%D0%BE%D0%B6%D0%BD%D0%BE%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C%20%D0%B8%20%D0%BE%20%D0%93%D0%B5%D1%80%D0%BC%D0%B0%D0%BD%D0%B8%D0%B8.)
^ru-Q0641-answer

**ru-Q0642** — То же самое можно сказать и о Германии.

The same holds true for Germany.

Modality can be expressed with verbs or impersonal predicates. Нужно/надо often combine with a dative experiencer and infinitive. Может can also be a verb meaning can; context distinguishes inference.

Why: Modal and impersonal words. [[Russian#^ru-Q0642|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%20%D0%B6%D0%B5%20%D1%81%D0%B0%D0%BC%D0%BE%D0%B5%20%D0%BC%D0%BE%D0%B6%D0%BD%D0%BE%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C%20%D0%B8%20%D0%BE%20%D0%93%D0%B5%D1%80%D0%BC%D0%B0%D0%BD%D0%B8%D0%B8.)
^ru-Q0642-answer

**ru-Q0643** — Я должна сесть на диету, чтобы похудеть.

I have to go on a diet to lose weight.

Expected form: **должна**

Why: Modal and impersonal words. [[Russian#^ru-Q0643|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B4%D0%BE%D0%BB%D0%B6%D0%BD%D0%B0%20%D1%81%D0%B5%D1%81%D1%82%D1%8C%20%D0%BD%D0%B0%20%D0%B4%D0%B8%D0%B5%D1%82%D1%83%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D0%BF%D0%BE%D1%85%D1%83%D0%B4%D0%B5%D1%82%D1%8C.)
^ru-Q0643-answer

**ru-Q0644** — Я должна сесть на диету, чтобы похудеть.

I have to go on a diet to lose weight.

Expected form: **должна**

Why: Modal and impersonal words. [[Russian#^ru-Q0644|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B4%D0%BE%D0%BB%D0%B6%D0%BD%D0%B0%20%D1%81%D0%B5%D1%81%D1%82%D1%8C%20%D0%BD%D0%B0%20%D0%B4%D0%B8%D0%B5%D1%82%D1%83%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D0%BF%D0%BE%D1%85%D1%83%D0%B4%D0%B5%D1%82%D1%8C.)
^ru-Q0644-answer

**ru-Q0645** — Знаете, чего я хочу?

Do you know what I want?

Expected form: **хочу**

Why: Modal and impersonal words. [[Russian#^ru-Q0645|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%97%D0%BD%D0%B0%D0%B5%D1%82%D0%B5%2C%20%D1%87%D0%B5%D0%B3%D0%BE%20%D1%8F%20%D1%85%D0%BE%D1%87%D1%83%3F)
^ru-Q0645-answer

**ru-Q0646** — Знаете, чего я хочу?

Do you know what I want?

Why: Modal and impersonal words. [[Russian#^ru-Q0646|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%97%D0%BD%D0%B0%D0%B5%D1%82%D0%B5%2C%20%D1%87%D0%B5%D0%B3%D0%BE%20%D1%8F%20%D1%85%D0%BE%D1%87%D1%83%3F)
^ru-Q0646-answer

**ru-Q0647** — Следующей весной я хочу поехать на Гавайи.

Next spring I want to go to Hawaii.

Why: Modal and impersonal words. [[Russian#^ru-Q0647|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BB%D0%B5%D0%B4%D1%83%D1%8E%D1%89%D0%B5%D0%B9%20%D0%B2%D0%B5%D1%81%D0%BD%D0%BE%D0%B9%20%D1%8F%20%D1%85%D0%BE%D1%87%D1%83%20%D0%BF%D0%BE%D0%B5%D1%85%D0%B0%D1%82%D1%8C%20%D0%BD%D0%B0%20%D0%93%D0%B0%D0%B2%D0%B0%D0%B9%D0%B8.)
^ru-Q0647-answer

**ru-Q0648** — Следующей весной я хочу поехать на Гавайи.

Next spring I want to go to Hawaii.

Modality can be expressed with verbs or impersonal predicates. Нужно/надо often combine with a dative experiencer and infinitive. Может can also be a verb meaning can; context distinguishes inference.

Why: Modal and impersonal words. [[Russian#^ru-Q0648|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BB%D0%B5%D0%B4%D1%83%D1%8E%D1%89%D0%B5%D0%B9%20%D0%B2%D0%B5%D1%81%D0%BD%D0%BE%D0%B9%20%D1%8F%20%D1%85%D0%BE%D1%87%D1%83%20%D0%BF%D0%BE%D0%B5%D1%85%D0%B0%D1%82%D1%8C%20%D0%BD%D0%B0%20%D0%93%D0%B0%D0%B2%D0%B0%D0%B9%D0%B8.)
^ru-Q0648-answer

**ru-Q0649** — Санта, вместо подарка я хочу получить на Рождество девушку.

Santa Claus, I want to receive a girlfriend for Christmas.

Expected form: **хочу**

Why: Modal and impersonal words. [[Russian#^ru-Q0649|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%B0%D0%BD%D1%82%D0%B0%2C%20%D0%B2%D0%BC%D0%B5%D1%81%D1%82%D0%BE%20%D0%BF%D0%BE%D0%B4%D0%B0%D1%80%D0%BA%D0%B0%20%D1%8F%20%D1%85%D0%BE%D1%87%D1%83%20%D0%BF%D0%BE%D0%BB%D1%83%D1%87%D0%B8%D1%82%D1%8C%20%D0%BD%D0%B0%20%D0%A0%D0%BE%D0%B6%D0%B4%D0%B5%D1%81%D1%82%D0%B2%D0%BE%20%D0%B4%D0%B5%D0%B2%D1%83%D1%88%D0%BA%D1%83.)
^ru-Q0649-answer

**ru-Q0650** — Санта, вместо подарка я хочу получить на Рождество девушку.

Santa Claus, I want to receive a girlfriend for Christmas.

Expected form: **хочу**

Why: Modal and impersonal words. [[Russian#^ru-Q0650|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%B0%D0%BD%D1%82%D0%B0%2C%20%D0%B2%D0%BC%D0%B5%D1%81%D1%82%D0%BE%20%D0%BF%D0%BE%D0%B4%D0%B0%D1%80%D0%BA%D0%B0%20%D1%8F%20%D1%85%D0%BE%D1%87%D1%83%20%D0%BF%D0%BE%D0%BB%D1%83%D1%87%D0%B8%D1%82%D1%8C%20%D0%BD%D0%B0%20%D0%A0%D0%BE%D0%B6%D0%B4%D0%B5%D1%81%D1%82%D0%B2%D0%BE%20%D0%B4%D0%B5%D0%B2%D1%83%D1%88%D0%BA%D1%83.)
^ru-Q0650-answer


### Answers 651–700

**ru-Q0651** — Когда мы можем пойти купаться?

When can we go swimming?

Expected form: **Когда**

Why: Questions. [[Russian#^ru-Q0651|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%BC%D1%8B%20%D0%BC%D0%BE%D0%B6%D0%B5%D0%BC%20%D0%BF%D0%BE%D0%B9%D1%82%D0%B8%20%D0%BA%D1%83%D0%BF%D0%B0%D1%82%D1%8C%D1%81%D1%8F%3F)
^ru-Q0651-answer

**ru-Q0652** — Когда мы можем пойти купаться?

When can we go swimming?

Why: Questions. [[Russian#^ru-Q0652|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%BC%D1%8B%20%D0%BC%D0%BE%D0%B6%D0%B5%D0%BC%20%D0%BF%D0%BE%D0%B9%D1%82%D0%B8%20%D0%BA%D1%83%D0%BF%D0%B0%D1%82%D1%8C%D1%81%D1%8F%3F)
^ru-Q0652-answer

**ru-Q0653** — Том, вероятно, думал, что я счастлив.

Tom probably thought I was happy.

Why: Questions. [[Russian#^ru-Q0653|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%2C%20%D0%B2%D0%B5%D1%80%D0%BE%D1%8F%D1%82%D0%BD%D0%BE%2C%20%D0%B4%D1%83%D0%BC%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D1%8F%20%D1%81%D1%87%D0%B0%D1%81%D1%82%D0%BB%D0%B8%D0%B2.)
^ru-Q0653-answer

**ru-Q0654** — Том, вероятно, думал, что я счастлив.

Tom probably thought I was happy.

Где asks location, куда destination, откуда source. Question words can inflect for case. Word order and intonation help mark a question without an English do auxiliary.

Why: Questions. [[Russian#^ru-Q0654|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%2C%20%D0%B2%D0%B5%D1%80%D0%BE%D1%8F%D1%82%D0%BD%D0%BE%2C%20%D0%B4%D1%83%D0%BC%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D1%8F%20%D1%81%D1%87%D0%B0%D1%81%D1%82%D0%BB%D0%B8%D0%B2.)
^ru-Q0654-answer

**ru-Q0655** — Где ближайшая пиццерия?

Where's the nearest pizzeria?

Expected form: **Где**

Why: Questions. [[Russian#^ru-Q0655|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%93%D0%B4%D0%B5%20%D0%B1%D0%BB%D0%B8%D0%B6%D0%B0%D0%B9%D1%88%D0%B0%D1%8F%20%D0%BF%D0%B8%D1%86%D1%86%D0%B5%D1%80%D0%B8%D1%8F%3F)
^ru-Q0655-answer

**ru-Q0656** — Где ближайшая пиццерия?

Where's the nearest pizzeria?

Expected form: **Где**

Why: Questions. [[Russian#^ru-Q0656|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%93%D0%B4%D0%B5%20%D0%B1%D0%BB%D0%B8%D0%B6%D0%B0%D0%B9%D1%88%D0%B0%D1%8F%20%D0%BF%D0%B8%D1%86%D1%86%D0%B5%D1%80%D0%B8%D1%8F%3F)
^ru-Q0656-answer

**ru-Q0657** — Почему Том решил изучать французский?

Why did Tom decide to study French?

Expected form: **Почему**

Why: Questions. [[Russian#^ru-Q0657|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D0%A2%D0%BE%D0%BC%20%D1%80%D0%B5%D1%88%D0%B8%D0%BB%20%D0%B8%D0%B7%D1%83%D1%87%D0%B0%D1%82%D1%8C%20%D1%84%D1%80%D0%B0%D0%BD%D1%86%D1%83%D0%B7%D1%81%D0%BA%D0%B8%D0%B9%3F)
^ru-Q0657-answer

**ru-Q0658** — Почему Том решил изучать французский?

Why did Tom decide to study French?

Why: Questions. [[Russian#^ru-Q0658|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D0%A2%D0%BE%D0%BC%20%D1%80%D0%B5%D1%88%D0%B8%D0%BB%20%D0%B8%D0%B7%D1%83%D1%87%D0%B0%D1%82%D1%8C%20%D1%84%D1%80%D0%B0%D0%BD%D1%86%D1%83%D0%B7%D1%81%D0%BA%D0%B8%D0%B9%3F)
^ru-Q0658-answer

**ru-Q0659** — Интересно, работает ли Том когда-либо по воскресеньям.

I wonder if Tom ever works on Sunday.

Why: Questions. [[Russian#^ru-Q0659|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%98%D0%BD%D1%82%D0%B5%D1%80%D0%B5%D1%81%D0%BD%D0%BE%2C%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B0%D0%B5%D1%82%20%D0%BB%D0%B8%20%D0%A2%D0%BE%D0%BC%20%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0-%D0%BB%D0%B8%D0%B1%D0%BE%20%D0%BF%D0%BE%20%D0%B2%D0%BE%D1%81%D0%BA%D1%80%D0%B5%D1%81%D0%B5%D0%BD%D1%8C%D1%8F%D0%BC.)
^ru-Q0659-answer

**ru-Q0660** — Интересно, работает ли Том когда-либо по воскресеньям.

I wonder if Tom ever works on Sunday.

Где asks location, куда destination, откуда source. Question words can inflect for case. Word order and intonation help mark a question without an English do auxiliary.

Why: Questions. [[Russian#^ru-Q0660|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%98%D0%BD%D1%82%D0%B5%D1%80%D0%B5%D1%81%D0%BD%D0%BE%2C%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B0%D0%B5%D1%82%20%D0%BB%D0%B8%20%D0%A2%D0%BE%D0%BC%20%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0-%D0%BB%D0%B8%D0%B1%D0%BE%20%D0%BF%D0%BE%20%D0%B2%D0%BE%D1%81%D0%BA%D1%80%D0%B5%D1%81%D0%B5%D0%BD%D1%8C%D1%8F%D0%BC.)
^ru-Q0660-answer

**ru-Q0661** — Я думал, что тону.

I thought I was drowning.

Expected form: **что**

Why: Questions. [[Russian#^ru-Q0661|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B4%D1%83%D0%BC%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D1%82%D0%BE%D0%BD%D1%83.)
^ru-Q0661-answer

**ru-Q0662** — Я думал, что тону.

I thought I was drowning.

Expected form: **что**

Why: Questions. [[Russian#^ru-Q0662|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B4%D1%83%D0%BC%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D1%82%D0%BE%D0%BD%D1%83.)
^ru-Q0662-answer

**ru-Q0663** — Ненависть слепа, как и любовь.

Hatred is blind, as well as love.

Expected form: **как**

Why: Questions. [[Russian#^ru-Q0663|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%D0%BD%D0%B0%D0%B2%D0%B8%D1%81%D1%82%D1%8C%20%D1%81%D0%BB%D0%B5%D0%BF%D0%B0%2C%20%D0%BA%D0%B0%D0%BA%20%D0%B8%20%D0%BB%D1%8E%D0%B1%D0%BE%D0%B2%D1%8C.)
^ru-Q0663-answer

**ru-Q0664** — Ненависть слепа, как и любовь.

Hatred is blind, as well as love.

Why: Questions. [[Russian#^ru-Q0664|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%D0%BD%D0%B0%D0%B2%D0%B8%D1%81%D1%82%D1%8C%20%D1%81%D0%BB%D0%B5%D0%BF%D0%B0%2C%20%D0%BA%D0%B0%D0%BA%20%D0%B8%20%D0%BB%D1%8E%D0%B1%D0%BE%D0%B2%D1%8C.)
^ru-Q0664-answer

**ru-Q0665** — Как вы к этому относитесь?

How do you feel about this?

Why: Questions. [[Russian#^ru-Q0665|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%B0%D0%BA%20%D0%B2%D1%8B%20%D0%BA%20%D1%8D%D1%82%D0%BE%D0%BC%D1%83%20%D0%BE%D1%82%D0%BD%D0%BE%D1%81%D0%B8%D1%82%D0%B5%D1%81%D1%8C%3F)
^ru-Q0665-answer

**ru-Q0666** — Как вы к этому относитесь?

How do you feel about this?

Где asks location, куда destination, откуда source. Question words can inflect for case. Word order and intonation help mark a question without an English do auxiliary.

Why: Questions. [[Russian#^ru-Q0666|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%B0%D0%BA%20%D0%B2%D1%8B%20%D0%BA%20%D1%8D%D1%82%D0%BE%D0%BC%D1%83%20%D0%BE%D1%82%D0%BD%D0%BE%D1%81%D0%B8%D1%82%D0%B5%D1%81%D1%8C%3F)
^ru-Q0666-answer

**ru-Q0667** — Кажется, Том что-то бормочет.

Tom seems to be babbling.

Expected form: **что**

Why: Questions. [[Russian#^ru-Q0667|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%B0%D0%B6%D0%B5%D1%82%D1%81%D1%8F%2C%20%D0%A2%D0%BE%D0%BC%20%D1%87%D1%82%D0%BE-%D1%82%D0%BE%20%D0%B1%D0%BE%D1%80%D0%BC%D0%BE%D1%87%D0%B5%D1%82.)
^ru-Q0667-answer

**ru-Q0668** — Кажется, Том что-то бормочет.

Tom seems to be babbling.

Expected form: **что**

Why: Questions. [[Russian#^ru-Q0668|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%B0%D0%B6%D0%B5%D1%82%D1%81%D1%8F%2C%20%D0%A2%D0%BE%D0%BC%20%D1%87%D1%82%D0%BE-%D1%82%D0%BE%20%D0%B1%D0%BE%D1%80%D0%BC%D0%BE%D1%87%D0%B5%D1%82.)
^ru-Q0668-answer

**ru-Q0669** — Том позвонил сказать, что опоздает.

Tom called to say that he'd be late.

Expected form: **что**

Why: Questions. [[Russian#^ru-Q0669|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BF%D0%BE%D0%B7%D0%B2%D0%BE%D0%BD%D0%B8%D0%BB%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C%2C%20%D1%87%D1%82%D0%BE%20%D0%BE%D0%BF%D0%BE%D0%B7%D0%B4%D0%B0%D0%B5%D1%82.)
^ru-Q0669-answer

**ru-Q0670** — Том позвонил сказать, что опоздает.

Tom called to say that he'd be late.

Why: Questions. [[Russian#^ru-Q0670|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BF%D0%BE%D0%B7%D0%B2%D0%BE%D0%BD%D0%B8%D0%BB%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C%2C%20%D1%87%D1%82%D0%BE%20%D0%BE%D0%BF%D0%BE%D0%B7%D0%B4%D0%B0%D0%B5%D1%82.)
^ru-Q0670-answer

**ru-Q0671** — Том женился на Мэри, после того как её муж умер.

Tom married Mary after her husband died.

Why: Questions. [[Russian#^ru-Q0671|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B6%D0%B5%D0%BD%D0%B8%D0%BB%D1%81%D1%8F%20%D0%BD%D0%B0%20%D0%9C%D1%8D%D1%80%D0%B8%2C%20%D0%BF%D0%BE%D1%81%D0%BB%D0%B5%20%D1%82%D0%BE%D0%B3%D0%BE%20%D0%BA%D0%B0%D0%BA%20%D0%B5%D1%91%20%D0%BC%D1%83%D0%B6%20%D1%83%D0%BC%D0%B5%D1%80.)
^ru-Q0671-answer

**ru-Q0672** — Том женился на Мэри, после того как её муж умер.

Tom married Mary after her husband died.

Где asks location, куда destination, откуда source. Question words can inflect for case. Word order and intonation help mark a question without an English do auxiliary.

Why: Questions. [[Russian#^ru-Q0672|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B6%D0%B5%D0%BD%D0%B8%D0%BB%D1%81%D1%8F%20%D0%BD%D0%B0%20%D0%9C%D1%8D%D1%80%D0%B8%2C%20%D0%BF%D0%BE%D1%81%D0%BB%D0%B5%20%D1%82%D0%BE%D0%B3%D0%BE%20%D0%BA%D0%B0%D0%BA%20%D0%B5%D1%91%20%D0%BC%D1%83%D0%B6%20%D1%83%D0%BC%D0%B5%D1%80.)
^ru-Q0672-answer

**ru-Q0673** — Вы знаете, как с ними связаться?

Do you know how to reach them?

Expected form: **как**

Why: Questions. [[Russian#^ru-Q0673|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D0%B7%D0%BD%D0%B0%D0%B5%D1%82%D0%B5%2C%20%D0%BA%D0%B0%D0%BA%20%D1%81%20%D0%BD%D0%B8%D0%BC%D0%B8%20%D1%81%D0%B2%D1%8F%D0%B7%D0%B0%D1%82%D1%8C%D1%81%D1%8F%3F)
^ru-Q0673-answer

**ru-Q0674** — Вы знаете, как с ними связаться?

Do you know how to reach them?

Expected form: **как**

Why: Questions. [[Russian#^ru-Q0674|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D0%B7%D0%BD%D0%B0%D0%B5%D1%82%D0%B5%2C%20%D0%BA%D0%B0%D0%BA%20%D1%81%20%D0%BD%D0%B8%D0%BC%D0%B8%20%D1%81%D0%B2%D1%8F%D0%B7%D0%B0%D1%82%D1%8C%D1%81%D1%8F%3F)
^ru-Q0674-answer

**ru-Q0675** — Как ты это починишь?

How will you fix it?

Expected form: **Как**

Why: Questions. [[Russian#^ru-Q0675|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%B0%D0%BA%20%D1%82%D1%8B%20%D1%8D%D1%82%D0%BE%20%D0%BF%D0%BE%D1%87%D0%B8%D0%BD%D0%B8%D1%88%D1%8C%3F)
^ru-Q0675-answer

**ru-Q0676** — Как ты это починишь?

How will you fix it?

Why: Questions. [[Russian#^ru-Q0676|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%B0%D0%BA%20%D1%82%D1%8B%20%D1%8D%D1%82%D0%BE%20%D0%BF%D0%BE%D1%87%D0%B8%D0%BD%D0%B8%D1%88%D1%8C%3F)
^ru-Q0676-answer

**ru-Q0677** — Где Том поёт?

Where does Tom sing?

Why: Questions. [[Russian#^ru-Q0677|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%93%D0%B4%D0%B5%20%D0%A2%D0%BE%D0%BC%20%D0%BF%D0%BE%D1%91%D1%82%3F)
^ru-Q0677-answer

**ru-Q0678** — Где Том поёт?

Where does Tom sing?

Где asks location, куда destination, откуда source. Question words can inflect for case. Word order and intonation help mark a question without an English do auxiliary.

Why: Questions. [[Russian#^ru-Q0678|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%93%D0%B4%D0%B5%20%D0%A2%D0%BE%D0%BC%20%D0%BF%D0%BE%D1%91%D1%82%3F)
^ru-Q0678-answer

**ru-Q0679** — Тщательно обдумай это перед тем, как решить.

Sleep on it before deciding.

Expected form: **как**

Why: Questions. [[Russian#^ru-Q0679|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%89%D0%B0%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE%20%D0%BE%D0%B1%D0%B4%D1%83%D0%BC%D0%B0%D0%B9%20%D1%8D%D1%82%D0%BE%20%D0%BF%D0%B5%D1%80%D0%B5%D0%B4%20%D1%82%D0%B5%D0%BC%2C%20%D0%BA%D0%B0%D0%BA%20%D1%80%D0%B5%D1%88%D0%B8%D1%82%D1%8C.)
^ru-Q0679-answer

**ru-Q0680** — Тщательно обдумай это перед тем, как решить.

Sleep on it before deciding.

Expected form: **как**

Why: Questions. [[Russian#^ru-Q0680|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%89%D0%B0%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE%20%D0%BE%D0%B1%D0%B4%D1%83%D0%BC%D0%B0%D0%B9%20%D1%8D%D1%82%D0%BE%20%D0%BF%D0%B5%D1%80%D0%B5%D0%B4%20%D1%82%D0%B5%D0%BC%2C%20%D0%BA%D0%B0%D0%BA%20%D1%80%D0%B5%D1%88%D0%B8%D1%82%D1%8C.)
^ru-Q0680-answer

**ru-Q0681** — Я рад, что кто-то понимает.

I'm glad someone understands.

Expected form: **что**

Why: Questions. [[Russian#^ru-Q0681|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%80%D0%B0%D0%B4%2C%20%D1%87%D1%82%D0%BE%20%D0%BA%D1%82%D0%BE-%D1%82%D0%BE%20%D0%BF%D0%BE%D0%BD%D0%B8%D0%BC%D0%B0%D0%B5%D1%82.)
^ru-Q0681-answer

**ru-Q0682** — Я рад, что кто-то понимает.

I'm glad someone understands.

Why: Questions. [[Russian#^ru-Q0682|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%80%D0%B0%D0%B4%2C%20%D1%87%D1%82%D0%BE%20%D0%BA%D1%82%D0%BE-%D1%82%D0%BE%20%D0%BF%D0%BE%D0%BD%D0%B8%D0%BC%D0%B0%D0%B5%D1%82.)
^ru-Q0682-answer

**ru-Q0683** — Татоэба: там, где споры разгорячённей, чем два совокупляющихся в носке кролика!

Tatoeba: Where debates are hotter than two rabbits making babies in a sock!

Why: Questions. [[Russian#^ru-Q0683|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%B0%D1%82%D0%BE%D1%8D%D0%B1%D0%B0%3A%20%D1%82%D0%B0%D0%BC%2C%20%D0%B3%D0%B4%D0%B5%20%D1%81%D0%BF%D0%BE%D1%80%D1%8B%20%D1%80%D0%B0%D0%B7%D0%B3%D0%BE%D1%80%D1%8F%D1%87%D1%91%D0%BD%D0%BD%D0%B5%D0%B9%2C%20%D1%87%D0%B5%D0%BC%20%D0%B4%D0%B2%D0%B0%20%D1%81%D0%BE%D0%B2%D0%BE%D0%BA%D1%83%D0%BF%D0%BB%D1%8F%D1%8E%D1%89%D0%B8%D1%85%D1%81%D1%8F%20%D0%B2%20%D0%BD%D0%BE%D1%81%D0%BA%D0%B5%20%D0%BA%D1%80%D0%BE%D0%BB%D0%B8%D0%BA%D0%B0%21)
^ru-Q0683-answer

**ru-Q0684** — Татоэба: там, где споры разгорячённей, чем два совокупляющихся в носке кролика!

Tatoeba: Where debates are hotter than two rabbits making babies in a sock!

Где asks location, куда destination, откуда source. Question words can inflect for case. Word order and intonation help mark a question without an English do auxiliary.

Why: Questions. [[Russian#^ru-Q0684|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%B0%D1%82%D0%BE%D1%8D%D0%B1%D0%B0%3A%20%D1%82%D0%B0%D0%BC%2C%20%D0%B3%D0%B4%D0%B5%20%D1%81%D0%BF%D0%BE%D1%80%D1%8B%20%D1%80%D0%B0%D0%B7%D0%B3%D0%BE%D1%80%D1%8F%D1%87%D1%91%D0%BD%D0%BD%D0%B5%D0%B9%2C%20%D1%87%D0%B5%D0%BC%20%D0%B4%D0%B2%D0%B0%20%D1%81%D0%BE%D0%B2%D0%BE%D0%BA%D1%83%D0%BF%D0%BB%D1%8F%D1%8E%D1%89%D0%B8%D1%85%D1%81%D1%8F%20%D0%B2%20%D0%BD%D0%BE%D1%81%D0%BA%D0%B5%20%D0%BA%D1%80%D0%BE%D0%BB%D0%B8%D0%BA%D0%B0%21)
^ru-Q0684-answer

**ru-Q0685** — Ты что, не видишь, что Том и Мэри умирают?

Can't you see Tom and Mary are dying?

Expected form: **что**

Why: Questions. [[Russian#^ru-Q0685|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D1%87%D1%82%D0%BE%2C%20%D0%BD%D0%B5%20%D0%B2%D0%B8%D0%B4%D0%B8%D1%88%D1%8C%2C%20%D1%87%D1%82%D0%BE%20%D0%A2%D0%BE%D0%BC%20%D0%B8%20%D0%9C%D1%8D%D1%80%D0%B8%20%D1%83%D0%BC%D0%B8%D1%80%D0%B0%D1%8E%D1%82%3F)
^ru-Q0685-answer

**ru-Q0686** — Ты что, не видишь, что Том и Мэри умирают?

Can't you see Tom and Mary are dying?

Expected form: **что**

Why: Questions. [[Russian#^ru-Q0686|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D1%87%D1%82%D0%BE%2C%20%D0%BD%D0%B5%20%D0%B2%D0%B8%D0%B4%D0%B8%D1%88%D1%8C%2C%20%D1%87%D1%82%D0%BE%20%D0%A2%D0%BE%D0%BC%20%D0%B8%20%D0%9C%D1%8D%D1%80%D0%B8%20%D1%83%D0%BC%D0%B8%D1%80%D0%B0%D1%8E%D1%82%3F)
^ru-Q0686-answer

**ru-Q0687** — Как ты украшаешь свой дом к Рождеству?

How do you decorate your house for Christmas?

Expected form: **Как**

Why: Questions. [[Russian#^ru-Q0687|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%B0%D0%BA%20%D1%82%D1%8B%20%D1%83%D0%BA%D1%80%D0%B0%D1%88%D0%B0%D0%B5%D1%88%D1%8C%20%D1%81%D0%B2%D0%BE%D0%B9%20%D0%B4%D0%BE%D0%BC%20%D0%BA%20%D0%A0%D0%BE%D0%B6%D0%B4%D0%B5%D1%81%D1%82%D0%B2%D1%83%3F)
^ru-Q0687-answer

**ru-Q0688** — Как ты украшаешь свой дом к Рождеству?

How do you decorate your house for Christmas?

Why: Questions. [[Russian#^ru-Q0688|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%B0%D0%BA%20%D1%82%D1%8B%20%D1%83%D0%BA%D1%80%D0%B0%D1%88%D0%B0%D0%B5%D1%88%D1%8C%20%D1%81%D0%B2%D0%BE%D0%B9%20%D0%B4%D0%BE%D0%BC%20%D0%BA%20%D0%A0%D0%BE%D0%B6%D0%B4%D0%B5%D1%81%D1%82%D0%B2%D1%83%3F)
^ru-Q0688-answer

**ru-Q0689** — Ты узнал, во сколько начинается собрание?

Did you find out what time the meeting starts?

Why: Questions. [[Russian#^ru-Q0689|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D1%83%D0%B7%D0%BD%D0%B0%D0%BB%2C%20%D0%B2%D0%BE%20%D1%81%D0%BA%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE%20%D0%BD%D0%B0%D1%87%D0%B8%D0%BD%D0%B0%D0%B5%D1%82%D1%81%D1%8F%20%D1%81%D0%BE%D0%B1%D1%80%D0%B0%D0%BD%D0%B8%D0%B5%3F)
^ru-Q0689-answer

**ru-Q0690** — Ты узнал, во сколько начинается собрание?

Did you find out what time the meeting starts?

Где asks location, куда destination, откуда source. Question words can inflect for case. Word order and intonation help mark a question without an English do auxiliary.

Why: Questions. [[Russian#^ru-Q0690|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D1%83%D0%B7%D0%BD%D0%B0%D0%BB%2C%20%D0%B2%D0%BE%20%D1%81%D0%BA%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE%20%D0%BD%D0%B0%D1%87%D0%B8%D0%BD%D0%B0%D0%B5%D1%82%D1%81%D1%8F%20%D1%81%D0%BE%D0%B1%D1%80%D0%B0%D0%BD%D0%B8%D0%B5%3F)
^ru-Q0690-answer

**ru-Q0691** — Что мне делать в этой ситуации?

What should I do in this situation?

Expected form: **Что**

Why: Questions. [[Russian#^ru-Q0691|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A7%D1%82%D0%BE%20%D0%BC%D0%BD%D0%B5%20%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C%20%D0%B2%20%D1%8D%D1%82%D0%BE%D0%B9%20%D1%81%D0%B8%D1%82%D1%83%D0%B0%D1%86%D0%B8%D0%B8%3F)
^ru-Q0691-answer

**ru-Q0692** — Что мне делать в этой ситуации?

What should I do in this situation?

Expected form: **Что**

Why: Questions. [[Russian#^ru-Q0692|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A7%D1%82%D0%BE%20%D0%BC%D0%BD%D0%B5%20%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C%20%D0%B2%20%D1%8D%D1%82%D0%BE%D0%B9%20%D1%81%D0%B8%D1%82%D1%83%D0%B0%D1%86%D0%B8%D0%B8%3F)
^ru-Q0692-answer

**ru-Q0693** — Нам придётся что-то сделать.

We will have to do something.

Expected form: **что**

Why: Questions. [[Russian#^ru-Q0693|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%D0%BC%20%D0%BF%D1%80%D0%B8%D0%B4%D1%91%D1%82%D1%81%D1%8F%20%D1%87%D1%82%D0%BE-%D1%82%D0%BE%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C.)
^ru-Q0693-answer

**ru-Q0694** — Нам придётся что-то сделать.

We will have to do something.

Why: Questions. [[Russian#^ru-Q0694|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%D0%BC%20%D0%BF%D1%80%D0%B8%D0%B4%D1%91%D1%82%D1%81%D1%8F%20%D1%87%D1%82%D0%BE-%D1%82%D0%BE%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C.)
^ru-Q0694-answer

**ru-Q0695** — Неудивительно, что вы никому не нравитесь.

No wonder nobody likes you.

Why: Questions. [[Russian#^ru-Q0695|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%D1%83%D0%B4%D0%B8%D0%B2%D0%B8%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE%2C%20%D1%87%D1%82%D0%BE%20%D0%B2%D1%8B%20%D0%BD%D0%B8%D0%BA%D0%BE%D0%BC%D1%83%20%D0%BD%D0%B5%20%D0%BD%D1%80%D0%B0%D0%B2%D0%B8%D1%82%D0%B5%D1%81%D1%8C.)
^ru-Q0695-answer

**ru-Q0696** — Неудивительно, что вы никому не нравитесь.

No wonder nobody likes you.

Где asks location, куда destination, откуда source. Question words can inflect for case. Word order and intonation help mark a question without an English do auxiliary.

Why: Questions. [[Russian#^ru-Q0696|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%D1%83%D0%B4%D0%B8%D0%B2%D0%B8%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE%2C%20%D1%87%D1%82%D0%BE%20%D0%B2%D1%8B%20%D0%BD%D0%B8%D0%BA%D0%BE%D0%BC%D1%83%20%D0%BD%D0%B5%20%D0%BD%D1%80%D0%B0%D0%B2%D0%B8%D1%82%D0%B5%D1%81%D1%8C.)
^ru-Q0696-answer

**ru-Q0697** — Сколько у тебя служащих?

How many employees do you have?

Expected form: **Сколько**

Why: Questions. [[Russian#^ru-Q0697|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BA%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE%20%D1%83%20%D1%82%D0%B5%D0%B1%D1%8F%20%D1%81%D0%BB%D1%83%D0%B6%D0%B0%D1%89%D0%B8%D1%85%3F)
^ru-Q0697-answer

**ru-Q0698** — Сколько у тебя служащих?

How many employees do you have?

Expected form: **Сколько**

Why: Questions. [[Russian#^ru-Q0698|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BA%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE%20%D1%83%20%D1%82%D0%B5%D0%B1%D1%8F%20%D1%81%D0%BB%D1%83%D0%B6%D0%B0%D1%89%D0%B8%D1%85%3F)
^ru-Q0698-answer

**ru-Q0699** — Почему ты пришёл так рано?

Why did you come so early?

Expected form: **Почему**

Why: Questions. [[Russian#^ru-Q0699|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D1%82%D1%8B%20%D0%BF%D1%80%D0%B8%D1%88%D1%91%D0%BB%20%D1%82%D0%B0%D0%BA%20%D1%80%D0%B0%D0%BD%D0%BE%3F)
^ru-Q0699-answer

**ru-Q0700** — Почему ты пришёл так рано?

Why did you come so early?

Why: Questions. [[Russian#^ru-Q0700|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D1%82%D1%8B%20%D0%BF%D1%80%D0%B8%D1%88%D1%91%D0%BB%20%D1%82%D0%B0%D0%BA%20%D1%80%D0%B0%D0%BD%D0%BE%3F)
^ru-Q0700-answer


### Answers 701–750

**ru-Q0701** — Том приехал сюда, чтобы учить французский.

Tom came here to study French.

Why: Content clauses. [[Russian#^ru-Q0701|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BF%D1%80%D0%B8%D0%B5%D1%85%D0%B0%D0%BB%20%D1%81%D1%8E%D0%B4%D0%B0%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D1%83%D1%87%D0%B8%D1%82%D1%8C%20%D1%84%D1%80%D0%B0%D0%BD%D1%86%D1%83%D0%B7%D1%81%D0%BA%D0%B8%D0%B9.)
^ru-Q0701-answer

**ru-Q0702** — Том приехал сюда, чтобы учить французский.

Tom came here to study French.

Что can introduce reported content, while чтобы often marks purpose or a desired event. Ли helps form indirect yes/no questions. Identical words may have interrogative or relative roles elsewhere.

Why: Content clauses. [[Russian#^ru-Q0702|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BF%D1%80%D0%B8%D0%B5%D1%85%D0%B0%D0%BB%20%D1%81%D1%8E%D0%B4%D0%B0%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D1%83%D1%87%D0%B8%D1%82%D1%8C%20%D1%84%D1%80%D0%B0%D0%BD%D1%86%D1%83%D0%B7%D1%81%D0%BA%D0%B8%D0%B9.)
^ru-Q0702-answer

**ru-Q0703** — Том использовал лом, чтобы открыть крышку ящика.

Tom used a crowbar to pry open the lid of the crate.

Expected form: **чтобы**

Why: Content clauses. [[Russian#^ru-Q0703|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B8%D1%81%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D0%BB%20%D0%BB%D0%BE%D0%BC%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D0%BE%D1%82%D0%BA%D1%80%D1%8B%D1%82%D1%8C%20%D0%BA%D1%80%D1%8B%D1%88%D0%BA%D1%83%20%D1%8F%D1%89%D0%B8%D0%BA%D0%B0.)
^ru-Q0703-answer

**ru-Q0704** — Том использовал лом, чтобы открыть крышку ящика.

Tom used a crowbar to pry open the lid of the crate.

Expected form: **чтобы**

Why: Content clauses. [[Russian#^ru-Q0704|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B8%D1%81%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D0%BB%20%D0%BB%D0%BE%D0%BC%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D0%BE%D1%82%D0%BA%D1%80%D1%8B%D1%82%D1%8C%20%D0%BA%D1%80%D1%8B%D1%88%D0%BA%D1%83%20%D1%8F%D1%89%D0%B8%D0%BA%D0%B0.)
^ru-Q0704-answer

**ru-Q0705** — Том хотел, чтобы они оба ушли.

Tom wanted both of them to leave.

Expected form: **чтобы**

Why: Content clauses. [[Russian#^ru-Q0705|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D0%BE%D0%BD%D0%B8%20%D0%BE%D0%B1%D0%B0%20%D1%83%D1%88%D0%BB%D0%B8.)
^ru-Q0705-answer

**ru-Q0706** — Том хотел, чтобы они оба ушли.

Tom wanted both of them to leave.

Why: Content clauses. [[Russian#^ru-Q0706|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D0%BE%D0%BD%D0%B8%20%D0%BE%D0%B1%D0%B0%20%D1%83%D1%88%D0%BB%D0%B8.)
^ru-Q0706-answer

**ru-Q0707** — Я не понимаю, как это возможно.

I don't see how that can be true.

Why: Content clauses. [[Russian#^ru-Q0707|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D0%BF%D0%BE%D0%BD%D0%B8%D0%BC%D0%B0%D1%8E%2C%20%D0%BA%D0%B0%D0%BA%20%D1%8D%D1%82%D0%BE%20%D0%B2%D0%BE%D0%B7%D0%BC%D0%BE%D0%B6%D0%BD%D0%BE.)
^ru-Q0707-answer

**ru-Q0708** — Я не понимаю, как это возможно.

I don't see how that can be true.

Что can introduce reported content, while чтобы often marks purpose or a desired event. Ли helps form indirect yes/no questions. Identical words may have interrogative or relative roles elsewhere.

Why: Content clauses. [[Russian#^ru-Q0708|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D0%BF%D0%BE%D0%BD%D0%B8%D0%BC%D0%B0%D1%8E%2C%20%D0%BA%D0%B0%D0%BA%20%D1%8D%D1%82%D0%BE%20%D0%B2%D0%BE%D0%B7%D0%BC%D0%BE%D0%B6%D0%BD%D0%BE.)
^ru-Q0708-answer

**ru-Q0709** — Я знал, что Том не умеет врать.

I knew Tom wasn't good at lying.

Expected form: **что**

Why: Content clauses. [[Russian#^ru-Q0709|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B7%D0%BD%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D1%83%D0%BC%D0%B5%D0%B5%D1%82%20%D0%B2%D1%80%D0%B0%D1%82%D1%8C.)
^ru-Q0709-answer

**ru-Q0710** — Я знал, что Том не умеет врать.

I knew Tom wasn't good at lying.

Expected form: **что**

Why: Content clauses. [[Russian#^ru-Q0710|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B7%D0%BD%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D1%83%D0%BC%D0%B5%D0%B5%D1%82%20%D0%B2%D1%80%D0%B0%D1%82%D1%8C.)
^ru-Q0710-answer

**ru-Q0711** — Никогда не думал, что такая нежная девочка станет такой грубой и высокомерной женщиной.

I never thought that such a tender girl would become such a rude and arrogant woman.

Expected form: **что**

Why: Content clauses. [[Russian#^ru-Q0711|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B8%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%BD%D0%B5%20%D0%B4%D1%83%D0%BC%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D1%82%D0%B0%D0%BA%D0%B0%D1%8F%20%D0%BD%D0%B5%D0%B6%D0%BD%D0%B0%D1%8F%20%D0%B4%D0%B5%D0%B2%D0%BE%D1%87%D0%BA%D0%B0%20%D1%81%D1%82%D0%B0%D0%BD%D0%B5%D1%82%20%D1%82%D0%B0%D0%BA%D0%BE%D0%B9%20%D0%B3%D1%80%D1%83%D0%B1%D0%BE%D0%B9%20%D0%B8%20%D0%B2%D1%8B%D1%81%D0%BE%D0%BA%D0%BE%D0%BC%D0%B5%D1%80%D0%BD%D0%BE%D0%B9%20%D0%B6%D0%B5%D0%BD%D1%89%D0%B8%D0%BD%D0%BE%D0%B9.)
^ru-Q0711-answer

**ru-Q0712** — Никогда не думал, что такая нежная девочка станет такой грубой и высокомерной женщиной.

I never thought that such a tender girl would become such a rude and arrogant woman.

Why: Content clauses. [[Russian#^ru-Q0712|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B8%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%BD%D0%B5%20%D0%B4%D1%83%D0%BC%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D1%82%D0%B0%D0%BA%D0%B0%D1%8F%20%D0%BD%D0%B5%D0%B6%D0%BD%D0%B0%D1%8F%20%D0%B4%D0%B5%D0%B2%D0%BE%D1%87%D0%BA%D0%B0%20%D1%81%D1%82%D0%B0%D0%BD%D0%B5%D1%82%20%D1%82%D0%B0%D0%BA%D0%BE%D0%B9%20%D0%B3%D1%80%D1%83%D0%B1%D0%BE%D0%B9%20%D0%B8%20%D0%B2%D1%8B%D1%81%D0%BE%D0%BA%D0%BE%D0%BC%D0%B5%D1%80%D0%BD%D0%BE%D0%B9%20%D0%B6%D0%B5%D0%BD%D1%89%D0%B8%D0%BD%D0%BE%D0%B9.)
^ru-Q0712-answer

**ru-Q0713** — На то, чтобы закончить работу, у меня ушло пять часов.

It took me five hours to finish the work.

Why: Content clauses. [[Russian#^ru-Q0713|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%20%D1%82%D0%BE%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D0%B7%D0%B0%D0%BA%D0%BE%D0%BD%D1%87%D0%B8%D1%82%D1%8C%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%83%2C%20%D1%83%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D1%83%D1%88%D0%BB%D0%BE%20%D0%BF%D1%8F%D1%82%D1%8C%20%D1%87%D0%B0%D1%81%D0%BE%D0%B2.)
^ru-Q0713-answer

**ru-Q0714** — На то, чтобы закончить работу, у меня ушло пять часов.

It took me five hours to finish the work.

Что can introduce reported content, while чтобы often marks purpose or a desired event. Ли helps form indirect yes/no questions. Identical words may have interrogative or relative roles elsewhere.

Why: Content clauses. [[Russian#^ru-Q0714|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%20%D1%82%D0%BE%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D0%B7%D0%B0%D0%BA%D0%BE%D0%BD%D1%87%D0%B8%D1%82%D1%8C%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%83%2C%20%D1%83%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D1%83%D1%88%D0%BB%D0%BE%20%D0%BF%D1%8F%D1%82%D1%8C%20%D1%87%D0%B0%D1%81%D0%BE%D0%B2.)
^ru-Q0714-answer

**ru-Q0715** — Он точен как часы.

He is as punctual as a clock.

Expected form: **как**

Why: Content clauses. [[Russian#^ru-Q0715|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D1%82%D0%BE%D1%87%D0%B5%D0%BD%20%D0%BA%D0%B0%D0%BA%20%D1%87%D0%B0%D1%81%D1%8B.)
^ru-Q0715-answer

**ru-Q0716** — Он точен как часы.

He is as punctual as a clock.

Expected form: **как**

Why: Content clauses. [[Russian#^ru-Q0716|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D1%82%D0%BE%D1%87%D0%B5%D0%BD%20%D0%BA%D0%B0%D0%BA%20%D1%87%D0%B0%D1%81%D1%8B.)
^ru-Q0716-answer

**ru-Q0717** — Извините за то, что я вас беспокою, но не могли бы вы помочь мне?

Sorry to trouble you, but can you help me?

Expected form: **что**

Why: Content clauses. [[Russian#^ru-Q0717|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%98%D0%B7%D0%B2%D0%B8%D0%BD%D0%B8%D1%82%D0%B5%20%D0%B7%D0%B0%20%D1%82%D0%BE%2C%20%D1%87%D1%82%D0%BE%20%D1%8F%20%D0%B2%D0%B0%D1%81%20%D0%B1%D0%B5%D1%81%D0%BF%D0%BE%D0%BA%D0%BE%D1%8E%2C%20%D0%BD%D0%BE%20%D0%BD%D0%B5%20%D0%BC%D0%BE%D0%B3%D0%BB%D0%B8%20%D0%B1%D1%8B%20%D0%B2%D1%8B%20%D0%BF%D0%BE%D0%BC%D0%BE%D1%87%D1%8C%20%D0%BC%D0%BD%D0%B5%3F)
^ru-Q0717-answer

**ru-Q0718** — Извините за то, что я вас беспокою, но не могли бы вы помочь мне?

Sorry to trouble you, but can you help me?

Why: Content clauses. [[Russian#^ru-Q0718|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%98%D0%B7%D0%B2%D0%B8%D0%BD%D0%B8%D1%82%D0%B5%20%D0%B7%D0%B0%20%D1%82%D0%BE%2C%20%D1%87%D1%82%D0%BE%20%D1%8F%20%D0%B2%D0%B0%D1%81%20%D0%B1%D0%B5%D1%81%D0%BF%D0%BE%D0%BA%D0%BE%D1%8E%2C%20%D0%BD%D0%BE%20%D0%BD%D0%B5%20%D0%BC%D0%BE%D0%B3%D0%BB%D0%B8%20%D0%B1%D1%8B%20%D0%B2%D1%8B%20%D0%BF%D0%BE%D0%BC%D0%BE%D1%87%D1%8C%20%D0%BC%D0%BD%D0%B5%3F)
^ru-Q0718-answer

**ru-Q0719** — Ты не поверишь, что Том мне рассказал!

You won't believe what Tom told me!

Why: Content clauses. [[Russian#^ru-Q0719|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%BD%D0%B5%20%D0%BF%D0%BE%D0%B2%D0%B5%D1%80%D0%B8%D1%88%D1%8C%2C%20%D1%87%D1%82%D0%BE%20%D0%A2%D0%BE%D0%BC%20%D0%BC%D0%BD%D0%B5%20%D1%80%D0%B0%D1%81%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%21)
^ru-Q0719-answer

**ru-Q0720** — Ты не поверишь, что Том мне рассказал!

You won't believe what Tom told me!

Что can introduce reported content, while чтобы often marks purpose or a desired event. Ли helps form indirect yes/no questions. Identical words may have interrogative or relative roles elsewhere.

Why: Content clauses. [[Russian#^ru-Q0720|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%BD%D0%B5%20%D0%BF%D0%BE%D0%B2%D0%B5%D1%80%D0%B8%D1%88%D1%8C%2C%20%D1%87%D1%82%D0%BE%20%D0%A2%D0%BE%D0%BC%20%D0%BC%D0%BD%D0%B5%20%D1%80%D0%B0%D1%81%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%21)
^ru-Q0720-answer

**ru-Q0721** — Я говорила вам, чтобы вы держались от меня подальше.

I told you to stay away from me.

Expected form: **чтобы**

Why: Content clauses. [[Russian#^ru-Q0721|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D0%BB%D0%B0%20%D0%B2%D0%B0%D0%BC%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D0%B2%D1%8B%20%D0%B4%D0%B5%D1%80%D0%B6%D0%B0%D0%BB%D0%B8%D1%81%D1%8C%20%D0%BE%D1%82%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D0%BF%D0%BE%D0%B4%D0%B0%D0%BB%D1%8C%D1%88%D0%B5.)
^ru-Q0721-answer

**ru-Q0722** — Я говорила вам, чтобы вы держались от меня подальше.

I told you to stay away from me.

Expected form: **чтобы**

Why: Content clauses. [[Russian#^ru-Q0722|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D0%BB%D0%B0%20%D0%B2%D0%B0%D0%BC%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D0%B2%D1%8B%20%D0%B4%D0%B5%D1%80%D0%B6%D0%B0%D0%BB%D0%B8%D1%81%D1%8C%20%D0%BE%D1%82%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D0%BF%D0%BE%D0%B4%D0%B0%D0%BB%D1%8C%D1%88%D0%B5.)
^ru-Q0722-answer

**ru-Q0723** — Я видел, как пожилая женщина переходила улицу.

I saw an old woman cross the street.

Expected form: **как**

Why: Content clauses. [[Russian#^ru-Q0723|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B2%D0%B8%D0%B4%D0%B5%D0%BB%2C%20%D0%BA%D0%B0%D0%BA%20%D0%BF%D0%BE%D0%B6%D0%B8%D0%BB%D0%B0%D1%8F%20%D0%B6%D0%B5%D0%BD%D1%89%D0%B8%D0%BD%D0%B0%20%D0%BF%D0%B5%D1%80%D0%B5%D1%85%D0%BE%D0%B4%D0%B8%D0%BB%D0%B0%20%D1%83%D0%BB%D0%B8%D1%86%D1%83.)
^ru-Q0723-answer

**ru-Q0724** — Я видел, как пожилая женщина переходила улицу.

I saw an old woman cross the street.

Why: Content clauses. [[Russian#^ru-Q0724|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B2%D0%B8%D0%B4%D0%B5%D0%BB%2C%20%D0%BA%D0%B0%D0%BA%20%D0%BF%D0%BE%D0%B6%D0%B8%D0%BB%D0%B0%D1%8F%20%D0%B6%D0%B5%D0%BD%D1%89%D0%B8%D0%BD%D0%B0%20%D0%BF%D0%B5%D1%80%D0%B5%D1%85%D0%BE%D0%B4%D0%B8%D0%BB%D0%B0%20%D1%83%D0%BB%D0%B8%D1%86%D1%83.)
^ru-Q0724-answer

**ru-Q0725** — Никогда не думал, что скажу такое.

I never thought I'd say that.

Why: Content clauses. [[Russian#^ru-Q0725|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B8%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%BD%D0%B5%20%D0%B4%D1%83%D0%BC%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D1%81%D0%BA%D0%B0%D0%B6%D1%83%20%D1%82%D0%B0%D0%BA%D0%BE%D0%B5.)
^ru-Q0725-answer

**ru-Q0726** — Никогда не думал, что скажу такое.

I never thought I'd say that.

Что can introduce reported content, while чтобы often marks purpose or a desired event. Ли helps form indirect yes/no questions. Identical words may have interrogative or relative roles elsewhere.

Why: Content clauses. [[Russian#^ru-Q0726|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B8%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%BD%D0%B5%20%D0%B4%D1%83%D0%BC%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D1%81%D0%BA%D0%B0%D0%B6%D1%83%20%D1%82%D0%B0%D0%BA%D0%BE%D0%B5.)
^ru-Q0726-answer

**ru-Q0727** — Воздух человеку, что рыбе вода.

Air is to man what water is to fish.

Expected form: **что**

Why: Content clauses. [[Russian#^ru-Q0727|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D0%BE%D0%B7%D0%B4%D1%83%D1%85%20%D1%87%D0%B5%D0%BB%D0%BE%D0%B2%D0%B5%D0%BA%D1%83%2C%20%D1%87%D1%82%D0%BE%20%D1%80%D1%8B%D0%B1%D0%B5%20%D0%B2%D0%BE%D0%B4%D0%B0.)
^ru-Q0727-answer

**ru-Q0728** — Воздух человеку, что рыбе вода.

Air is to man what water is to fish.

Expected form: **что**

Why: Content clauses. [[Russian#^ru-Q0728|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D0%BE%D0%B7%D0%B4%D1%83%D1%85%20%D1%87%D0%B5%D0%BB%D0%BE%D0%B2%D0%B5%D0%BA%D1%83%2C%20%D1%87%D1%82%D0%BE%20%D1%80%D1%8B%D0%B1%D0%B5%20%D0%B2%D0%BE%D0%B4%D0%B0.)
^ru-Q0728-answer

**ru-Q0729** — Что, если она ушла насовсем?

What if she's gone for good?

Expected form: **Что**

Why: Content clauses. [[Russian#^ru-Q0729|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A7%D1%82%D0%BE%2C%20%D0%B5%D1%81%D0%BB%D0%B8%20%D0%BE%D0%BD%D0%B0%20%D1%83%D1%88%D0%BB%D0%B0%20%D0%BD%D0%B0%D1%81%D0%BE%D0%B2%D1%81%D0%B5%D0%BC%3F)
^ru-Q0729-answer

**ru-Q0730** — Что, если она ушла насовсем?

What if she's gone for good?

Why: Content clauses. [[Russian#^ru-Q0730|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A7%D1%82%D0%BE%2C%20%D0%B5%D1%81%D0%BB%D0%B8%20%D0%BE%D0%BD%D0%B0%20%D1%83%D1%88%D0%BB%D0%B0%20%D0%BD%D0%B0%D1%81%D0%BE%D0%B2%D1%81%D0%B5%D0%BC%3F)
^ru-Q0730-answer

**ru-Q0731** — Я бы хотела такие же туфли, как эти.

I would like shoes like that.

Why: Content clauses. [[Russian#^ru-Q0731|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%8B%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%D0%B0%20%D1%82%D0%B0%D0%BA%D0%B8%D0%B5%20%D0%B6%D0%B5%20%D1%82%D1%83%D1%84%D0%BB%D0%B8%2C%20%D0%BA%D0%B0%D0%BA%20%D1%8D%D1%82%D0%B8.)
^ru-Q0731-answer

**ru-Q0732** — Я бы хотела такие же туфли, как эти.

I would like shoes like that.

Что can introduce reported content, while чтобы often marks purpose or a desired event. Ли helps form indirect yes/no questions. Identical words may have interrogative or relative roles elsewhere.

Why: Content clauses. [[Russian#^ru-Q0732|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%8B%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%D0%B0%20%D1%82%D0%B0%D0%BA%D0%B8%D0%B5%20%D0%B6%D0%B5%20%D1%82%D1%83%D1%84%D0%BB%D0%B8%2C%20%D0%BA%D0%B0%D0%BA%20%D1%8D%D1%82%D0%B8.)
^ru-Q0732-answer

**ru-Q0733** — Я не хотел, чтобы правда вышла наружу.

I didn't want the truth to come out.

Expected form: **чтобы**

Why: Content clauses. [[Russian#^ru-Q0733|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D0%BF%D1%80%D0%B0%D0%B2%D0%B4%D0%B0%20%D0%B2%D1%8B%D1%88%D0%BB%D0%B0%20%D0%BD%D0%B0%D1%80%D1%83%D0%B6%D1%83.)
^ru-Q0733-answer

**ru-Q0734** — Я не хотел, чтобы правда вышла наружу.

I didn't want the truth to come out.

Expected form: **чтобы**

Why: Content clauses. [[Russian#^ru-Q0734|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D0%BF%D1%80%D0%B0%D0%B2%D0%B4%D0%B0%20%D0%B2%D1%8B%D1%88%D0%BB%D0%B0%20%D0%BD%D0%B0%D1%80%D1%83%D0%B6%D1%83.)
^ru-Q0734-answer

**ru-Q0735** — Я не знал, как отказаться.

I didn't know how to say no.

Expected form: **как**

Why: Content clauses. [[Russian#^ru-Q0735|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D0%B7%D0%BD%D0%B0%D0%BB%2C%20%D0%BA%D0%B0%D0%BA%20%D0%BE%D1%82%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C%D1%81%D1%8F.)
^ru-Q0735-answer

**ru-Q0736** — Я не знал, как отказаться.

I didn't know how to say no.

Why: Content clauses. [[Russian#^ru-Q0736|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D0%B7%D0%BD%D0%B0%D0%BB%2C%20%D0%BA%D0%B0%D0%BA%20%D0%BE%D1%82%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C%D1%81%D1%8F.)
^ru-Q0736-answer

**ru-Q0737** — Скажи им, чтобы шли домой.

Tell them to go home.

Why: Content clauses. [[Russian#^ru-Q0737|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BA%D0%B0%D0%B6%D0%B8%20%D0%B8%D0%BC%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D1%88%D0%BB%D0%B8%20%D0%B4%D0%BE%D0%BC%D0%BE%D0%B9.)
^ru-Q0737-answer

**ru-Q0738** — Скажи им, чтобы шли домой.

Tell them to go home.

Что can introduce reported content, while чтобы often marks purpose or a desired event. Ли helps form indirect yes/no questions. Identical words may have interrogative or relative roles elsewhere.

Why: Content clauses. [[Russian#^ru-Q0738|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BA%D0%B0%D0%B6%D0%B8%20%D0%B8%D0%BC%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D1%88%D0%BB%D0%B8%20%D0%B4%D0%BE%D0%BC%D0%BE%D0%B9.)
^ru-Q0738-answer

**ru-Q0739** — Я знал, что этот день придёт.

I knew this day was coming.

Expected form: **что**

Why: Content clauses. [[Russian#^ru-Q0739|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B7%D0%BD%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D1%8D%D1%82%D0%BE%D1%82%20%D0%B4%D0%B5%D0%BD%D1%8C%20%D0%BF%D1%80%D0%B8%D0%B4%D1%91%D1%82.)
^ru-Q0739-answer

**ru-Q0740** — Я знал, что этот день придёт.

I knew this day was coming.

Expected form: **что**

Why: Content clauses. [[Russian#^ru-Q0740|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B7%D0%BD%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D1%8D%D1%82%D0%BE%D1%82%20%D0%B4%D0%B5%D0%BD%D1%8C%20%D0%BF%D1%80%D0%B8%D0%B4%D1%91%D1%82.)
^ru-Q0740-answer

**ru-Q0741** — Планируете ли вы сказать об этом Тому?

Do you plan on telling Tom to do that?

Expected form: **ли**

Why: Content clauses. [[Russian#^ru-Q0741|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BB%D0%B0%D0%BD%D0%B8%D1%80%D1%83%D0%B5%D1%82%D0%B5%20%D0%BB%D0%B8%20%D0%B2%D1%8B%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C%20%D0%BE%D0%B1%20%D1%8D%D1%82%D0%BE%D0%BC%20%D0%A2%D0%BE%D0%BC%D1%83%3F)
^ru-Q0741-answer

**ru-Q0742** — Планируете ли вы сказать об этом Тому?

Do you plan on telling Tom to do that?

Why: Content clauses. [[Russian#^ru-Q0742|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BB%D0%B0%D0%BD%D0%B8%D1%80%D1%83%D0%B5%D1%82%D0%B5%20%D0%BB%D0%B8%20%D0%B2%D1%8B%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C%20%D0%BE%D0%B1%20%D1%8D%D1%82%D0%BE%D0%BC%20%D0%A2%D0%BE%D0%BC%D1%83%3F)
^ru-Q0742-answer

**ru-Q0743** — Спасибо, что спасла мне жизнь.

Thanks for saving my life.

Why: Content clauses. [[Russian#^ru-Q0743|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BF%D0%B0%D1%81%D0%B8%D0%B1%D0%BE%2C%20%D1%87%D1%82%D0%BE%20%D1%81%D0%BF%D0%B0%D1%81%D0%BB%D0%B0%20%D0%BC%D0%BD%D0%B5%20%D0%B6%D0%B8%D0%B7%D0%BD%D1%8C.)
^ru-Q0743-answer

**ru-Q0744** — Спасибо, что спасла мне жизнь.

Thanks for saving my life.

Что can introduce reported content, while чтобы often marks purpose or a desired event. Ли helps form indirect yes/no questions. Identical words may have interrogative or relative roles elsewhere.

Why: Content clauses. [[Russian#^ru-Q0744|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BF%D0%B0%D1%81%D0%B8%D0%B1%D0%BE%2C%20%D1%87%D1%82%D0%BE%20%D1%81%D0%BF%D0%B0%D1%81%D0%BB%D0%B0%20%D0%BC%D0%BD%D0%B5%20%D0%B6%D0%B8%D0%B7%D0%BD%D1%8C.)
^ru-Q0744-answer

**ru-Q0745** — Разве я тебе не говорил, чтобы ты туда не ездил?

Didn't I tell you not to go there?

Expected form: **чтобы**

Why: Content clauses. [[Russian#^ru-Q0745|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A0%D0%B0%D0%B7%D0%B2%D0%B5%20%D1%8F%20%D1%82%D0%B5%D0%B1%D0%B5%20%D0%BD%D0%B5%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D0%BB%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D1%82%D1%8B%20%D1%82%D1%83%D0%B4%D0%B0%20%D0%BD%D0%B5%20%D0%B5%D0%B7%D0%B4%D0%B8%D0%BB%3F)
^ru-Q0745-answer

**ru-Q0746** — Разве я тебе не говорил, чтобы ты туда не ездил?

Didn't I tell you not to go there?

Expected form: **чтобы**

Why: Content clauses. [[Russian#^ru-Q0746|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A0%D0%B0%D0%B7%D0%B2%D0%B5%20%D1%8F%20%D1%82%D0%B5%D0%B1%D0%B5%20%D0%BD%D0%B5%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D0%BB%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D1%82%D1%8B%20%D1%82%D1%83%D0%B4%D0%B0%20%D0%BD%D0%B5%20%D0%B5%D0%B7%D0%B4%D0%B8%D0%BB%3F)
^ru-Q0746-answer

**ru-Q0747** — Том тебе не говорил, потому что не хотел, чтобы ты о нём беспокоилась.

Tom never told you because he didn't want you to worry about him.

Expected form: **что**

Why: Content clauses. [[Russian#^ru-Q0747|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%82%D0%B5%D0%B1%D0%B5%20%D0%BD%D0%B5%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D0%BB%2C%20%D0%BF%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE%20%D0%BD%D0%B5%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D1%82%D1%8B%20%D0%BE%20%D0%BD%D1%91%D0%BC%20%D0%B1%D0%B5%D1%81%D0%BF%D0%BE%D0%BA%D0%BE%D0%B8%D0%BB%D0%B0%D1%81%D1%8C.)
^ru-Q0747-answer

**ru-Q0748** — Том тебе не говорил, потому что не хотел, чтобы ты о нём беспокоилась.

Tom never told you because he didn't want you to worry about him.

Why: Content clauses. [[Russian#^ru-Q0748|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%82%D0%B5%D0%B1%D0%B5%20%D0%BD%D0%B5%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D0%BB%2C%20%D0%BF%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE%20%D0%BD%D0%B5%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%2C%20%D1%87%D1%82%D0%BE%D0%B1%D1%8B%20%D1%82%D1%8B%20%D0%BE%20%D0%BD%D1%91%D0%BC%20%D0%B1%D0%B5%D1%81%D0%BF%D0%BE%D0%BA%D0%BE%D0%B8%D0%BB%D0%B0%D1%81%D1%8C.)
^ru-Q0748-answer

**ru-Q0749** — Спасибо, что вернулись.

Thanks for coming back.

Why: Content clauses. [[Russian#^ru-Q0749|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BF%D0%B0%D1%81%D0%B8%D0%B1%D0%BE%2C%20%D1%87%D1%82%D0%BE%20%D0%B2%D0%B5%D1%80%D0%BD%D1%83%D0%BB%D0%B8%D1%81%D1%8C.)
^ru-Q0749-answer

**ru-Q0750** — Спасибо, что вернулись.

Thanks for coming back.

Что can introduce reported content, while чтобы often marks purpose or a desired event. Ли helps form indirect yes/no questions. Identical words may have interrogative or relative roles elsewhere.

Why: Content clauses. [[Russian#^ru-Q0750|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BF%D0%B0%D1%81%D0%B8%D0%B1%D0%BE%2C%20%D1%87%D1%82%D0%BE%20%D0%B2%D0%B5%D1%80%D0%BD%D1%83%D0%BB%D0%B8%D1%81%D1%8C.)
^ru-Q0750-answer


### Answers 751–800

**ru-Q0751** — Первым предметом, который он приобрёл, стал будильник.

The first item he bought was an alarm clock.

Expected form: **который**

Why: Relative forms. [[Russian#^ru-Q0751|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%B5%D1%80%D0%B2%D1%8B%D0%BC%20%D0%BF%D1%80%D0%B5%D0%B4%D0%BC%D0%B5%D1%82%D0%BE%D0%BC%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%8B%D0%B9%20%D0%BE%D0%BD%20%D0%BF%D1%80%D0%B8%D0%BE%D0%B1%D1%80%D1%91%D0%BB%2C%20%D1%81%D1%82%D0%B0%D0%BB%20%D0%B1%D1%83%D0%B4%D0%B8%D0%BB%D1%8C%D0%BD%D0%B8%D0%BA.)
^ru-Q0751-answer

**ru-Q0752** — Первым предметом, который он приобрёл, стал будильник.

The first item he bought was an alarm clock.

Expected form: **который**

Why: Relative forms. [[Russian#^ru-Q0752|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%B5%D1%80%D0%B2%D1%8B%D0%BC%20%D0%BF%D1%80%D0%B5%D0%B4%D0%BC%D0%B5%D1%82%D0%BE%D0%BC%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%8B%D0%B9%20%D0%BE%D0%BD%20%D0%BF%D1%80%D0%B8%D0%BE%D0%B1%D1%80%D1%91%D0%BB%2C%20%D1%81%D1%82%D0%B0%D0%BB%20%D0%B1%D1%83%D0%B4%D0%B8%D0%BB%D1%8C%D0%BD%D0%B8%D0%BA.)
^ru-Q0752-answer

**ru-Q0753** — Есть математическое понятие, которого я не понимаю. Не могли бы вы мне его объяснить?

There's a mathematical concept that I don't understand. Could you explain it to me?

Expected form: **которого**

Why: Relative forms. [[Russian#^ru-Q0753|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D1%82%D1%8C%20%D0%BC%D0%B0%D1%82%D0%B5%D0%BC%D0%B0%D1%82%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%BE%D0%B5%20%D0%BF%D0%BE%D0%BD%D1%8F%D1%82%D0%B8%D0%B5%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%BE%D0%B3%D0%BE%20%D1%8F%20%D0%BD%D0%B5%20%D0%BF%D0%BE%D0%BD%D0%B8%D0%BC%D0%B0%D1%8E.%20%D0%9D%D0%B5%20%D0%BC%D0%BE%D0%B3%D0%BB%D0%B8%20%D0%B1%D1%8B%20%D0%B2%D1%8B%20%D0%BC%D0%BD%D0%B5%20%D0%B5%D0%B3%D0%BE%20%D0%BE%D0%B1%D1%8A%D1%8F%D1%81%D0%BD%D0%B8%D1%82%D1%8C%3F)
^ru-Q0753-answer

**ru-Q0754** — Есть математическое понятие, которого я не понимаю. Не могли бы вы мне его объяснить?

There's a mathematical concept that I don't understand. Could you explain it to me?

Why: Relative forms. [[Russian#^ru-Q0754|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D1%82%D1%8C%20%D0%BC%D0%B0%D1%82%D0%B5%D0%BC%D0%B0%D1%82%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%BE%D0%B5%20%D0%BF%D0%BE%D0%BD%D1%8F%D1%82%D0%B8%D0%B5%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%BE%D0%B3%D0%BE%20%D1%8F%20%D0%BD%D0%B5%20%D0%BF%D0%BE%D0%BD%D0%B8%D0%BC%D0%B0%D1%8E.%20%D0%9D%D0%B5%20%D0%BC%D0%BE%D0%B3%D0%BB%D0%B8%20%D0%B1%D1%8B%20%D0%B2%D1%8B%20%D0%BC%D0%BD%D0%B5%20%D0%B5%D0%B3%D0%BE%20%D0%BE%D0%B1%D1%8A%D1%8F%D1%81%D0%BD%D0%B8%D1%82%D1%8C%3F)
^ru-Q0754-answer

**ru-Q0755** — Экзолуна - это луна, которая вращается вокруг экзопланеты.

An exomoon is a moon that orbits around an exoplanet.

Why: Relative forms. [[Russian#^ru-Q0755|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D0%BA%D0%B7%D0%BE%D0%BB%D1%83%D0%BD%D0%B0%20-%20%D1%8D%D1%82%D0%BE%20%D0%BB%D1%83%D0%BD%D0%B0%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%B0%D1%8F%20%D0%B2%D1%80%D0%B0%D1%89%D0%B0%D0%B5%D1%82%D1%81%D1%8F%20%D0%B2%D0%BE%D0%BA%D1%80%D1%83%D0%B3%20%D1%8D%D0%BA%D0%B7%D0%BE%D0%BF%D0%BB%D0%B0%D0%BD%D0%B5%D1%82%D1%8B.)
^ru-Q0755-answer

**ru-Q0756** — Экзолуна - это луна, которая вращается вокруг экзопланеты.

An exomoon is a moon that orbits around an exoplanet.

Который agrees with its antecedent for gender/number but takes case from its role inside the relative clause. Do not copy the antecedent’s case automatically.

Why: Relative forms. [[Russian#^ru-Q0756|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D0%BA%D0%B7%D0%BE%D0%BB%D1%83%D0%BD%D0%B0%20-%20%D1%8D%D1%82%D0%BE%20%D0%BB%D1%83%D0%BD%D0%B0%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%B0%D1%8F%20%D0%B2%D1%80%D0%B0%D1%89%D0%B0%D0%B5%D1%82%D1%81%D1%8F%20%D0%B2%D0%BE%D0%BA%D1%80%D1%83%D0%B3%20%D1%8D%D0%BA%D0%B7%D0%BE%D0%BF%D0%BB%D0%B0%D0%BD%D0%B5%D1%82%D1%8B.)
^ru-Q0756-answer

**ru-Q0757** — Я думаю, маловероятно, что Тому разрешат оставить себе золото, которое он нашел.

I think it's highly unlikely that Tom will be allowed to keep the gold that he found.

Expected form: **которое**

Why: Relative forms. [[Russian#^ru-Q0757|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B4%D1%83%D0%BC%D0%B0%D1%8E%2C%20%D0%BC%D0%B0%D0%BB%D0%BE%D0%B2%D0%B5%D1%80%D0%BE%D1%8F%D1%82%D0%BD%D0%BE%2C%20%D1%87%D1%82%D0%BE%20%D0%A2%D0%BE%D0%BC%D1%83%20%D1%80%D0%B0%D0%B7%D1%80%D0%B5%D1%88%D0%B0%D1%82%20%D0%BE%D1%81%D1%82%D0%B0%D0%B2%D0%B8%D1%82%D1%8C%20%D1%81%D0%B5%D0%B1%D0%B5%20%D0%B7%D0%BE%D0%BB%D0%BE%D1%82%D0%BE%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%BE%D0%B5%20%D0%BE%D0%BD%20%D0%BD%D0%B0%D1%88%D0%B5%D0%BB.)
^ru-Q0757-answer

**ru-Q0758** — Я думаю, маловероятно, что Тому разрешат оставить себе золото, которое он нашел.

I think it's highly unlikely that Tom will be allowed to keep the gold that he found.

Expected form: **которое**

Why: Relative forms. [[Russian#^ru-Q0758|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B4%D1%83%D0%BC%D0%B0%D1%8E%2C%20%D0%BC%D0%B0%D0%BB%D0%BE%D0%B2%D0%B5%D1%80%D0%BE%D1%8F%D1%82%D0%BD%D0%BE%2C%20%D1%87%D1%82%D0%BE%20%D0%A2%D0%BE%D0%BC%D1%83%20%D1%80%D0%B0%D0%B7%D1%80%D0%B5%D1%88%D0%B0%D1%82%20%D0%BE%D1%81%D1%82%D0%B0%D0%B2%D0%B8%D1%82%D1%8C%20%D1%81%D0%B5%D0%B1%D0%B5%20%D0%B7%D0%BE%D0%BB%D0%BE%D1%82%D0%BE%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%BE%D0%B5%20%D0%BE%D0%BD%20%D0%BD%D0%B0%D1%88%D0%B5%D0%BB.)
^ru-Q0758-answer

**ru-Q0759** — Мужчина, которого мы видели сегодня утром, был мистер Грин.

The man we saw this morning was Mr Green.

Expected form: **которого**

Why: Relative forms. [[Russian#^ru-Q0759|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%83%D0%B6%D1%87%D0%B8%D0%BD%D0%B0%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%BE%D0%B3%D0%BE%20%D0%BC%D1%8B%20%D0%B2%D0%B8%D0%B4%D0%B5%D0%BB%D0%B8%20%D1%81%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F%20%D1%83%D1%82%D1%80%D0%BE%D0%BC%2C%20%D0%B1%D1%8B%D0%BB%20%D0%BC%D0%B8%D1%81%D1%82%D0%B5%D1%80%20%D0%93%D1%80%D0%B8%D0%BD.)
^ru-Q0759-answer

**ru-Q0760** — Мужчина, которого мы видели сегодня утром, был мистер Грин.

The man we saw this morning was Mr Green.

Why: Relative forms. [[Russian#^ru-Q0760|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%83%D0%B6%D1%87%D0%B8%D0%BD%D0%B0%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%BE%D0%B3%D0%BE%20%D0%BC%D1%8B%20%D0%B2%D0%B8%D0%B4%D0%B5%D0%BB%D0%B8%20%D1%81%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F%20%D1%83%D1%82%D1%80%D0%BE%D0%BC%2C%20%D0%B1%D1%8B%D0%BB%20%D0%BC%D0%B8%D1%81%D1%82%D0%B5%D1%80%20%D0%93%D1%80%D0%B8%D0%BD.)
^ru-Q0760-answer

**ru-Q0761** — Я не ошибался. Я просто нашёл 10000 способов, которые не работают.

I have not failed. I've just found 10,000 ways that won't work.

Why: Relative forms. [[Russian#^ru-Q0761|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D0%BE%D1%88%D0%B8%D0%B1%D0%B0%D0%BB%D1%81%D1%8F.%20%D0%AF%20%D0%BF%D1%80%D0%BE%D1%81%D1%82%D0%BE%20%D0%BD%D0%B0%D1%88%D1%91%D0%BB%2010000%20%D1%81%D0%BF%D0%BE%D1%81%D0%BE%D0%B1%D0%BE%D0%B2%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%8B%D0%B5%20%D0%BD%D0%B5%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B0%D1%8E%D1%82.)
^ru-Q0761-answer

**ru-Q0762** — Я не ошибался. Я просто нашёл 10000 способов, которые не работают.

I have not failed. I've just found 10,000 ways that won't work.

Который agrees with its antecedent for gender/number but takes case from its role inside the relative clause. Do not copy the antecedent’s case automatically.

Why: Relative forms. [[Russian#^ru-Q0762|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D0%BE%D1%88%D0%B8%D0%B1%D0%B0%D0%BB%D1%81%D1%8F.%20%D0%AF%20%D0%BF%D1%80%D0%BE%D1%81%D1%82%D0%BE%20%D0%BD%D0%B0%D1%88%D1%91%D0%BB%2010000%20%D1%81%D0%BF%D0%BE%D1%81%D0%BE%D0%B1%D0%BE%D0%B2%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%8B%D0%B5%20%D0%BD%D0%B5%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B0%D1%8E%D1%82.)
^ru-Q0762-answer

**ru-Q0763** — Нет ничего пугающего в обычной, естественной смерти; в смерти человека, который реализовал себя и прожил свою жизнь.

There is nothing frightening about a normal, natural death, the death of a man who has fulfilled himself and lived out his life.

Expected form: **который**

Why: Relative forms. [[Russian#^ru-Q0763|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%D1%82%20%D0%BD%D0%B8%D1%87%D0%B5%D0%B3%D0%BE%20%D0%BF%D1%83%D0%B3%D0%B0%D1%8E%D1%89%D0%B5%D0%B3%D0%BE%20%D0%B2%20%D0%BE%D0%B1%D1%8B%D1%87%D0%BD%D0%BE%D0%B9%2C%20%D0%B5%D1%81%D1%82%D0%B5%D1%81%D1%82%D0%B2%D0%B5%D0%BD%D0%BD%D0%BE%D0%B9%20%D1%81%D0%BC%D0%B5%D1%80%D1%82%D0%B8%3B%20%D0%B2%20%D1%81%D0%BC%D0%B5%D1%80%D1%82%D0%B8%20%D1%87%D0%B5%D0%BB%D0%BE%D0%B2%D0%B5%D0%BA%D0%B0%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%8B%D0%B9%20%D1%80%D0%B5%D0%B0%D0%BB%D0%B8%D0%B7%D0%BE%D0%B2%D0%B0%D0%BB%20%D1%81%D0%B5%D0%B1%D1%8F%20%D0%B8%20%D0%BF%D1%80%D0%BE%D0%B6%D0%B8%D0%BB%20%D1%81%D0%B2%D0%BE%D1%8E%20%D0%B6%D0%B8%D0%B7%D0%BD%D1%8C.)
^ru-Q0763-answer

**ru-Q0764** — Нет ничего пугающего в обычной, естественной смерти; в смерти человека, который реализовал себя и прожил свою жизнь.

There is nothing frightening about a normal, natural death, the death of a man who has fulfilled himself and lived out his life.

Expected form: **который**

Why: Relative forms. [[Russian#^ru-Q0764|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%D1%82%20%D0%BD%D0%B8%D1%87%D0%B5%D0%B3%D0%BE%20%D0%BF%D1%83%D0%B3%D0%B0%D1%8E%D1%89%D0%B5%D0%B3%D0%BE%20%D0%B2%20%D0%BE%D0%B1%D1%8B%D1%87%D0%BD%D0%BE%D0%B9%2C%20%D0%B5%D1%81%D1%82%D0%B5%D1%81%D1%82%D0%B2%D0%B5%D0%BD%D0%BD%D0%BE%D0%B9%20%D1%81%D0%BC%D0%B5%D1%80%D1%82%D0%B8%3B%20%D0%B2%20%D1%81%D0%BC%D0%B5%D1%80%D1%82%D0%B8%20%D1%87%D0%B5%D0%BB%D0%BE%D0%B2%D0%B5%D0%BA%D0%B0%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%8B%D0%B9%20%D1%80%D0%B5%D0%B0%D0%BB%D0%B8%D0%B7%D0%BE%D0%B2%D0%B0%D0%BB%20%D1%81%D0%B5%D0%B1%D1%8F%20%D0%B8%20%D0%BF%D1%80%D0%BE%D0%B6%D0%B8%D0%BB%20%D1%81%D0%B2%D0%BE%D1%8E%20%D0%B6%D0%B8%D0%B7%D0%BD%D1%8C.)
^ru-Q0764-answer

**ru-Q0765** — Машина красивая, но она не стоит тех денег, которые я отдал за неё.

It is a beautiful car, but it is not worth the price that I paid for it.

Expected form: **которые**

Why: Relative forms. [[Russian#^ru-Q0765|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%B0%D1%88%D0%B8%D0%BD%D0%B0%20%D0%BA%D1%80%D0%B0%D1%81%D0%B8%D0%B2%D0%B0%D1%8F%2C%20%D0%BD%D0%BE%20%D0%BE%D0%BD%D0%B0%20%D0%BD%D0%B5%20%D1%81%D1%82%D0%BE%D0%B8%D1%82%20%D1%82%D0%B5%D1%85%20%D0%B4%D0%B5%D0%BD%D0%B5%D0%B3%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%8B%D0%B5%20%D1%8F%20%D0%BE%D1%82%D0%B4%D0%B0%D0%BB%20%D0%B7%D0%B0%20%D0%BD%D0%B5%D1%91.)
^ru-Q0765-answer

**ru-Q0766** — Машина красивая, но она не стоит тех денег, которые я отдал за неё.

It is a beautiful car, but it is not worth the price that I paid for it.

Why: Relative forms. [[Russian#^ru-Q0766|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%B0%D1%88%D0%B8%D0%BD%D0%B0%20%D0%BA%D1%80%D0%B0%D1%81%D0%B8%D0%B2%D0%B0%D1%8F%2C%20%D0%BD%D0%BE%20%D0%BE%D0%BD%D0%B0%20%D0%BD%D0%B5%20%D1%81%D1%82%D0%BE%D0%B8%D1%82%20%D1%82%D0%B5%D1%85%20%D0%B4%D0%B5%D0%BD%D0%B5%D0%B3%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%8B%D0%B5%20%D1%8F%20%D0%BE%D1%82%D0%B4%D0%B0%D0%BB%20%D0%B7%D0%B0%20%D0%BD%D0%B5%D1%91.)
^ru-Q0766-answer

**ru-Q0767** — Это место, в котором родился мой отец.

This is the place where my father was born.

Why: Relative forms. [[Russian#^ru-Q0767|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D1%82%D0%BE%20%D0%BC%D0%B5%D1%81%D1%82%D0%BE%2C%20%D0%B2%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%BE%D0%BC%20%D1%80%D0%BE%D0%B4%D0%B8%D0%BB%D1%81%D1%8F%20%D0%BC%D0%BE%D0%B9%20%D0%BE%D1%82%D0%B5%D1%86.)
^ru-Q0767-answer

**ru-Q0768** — Это место, в котором родился мой отец.

This is the place where my father was born.

Который agrees with its antecedent for gender/number but takes case from its role inside the relative clause. Do not copy the antecedent’s case automatically.

Why: Relative forms. [[Russian#^ru-Q0768|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D1%82%D0%BE%20%D0%BC%D0%B5%D1%81%D1%82%D0%BE%2C%20%D0%B2%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%BE%D0%BC%20%D1%80%D0%BE%D0%B4%D0%B8%D0%BB%D1%81%D1%8F%20%D0%BC%D0%BE%D0%B9%20%D0%BE%D1%82%D0%B5%D1%86.)
^ru-Q0768-answer

**ru-Q0769** — Это тот мужчина, жена которого умерла.

That's the man whose wife died.

Expected form: **которого**

Why: Relative forms. [[Russian#^ru-Q0769|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D1%82%D0%BE%20%D1%82%D0%BE%D1%82%20%D0%BC%D1%83%D0%B6%D1%87%D0%B8%D0%BD%D0%B0%2C%20%D0%B6%D0%B5%D0%BD%D0%B0%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%BE%D0%B3%D0%BE%20%D1%83%D0%BC%D0%B5%D1%80%D0%BB%D0%B0.)
^ru-Q0769-answer

**ru-Q0770** — Это тот мужчина, жена которого умерла.

That's the man whose wife died.

Expected form: **которого**

Why: Relative forms. [[Russian#^ru-Q0770|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AD%D1%82%D0%BE%20%D1%82%D0%BE%D1%82%20%D0%BC%D1%83%D0%B6%D1%87%D0%B8%D0%BD%D0%B0%2C%20%D0%B6%D0%B5%D0%BD%D0%B0%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%BE%D0%B3%D0%BE%20%D1%83%D0%BC%D0%B5%D1%80%D0%BB%D0%B0.)
^ru-Q0770-answer

**ru-Q0771** — Мы нашли ту вещь, которую искали.

We found the thing we were looking for.

Expected form: **которую**

Why: Relative forms. [[Russian#^ru-Q0771|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%BD%D0%B0%D1%88%D0%BB%D0%B8%20%D1%82%D1%83%20%D0%B2%D0%B5%D1%89%D1%8C%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%83%D1%8E%20%D0%B8%D1%81%D0%BA%D0%B0%D0%BB%D0%B8.)
^ru-Q0771-answer

**ru-Q0772** — Мы нашли ту вещь, которую искали.

We found the thing we were looking for.

Why: Relative forms. [[Russian#^ru-Q0772|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%BD%D0%B0%D1%88%D0%BB%D0%B8%20%D1%82%D1%83%20%D0%B2%D0%B5%D1%89%D1%8C%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%83%D1%8E%20%D0%B8%D1%81%D0%BA%D0%B0%D0%BB%D0%B8.)
^ru-Q0772-answer

**ru-Q0773** — У меня есть я-2, который сильнее, чем мой я-1.

I have a Me 2, which is stronger than my Me 1.

Why: Relative forms. [[Russian#^ru-Q0773|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D0%B5%D1%81%D1%82%D1%8C%20%D1%8F-2%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%8B%D0%B9%20%D1%81%D0%B8%D0%BB%D1%8C%D0%BD%D0%B5%D0%B5%2C%20%D1%87%D0%B5%D0%BC%20%D0%BC%D0%BE%D0%B9%20%D1%8F-1.)
^ru-Q0773-answer

**ru-Q0774** — У меня есть я-2, который сильнее, чем мой я-1.

I have a Me 2, which is stronger than my Me 1.

Который agrees with its antecedent for gender/number but takes case from its role inside the relative clause. Do not copy the antecedent’s case automatically.

Why: Relative forms. [[Russian#^ru-Q0774|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D0%B5%D1%81%D1%82%D1%8C%20%D1%8F-2%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%8B%D0%B9%20%D1%81%D0%B8%D0%BB%D1%8C%D0%BD%D0%B5%D0%B5%2C%20%D1%87%D0%B5%D0%BC%20%D0%BC%D0%BE%D0%B9%20%D1%8F-1.)
^ru-Q0774-answer

**ru-Q0775** — Зонтик, который я вам дал, всё ещё у вас?

Do you still have that umbrella I gave you?

Expected form: **который**

Why: Relative forms. [[Russian#^ru-Q0775|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%97%D0%BE%D0%BD%D1%82%D0%B8%D0%BA%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%8B%D0%B9%20%D1%8F%20%D0%B2%D0%B0%D0%BC%20%D0%B4%D0%B0%D0%BB%2C%20%D0%B2%D1%81%D1%91%20%D0%B5%D1%89%D1%91%20%D1%83%20%D0%B2%D0%B0%D1%81%3F)
^ru-Q0775-answer

**ru-Q0776** — Зонтик, который я вам дал, всё ещё у вас?

Do you still have that umbrella I gave you?

Expected form: **который**

Why: Relative forms. [[Russian#^ru-Q0776|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%97%D0%BE%D0%BD%D1%82%D0%B8%D0%BA%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%8B%D0%B9%20%D1%8F%20%D0%B2%D0%B0%D0%BC%20%D0%B4%D0%B0%D0%BB%2C%20%D0%B2%D1%81%D1%91%20%D0%B5%D1%89%D1%91%20%D1%83%20%D0%B2%D0%B0%D1%81%3F)
^ru-Q0776-answer

**ru-Q0777** — Нам сложно выбрать, который из них купить.

We find it difficult to decide which one to buy.

Expected form: **который**

Why: Relative forms. [[Russian#^ru-Q0777|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%D0%BC%20%D1%81%D0%BB%D0%BE%D0%B6%D0%BD%D0%BE%20%D0%B2%D1%8B%D0%B1%D1%80%D0%B0%D1%82%D1%8C%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%8B%D0%B9%20%D0%B8%D0%B7%20%D0%BD%D0%B8%D1%85%20%D0%BA%D1%83%D0%BF%D0%B8%D1%82%D1%8C.)
^ru-Q0777-answer

**ru-Q0778** — Нам сложно выбрать, который из них купить.

We find it difficult to decide which one to buy.

Why: Relative forms. [[Russian#^ru-Q0778|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%D0%BC%20%D1%81%D0%BB%D0%BE%D0%B6%D0%BD%D0%BE%20%D0%B2%D1%8B%D0%B1%D1%80%D0%B0%D1%82%D1%8C%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%8B%D0%B9%20%D0%B8%D0%B7%20%D0%BD%D0%B8%D1%85%20%D0%BA%D1%83%D0%BF%D0%B8%D1%82%D1%8C.)
^ru-Q0778-answer

**ru-Q0779** — Вы прочли книгу, которую Том вам купил?

Have you read the book Tom bought for you?

Why: Relative forms. [[Russian#^ru-Q0779|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D0%BF%D1%80%D0%BE%D1%87%D0%BB%D0%B8%20%D0%BA%D0%BD%D0%B8%D0%B3%D1%83%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%83%D1%8E%20%D0%A2%D0%BE%D0%BC%20%D0%B2%D0%B0%D0%BC%20%D0%BA%D1%83%D0%BF%D0%B8%D0%BB%3F)
^ru-Q0779-answer

**ru-Q0780** — Вы прочли книгу, которую Том вам купил?

Have you read the book Tom bought for you?

Который agrees with its antecedent for gender/number but takes case from its role inside the relative clause. Do not copy the antecedent’s case automatically.

Why: Relative forms. [[Russian#^ru-Q0780|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D0%BF%D1%80%D0%BE%D1%87%D0%BB%D0%B8%20%D0%BA%D0%BD%D0%B8%D0%B3%D1%83%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%83%D1%8E%20%D0%A2%D0%BE%D0%BC%20%D0%B2%D0%B0%D0%BC%20%D0%BA%D1%83%D0%BF%D0%B8%D0%BB%3F)
^ru-Q0780-answer

**ru-Q0781** — Я помню радостные дни, которые мы провели вместе.

I remember the happy days we spent together.

Expected form: **которые**

Why: Relative forms. [[Russian#^ru-Q0781|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BF%D0%BE%D0%BC%D0%BD%D1%8E%20%D1%80%D0%B0%D0%B4%D0%BE%D1%81%D1%82%D0%BD%D1%8B%D0%B5%20%D0%B4%D0%BD%D0%B8%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%8B%D0%B5%20%D0%BC%D1%8B%20%D0%BF%D1%80%D0%BE%D0%B2%D0%B5%D0%BB%D0%B8%20%D0%B2%D0%BC%D0%B5%D1%81%D1%82%D0%B5.)
^ru-Q0781-answer

**ru-Q0782** — Я помню радостные дни, которые мы провели вместе.

I remember the happy days we spent together.

Expected form: **которые**

Why: Relative forms. [[Russian#^ru-Q0782|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BF%D0%BE%D0%BC%D0%BD%D1%8E%20%D1%80%D0%B0%D0%B4%D0%BE%D1%81%D1%82%D0%BD%D1%8B%D0%B5%20%D0%B4%D0%BD%D0%B8%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%8B%D0%B5%20%D0%BC%D1%8B%20%D0%BF%D1%80%D0%BE%D0%B2%D0%B5%D0%BB%D0%B8%20%D0%B2%D0%BC%D0%B5%D1%81%D1%82%D0%B5.)
^ru-Q0782-answer

**ru-Q0783** — Все, чего хотел Том, - это найти женщину, которая была бы способна принять его любовь.

All Tom wanted was to find a woman who would accept all the love he had to give.

Expected form: **которая**

Why: Relative forms. [[Russian#^ru-Q0783|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%81%D0%B5%2C%20%D1%87%D0%B5%D0%B3%D0%BE%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%20%D0%A2%D0%BE%D0%BC%2C%20-%20%D1%8D%D1%82%D0%BE%20%D0%BD%D0%B0%D0%B9%D1%82%D0%B8%20%D0%B6%D0%B5%D0%BD%D1%89%D0%B8%D0%BD%D1%83%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%B0%D1%8F%20%D0%B1%D1%8B%D0%BB%D0%B0%20%D0%B1%D1%8B%20%D1%81%D0%BF%D0%BE%D1%81%D0%BE%D0%B1%D0%BD%D0%B0%20%D0%BF%D1%80%D0%B8%D0%BD%D1%8F%D1%82%D1%8C%20%D0%B5%D0%B3%D0%BE%20%D0%BB%D1%8E%D0%B1%D0%BE%D0%B2%D1%8C.)
^ru-Q0783-answer

**ru-Q0784** — Все, чего хотел Том, - это найти женщину, которая была бы способна принять его любовь.

All Tom wanted was to find a woman who would accept all the love he had to give.

Why: Relative forms. [[Russian#^ru-Q0784|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%81%D0%B5%2C%20%D1%87%D0%B5%D0%B3%D0%BE%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%20%D0%A2%D0%BE%D0%BC%2C%20-%20%D1%8D%D1%82%D0%BE%20%D0%BD%D0%B0%D0%B9%D1%82%D0%B8%20%D0%B6%D0%B5%D0%BD%D1%89%D0%B8%D0%BD%D1%83%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%B0%D1%8F%20%D0%B1%D1%8B%D0%BB%D0%B0%20%D0%B1%D1%8B%20%D1%81%D0%BF%D0%BE%D1%81%D0%BE%D0%B1%D0%BD%D0%B0%20%D0%BF%D1%80%D0%B8%D0%BD%D1%8F%D1%82%D1%8C%20%D0%B5%D0%B3%D0%BE%20%D0%BB%D1%8E%D0%B1%D0%BE%D0%B2%D1%8C.)
^ru-Q0784-answer

**ru-Q0785** — Я знаю одну девушку, которая говорит по-французски.

I know a girl who speaks French.

Why: Relative forms. [[Russian#^ru-Q0785|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B7%D0%BD%D0%B0%D1%8E%20%D0%BE%D0%B4%D0%BD%D1%83%20%D0%B4%D0%B5%D0%B2%D1%83%D1%88%D0%BA%D1%83%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%B0%D1%8F%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%20%D0%BF%D0%BE-%D1%84%D1%80%D0%B0%D0%BD%D1%86%D1%83%D0%B7%D1%81%D0%BA%D0%B8.)
^ru-Q0785-answer

**ru-Q0786** — Я знаю одну девушку, которая говорит по-французски.

I know a girl who speaks French.

Который agrees with its antecedent for gender/number but takes case from its role inside the relative clause. Do not copy the antecedent’s case automatically.

Why: Relative forms. [[Russian#^ru-Q0786|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B7%D0%BD%D0%B0%D1%8E%20%D0%BE%D0%B4%D0%BD%D1%83%20%D0%B4%D0%B5%D0%B2%D1%83%D1%88%D0%BA%D1%83%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%B0%D1%8F%20%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%20%D0%BF%D0%BE-%D1%84%D1%80%D0%B0%D0%BD%D1%86%D1%83%D0%B7%D1%81%D0%BA%D0%B8.)
^ru-Q0786-answer

**ru-Q0787** — Когда читаешь книгу на английском, плохая идея искать перевод каждого слова, которого не знаешь.

When you're reading an English book, it isn't a great idea to look up every word you don't know.

Expected form: **которого**

Why: Relative forms. [[Russian#^ru-Q0787|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%BE%D0%B3%D0%B4%D0%B0%20%D1%87%D0%B8%D1%82%D0%B0%D0%B5%D1%88%D1%8C%20%D0%BA%D0%BD%D0%B8%D0%B3%D1%83%20%D0%BD%D0%B0%20%D0%B0%D0%BD%D0%B3%D0%BB%D0%B8%D0%B9%D1%81%D0%BA%D0%BE%D0%BC%2C%20%D0%BF%D0%BB%D0%BE%D1%85%D0%B0%D1%8F%20%D0%B8%D0%B4%D0%B5%D1%8F%20%D0%B8%D1%81%D0%BA%D0%B0%D1%82%D1%8C%20%D0%BF%D0%B5%D1%80%D0%B5%D0%B2%D0%BE%D0%B4%20%D0%BA%D0%B0%D0%B6%D0%B4%D0%BE%D0%B3%D0%BE%20%D1%81%D0%BB%D0%BE%D0%B2%D0%B0%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%BE%D0%B3%D0%BE%20%D0%BD%D0%B5%20%D0%B7%D0%BD%D0%B0%D0%B5%D1%88%D1%8C.)
^ru-Q0787-answer

**ru-Q0788** — Когда читаешь книгу на английском, плохая идея искать перевод каждого слова, которого не знаешь.

When you're reading an English book, it isn't a great idea to look up every word you don't know.

Expected form: **которого**

Why: Relative forms. [[Russian#^ru-Q0788|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%BE%D0%B3%D0%B4%D0%B0%20%D1%87%D0%B8%D1%82%D0%B0%D0%B5%D1%88%D1%8C%20%D0%BA%D0%BD%D0%B8%D0%B3%D1%83%20%D0%BD%D0%B0%20%D0%B0%D0%BD%D0%B3%D0%BB%D0%B8%D0%B9%D1%81%D0%BA%D0%BE%D0%BC%2C%20%D0%BF%D0%BB%D0%BE%D1%85%D0%B0%D1%8F%20%D0%B8%D0%B4%D0%B5%D1%8F%20%D0%B8%D1%81%D0%BA%D0%B0%D1%82%D1%8C%20%D0%BF%D0%B5%D1%80%D0%B5%D0%B2%D0%BE%D0%B4%20%D0%BA%D0%B0%D0%B6%D0%B4%D0%BE%D0%B3%D0%BE%20%D1%81%D0%BB%D0%BE%D0%B2%D0%B0%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%BE%D0%B3%D0%BE%20%D0%BD%D0%B5%20%D0%B7%D0%BD%D0%B0%D0%B5%D1%88%D1%8C.)
^ru-Q0788-answer

**ru-Q0789** — Тому были нужны деньги, и он сказал, что устроится на любую работу, которую ему предложат.

Tom was hard up for money and said he would take any job he was offered.

Expected form: **которую**

Why: Relative forms. [[Russian#^ru-Q0789|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%D1%83%20%D0%B1%D1%8B%D0%BB%D0%B8%20%D0%BD%D1%83%D0%B6%D0%BD%D1%8B%20%D0%B4%D0%B5%D0%BD%D1%8C%D0%B3%D0%B8%2C%20%D0%B8%20%D0%BE%D0%BD%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D1%83%D1%81%D1%82%D1%80%D0%BE%D0%B8%D1%82%D1%81%D1%8F%20%D0%BD%D0%B0%20%D0%BB%D1%8E%D0%B1%D1%83%D1%8E%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%83%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%83%D1%8E%20%D0%B5%D0%BC%D1%83%20%D0%BF%D1%80%D0%B5%D0%B4%D0%BB%D0%BE%D0%B6%D0%B0%D1%82.)
^ru-Q0789-answer

**ru-Q0790** — Тому были нужны деньги, и он сказал, что устроится на любую работу, которую ему предложат.

Tom was hard up for money and said he would take any job he was offered.

Why: Relative forms. [[Russian#^ru-Q0790|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%D1%83%20%D0%B1%D1%8B%D0%BB%D0%B8%20%D0%BD%D1%83%D0%B6%D0%BD%D1%8B%20%D0%B4%D0%B5%D0%BD%D1%8C%D0%B3%D0%B8%2C%20%D0%B8%20%D0%BE%D0%BD%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%2C%20%D1%87%D1%82%D0%BE%20%D1%83%D1%81%D1%82%D1%80%D0%BE%D0%B8%D1%82%D1%81%D1%8F%20%D0%BD%D0%B0%20%D0%BB%D1%8E%D0%B1%D1%83%D1%8E%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%83%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%83%D1%8E%20%D0%B5%D0%BC%D1%83%20%D0%BF%D1%80%D0%B5%D0%B4%D0%BB%D0%BE%D0%B6%D0%B0%D1%82.)
^ru-Q0790-answer

**ru-Q0791** — Том ещё не съел печенье, которое вы ему испекли.

Tom still hasn't eaten the cookies you made for him.

Why: Relative forms. [[Russian#^ru-Q0791|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B5%D1%89%D1%91%20%D0%BD%D0%B5%20%D1%81%D1%8A%D0%B5%D0%BB%20%D0%BF%D0%B5%D1%87%D0%B5%D0%BD%D1%8C%D0%B5%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%BE%D0%B5%20%D0%B2%D1%8B%20%D0%B5%D0%BC%D1%83%20%D0%B8%D1%81%D0%BF%D0%B5%D0%BA%D0%BB%D0%B8.)
^ru-Q0791-answer

**ru-Q0792** — Том ещё не съел печенье, которое вы ему испекли.

Tom still hasn't eaten the cookies you made for him.

Который agrees with its antecedent for gender/number but takes case from its role inside the relative clause. Do not copy the antecedent’s case automatically.

Why: Relative forms. [[Russian#^ru-Q0792|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B5%D1%89%D1%91%20%D0%BD%D0%B5%20%D1%81%D1%8A%D0%B5%D0%BB%20%D0%BF%D0%B5%D1%87%D0%B5%D0%BD%D1%8C%D0%B5%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%BE%D0%B5%20%D0%B2%D1%8B%20%D0%B5%D0%BC%D1%83%20%D0%B8%D1%81%D0%BF%D0%B5%D0%BA%D0%BB%D0%B8.)
^ru-Q0792-answer

**ru-Q0793** — Мне не понравилось платье, в котором Мэри была.

I didn't like the dress that Mary was wearing.

Expected form: **котором**

Why: Relative forms. [[Russian#^ru-Q0793|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BD%D0%B5%20%D0%BD%D0%B5%20%D0%BF%D0%BE%D0%BD%D1%80%D0%B0%D0%B2%D0%B8%D0%BB%D0%BE%D1%81%D1%8C%20%D0%BF%D0%BB%D0%B0%D1%82%D1%8C%D0%B5%2C%20%D0%B2%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%BE%D0%BC%20%D0%9C%D1%8D%D1%80%D0%B8%20%D0%B1%D1%8B%D0%BB%D0%B0.)
^ru-Q0793-answer

**ru-Q0794** — Мне не понравилось платье, в котором Мэри была.

I didn't like the dress that Mary was wearing.

Expected form: **котором**

Why: Relative forms. [[Russian#^ru-Q0794|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BD%D0%B5%20%D0%BD%D0%B5%20%D0%BF%D0%BE%D0%BD%D1%80%D0%B0%D0%B2%D0%B8%D0%BB%D0%BE%D1%81%D1%8C%20%D0%BF%D0%BB%D0%B0%D1%82%D1%8C%D0%B5%2C%20%D0%B2%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%BE%D0%BC%20%D0%9C%D1%8D%D1%80%D0%B8%20%D0%B1%D1%8B%D0%BB%D0%B0.)
^ru-Q0794-answer

**ru-Q0795** — Том нашёл то место, которое искал.

Tom found the place he was looking for.

Expected form: **которое**

Why: Relative forms. [[Russian#^ru-Q0795|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B0%D1%88%D1%91%D0%BB%20%D1%82%D0%BE%20%D0%BC%D0%B5%D1%81%D1%82%D0%BE%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%BE%D0%B5%20%D0%B8%D1%81%D0%BA%D0%B0%D0%BB.)
^ru-Q0795-answer

**ru-Q0796** — Том нашёл то место, которое искал.

Tom found the place he was looking for.

Why: Relative forms. [[Russian#^ru-Q0796|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B0%D1%88%D1%91%D0%BB%20%D1%82%D0%BE%20%D0%BC%D0%B5%D1%81%D1%82%D0%BE%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%BE%D0%B5%20%D0%B8%D1%81%D0%BA%D0%B0%D0%BB.)
^ru-Q0796-answer

**ru-Q0797** — Мой дедушка, у которого старомодные взгляды на жизнь, сетует на то, как одеваются современные девушки.

My grandfather, who has an old-fashioned attitude, complains about how girls dress nowadays.

Why: Relative forms. [[Russian#^ru-Q0797|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D0%B9%20%D0%B4%D0%B5%D0%B4%D1%83%D1%88%D0%BA%D0%B0%2C%20%D1%83%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%BE%D0%B3%D0%BE%20%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BC%D0%BE%D0%B4%D0%BD%D1%8B%D0%B5%20%D0%B2%D0%B7%D0%B3%D0%BB%D1%8F%D0%B4%D1%8B%20%D0%BD%D0%B0%20%D0%B6%D0%B8%D0%B7%D0%BD%D1%8C%2C%20%D1%81%D0%B5%D1%82%D1%83%D0%B5%D1%82%20%D0%BD%D0%B0%20%D1%82%D0%BE%2C%20%D0%BA%D0%B0%D0%BA%20%D0%BE%D0%B4%D0%B5%D0%B2%D0%B0%D1%8E%D1%82%D1%81%D1%8F%20%D1%81%D0%BE%D0%B2%D1%80%D0%B5%D0%BC%D0%B5%D0%BD%D0%BD%D1%8B%D0%B5%20%D0%B4%D0%B5%D0%B2%D1%83%D1%88%D0%BA%D0%B8.)
^ru-Q0797-answer

**ru-Q0798** — Мой дедушка, у которого старомодные взгляды на жизнь, сетует на то, как одеваются современные девушки.

My grandfather, who has an old-fashioned attitude, complains about how girls dress nowadays.

Который agrees with its antecedent for gender/number but takes case from its role inside the relative clause. Do not copy the antecedent’s case automatically.

Why: Relative forms. [[Russian#^ru-Q0798|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D0%B9%20%D0%B4%D0%B5%D0%B4%D1%83%D1%88%D0%BA%D0%B0%2C%20%D1%83%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%BE%D0%B3%D0%BE%20%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BC%D0%BE%D0%B4%D0%BD%D1%8B%D0%B5%20%D0%B2%D0%B7%D0%B3%D0%BB%D1%8F%D0%B4%D1%8B%20%D0%BD%D0%B0%20%D0%B6%D0%B8%D0%B7%D0%BD%D1%8C%2C%20%D1%81%D0%B5%D1%82%D1%83%D0%B5%D1%82%20%D0%BD%D0%B0%20%D1%82%D0%BE%2C%20%D0%BA%D0%B0%D0%BA%20%D0%BE%D0%B4%D0%B5%D0%B2%D0%B0%D1%8E%D1%82%D1%81%D1%8F%20%D1%81%D0%BE%D0%B2%D1%80%D0%B5%D0%BC%D0%B5%D0%BD%D0%BD%D1%8B%D0%B5%20%D0%B4%D0%B5%D0%B2%D1%83%D1%88%D0%BA%D0%B8.)
^ru-Q0798-answer

**ru-Q0799** — Машина, которую он ведёт, не его.

The car he's driving is not his.

Expected form: **которую**

Why: Relative forms. [[Russian#^ru-Q0799|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%B0%D1%88%D0%B8%D0%BD%D0%B0%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%83%D1%8E%20%D0%BE%D0%BD%20%D0%B2%D0%B5%D0%B4%D1%91%D1%82%2C%20%D0%BD%D0%B5%20%D0%B5%D0%B3%D0%BE.)
^ru-Q0799-answer

**ru-Q0800** — Машина, которую он ведёт, не его.

The car he's driving is not his.

Expected form: **которую**

Why: Relative forms. [[Russian#^ru-Q0800|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%B0%D1%88%D0%B8%D0%BD%D0%B0%2C%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%83%D1%8E%20%D0%BE%D0%BD%20%D0%B2%D0%B5%D0%B4%D1%91%D1%82%2C%20%D0%BD%D0%B5%20%D0%B5%D0%B3%D0%BE.)
^ru-Q0800-answer


### Answers 801–850

**ru-Q0801** — Она бы вам понравилась.

You would've liked her.

Expected form: **бы**

Why: Hypothetical бы. [[Russian#^ru-Q0801|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D0%B1%D1%8B%20%D0%B2%D0%B0%D0%BC%20%D0%BF%D0%BE%D0%BD%D1%80%D0%B0%D0%B2%D0%B8%D0%BB%D0%B0%D1%81%D1%8C.)
^ru-Q0801-answer

**ru-Q0802** — Она бы вам понравилась.

You would've liked her.

Why: Hypothetical бы. [[Russian#^ru-Q0802|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D0%B1%D1%8B%20%D0%B2%D0%B0%D0%BC%20%D0%BF%D0%BE%D0%BD%D1%80%D0%B0%D0%B2%D0%B8%D0%BB%D0%B0%D1%81%D1%8C.)
^ru-Q0802-answer

**ru-Q0803** — Вот бы мне мозги Тома.

I wish I had Tom's brains.

Why: Hypothetical бы. [[Russian#^ru-Q0803|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D0%BE%D1%82%20%D0%B1%D1%8B%20%D0%BC%D0%BD%D0%B5%20%D0%BC%D0%BE%D0%B7%D0%B3%D0%B8%20%D0%A2%D0%BE%D0%BC%D0%B0.)
^ru-Q0803-answer

**ru-Q0804** — Вот бы мне мозги Тома.

I wish I had Tom's brains.

Бы combines with a past-form verb to express a conditional/subjunctive meaning. Past morphology here does not always locate the situation in the past. Если introduces an if condition.

Why: Hypothetical бы. [[Russian#^ru-Q0804|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D0%BE%D1%82%20%D0%B1%D1%8B%20%D0%BC%D0%BD%D0%B5%20%D0%BC%D0%BE%D0%B7%D0%B3%D0%B8%20%D0%A2%D0%BE%D0%BC%D0%B0.)
^ru-Q0804-answer

**ru-Q0805** — О чём бы вы хотели поговорить?

What would you like to talk about?

Expected form: **бы**

Why: Hypothetical бы. [[Russian#^ru-Q0805|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%20%D1%87%D1%91%D0%BC%20%D0%B1%D1%8B%20%D0%B2%D1%8B%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%D0%B8%20%D0%BF%D0%BE%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D1%8C%3F)
^ru-Q0805-answer

**ru-Q0806** — О чём бы вы хотели поговорить?

What would you like to talk about?

Expected form: **бы**

Why: Hypothetical бы. [[Russian#^ru-Q0806|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%20%D1%87%D1%91%D0%BC%20%D0%B1%D1%8B%20%D0%B2%D1%8B%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%D0%B8%20%D0%BF%D0%BE%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D1%8C%3F)
^ru-Q0806-answer

**ru-Q0807** — Если он занят, помогите ему.

If he's busy, help him.

Expected form: **Если**

Why: Hypothetical бы. [[Russian#^ru-Q0807|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D0%BB%D0%B8%20%D0%BE%D0%BD%20%D0%B7%D0%B0%D0%BD%D1%8F%D1%82%2C%20%D0%BF%D0%BE%D0%BC%D0%BE%D0%B3%D0%B8%D1%82%D0%B5%20%D0%B5%D0%BC%D1%83.)
^ru-Q0807-answer

**ru-Q0808** — Если он занят, помогите ему.

If he's busy, help him.

Why: Hypothetical бы. [[Russian#^ru-Q0808|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D0%BB%D0%B8%20%D0%BE%D0%BD%20%D0%B7%D0%B0%D0%BD%D1%8F%D1%82%2C%20%D0%BF%D0%BE%D0%BC%D0%BE%D0%B3%D0%B8%D1%82%D0%B5%20%D0%B5%D0%BC%D1%83.)
^ru-Q0808-answer

**ru-Q0809** — Если хочешь уехать, уезжай.

If you want to leave, leave.

Why: Hypothetical бы. [[Russian#^ru-Q0809|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D0%BB%D0%B8%20%D1%85%D0%BE%D1%87%D0%B5%D1%88%D1%8C%20%D1%83%D0%B5%D1%85%D0%B0%D1%82%D1%8C%2C%20%D1%83%D0%B5%D0%B7%D0%B6%D0%B0%D0%B9.)
^ru-Q0809-answer

**ru-Q0810** — Если хочешь уехать, уезжай.

If you want to leave, leave.

Бы combines with a past-form verb to express a conditional/subjunctive meaning. Past morphology here does not always locate the situation in the past. Если introduces an if condition.

Why: Hypothetical бы. [[Russian#^ru-Q0810|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D0%BB%D0%B8%20%D1%85%D0%BE%D1%87%D0%B5%D1%88%D1%8C%20%D1%83%D0%B5%D1%85%D0%B0%D1%82%D1%8C%2C%20%D1%83%D0%B5%D0%B7%D0%B6%D0%B0%D0%B9.)
^ru-Q0810-answer

**ru-Q0811** — Если вы написали на сиденье в туалете, то вытрите за собой!

If you piss on the toilet seat, wipe it off!

Expected form: **Если**

Why: Hypothetical бы. [[Russian#^ru-Q0811|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D0%BB%D0%B8%20%D0%B2%D1%8B%20%D0%BD%D0%B0%D0%BF%D0%B8%D1%81%D0%B0%D0%BB%D0%B8%20%D0%BD%D0%B0%20%D1%81%D0%B8%D0%B4%D0%B5%D0%BD%D1%8C%D0%B5%20%D0%B2%20%D1%82%D1%83%D0%B0%D0%BB%D0%B5%D1%82%D0%B5%2C%20%D1%82%D0%BE%20%D0%B2%D1%8B%D1%82%D1%80%D0%B8%D1%82%D0%B5%20%D0%B7%D0%B0%20%D1%81%D0%BE%D0%B1%D0%BE%D0%B9%21)
^ru-Q0811-answer

**ru-Q0812** — Если вы написали на сиденье в туалете, то вытрите за собой!

If you piss on the toilet seat, wipe it off!

Expected form: **Если**

Why: Hypothetical бы. [[Russian#^ru-Q0812|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D0%BB%D0%B8%20%D0%B2%D1%8B%20%D0%BD%D0%B0%D0%BF%D0%B8%D1%81%D0%B0%D0%BB%D0%B8%20%D0%BD%D0%B0%20%D1%81%D0%B8%D0%B4%D0%B5%D0%BD%D1%8C%D0%B5%20%D0%B2%20%D1%82%D1%83%D0%B0%D0%BB%D0%B5%D1%82%D0%B5%2C%20%D1%82%D0%BE%20%D0%B2%D1%8B%D1%82%D1%80%D0%B8%D1%82%D0%B5%20%D0%B7%D0%B0%20%D1%81%D0%BE%D0%B1%D0%BE%D0%B9%21)
^ru-Q0812-answer

**ru-Q0813** — Том хотел бы это сделать.

Tom would want to do that.

Expected form: **бы**

Why: Hypothetical бы. [[Russian#^ru-Q0813|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%20%D0%B1%D1%8B%20%D1%8D%D1%82%D0%BE%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C.)
^ru-Q0813-answer

**ru-Q0814** — Том хотел бы это сделать.

Tom would want to do that.

Why: Hypothetical бы. [[Russian#^ru-Q0814|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%20%D0%B1%D1%8B%20%D1%8D%D1%82%D0%BE%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C.)
^ru-Q0814-answer

**ru-Q0815** — Я хотел бы к вам присоединиться.

I'd like to join you.

Why: Hypothetical бы. [[Russian#^ru-Q0815|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%20%D0%B1%D1%8B%20%D0%BA%20%D0%B2%D0%B0%D0%BC%20%D0%BF%D1%80%D0%B8%D1%81%D0%BE%D0%B5%D0%B4%D0%B8%D0%BD%D0%B8%D1%82%D1%8C%D1%81%D1%8F.)
^ru-Q0815-answer

**ru-Q0816** — Я хотел бы к вам присоединиться.

I'd like to join you.

Бы combines with a past-form verb to express a conditional/subjunctive meaning. Past morphology here does not always locate the situation in the past. Если introduces an if condition.

Why: Hypothetical бы. [[Russian#^ru-Q0816|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%20%D0%B1%D1%8B%20%D0%BA%20%D0%B2%D0%B0%D0%BC%20%D0%BF%D1%80%D0%B8%D1%81%D0%BE%D0%B5%D0%B4%D0%B8%D0%BD%D0%B8%D1%82%D1%8C%D1%81%D1%8F.)
^ru-Q0816-answer

**ru-Q0817** — Почему бы тебе не поехать с нами?

Why don't you go with us?

Expected form: **бы**

Why: Hypothetical бы. [[Russian#^ru-Q0817|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D0%B1%D1%8B%20%D1%82%D0%B5%D0%B1%D0%B5%20%D0%BD%D0%B5%20%D0%BF%D0%BE%D0%B5%D1%85%D0%B0%D1%82%D1%8C%20%D1%81%20%D0%BD%D0%B0%D0%BC%D0%B8%3F)
^ru-Q0817-answer

**ru-Q0818** — Почему бы тебе не поехать с нами?

Why don't you go with us?

Expected form: **бы**

Why: Hypothetical бы. [[Russian#^ru-Q0818|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D0%B1%D1%8B%20%D1%82%D0%B5%D0%B1%D0%B5%20%D0%BD%D0%B5%20%D0%BF%D0%BE%D0%B5%D1%85%D0%B0%D1%82%D1%8C%20%D1%81%20%D0%BD%D0%B0%D0%BC%D0%B8%3F)
^ru-Q0818-answer

**ru-Q0819** — Том не понимает, почему кто-либо стал бы так делать.

Tom doesn't see why anybody would want to do that.

Expected form: **бы**

Why: Hypothetical бы. [[Russian#^ru-Q0819|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D0%BF%D0%BE%D0%BD%D0%B8%D0%BC%D0%B0%D0%B5%D1%82%2C%20%D0%BF%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D0%BA%D1%82%D0%BE-%D0%BB%D0%B8%D0%B1%D0%BE%20%D1%81%D1%82%D0%B0%D0%BB%20%D0%B1%D1%8B%20%D1%82%D0%B0%D0%BA%20%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C.)
^ru-Q0819-answer

**ru-Q0820** — Том не понимает, почему кто-либо стал бы так делать.

Tom doesn't see why anybody would want to do that.

Why: Hypothetical бы. [[Russian#^ru-Q0820|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D0%BF%D0%BE%D0%BD%D0%B8%D0%BC%D0%B0%D0%B5%D1%82%2C%20%D0%BF%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D0%BA%D1%82%D0%BE-%D0%BB%D0%B8%D0%B1%D0%BE%20%D1%81%D1%82%D0%B0%D0%BB%20%D0%B1%D1%8B%20%D1%82%D0%B0%D0%BA%20%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C.)
^ru-Q0820-answer

**ru-Q0821** — Почему бы тебе не попросить Тома помочь?

Why don't you ask Tom to help?

Why: Hypothetical бы. [[Russian#^ru-Q0821|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D0%B1%D1%8B%20%D1%82%D0%B5%D0%B1%D0%B5%20%D0%BD%D0%B5%20%D0%BF%D0%BE%D0%BF%D1%80%D0%BE%D1%81%D0%B8%D1%82%D1%8C%20%D0%A2%D0%BE%D0%BC%D0%B0%20%D0%BF%D0%BE%D0%BC%D0%BE%D1%87%D1%8C%3F)
^ru-Q0821-answer

**ru-Q0822** — Почему бы тебе не попросить Тома помочь?

Why don't you ask Tom to help?

Бы combines with a past-form verb to express a conditional/subjunctive meaning. Past morphology here does not always locate the situation in the past. Если introduces an if condition.

Why: Hypothetical бы. [[Russian#^ru-Q0822|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D0%B1%D1%8B%20%D1%82%D0%B5%D0%B1%D0%B5%20%D0%BD%D0%B5%20%D0%BF%D0%BE%D0%BF%D1%80%D0%BE%D1%81%D0%B8%D1%82%D1%8C%20%D0%A2%D0%BE%D0%BC%D0%B0%20%D0%BF%D0%BE%D0%BC%D0%BE%D1%87%D1%8C%3F)
^ru-Q0822-answer

**ru-Q0823** — Том не стал бы объяснять почему.

Tom wouldn't explain why.

Expected form: **бы**

Why: Hypothetical бы. [[Russian#^ru-Q0823|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D1%81%D1%82%D0%B0%D0%BB%20%D0%B1%D1%8B%20%D0%BE%D0%B1%D1%8A%D1%8F%D1%81%D0%BD%D1%8F%D1%82%D1%8C%20%D0%BF%D0%BE%D1%87%D0%B5%D0%BC%D1%83.)
^ru-Q0823-answer

**ru-Q0824** — Том не стал бы объяснять почему.

Tom wouldn't explain why.

Expected form: **бы**

Why: Hypothetical бы. [[Russian#^ru-Q0824|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D1%81%D1%82%D0%B0%D0%BB%20%D0%B1%D1%8B%20%D0%BE%D0%B1%D1%8A%D1%8F%D1%81%D0%BD%D1%8F%D1%82%D1%8C%20%D0%BF%D0%BE%D1%87%D0%B5%D0%BC%D1%83.)
^ru-Q0824-answer

**ru-Q0825** — Почему бы вам не дать ему самому решить?

Why don't you let him decide?

Expected form: **бы**

Why: Hypothetical бы. [[Russian#^ru-Q0825|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D0%B1%D1%8B%20%D0%B2%D0%B0%D0%BC%20%D0%BD%D0%B5%20%D0%B4%D0%B0%D1%82%D1%8C%20%D0%B5%D0%BC%D1%83%20%D1%81%D0%B0%D0%BC%D0%BE%D0%BC%D1%83%20%D1%80%D0%B5%D1%88%D0%B8%D1%82%D1%8C%3F)
^ru-Q0825-answer

**ru-Q0826** — Почему бы вам не дать ему самому решить?

Why don't you let him decide?

Why: Hypothetical бы. [[Russian#^ru-Q0826|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D0%B1%D1%8B%20%D0%B2%D0%B0%D0%BC%20%D0%BD%D0%B5%20%D0%B4%D0%B0%D1%82%D1%8C%20%D0%B5%D0%BC%D1%83%20%D1%81%D0%B0%D0%BC%D0%BE%D0%BC%D1%83%20%D1%80%D0%B5%D1%88%D0%B8%D1%82%D1%8C%3F)
^ru-Q0826-answer

**ru-Q0827** — Тому надо бы сказать ему правду.

Tom should tell him the truth.

Why: Hypothetical бы. [[Russian#^ru-Q0827|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%D1%83%20%D0%BD%D0%B0%D0%B4%D0%BE%20%D0%B1%D1%8B%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C%20%D0%B5%D0%BC%D1%83%20%D0%BF%D1%80%D0%B0%D0%B2%D0%B4%D1%83.)
^ru-Q0827-answer

**ru-Q0828** — Тому надо бы сказать ему правду.

Tom should tell him the truth.

Бы combines with a past-form verb to express a conditional/subjunctive meaning. Past morphology here does not always locate the situation in the past. Если introduces an if condition.

Why: Hypothetical бы. [[Russian#^ru-Q0828|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%D1%83%20%D0%BD%D0%B0%D0%B4%D0%BE%20%D0%B1%D1%8B%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C%20%D0%B5%D0%BC%D1%83%20%D0%BF%D1%80%D0%B0%D0%B2%D0%B4%D1%83.)
^ru-Q0828-answer

**ru-Q0829** — Я бы хотел апельсинового сока.

I'd like an orange juice.

Expected form: **бы**

Why: Hypothetical бы. [[Russian#^ru-Q0829|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%8B%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%20%D0%B0%D0%BF%D0%B5%D0%BB%D1%8C%D1%81%D0%B8%D0%BD%D0%BE%D0%B2%D0%BE%D0%B3%D0%BE%20%D1%81%D0%BE%D0%BA%D0%B0.)
^ru-Q0829-answer

**ru-Q0830** — Я бы хотел апельсинового сока.

I'd like an orange juice.

Expected form: **бы**

Why: Hypothetical бы. [[Russian#^ru-Q0830|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%8B%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%20%D0%B0%D0%BF%D0%B5%D0%BB%D1%8C%D1%81%D0%B8%D0%BD%D0%BE%D0%B2%D0%BE%D0%B3%D0%BE%20%D1%81%D0%BE%D0%BA%D0%B0.)
^ru-Q0830-answer

**ru-Q0831** — Я бы никогда не стал пробовать это делать.

I'd never try to do that.

Expected form: **бы**

Why: Hypothetical бы. [[Russian#^ru-Q0831|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%8B%20%D0%BD%D0%B8%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%BD%D0%B5%20%D1%81%D1%82%D0%B0%D0%BB%20%D0%BF%D1%80%D0%BE%D0%B1%D0%BE%D0%B2%D0%B0%D1%82%D1%8C%20%D1%8D%D1%82%D0%BE%20%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C.)
^ru-Q0831-answer

**ru-Q0832** — Я бы никогда не стал пробовать это делать.

I'd never try to do that.

Why: Hypothetical бы. [[Russian#^ru-Q0832|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D1%8B%20%D0%BD%D0%B8%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%BD%D0%B5%20%D1%81%D1%82%D0%B0%D0%BB%20%D0%BF%D1%80%D0%BE%D0%B1%D0%BE%D0%B2%D0%B0%D1%82%D1%8C%20%D1%8D%D1%82%D0%BE%20%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C.)
^ru-Q0832-answer

**ru-Q0833** — Могли бы и сказать.

You could have told me.

Why: Hypothetical бы. [[Russian#^ru-Q0833|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D0%B3%D0%BB%D0%B8%20%D0%B1%D1%8B%20%D0%B8%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C.)
^ru-Q0833-answer

**ru-Q0834** — Могли бы и сказать.

You could have told me.

Бы combines with a past-form verb to express a conditional/subjunctive meaning. Past morphology here does not always locate the situation in the past. Если introduces an if condition.

Why: Hypothetical бы. [[Russian#^ru-Q0834|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D0%B3%D0%BB%D0%B8%20%D0%B1%D1%8B%20%D0%B8%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C.)
^ru-Q0834-answer

**ru-Q0835** — А что, если он отвергнет меня?

And what if he rejects me?

Expected form: **если**

Why: Hypothetical бы. [[Russian#^ru-Q0835|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%90%20%D1%87%D1%82%D0%BE%2C%20%D0%B5%D1%81%D0%BB%D0%B8%20%D0%BE%D0%BD%20%D0%BE%D1%82%D0%B2%D0%B5%D1%80%D0%B3%D0%BD%D0%B5%D1%82%20%D0%BC%D0%B5%D0%BD%D1%8F%3F)
^ru-Q0835-answer

**ru-Q0836** — А что, если он отвергнет меня?

And what if he rejects me?

Expected form: **если**

Why: Hypothetical бы. [[Russian#^ru-Q0836|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%90%20%D1%87%D1%82%D0%BE%2C%20%D0%B5%D1%81%D0%BB%D0%B8%20%D0%BE%D0%BD%20%D0%BE%D1%82%D0%B2%D0%B5%D1%80%D0%B3%D0%BD%D0%B5%D1%82%20%D0%BC%D0%B5%D0%BD%D1%8F%3F)
^ru-Q0836-answer

**ru-Q0837** — Почему бы нам не встретиться напротив вокзала?

Why don't we meet in front of the station?

Expected form: **бы**

Why: Hypothetical бы. [[Russian#^ru-Q0837|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D0%B1%D1%8B%20%D0%BD%D0%B0%D0%BC%20%D0%BD%D0%B5%20%D0%B2%D1%81%D1%82%D1%80%D0%B5%D1%82%D0%B8%D1%82%D1%8C%D1%81%D1%8F%20%D0%BD%D0%B0%D0%BF%D1%80%D0%BE%D1%82%D0%B8%D0%B2%20%D0%B2%D0%BE%D0%BA%D0%B7%D0%B0%D0%BB%D0%B0%3F)
^ru-Q0837-answer

**ru-Q0838** — Почему бы нам не встретиться напротив вокзала?

Why don't we meet in front of the station?

Why: Hypothetical бы. [[Russian#^ru-Q0838|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D0%B1%D1%8B%20%D0%BD%D0%B0%D0%BC%20%D0%BD%D0%B5%20%D0%B2%D1%81%D1%82%D1%80%D0%B5%D1%82%D0%B8%D1%82%D1%8C%D1%81%D1%8F%20%D0%BD%D0%B0%D0%BF%D1%80%D0%BE%D1%82%D0%B8%D0%B2%20%D0%B2%D0%BE%D0%BA%D0%B7%D0%B0%D0%BB%D0%B0%3F)
^ru-Q0838-answer

**ru-Q0839** — Полагаю, мы могли бы спросить у него.

I suppose we could ask him.

Why: Hypothetical бы. [[Russian#^ru-Q0839|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%BB%D0%B0%D0%B3%D0%B0%D1%8E%2C%20%D0%BC%D1%8B%20%D0%BC%D0%BE%D0%B3%D0%BB%D0%B8%20%D0%B1%D1%8B%20%D1%81%D0%BF%D1%80%D0%BE%D1%81%D0%B8%D1%82%D1%8C%20%D1%83%20%D0%BD%D0%B5%D0%B3%D0%BE.)
^ru-Q0839-answer

**ru-Q0840** — Полагаю, мы могли бы спросить у него.

I suppose we could ask him.

Бы combines with a past-form verb to express a conditional/subjunctive meaning. Past morphology here does not always locate the situation in the past. Если introduces an if condition.

Why: Hypothetical бы. [[Russian#^ru-Q0840|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%BB%D0%B0%D0%B3%D0%B0%D1%8E%2C%20%D0%BC%D1%8B%20%D0%BC%D0%BE%D0%B3%D0%BB%D0%B8%20%D0%B1%D1%8B%20%D1%81%D0%BF%D1%80%D0%BE%D1%81%D0%B8%D1%82%D1%8C%20%D1%83%20%D0%BD%D0%B5%D0%B3%D0%BE.)
^ru-Q0840-answer

**ru-Q0841** — Почему бы тебе не присесть прямо вон там на кушетке?

Why don't you sit right there on the couch?

Expected form: **бы**

Why: Hypothetical бы. [[Russian#^ru-Q0841|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D0%B1%D1%8B%20%D1%82%D0%B5%D0%B1%D0%B5%20%D0%BD%D0%B5%20%D0%BF%D1%80%D0%B8%D1%81%D0%B5%D1%81%D1%82%D1%8C%20%D0%BF%D1%80%D1%8F%D0%BC%D0%BE%20%D0%B2%D0%BE%D0%BD%20%D1%82%D0%B0%D0%BC%20%D0%BD%D0%B0%20%D0%BA%D1%83%D1%88%D0%B5%D1%82%D0%BA%D0%B5%3F)
^ru-Q0841-answer

**ru-Q0842** — Почему бы тебе не присесть прямо вон там на кушетке?

Why don't you sit right there on the couch?

Expected form: **бы**

Why: Hypothetical бы. [[Russian#^ru-Q0842|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D0%B1%D1%8B%20%D1%82%D0%B5%D0%B1%D0%B5%20%D0%BD%D0%B5%20%D0%BF%D1%80%D0%B8%D1%81%D0%B5%D1%81%D1%82%D1%8C%20%D0%BF%D1%80%D1%8F%D0%BC%D0%BE%20%D0%B2%D0%BE%D0%BD%20%D1%82%D0%B0%D0%BC%20%D0%BD%D0%B0%20%D0%BA%D1%83%D1%88%D0%B5%D1%82%D0%BA%D0%B5%3F)
^ru-Q0842-answer

**ru-Q0843** — Если вы этого не сделаете, Том рассердится.

If you don't do that, Tom will get angry.

Expected form: **Если**

Why: Hypothetical бы. [[Russian#^ru-Q0843|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D0%BB%D0%B8%20%D0%B2%D1%8B%20%D1%8D%D1%82%D0%BE%D0%B3%D0%BE%20%D0%BD%D0%B5%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D0%B5%D1%82%D0%B5%2C%20%D0%A2%D0%BE%D0%BC%20%D1%80%D0%B0%D1%81%D1%81%D0%B5%D1%80%D0%B4%D0%B8%D1%82%D1%81%D1%8F.)
^ru-Q0843-answer

**ru-Q0844** — Если вы этого не сделаете, Том рассердится.

If you don't do that, Tom will get angry.

Why: Hypothetical бы. [[Russian#^ru-Q0844|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D0%BB%D0%B8%20%D0%B2%D1%8B%20%D1%8D%D1%82%D0%BE%D0%B3%D0%BE%20%D0%BD%D0%B5%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D0%B5%D1%82%D0%B5%2C%20%D0%A2%D0%BE%D0%BC%20%D1%80%D0%B0%D1%81%D1%81%D0%B5%D1%80%D0%B4%D0%B8%D1%82%D1%81%D1%8F.)
^ru-Q0844-answer

**ru-Q0845** — Чем бы вы хотели сегодня заняться?

What would you like to do today?

Why: Hypothetical бы. [[Russian#^ru-Q0845|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A7%D0%B5%D0%BC%20%D0%B1%D1%8B%20%D0%B2%D1%8B%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%D0%B8%20%D1%81%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F%20%D0%B7%D0%B0%D0%BD%D1%8F%D1%82%D1%8C%D1%81%D1%8F%3F)
^ru-Q0845-answer

**ru-Q0846** — Чем бы вы хотели сегодня заняться?

What would you like to do today?

Бы combines with a past-form verb to express a conditional/subjunctive meaning. Past morphology here does not always locate the situation in the past. Если introduces an if condition.

Why: Hypothetical бы. [[Russian#^ru-Q0846|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A7%D0%B5%D0%BC%20%D0%B1%D1%8B%20%D0%B2%D1%8B%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%D0%B8%20%D1%81%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F%20%D0%B7%D0%B0%D0%BD%D1%8F%D1%82%D1%8C%D1%81%D1%8F%3F)
^ru-Q0846-answer

**ru-Q0847** — Видел бы ты выражение своего лица.

You should've seen the look on your face.

Expected form: **бы**

Why: Hypothetical бы. [[Russian#^ru-Q0847|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D0%B8%D0%B4%D0%B5%D0%BB%20%D0%B1%D1%8B%20%D1%82%D1%8B%20%D0%B2%D1%8B%D1%80%D0%B0%D0%B6%D0%B5%D0%BD%D0%B8%D0%B5%20%D1%81%D0%B2%D0%BE%D0%B5%D0%B3%D0%BE%20%D0%BB%D0%B8%D1%86%D0%B0.)
^ru-Q0847-answer

**ru-Q0848** — Видел бы ты выражение своего лица.

You should've seen the look on your face.

Expected form: **бы**

Why: Hypothetical бы. [[Russian#^ru-Q0848|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D0%B8%D0%B4%D0%B5%D0%BB%20%D0%B1%D1%8B%20%D1%82%D1%8B%20%D0%B2%D1%8B%D1%80%D0%B0%D0%B6%D0%B5%D0%BD%D0%B8%D0%B5%20%D1%81%D0%B2%D0%BE%D0%B5%D0%B3%D0%BE%20%D0%BB%D0%B8%D1%86%D0%B0.)
^ru-Q0848-answer

**ru-Q0849** — Пожалуйста, вы бы не могли это взять?

Could you take this, please?

Expected form: **бы**

Why: Hypothetical бы. [[Russian#^ru-Q0849|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%B2%D1%8B%20%D0%B1%D1%8B%20%D0%BD%D0%B5%20%D0%BC%D0%BE%D0%B3%D0%BB%D0%B8%20%D1%8D%D1%82%D0%BE%20%D0%B2%D0%B7%D1%8F%D1%82%D1%8C%3F)
^ru-Q0849-answer

**ru-Q0850** — Пожалуйста, вы бы не могли это взять?

Could you take this, please?

Why: Hypothetical бы. [[Russian#^ru-Q0850|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%B2%D1%8B%20%D0%B1%D1%8B%20%D0%BD%D0%B5%20%D0%BC%D0%BE%D0%B3%D0%BB%D0%B8%20%D1%8D%D1%82%D0%BE%20%D0%B2%D0%B7%D1%8F%D1%82%D1%8C%3F)
^ru-Q0850-answer


### Answers 851–900

**ru-Q0851** — Есть только одна религия, хотя у неё сотня вариаций.

There is only one religion, though there are a hundred versions of it.

Why: Logical connectors. [[Russian#^ru-Q0851|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D1%82%D1%8C%20%D1%82%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE%20%D0%BE%D0%B4%D0%BD%D0%B0%20%D1%80%D0%B5%D0%BB%D0%B8%D0%B3%D0%B8%D1%8F%2C%20%D1%85%D0%BE%D1%82%D1%8F%20%D1%83%20%D0%BD%D0%B5%D1%91%20%D1%81%D0%BE%D1%82%D0%BD%D1%8F%20%D0%B2%D0%B0%D1%80%D0%B8%D0%B0%D1%86%D0%B8%D0%B9.)
^ru-Q0851-answer

**ru-Q0852** — Есть только одна религия, хотя у неё сотня вариаций.

There is only one religion, though there are a hundred versions of it.

Distinguish cause, concession and result. Поэтому presents a consequence, not its cause. Несмотря often belongs to a prepositional concessive construction requiring its own complement.

Why: Logical connectors. [[Russian#^ru-Q0852|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D1%82%D1%8C%20%D1%82%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE%20%D0%BE%D0%B4%D0%BD%D0%B0%20%D1%80%D0%B5%D0%BB%D0%B8%D0%B3%D0%B8%D1%8F%2C%20%D1%85%D0%BE%D1%82%D1%8F%20%D1%83%20%D0%BD%D0%B5%D1%91%20%D1%81%D0%BE%D1%82%D0%BD%D1%8F%20%D0%B2%D0%B0%D1%80%D0%B8%D0%B0%D1%86%D0%B8%D0%B9.)
^ru-Q0852-answer

**ru-Q0853** — Он не извинился, хотя и был неправ.

Although he was wrong, he didn't say he was sorry.

Expected form: **хотя**

Why: Logical connectors. [[Russian#^ru-Q0853|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D0%BD%D0%B5%20%D0%B8%D0%B7%D0%B2%D0%B8%D0%BD%D0%B8%D0%BB%D1%81%D1%8F%2C%20%D1%85%D0%BE%D1%82%D1%8F%20%D0%B8%20%D0%B1%D1%8B%D0%BB%20%D0%BD%D0%B5%D0%BF%D1%80%D0%B0%D0%B2.)
^ru-Q0853-answer

**ru-Q0854** — Он не извинился, хотя и был неправ.

Although he was wrong, he didn't say he was sorry.

Expected form: **хотя**

Why: Logical connectors. [[Russian#^ru-Q0854|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%20%D0%BD%D0%B5%20%D0%B8%D0%B7%D0%B2%D0%B8%D0%BD%D0%B8%D0%BB%D1%81%D1%8F%2C%20%D1%85%D0%BE%D1%82%D1%8F%20%D0%B8%20%D0%B1%D1%8B%D0%BB%20%D0%BD%D0%B5%D0%BF%D1%80%D0%B0%D0%B2.)
^ru-Q0854-answer

**ru-Q0855** — Так как автобуса не было, мне пришлось идти пешком.

Since there was no bus, I had to walk.

Expected form: **Так как**

Why: Logical connectors. [[Russian#^ru-Q0855|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%B0%D0%BA%20%D0%BA%D0%B0%D0%BA%20%D0%B0%D0%B2%D1%82%D0%BE%D0%B1%D1%83%D1%81%D0%B0%20%D0%BD%D0%B5%20%D0%B1%D1%8B%D0%BB%D0%BE%2C%20%D0%BC%D0%BD%D0%B5%20%D0%BF%D1%80%D0%B8%D1%88%D0%BB%D0%BE%D1%81%D1%8C%20%D0%B8%D0%B4%D1%82%D0%B8%20%D0%BF%D0%B5%D1%88%D0%BA%D0%BE%D0%BC.)
^ru-Q0855-answer

**ru-Q0856** — Так как автобуса не было, мне пришлось идти пешком.

Since there was no bus, I had to walk.

Why: Logical connectors. [[Russian#^ru-Q0856|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%B0%D0%BA%20%D0%BA%D0%B0%D0%BA%20%D0%B0%D0%B2%D1%82%D0%BE%D0%B1%D1%83%D1%81%D0%B0%20%D0%BD%D0%B5%20%D0%B1%D1%8B%D0%BB%D0%BE%2C%20%D0%BC%D0%BD%D0%B5%20%D0%BF%D1%80%D0%B8%D1%88%D0%BB%D0%BE%D1%81%D1%8C%20%D0%B8%D0%B4%D1%82%D0%B8%20%D0%BF%D0%B5%D1%88%D0%BA%D0%BE%D0%BC.)
^ru-Q0856-answer

**ru-Q0857** — Не сердитесь на меня, потому что я сделал это ради вас.

Don't be angry with me, for I did it for your sake.

Why: Logical connectors. [[Russian#^ru-Q0857|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%20%D1%81%D0%B5%D1%80%D0%B4%D0%B8%D1%82%D0%B5%D1%81%D1%8C%20%D0%BD%D0%B0%20%D0%BC%D0%B5%D0%BD%D1%8F%2C%20%D0%BF%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE%20%D1%8F%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D0%BB%20%D1%8D%D1%82%D0%BE%20%D1%80%D0%B0%D0%B4%D0%B8%20%D0%B2%D0%B0%D1%81.)
^ru-Q0857-answer

**ru-Q0858** — Не сердитесь на меня, потому что я сделал это ради вас.

Don't be angry with me, for I did it for your sake.

Distinguish cause, concession and result. Поэтому presents a consequence, not its cause. Несмотря often belongs to a prepositional concessive construction requiring its own complement.

Why: Logical connectors. [[Russian#^ru-Q0858|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%20%D1%81%D0%B5%D1%80%D0%B4%D0%B8%D1%82%D0%B5%D1%81%D1%8C%20%D0%BD%D0%B0%20%D0%BC%D0%B5%D0%BD%D1%8F%2C%20%D0%BF%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE%20%D1%8F%20%D1%81%D0%B4%D0%B5%D0%BB%D0%B0%D0%BB%20%D1%8D%D1%82%D0%BE%20%D1%80%D0%B0%D0%B4%D0%B8%20%D0%B2%D0%B0%D1%81.)
^ru-Q0858-answer

**ru-Q0859** — Хотя Том вырос рядом с океаном, он так и не научился плавать.

Even though Tom grew up near the ocean, he never learned how to swim.

Expected form: **Хотя**

Why: Logical connectors. [[Russian#^ru-Q0859|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A5%D0%BE%D1%82%D1%8F%20%D0%A2%D0%BE%D0%BC%20%D0%B2%D1%8B%D1%80%D0%BE%D1%81%20%D1%80%D1%8F%D0%B4%D0%BE%D0%BC%20%D1%81%20%D0%BE%D0%BA%D0%B5%D0%B0%D0%BD%D0%BE%D0%BC%2C%20%D0%BE%D0%BD%20%D1%82%D0%B0%D0%BA%20%D0%B8%20%D0%BD%D0%B5%20%D0%BD%D0%B0%D1%83%D1%87%D0%B8%D0%BB%D1%81%D1%8F%20%D0%BF%D0%BB%D0%B0%D0%B2%D0%B0%D1%82%D1%8C.)
^ru-Q0859-answer

**ru-Q0860** — Хотя Том вырос рядом с океаном, он так и не научился плавать.

Even though Tom grew up near the ocean, he never learned how to swim.

Expected form: **Хотя**

Why: Logical connectors. [[Russian#^ru-Q0860|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A5%D0%BE%D1%82%D1%8F%20%D0%A2%D0%BE%D0%BC%20%D0%B2%D1%8B%D1%80%D0%BE%D1%81%20%D1%80%D1%8F%D0%B4%D0%BE%D0%BC%20%D1%81%20%D0%BE%D0%BA%D0%B5%D0%B0%D0%BD%D0%BE%D0%BC%2C%20%D0%BE%D0%BD%20%D1%82%D0%B0%D0%BA%20%D0%B8%20%D0%BD%D0%B5%20%D0%BD%D0%B0%D1%83%D1%87%D0%B8%D0%BB%D1%81%D1%8F%20%D0%BF%D0%BB%D0%B0%D0%B2%D0%B0%D1%82%D1%8C.)
^ru-Q0860-answer

**ru-Q0861** — Я не буду разгружать машину, потому что это не моя работа.

I won't unload the car because that's somebody else's job.

Expected form: **потому что**

Why: Logical connectors. [[Russian#^ru-Q0861|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D0%B1%D1%83%D0%B4%D1%83%20%D1%80%D0%B0%D0%B7%D0%B3%D1%80%D1%83%D0%B6%D0%B0%D1%82%D1%8C%20%D0%BC%D0%B0%D1%88%D0%B8%D0%BD%D1%83%2C%20%D0%BF%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE%20%D1%8D%D1%82%D0%BE%20%D0%BD%D0%B5%20%D0%BC%D0%BE%D1%8F%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B0.)
^ru-Q0861-answer

**ru-Q0862** — Я не буду разгружать машину, потому что это не моя работа.

I won't unload the car because that's somebody else's job.

Why: Logical connectors. [[Russian#^ru-Q0862|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D0%B1%D1%83%D0%B4%D1%83%20%D1%80%D0%B0%D0%B7%D0%B3%D1%80%D1%83%D0%B6%D0%B0%D1%82%D1%8C%20%D0%BC%D0%B0%D1%88%D0%B8%D0%BD%D1%83%2C%20%D0%BF%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE%20%D1%8D%D1%82%D0%BE%20%D0%BD%D0%B5%20%D0%BC%D0%BE%D1%8F%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B0.)
^ru-Q0862-answer

**ru-Q0863** — Я всегда буду тебя любить. Несмотря ни на что.

I'll always love you. No matter what.

Why: Logical connectors. [[Russian#^ru-Q0863|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B2%D1%81%D0%B5%D0%B3%D0%B4%D0%B0%20%D0%B1%D1%83%D0%B4%D1%83%20%D1%82%D0%B5%D0%B1%D1%8F%20%D0%BB%D1%8E%D0%B1%D0%B8%D1%82%D1%8C.%20%D0%9D%D0%B5%D1%81%D0%BC%D0%BE%D1%82%D1%80%D1%8F%20%D0%BD%D0%B8%20%D0%BD%D0%B0%20%D1%87%D1%82%D0%BE.)
^ru-Q0863-answer

**ru-Q0864** — Я всегда буду тебя любить. Несмотря ни на что.

I'll always love you. No matter what.

Distinguish cause, concession and result. Поэтому presents a consequence, not its cause. Несмотря often belongs to a prepositional concessive construction requiring its own complement.

Why: Logical connectors. [[Russian#^ru-Q0864|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B2%D1%81%D0%B5%D0%B3%D0%B4%D0%B0%20%D0%B1%D1%83%D0%B4%D1%83%20%D1%82%D0%B5%D0%B1%D1%8F%20%D0%BB%D1%8E%D0%B1%D0%B8%D1%82%D1%8C.%20%D0%9D%D0%B5%D1%81%D0%BC%D0%BE%D1%82%D1%80%D1%8F%20%D0%BD%D0%B8%20%D0%BD%D0%B0%20%D1%87%D1%82%D0%BE.)
^ru-Q0864-answer

**ru-Q0865** — Даже несмотря на то, что она была занята, она пришла повидаться со мной.

Even though she was busy, she came to see me.

Expected form: **несмотря**

Why: Logical connectors. [[Russian#^ru-Q0865|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D0%B0%D0%B6%D0%B5%20%D0%BD%D0%B5%D1%81%D0%BC%D0%BE%D1%82%D1%80%D1%8F%20%D0%BD%D0%B0%20%D1%82%D0%BE%2C%20%D1%87%D1%82%D0%BE%20%D0%BE%D0%BD%D0%B0%20%D0%B1%D1%8B%D0%BB%D0%B0%20%D0%B7%D0%B0%D0%BD%D1%8F%D1%82%D0%B0%2C%20%D0%BE%D0%BD%D0%B0%20%D0%BF%D1%80%D0%B8%D1%88%D0%BB%D0%B0%20%D0%BF%D0%BE%D0%B2%D0%B8%D0%B4%D0%B0%D1%82%D1%8C%D1%81%D1%8F%20%D1%81%D0%BE%20%D0%BC%D0%BD%D0%BE%D0%B9.)
^ru-Q0865-answer

**ru-Q0866** — Даже несмотря на то, что она была занята, она пришла повидаться со мной.

Even though she was busy, she came to see me.

Expected form: **несмотря**

Why: Logical connectors. [[Russian#^ru-Q0866|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%94%D0%B0%D0%B6%D0%B5%20%D0%BD%D0%B5%D1%81%D0%BC%D0%BE%D1%82%D1%80%D1%8F%20%D0%BD%D0%B0%20%D1%82%D0%BE%2C%20%D1%87%D1%82%D0%BE%20%D0%BE%D0%BD%D0%B0%20%D0%B1%D1%8B%D0%BB%D0%B0%20%D0%B7%D0%B0%D0%BD%D1%8F%D1%82%D0%B0%2C%20%D0%BE%D0%BD%D0%B0%20%D0%BF%D1%80%D0%B8%D1%88%D0%BB%D0%B0%20%D0%BF%D0%BE%D0%B2%D0%B8%D0%B4%D0%B0%D1%82%D1%8C%D1%81%D1%8F%20%D1%81%D0%BE%20%D0%BC%D0%BD%D0%BE%D0%B9.)
^ru-Q0866-answer

**ru-Q0867** — Потому что ты идиот!

Because you are an idiot!

Expected form: **Потому что**

Why: Logical connectors. [[Russian#^ru-Q0867|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE%20%D1%82%D1%8B%20%D0%B8%D0%B4%D0%B8%D0%BE%D1%82%21)
^ru-Q0867-answer

**ru-Q0868** — Потому что ты идиот!

Because you are an idiot!

Why: Logical connectors. [[Russian#^ru-Q0868|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE%20%D1%82%D1%8B%20%D0%B8%D0%B4%D0%B8%D0%BE%D1%82%21)
^ru-Q0868-answer

**ru-Q0869** — Ты пришла, несмотря на мой запрет.

You came despite my ban.

Why: Logical connectors. [[Russian#^ru-Q0869|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%BF%D1%80%D0%B8%D1%88%D0%BB%D0%B0%2C%20%D0%BD%D0%B5%D1%81%D0%BC%D0%BE%D1%82%D1%80%D1%8F%20%D0%BD%D0%B0%20%D0%BC%D0%BE%D0%B9%20%D0%B7%D0%B0%D0%BF%D1%80%D0%B5%D1%82.)
^ru-Q0869-answer

**ru-Q0870** — Ты пришла, несмотря на мой запрет.

You came despite my ban.

Distinguish cause, concession and result. Поэтому presents a consequence, not its cause. Несмотря often belongs to a prepositional concessive construction requiring its own complement.

Why: Logical connectors. [[Russian#^ru-Q0870|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D1%8B%20%D0%BF%D1%80%D0%B8%D1%88%D0%BB%D0%B0%2C%20%D0%BD%D0%B5%D1%81%D0%BC%D0%BE%D1%82%D1%80%D1%8F%20%D0%BD%D0%B0%20%D0%BC%D0%BE%D0%B9%20%D0%B7%D0%B0%D0%BF%D1%80%D0%B5%D1%82.)
^ru-Q0870-answer

**ru-Q0871** — Мы выжаты как лимон, потому что мы весь день предавались греху.

We are worn out because we fucked all day long.

Expected form: **потому что**

Why: Logical connectors. [[Russian#^ru-Q0871|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%B2%D1%8B%D0%B6%D0%B0%D1%82%D1%8B%20%D0%BA%D0%B0%D0%BA%20%D0%BB%D0%B8%D0%BC%D0%BE%D0%BD%2C%20%D0%BF%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE%20%D0%BC%D1%8B%20%D0%B2%D0%B5%D1%81%D1%8C%20%D0%B4%D0%B5%D0%BD%D1%8C%20%D0%BF%D1%80%D0%B5%D0%B4%D0%B0%D0%B2%D0%B0%D0%BB%D0%B8%D1%81%D1%8C%20%D0%B3%D1%80%D0%B5%D1%85%D1%83.)
^ru-Q0871-answer

**ru-Q0872** — Мы выжаты как лимон, потому что мы весь день предавались греху.

We are worn out because we fucked all day long.

Expected form: **потому что**

Why: Logical connectors. [[Russian#^ru-Q0872|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%B2%D1%8B%D0%B6%D0%B0%D1%82%D1%8B%20%D0%BA%D0%B0%D0%BA%20%D0%BB%D0%B8%D0%BC%D0%BE%D0%BD%2C%20%D0%BF%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE%20%D0%BC%D1%8B%20%D0%B2%D0%B5%D1%81%D1%8C%20%D0%B4%D0%B5%D0%BD%D1%8C%20%D0%BF%D1%80%D0%B5%D0%B4%D0%B0%D0%B2%D0%B0%D0%BB%D0%B8%D1%81%D1%8C%20%D0%B3%D1%80%D0%B5%D1%85%D1%83.)
^ru-Q0872-answer

**ru-Q0873** — Вчера - уже история, а завтра - тайна. Однако, сегодня - подарок судьбы, а подарки должны приносить радость.

Yesterday is already history, and tomorrow, a mystery. However, today is a present of fate, and presents are supposed to bring joy.

Expected form: **Однако**

Why: Logical connectors. [[Russian#^ru-Q0873|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%87%D0%B5%D1%80%D0%B0%20-%20%D1%83%D0%B6%D0%B5%20%D0%B8%D1%81%D1%82%D0%BE%D1%80%D0%B8%D1%8F%2C%20%D0%B0%20%D0%B7%D0%B0%D0%B2%D1%82%D1%80%D0%B0%20-%20%D1%82%D0%B0%D0%B9%D0%BD%D0%B0.%20%D0%9E%D0%B4%D0%BD%D0%B0%D0%BA%D0%BE%2C%20%D1%81%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F%20-%20%D0%BF%D0%BE%D0%B4%D0%B0%D1%80%D0%BE%D0%BA%20%D1%81%D1%83%D0%B4%D1%8C%D0%B1%D1%8B%2C%20%D0%B0%20%D0%BF%D0%BE%D0%B4%D0%B0%D1%80%D0%BA%D0%B8%20%D0%B4%D0%BE%D0%BB%D0%B6%D0%BD%D1%8B%20%D0%BF%D1%80%D0%B8%D0%BD%D0%BE%D1%81%D0%B8%D1%82%D1%8C%20%D1%80%D0%B0%D0%B4%D0%BE%D1%81%D1%82%D1%8C.)
^ru-Q0873-answer

**ru-Q0874** — Вчера - уже история, а завтра - тайна. Однако, сегодня - подарок судьбы, а подарки должны приносить радость.

Yesterday is already history, and tomorrow, a mystery. However, today is a present of fate, and presents are supposed to bring joy.

Why: Logical connectors. [[Russian#^ru-Q0874|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%87%D0%B5%D1%80%D0%B0%20-%20%D1%83%D0%B6%D0%B5%20%D0%B8%D1%81%D1%82%D0%BE%D1%80%D0%B8%D1%8F%2C%20%D0%B0%20%D0%B7%D0%B0%D0%B2%D1%82%D1%80%D0%B0%20-%20%D1%82%D0%B0%D0%B9%D0%BD%D0%B0.%20%D0%9E%D0%B4%D0%BD%D0%B0%D0%BA%D0%BE%2C%20%D1%81%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F%20-%20%D0%BF%D0%BE%D0%B4%D0%B0%D1%80%D0%BE%D0%BA%20%D1%81%D1%83%D0%B4%D1%8C%D0%B1%D1%8B%2C%20%D0%B0%20%D0%BF%D0%BE%D0%B4%D0%B0%D1%80%D0%BA%D0%B8%20%D0%B4%D0%BE%D0%BB%D0%B6%D0%BD%D1%8B%20%D0%BF%D1%80%D0%B8%D0%BD%D0%BE%D1%81%D0%B8%D1%82%D1%8C%20%D1%80%D0%B0%D0%B4%D0%BE%D1%81%D1%82%D1%8C.)
^ru-Q0874-answer

**ru-Q0875** — Его нет, потому что он болеет.

He isn't here because he's ill.

Why: Logical connectors. [[Russian#^ru-Q0875|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D0%B3%D0%BE%20%D0%BD%D0%B5%D1%82%2C%20%D0%BF%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE%20%D0%BE%D0%BD%20%D0%B1%D0%BE%D0%BB%D0%B5%D0%B5%D1%82.)
^ru-Q0875-answer

**ru-Q0876** — Его нет, потому что он болеет.

He isn't here because he's ill.

Distinguish cause, concession and result. Поэтому presents a consequence, not its cause. Несмотря often belongs to a prepositional concessive construction requiring its own complement.

Why: Logical connectors. [[Russian#^ru-Q0876|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D0%B3%D0%BE%20%D0%BD%D0%B5%D1%82%2C%20%D0%BF%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE%20%D0%BE%D0%BD%20%D0%B1%D0%BE%D0%BB%D0%B5%D0%B5%D1%82.)
^ru-Q0876-answer

**ru-Q0877** — Тому было трудно дышать, поэтому мы отвезли его в больницу.

Tom was having trouble breathing, so we took him to the hospital.

Expected form: **поэтому**

Why: Logical connectors. [[Russian#^ru-Q0877|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%D1%83%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D1%82%D1%80%D1%83%D0%B4%D0%BD%D0%BE%20%D0%B4%D1%8B%D1%88%D0%B0%D1%82%D1%8C%2C%20%D0%BF%D0%BE%D1%8D%D1%82%D0%BE%D0%BC%D1%83%20%D0%BC%D1%8B%20%D0%BE%D1%82%D0%B2%D0%B5%D0%B7%D0%BB%D0%B8%20%D0%B5%D0%B3%D0%BE%20%D0%B2%20%D0%B1%D0%BE%D0%BB%D1%8C%D0%BD%D0%B8%D1%86%D1%83.)
^ru-Q0877-answer

**ru-Q0878** — Тому было трудно дышать, поэтому мы отвезли его в больницу.

Tom was having trouble breathing, so we took him to the hospital.

Expected form: **поэтому**

Why: Logical connectors. [[Russian#^ru-Q0878|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%D1%83%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D1%82%D1%80%D1%83%D0%B4%D0%BD%D0%BE%20%D0%B4%D1%8B%D1%88%D0%B0%D1%82%D1%8C%2C%20%D0%BF%D0%BE%D1%8D%D1%82%D0%BE%D0%BC%D1%83%20%D0%BC%D1%8B%20%D0%BE%D1%82%D0%B2%D0%B5%D0%B7%D0%BB%D0%B8%20%D0%B5%D0%B3%D0%BE%20%D0%B2%20%D0%B1%D0%BE%D0%BB%D1%8C%D0%BD%D0%B8%D1%86%D1%83.)
^ru-Q0878-answer

**ru-Q0879** — Однако в истории существуют примеры, когда успешно истреблялись целые народы.

However, there are instances in history where entire peoples were successfully exterminated.

Expected form: **Однако**

Why: Logical connectors. [[Russian#^ru-Q0879|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%B4%D0%BD%D0%B0%D0%BA%D0%BE%20%D0%B2%20%D0%B8%D1%81%D1%82%D0%BE%D1%80%D0%B8%D0%B8%20%D1%81%D1%83%D1%89%D0%B5%D1%81%D1%82%D0%B2%D1%83%D1%8E%D1%82%20%D0%BF%D1%80%D0%B8%D0%BC%D0%B5%D1%80%D1%8B%2C%20%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D1%83%D1%81%D0%BF%D0%B5%D1%88%D0%BD%D0%BE%20%D0%B8%D1%81%D1%82%D1%80%D0%B5%D0%B1%D0%BB%D1%8F%D0%BB%D0%B8%D1%81%D1%8C%20%D1%86%D0%B5%D0%BB%D1%8B%D0%B5%20%D0%BD%D0%B0%D1%80%D0%BE%D0%B4%D1%8B.)
^ru-Q0879-answer

**ru-Q0880** — Однако в истории существуют примеры, когда успешно истреблялись целые народы.

However, there are instances in history where entire peoples were successfully exterminated.

Why: Logical connectors. [[Russian#^ru-Q0880|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%B4%D0%BD%D0%B0%D0%BA%D0%BE%20%D0%B2%20%D0%B8%D1%81%D1%82%D0%BE%D1%80%D0%B8%D0%B8%20%D1%81%D1%83%D1%89%D0%B5%D1%81%D1%82%D0%B2%D1%83%D1%8E%D1%82%20%D0%BF%D1%80%D0%B8%D0%BC%D0%B5%D1%80%D1%8B%2C%20%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D1%83%D1%81%D0%BF%D0%B5%D1%88%D0%BD%D0%BE%20%D0%B8%D1%81%D1%82%D1%80%D0%B5%D0%B1%D0%BB%D1%8F%D0%BB%D0%B8%D1%81%D1%8C%20%D1%86%D0%B5%D0%BB%D1%8B%D0%B5%20%D0%BD%D0%B0%D1%80%D0%BE%D0%B4%D1%8B.)
^ru-Q0880-answer

**ru-Q0881** — Я не могу сегодня идти на работу, потому что у меня грипп.

I can't go to work today because I have the flu.

Why: Logical connectors. [[Russian#^ru-Q0881|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D0%BC%D0%BE%D0%B3%D1%83%20%D1%81%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F%20%D0%B8%D0%B4%D1%82%D0%B8%20%D0%BD%D0%B0%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%83%2C%20%D0%BF%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE%20%D1%83%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D0%B3%D1%80%D0%B8%D0%BF%D0%BF.)
^ru-Q0881-answer

**ru-Q0882** — Я не могу сегодня идти на работу, потому что у меня грипп.

I can't go to work today because I have the flu.

Distinguish cause, concession and result. Поэтому presents a consequence, not its cause. Несмотря often belongs to a prepositional concessive construction requiring its own complement.

Why: Logical connectors. [[Russian#^ru-Q0882|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D0%BC%D0%BE%D0%B3%D1%83%20%D1%81%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F%20%D0%B8%D0%B4%D1%82%D0%B8%20%D0%BD%D0%B0%20%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%83%2C%20%D0%BF%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE%20%D1%83%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D0%B3%D1%80%D0%B8%D0%BF%D0%BF.)
^ru-Q0882-answer

**ru-Q0883** — Шкурки были слишком повреждены и не годились для продажи, поэтому он сшил из них сыну пару рукавичек.

The pelts were too damaged to be sold, so he used them to make his son a pair of mittens.

Expected form: **поэтому**

Why: Logical connectors. [[Russian#^ru-Q0883|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A8%D0%BA%D1%83%D1%80%D0%BA%D0%B8%20%D0%B1%D1%8B%D0%BB%D0%B8%20%D1%81%D0%BB%D0%B8%D1%88%D0%BA%D0%BE%D0%BC%20%D0%BF%D0%BE%D0%B2%D1%80%D0%B5%D0%B6%D0%B4%D0%B5%D0%BD%D1%8B%20%D0%B8%20%D0%BD%D0%B5%20%D0%B3%D0%BE%D0%B4%D0%B8%D0%BB%D0%B8%D1%81%D1%8C%20%D0%B4%D0%BB%D1%8F%20%D0%BF%D1%80%D0%BE%D0%B4%D0%B0%D0%B6%D0%B8%2C%20%D0%BF%D0%BE%D1%8D%D1%82%D0%BE%D0%BC%D1%83%20%D0%BE%D0%BD%20%D1%81%D1%88%D0%B8%D0%BB%20%D0%B8%D0%B7%20%D0%BD%D0%B8%D1%85%20%D1%81%D1%8B%D0%BD%D1%83%20%D0%BF%D0%B0%D1%80%D1%83%20%D1%80%D1%83%D0%BA%D0%B0%D0%B2%D0%B8%D1%87%D0%B5%D0%BA.)
^ru-Q0883-answer

**ru-Q0884** — Шкурки были слишком повреждены и не годились для продажи, поэтому он сшил из них сыну пару рукавичек.

The pelts were too damaged to be sold, so he used them to make his son a pair of mittens.

Expected form: **поэтому**

Why: Logical connectors. [[Russian#^ru-Q0884|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A8%D0%BA%D1%83%D1%80%D0%BA%D0%B8%20%D0%B1%D1%8B%D0%BB%D0%B8%20%D1%81%D0%BB%D0%B8%D1%88%D0%BA%D0%BE%D0%BC%20%D0%BF%D0%BE%D0%B2%D1%80%D0%B5%D0%B6%D0%B4%D0%B5%D0%BD%D1%8B%20%D0%B8%20%D0%BD%D0%B5%20%D0%B3%D0%BE%D0%B4%D0%B8%D0%BB%D0%B8%D1%81%D1%8C%20%D0%B4%D0%BB%D1%8F%20%D0%BF%D1%80%D0%BE%D0%B4%D0%B0%D0%B6%D0%B8%2C%20%D0%BF%D0%BE%D1%8D%D1%82%D0%BE%D0%BC%D1%83%20%D0%BE%D0%BD%20%D1%81%D1%88%D0%B8%D0%BB%20%D0%B8%D0%B7%20%D0%BD%D0%B8%D1%85%20%D1%81%D1%8B%D0%BD%D1%83%20%D0%BF%D0%B0%D1%80%D1%83%20%D1%80%D1%83%D0%BA%D0%B0%D0%B2%D0%B8%D1%87%D0%B5%D0%BA.)
^ru-Q0884-answer

**ru-Q0885** — Я купила цветы, так как сегодня в гости заедет бабушка.

I bought flowers because my grandmother is coming today for a visit.

Expected form: **так как**

Why: Logical connectors. [[Russian#^ru-Q0885|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BA%D1%83%D0%BF%D0%B8%D0%BB%D0%B0%20%D1%86%D0%B2%D0%B5%D1%82%D1%8B%2C%20%D1%82%D0%B0%D0%BA%20%D0%BA%D0%B0%D0%BA%20%D1%81%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F%20%D0%B2%20%D0%B3%D0%BE%D1%81%D1%82%D0%B8%20%D0%B7%D0%B0%D0%B5%D0%B4%D0%B5%D1%82%20%D0%B1%D0%B0%D0%B1%D1%83%D1%88%D0%BA%D0%B0.)
^ru-Q0885-answer

**ru-Q0886** — Я купила цветы, так как сегодня в гости заедет бабушка.

I bought flowers because my grandmother is coming today for a visit.

Why: Logical connectors. [[Russian#^ru-Q0886|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BA%D1%83%D0%BF%D0%B8%D0%BB%D0%B0%20%D1%86%D0%B2%D0%B5%D1%82%D1%8B%2C%20%D1%82%D0%B0%D0%BA%20%D0%BA%D0%B0%D0%BA%20%D1%81%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F%20%D0%B2%20%D0%B3%D0%BE%D1%81%D1%82%D0%B8%20%D0%B7%D0%B0%D0%B5%D0%B4%D0%B5%D1%82%20%D0%B1%D0%B0%D0%B1%D1%83%D1%88%D0%BA%D0%B0.)
^ru-Q0886-answer

**ru-Q0887** — Я плачу, потому что мне грустно.

I'm crying because I'm sad.

Why: Logical connectors. [[Russian#^ru-Q0887|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BF%D0%BB%D0%B0%D1%87%D1%83%2C%20%D0%BF%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE%20%D0%BC%D0%BD%D0%B5%20%D0%B3%D1%80%D1%83%D1%81%D1%82%D0%BD%D0%BE.)
^ru-Q0887-answer

**ru-Q0888** — Я плачу, потому что мне грустно.

I'm crying because I'm sad.

Distinguish cause, concession and result. Поэтому presents a consequence, not its cause. Несмотря often belongs to a prepositional concessive construction requiring its own complement.

Why: Logical connectors. [[Russian#^ru-Q0888|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BF%D0%BB%D0%B0%D1%87%D1%83%2C%20%D0%BF%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE%20%D0%BC%D0%BD%D0%B5%20%D0%B3%D1%80%D1%83%D1%81%D1%82%D0%BD%D0%BE.)
^ru-Q0888-answer

**ru-Q0889** — Вы поэтому опоздали?

Is that why you were late?

Expected form: **поэтому**

Why: Logical connectors. [[Russian#^ru-Q0889|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D0%BF%D0%BE%D1%8D%D1%82%D0%BE%D0%BC%D1%83%20%D0%BE%D0%BF%D0%BE%D0%B7%D0%B4%D0%B0%D0%BB%D0%B8%3F)
^ru-Q0889-answer

**ru-Q0890** — Вы поэтому опоздали?

Is that why you were late?

Expected form: **поэтому**

Why: Logical connectors. [[Russian#^ru-Q0890|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D1%8B%20%D0%BF%D0%BE%D1%8D%D1%82%D0%BE%D0%BC%D1%83%20%D0%BE%D0%BF%D0%BE%D0%B7%D0%B4%D0%B0%D0%BB%D0%B8%3F)
^ru-Q0890-answer

**ru-Q0891** — "Почему ты не идёшь?" - "Потому что не хочу".

"Why aren't you going?" "Because I don't want to."

Expected form: **Потому что**

Why: Logical connectors. [[Russian#^ru-Q0891|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%22%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D1%82%D1%8B%20%D0%BD%D0%B5%20%D0%B8%D0%B4%D1%91%D1%88%D1%8C%3F%22%20-%20%22%D0%9F%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE%20%D0%BD%D0%B5%20%D1%85%D0%BE%D1%87%D1%83%22.)
^ru-Q0891-answer

**ru-Q0892** — "Почему ты не идёшь?" - "Потому что не хочу".

"Why aren't you going?" "Because I don't want to."

Why: Logical connectors. [[Russian#^ru-Q0892|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%22%D0%9F%D0%BE%D1%87%D0%B5%D0%BC%D1%83%20%D1%82%D1%8B%20%D0%BD%D0%B5%20%D0%B8%D0%B4%D1%91%D1%88%D1%8C%3F%22%20-%20%22%D0%9F%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE%20%D0%BD%D0%B5%20%D1%85%D0%BE%D1%87%D1%83%22.)
^ru-Q0892-answer

**ru-Q0893** — Том мог бы хотя бы спасибо сказать.

Tom could at least have said thank you.

Why: Logical connectors. [[Russian#^ru-Q0893|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BC%D0%BE%D0%B3%20%D0%B1%D1%8B%20%D1%85%D0%BE%D1%82%D1%8F%20%D0%B1%D1%8B%20%D1%81%D0%BF%D0%B0%D1%81%D0%B8%D0%B1%D0%BE%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C.)
^ru-Q0893-answer

**ru-Q0894** — Том мог бы хотя бы спасибо сказать.

Tom could at least have said thank you.

Distinguish cause, concession and result. Поэтому presents a consequence, not its cause. Несмотря often belongs to a prepositional concessive construction requiring its own complement.

Why: Logical connectors. [[Russian#^ru-Q0894|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BC%D0%BE%D0%B3%20%D0%B1%D1%8B%20%D1%85%D0%BE%D1%82%D1%8F%20%D0%B1%D1%8B%20%D1%81%D0%BF%D0%B0%D1%81%D0%B8%D0%B1%D0%BE%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C.)
^ru-Q0894-answer

**ru-Q0895** — Том не может сейчас с тобой поговорить, потому что занят.

Tom can't talk to you right now because he's busy.

Expected form: **потому что**

Why: Logical connectors. [[Russian#^ru-Q0895|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D0%BC%D0%BE%D0%B6%D0%B5%D1%82%20%D1%81%D0%B5%D0%B9%D1%87%D0%B0%D1%81%20%D1%81%20%D1%82%D0%BE%D0%B1%D0%BE%D0%B9%20%D0%BF%D0%BE%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D1%8C%2C%20%D0%BF%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE%20%D0%B7%D0%B0%D0%BD%D1%8F%D1%82.)
^ru-Q0895-answer

**ru-Q0896** — Том не может сейчас с тобой поговорить, потому что занят.

Tom can't talk to you right now because he's busy.

Expected form: **потому что**

Why: Logical connectors. [[Russian#^ru-Q0896|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%BD%D0%B5%20%D0%BC%D0%BE%D0%B6%D0%B5%D1%82%20%D1%81%D0%B5%D0%B9%D1%87%D0%B0%D1%81%20%D1%81%20%D1%82%D0%BE%D0%B1%D0%BE%D0%B9%20%D0%BF%D0%BE%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D1%8C%2C%20%D0%BF%D0%BE%D1%82%D0%BE%D0%BC%D1%83%20%D1%87%D1%82%D0%BE%20%D0%B7%D0%B0%D0%BD%D1%8F%D1%82.)
^ru-Q0896-answer

**ru-Q0897** — Вот именно поэтому я и пришла!

That's exactly why I came!

Expected form: **поэтому**

Why: Logical connectors. [[Russian#^ru-Q0897|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D0%BE%D1%82%20%D0%B8%D0%BC%D0%B5%D0%BD%D0%BD%D0%BE%20%D0%BF%D0%BE%D1%8D%D1%82%D0%BE%D0%BC%D1%83%20%D1%8F%20%D0%B8%20%D0%BF%D1%80%D0%B8%D1%88%D0%BB%D0%B0%21)
^ru-Q0897-answer

**ru-Q0898** — Вот именно поэтому я и пришла!

That's exactly why I came!

Why: Logical connectors. [[Russian#^ru-Q0898|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D0%BE%D1%82%20%D0%B8%D0%BC%D0%B5%D0%BD%D0%BD%D0%BE%20%D0%BF%D0%BE%D1%8D%D1%82%D0%BE%D0%BC%D1%83%20%D1%8F%20%D0%B8%20%D0%BF%D1%80%D0%B8%D1%88%D0%BB%D0%B0%21)
^ru-Q0898-answer

**ru-Q0899** — Начался сильный дождь. Поэтому мы играли внутри.

It started raining hard. Because of that, we played inside.

Why: Logical connectors. [[Russian#^ru-Q0899|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D1%81%D1%8F%20%D1%81%D0%B8%D0%BB%D1%8C%D0%BD%D1%8B%D0%B9%20%D0%B4%D0%BE%D0%B6%D0%B4%D1%8C.%20%D0%9F%D0%BE%D1%8D%D1%82%D0%BE%D0%BC%D1%83%20%D0%BC%D1%8B%20%D0%B8%D0%B3%D1%80%D0%B0%D0%BB%D0%B8%20%D0%B2%D0%BD%D1%83%D1%82%D1%80%D0%B8.)
^ru-Q0899-answer

**ru-Q0900** — Начался сильный дождь. Поэтому мы играли внутри.

It started raining hard. Because of that, we played inside.

Distinguish cause, concession and result. Поэтому presents a consequence, not its cause. Несмотря often belongs to a prepositional concessive construction requiring its own complement.

Why: Logical connectors. [[Russian#^ru-Q0900|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D1%81%D1%8F%20%D1%81%D0%B8%D0%BB%D1%8C%D0%BD%D1%8B%D0%B9%20%D0%B4%D0%BE%D0%B6%D0%B4%D1%8C.%20%D0%9F%D0%BE%D1%8D%D1%82%D0%BE%D0%BC%D1%83%20%D0%BC%D1%8B%20%D0%B8%D0%B3%D1%80%D0%B0%D0%BB%D0%B8%20%D0%B2%D0%BD%D1%83%D1%82%D1%80%D0%B8.)
^ru-Q0900-answer


### Answers 901–950

**ru-Q0901** — Она оказалась меньше, чем я себе её представлял.

She turned out to be smaller than I'd thought she was.

Expected form: **меньше**

Why: Quantity and comparison. [[Russian#^ru-Q0901|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D0%BE%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%D0%B0%D1%81%D1%8C%20%D0%BC%D0%B5%D0%BD%D1%8C%D1%88%D0%B5%2C%20%D1%87%D0%B5%D0%BC%20%D1%8F%20%D1%81%D0%B5%D0%B1%D0%B5%20%D0%B5%D1%91%20%D0%BF%D1%80%D0%B5%D0%B4%D1%81%D1%82%D0%B0%D0%B2%D0%BB%D1%8F%D0%BB.)
^ru-Q0901-answer

**ru-Q0902** — Она оказалась меньше, чем я себе её представлял.

She turned out to be smaller than I'd thought she was.

Expected form: **меньше**

Why: Quantity and comparison. [[Russian#^ru-Q0902|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D0%BD%D0%B0%20%D0%BE%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%D0%B0%D1%81%D1%8C%20%D0%BC%D0%B5%D0%BD%D1%8C%D1%88%D0%B5%2C%20%D1%87%D0%B5%D0%BC%20%D1%8F%20%D1%81%D0%B5%D0%B1%D0%B5%20%D0%B5%D1%91%20%D0%BF%D1%80%D0%B5%D0%B4%D1%81%D1%82%D0%B0%D0%B2%D0%BB%D1%8F%D0%BB.)
^ru-Q0902-answer

**ru-Q0903** — Том и Мария больше не любят друг друга.

Tom and Mary don't love each other anymore.

Expected form: **больше**

Why: Quantity and comparison. [[Russian#^ru-Q0903|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B8%20%D0%9C%D0%B0%D1%80%D0%B8%D1%8F%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BD%D0%B5%20%D0%BB%D1%8E%D0%B1%D1%8F%D1%82%20%D0%B4%D1%80%D1%83%D0%B3%20%D0%B4%D1%80%D1%83%D0%B3%D0%B0.)
^ru-Q0903-answer

**ru-Q0904** — Том и Мария больше не любят друг друга.

Tom and Mary don't love each other anymore.

Why: Quantity and comparison. [[Russian#^ru-Q0904|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D0%B8%20%D0%9C%D0%B0%D1%80%D0%B8%D1%8F%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BD%D0%B5%20%D0%BB%D1%8E%D0%B1%D1%8F%D1%82%20%D0%B4%D1%80%D1%83%D0%B3%20%D0%B4%D1%80%D1%83%D0%B3%D0%B0.)
^ru-Q0904-answer

**ru-Q0905** — Том съел больше меня.

Tom ate more than I did.

Why: Quantity and comparison. [[Russian#^ru-Q0905|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%81%D1%8A%D0%B5%D0%BB%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BC%D0%B5%D0%BD%D1%8F.)
^ru-Q0905-answer

**ru-Q0906** — Том съел больше меня.

Tom ate more than I did.

Numerals govern distinctive noun forms, with patterns for 1, 2–4 and other numbers. Gender can affect два/две. Comparatives such as лучше can be invariant in relevant uses.

Why: Quantity and comparison. [[Russian#^ru-Q0906|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%81%D1%8A%D0%B5%D0%BB%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BC%D0%B5%D0%BD%D1%8F.)
^ru-Q0906-answer

**ru-Q0907** — Том совершает пробежку три раза в неделю.

Tom jogs three times a week.

Expected form: **три**

Why: Quantity and comparison. [[Russian#^ru-Q0907|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%81%D0%BE%D0%B2%D0%B5%D1%80%D1%88%D0%B0%D0%B5%D1%82%20%D0%BF%D1%80%D0%BE%D0%B1%D0%B5%D0%B6%D0%BA%D1%83%20%D1%82%D1%80%D0%B8%20%D1%80%D0%B0%D0%B7%D0%B0%20%D0%B2%20%D0%BD%D0%B5%D0%B4%D0%B5%D0%BB%D1%8E.)
^ru-Q0907-answer

**ru-Q0908** — Том совершает пробежку три раза в неделю.

Tom jogs three times a week.

Expected form: **три**

Why: Quantity and comparison. [[Russian#^ru-Q0908|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%20%D1%81%D0%BE%D0%B2%D0%B5%D1%80%D1%88%D0%B0%D0%B5%D1%82%20%D0%BF%D1%80%D0%BE%D0%B1%D0%B5%D0%B6%D0%BA%D1%83%20%D1%82%D1%80%D0%B8%20%D1%80%D0%B0%D0%B7%D0%B0%20%D0%B2%20%D0%BD%D0%B5%D0%B4%D0%B5%D0%BB%D1%8E.)
^ru-Q0908-answer

**ru-Q0909** — Похоже, на Татоэбе слишком много турецких троллей.

Seems like there are too many Turkish trolls on Tatoeba.

Expected form: **много**

Why: Quantity and comparison. [[Russian#^ru-Q0909|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%85%D0%BE%D0%B6%D0%B5%2C%20%D0%BD%D0%B0%20%D0%A2%D0%B0%D1%82%D0%BE%D1%8D%D0%B1%D0%B5%20%D1%81%D0%BB%D0%B8%D1%88%D0%BA%D0%BE%D0%BC%20%D0%BC%D0%BD%D0%BE%D0%B3%D0%BE%20%D1%82%D1%83%D1%80%D0%B5%D1%86%D0%BA%D0%B8%D1%85%20%D1%82%D1%80%D0%BE%D0%BB%D0%BB%D0%B5%D0%B9.)
^ru-Q0909-answer

**ru-Q0910** — Похоже, на Татоэбе слишком много турецких троллей.

Seems like there are too many Turkish trolls on Tatoeba.

Why: Quantity and comparison. [[Russian#^ru-Q0910|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D1%85%D0%BE%D0%B6%D0%B5%2C%20%D0%BD%D0%B0%20%D0%A2%D0%B0%D1%82%D0%BE%D1%8D%D0%B1%D0%B5%20%D1%81%D0%BB%D0%B8%D1%88%D0%BA%D0%BE%D0%BC%20%D0%BC%D0%BD%D0%BE%D0%B3%D0%BE%20%D1%82%D1%83%D1%80%D0%B5%D1%86%D0%BA%D0%B8%D1%85%20%D1%82%D1%80%D0%BE%D0%BB%D0%BB%D0%B5%D0%B9.)
^ru-Q0910-answer

**ru-Q0911** — Какая машина тебе больше нравится?

Which car do you like more?

Why: Quantity and comparison. [[Russian#^ru-Q0911|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%B0%D0%BA%D0%B0%D1%8F%20%D0%BC%D0%B0%D1%88%D0%B8%D0%BD%D0%B0%20%D1%82%D0%B5%D0%B1%D0%B5%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BD%D1%80%D0%B0%D0%B2%D0%B8%D1%82%D1%81%D1%8F%3F)
^ru-Q0911-answer

**ru-Q0912** — Какая машина тебе больше нравится?

Which car do you like more?

Numerals govern distinctive noun forms, with patterns for 1, 2–4 and other numbers. Gender can affect два/две. Comparatives such as лучше can be invariant in relevant uses.

Why: Quantity and comparison. [[Russian#^ru-Q0912|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9A%D0%B0%D0%BA%D0%B0%D1%8F%20%D0%BC%D0%B0%D1%88%D0%B8%D0%BD%D0%B0%20%D1%82%D0%B5%D0%B1%D0%B5%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BD%D1%80%D0%B0%D0%B2%D0%B8%D1%82%D1%81%D1%8F%3F)
^ru-Q0912-answer

**ru-Q0913** — Никогда больше не опаздывай в школу.

Never be late for school again.

Expected form: **больше**

Why: Quantity and comparison. [[Russian#^ru-Q0913|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B8%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BD%D0%B5%20%D0%BE%D0%BF%D0%B0%D0%B7%D0%B4%D1%8B%D0%B2%D0%B0%D0%B9%20%D0%B2%20%D1%88%D0%BA%D0%BE%D0%BB%D1%83.)
^ru-Q0913-answer

**ru-Q0914** — Никогда больше не опаздывай в школу.

Never be late for school again.

Expected form: **больше**

Why: Quantity and comparison. [[Russian#^ru-Q0914|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B8%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BD%D0%B5%20%D0%BE%D0%BF%D0%B0%D0%B7%D0%B4%D1%8B%D0%B2%D0%B0%D0%B9%20%D0%B2%20%D1%88%D0%BA%D0%BE%D0%BB%D1%83.)
^ru-Q0914-answer

**ru-Q0915** — На строительство дома им понадобилось два года.

It took them two years to build the house.

Expected form: **два**

Why: Quantity and comparison. [[Russian#^ru-Q0915|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%20%D1%81%D1%82%D1%80%D0%BE%D0%B8%D1%82%D0%B5%D0%BB%D1%8C%D1%81%D1%82%D0%B2%D0%BE%20%D0%B4%D0%BE%D0%BC%D0%B0%20%D0%B8%D0%BC%20%D0%BF%D0%BE%D0%BD%D0%B0%D0%B4%D0%BE%D0%B1%D0%B8%D0%BB%D0%BE%D1%81%D1%8C%20%D0%B4%D0%B2%D0%B0%20%D0%B3%D0%BE%D0%B4%D0%B0.)
^ru-Q0915-answer

**ru-Q0916** — На строительство дома им понадобилось два года.

It took them two years to build the house.

Why: Quantity and comparison. [[Russian#^ru-Q0916|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B0%20%D1%81%D1%82%D1%80%D0%BE%D0%B8%D1%82%D0%B5%D0%BB%D1%8C%D1%81%D1%82%D0%B2%D0%BE%20%D0%B4%D0%BE%D0%BC%D0%B0%20%D0%B8%D0%BC%20%D0%BF%D0%BE%D0%BD%D0%B0%D0%B4%D0%BE%D0%B1%D0%B8%D0%BB%D0%BE%D1%81%D1%8C%20%D0%B4%D0%B2%D0%B0%20%D0%B3%D0%BE%D0%B4%D0%B0.)
^ru-Q0916-answer

**ru-Q0917** — Уверен, что у нас много общего.

I'm sure we have a lot in common.

Why: Quantity and comparison. [[Russian#^ru-Q0917|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%D0%B2%D0%B5%D1%80%D0%B5%D0%BD%2C%20%D1%87%D1%82%D0%BE%20%D1%83%20%D0%BD%D0%B0%D1%81%20%D0%BC%D0%BD%D0%BE%D0%B3%D0%BE%20%D0%BE%D0%B1%D1%89%D0%B5%D0%B3%D0%BE.)
^ru-Q0917-answer

**ru-Q0918** — Уверен, что у нас много общего.

I'm sure we have a lot in common.

Numerals govern distinctive noun forms, with patterns for 1, 2–4 and other numbers. Gender can affect два/две. Comparatives such as лучше can be invariant in relevant uses.

Why: Quantity and comparison. [[Russian#^ru-Q0918|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%D0%B2%D0%B5%D1%80%D0%B5%D0%BD%2C%20%D1%87%D1%82%D0%BE%20%D1%83%20%D0%BD%D0%B0%D1%81%20%D0%BC%D0%BD%D0%BE%D0%B3%D0%BE%20%D0%BE%D0%B1%D1%89%D0%B5%D0%B3%D0%BE.)
^ru-Q0918-answer

**ru-Q0919** — Лео начал рычать, когда ему было два года.

Leo started to roar when he was two years old.

Expected form: **два**

Why: Quantity and comparison. [[Russian#^ru-Q0919|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9B%D0%B5%D0%BE%20%D0%BD%D0%B0%D1%87%D0%B0%D0%BB%20%D1%80%D1%8B%D1%87%D0%B0%D1%82%D1%8C%2C%20%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%B5%D0%BC%D1%83%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D0%B4%D0%B2%D0%B0%20%D0%B3%D0%BE%D0%B4%D0%B0.)
^ru-Q0919-answer

**ru-Q0920** — Лео начал рычать, когда ему было два года.

Leo started to roar when he was two years old.

Expected form: **два**

Why: Quantity and comparison. [[Russian#^ru-Q0920|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9B%D0%B5%D0%BE%20%D0%BD%D0%B0%D1%87%D0%B0%D0%BB%20%D1%80%D1%8B%D1%87%D0%B0%D1%82%D1%8C%2C%20%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%B5%D0%BC%D1%83%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D0%B4%D0%B2%D0%B0%20%D0%B3%D0%BE%D0%B4%D0%B0.)
^ru-Q0920-answer

**ru-Q0921** — Пожалуйста, больше не плачь.

Please don't cry again.

Expected form: **больше**

Why: Quantity and comparison. [[Russian#^ru-Q0921|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BD%D0%B5%20%D0%BF%D0%BB%D0%B0%D1%87%D1%8C.)
^ru-Q0921-answer

**ru-Q0922** — Пожалуйста, больше не плачь.

Please don't cry again.

Why: Quantity and comparison. [[Russian#^ru-Q0922|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BD%D0%B5%20%D0%BF%D0%BB%D0%B0%D1%87%D1%8C.)
^ru-Q0922-answer

**ru-Q0923** — Мы вернёмся через три часа.

We'll be back in three hours.

Why: Quantity and comparison. [[Russian#^ru-Q0923|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%B2%D0%B5%D1%80%D0%BD%D1%91%D0%BC%D1%81%D1%8F%20%D1%87%D0%B5%D1%80%D0%B5%D0%B7%20%D1%82%D1%80%D0%B8%20%D1%87%D0%B0%D1%81%D0%B0.)
^ru-Q0923-answer

**ru-Q0924** — Мы вернёмся через три часа.

We'll be back in three hours.

Numerals govern distinctive noun forms, with patterns for 1, 2–4 and other numbers. Gender can affect два/две. Comparatives such as лучше can be invariant in relevant uses.

Why: Quantity and comparison. [[Russian#^ru-Q0924|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%B2%D0%B5%D1%80%D0%BD%D1%91%D0%BC%D1%81%D1%8F%20%D1%87%D0%B5%D1%80%D0%B5%D0%B7%20%D1%82%D1%80%D0%B8%20%D1%87%D0%B0%D1%81%D0%B0.)
^ru-Q0924-answer

**ru-Q0925** — Я не отниму у вас много времени.

I won't take up much of your time.

Expected form: **много**

Why: Quantity and comparison. [[Russian#^ru-Q0925|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D0%BE%D1%82%D0%BD%D0%B8%D0%BC%D1%83%20%D1%83%20%D0%B2%D0%B0%D1%81%20%D0%BC%D0%BD%D0%BE%D0%B3%D0%BE%20%D0%B2%D1%80%D0%B5%D0%BC%D0%B5%D0%BD%D0%B8.)
^ru-Q0925-answer

**ru-Q0926** — Я не отниму у вас много времени.

I won't take up much of your time.

Expected form: **много**

Why: Quantity and comparison. [[Russian#^ru-Q0926|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D0%BE%D1%82%D0%BD%D0%B8%D0%BC%D1%83%20%D1%83%20%D0%B2%D0%B0%D1%81%20%D0%BC%D0%BD%D0%BE%D0%B3%D0%BE%20%D0%B2%D1%80%D0%B5%D0%BC%D0%B5%D0%BD%D0%B8.)
^ru-Q0926-answer

**ru-Q0927** — Я больше боюсь Тома, чем Мэри.

I'm more afraid of Tom than I am of Mary.

Expected form: **больше**

Why: Quantity and comparison. [[Russian#^ru-Q0927|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%B1%D0%BE%D1%8E%D1%81%D1%8C%20%D0%A2%D0%BE%D0%BC%D0%B0%2C%20%D1%87%D0%B5%D0%BC%20%D0%9C%D1%8D%D1%80%D0%B8.)
^ru-Q0927-answer

**ru-Q0928** — Я больше боюсь Тома, чем Мэри.

I'm more afraid of Tom than I am of Mary.

Why: Quantity and comparison. [[Russian#^ru-Q0928|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%B1%D0%BE%D1%8E%D1%81%D1%8C%20%D0%A2%D0%BE%D0%BC%D0%B0%2C%20%D1%87%D0%B5%D0%BC%20%D0%9C%D1%8D%D1%80%D0%B8.)
^ru-Q0928-answer

**ru-Q0929** — Я не хочу больше лежать в постели.

I don't want to stay in bed any longer.

Why: Quantity and comparison. [[Russian#^ru-Q0929|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D1%85%D0%BE%D1%87%D1%83%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BB%D0%B5%D0%B6%D0%B0%D1%82%D1%8C%20%D0%B2%20%D0%BF%D0%BE%D1%81%D1%82%D0%B5%D0%BB%D0%B8.)
^ru-Q0929-answer

**ru-Q0930** — Я не хочу больше лежать в постели.

I don't want to stay in bed any longer.

Numerals govern distinctive noun forms, with patterns for 1, 2–4 and other numbers. Gender can affect два/две. Comparatives such as лучше can be invariant in relevant uses.

Why: Quantity and comparison. [[Russian#^ru-Q0930|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BD%D0%B5%20%D1%85%D0%BE%D1%87%D1%83%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BB%D0%B5%D0%B6%D0%B0%D1%82%D1%8C%20%D0%B2%20%D0%BF%D0%BE%D1%81%D1%82%D0%B5%D0%BB%D0%B8.)
^ru-Q0930-answer

**ru-Q0931** — Люди ошибаются, думая, будто прошлое было лучше, чем настоящее.

People mistakenly think that the past was better than the present.

Expected form: **лучше**

Why: Quantity and comparison. [[Russian#^ru-Q0931|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9B%D1%8E%D0%B4%D0%B8%20%D0%BE%D1%88%D0%B8%D0%B1%D0%B0%D1%8E%D1%82%D1%81%D1%8F%2C%20%D0%B4%D1%83%D0%BC%D0%B0%D1%8F%2C%20%D0%B1%D1%83%D0%B4%D1%82%D0%BE%20%D0%BF%D1%80%D0%BE%D1%88%D0%BB%D0%BE%D0%B5%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D0%BB%D1%83%D1%87%D1%88%D0%B5%2C%20%D1%87%D0%B5%D0%BC%20%D0%BD%D0%B0%D1%81%D1%82%D0%BE%D1%8F%D1%89%D0%B5%D0%B5.)
^ru-Q0931-answer

**ru-Q0932** — Люди ошибаются, думая, будто прошлое было лучше, чем настоящее.

People mistakenly think that the past was better than the present.

Expected form: **лучше**

Why: Quantity and comparison. [[Russian#^ru-Q0932|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9B%D1%8E%D0%B4%D0%B8%20%D0%BE%D1%88%D0%B8%D0%B1%D0%B0%D1%8E%D1%82%D1%81%D1%8F%2C%20%D0%B4%D1%83%D0%BC%D0%B0%D1%8F%2C%20%D0%B1%D1%83%D0%B4%D1%82%D0%BE%20%D0%BF%D1%80%D0%BE%D1%88%D0%BB%D0%BE%D0%B5%20%D0%B1%D1%8B%D0%BB%D0%BE%20%D0%BB%D1%83%D1%87%D1%88%D0%B5%2C%20%D1%87%D0%B5%D0%BC%20%D0%BD%D0%B0%D1%81%D1%82%D0%BE%D1%8F%D1%89%D0%B5%D0%B5.)
^ru-Q0932-answer

**ru-Q0933** — Я об этом уже больше не думаю.

I never think about it anymore.

Expected form: **больше**

Why: Quantity and comparison. [[Russian#^ru-Q0933|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BE%D0%B1%20%D1%8D%D1%82%D0%BE%D0%BC%20%D1%83%D0%B6%D0%B5%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BD%D0%B5%20%D0%B4%D1%83%D0%BC%D0%B0%D1%8E.)
^ru-Q0933-answer

**ru-Q0934** — Я об этом уже больше не думаю.

I never think about it anymore.

Why: Quantity and comparison. [[Russian#^ru-Q0934|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%BE%D0%B1%20%D1%8D%D1%82%D0%BE%D0%BC%20%D1%83%D0%B6%D0%B5%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BD%D0%B5%20%D0%B4%D1%83%D0%BC%D0%B0%D1%8E.)
^ru-Q0934-answer

**ru-Q0935** — В Японии живёт много видов птиц.

Many kinds of birds live in Japan.

Why: Quantity and comparison. [[Russian#^ru-Q0935|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%20%D0%AF%D0%BF%D0%BE%D0%BD%D0%B8%D0%B8%20%D0%B6%D0%B8%D0%B2%D1%91%D1%82%20%D0%BC%D0%BD%D0%BE%D0%B3%D0%BE%20%D0%B2%D0%B8%D0%B4%D0%BE%D0%B2%20%D0%BF%D1%82%D0%B8%D1%86.)
^ru-Q0935-answer

**ru-Q0936** — В Японии живёт много видов птиц.

Many kinds of birds live in Japan.

Numerals govern distinctive noun forms, with patterns for 1, 2–4 and other numbers. Gender can affect два/две. Comparatives such as лучше can be invariant in relevant uses.

Why: Quantity and comparison. [[Russian#^ru-Q0936|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%20%D0%AF%D0%BF%D0%BE%D0%BD%D0%B8%D0%B8%20%D0%B6%D0%B8%D0%B2%D1%91%D1%82%20%D0%BC%D0%BD%D0%BE%D0%B3%D0%BE%20%D0%B2%D0%B8%D0%B4%D0%BE%D0%B2%20%D0%BF%D1%82%D0%B8%D1%86.)
^ru-Q0936-answer

**ru-Q0937** — Мы никогда его больше не увидим.

We'll never see him again.

Expected form: **больше**

Why: Quantity and comparison. [[Russian#^ru-Q0937|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%BD%D0%B8%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%B5%D0%B3%D0%BE%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BD%D0%B5%20%D1%83%D0%B2%D0%B8%D0%B4%D0%B8%D0%BC.)
^ru-Q0937-answer

**ru-Q0938** — Мы никогда его больше не увидим.

We'll never see him again.

Expected form: **больше**

Why: Quantity and comparison. [[Russian#^ru-Q0938|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8B%20%D0%BD%D0%B8%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D0%B5%D0%B3%D0%BE%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BD%D0%B5%20%D1%83%D0%B2%D0%B8%D0%B4%D0%B8%D0%BC.)
^ru-Q0938-answer

**ru-Q0939** — Тома, похоже, больше ничего не волнует.

Tom doesn't seem to care about anything else.

Expected form: **больше**

Why: Quantity and comparison. [[Russian#^ru-Q0939|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%D0%B0%2C%20%D0%BF%D0%BE%D1%85%D0%BE%D0%B6%D0%B5%2C%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BD%D0%B8%D1%87%D0%B5%D0%B3%D0%BE%20%D0%BD%D0%B5%20%D0%B2%D0%BE%D0%BB%D0%BD%D1%83%D0%B5%D1%82.)
^ru-Q0939-answer

**ru-Q0940** — Тома, похоже, больше ничего не волнует.

Tom doesn't seem to care about anything else.

Why: Quantity and comparison. [[Russian#^ru-Q0940|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%D0%B0%2C%20%D0%BF%D0%BE%D1%85%D0%BE%D0%B6%D0%B5%2C%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BD%D0%B8%D1%87%D0%B5%D0%B3%D0%BE%20%D0%BD%D0%B5%20%D0%B2%D0%BE%D0%BB%D0%BD%D1%83%D0%B5%D1%82.)
^ru-Q0940-answer

**ru-Q0941** — Тому больше ничего не нужно.

Tom doesn't need anything else.

Why: Quantity and comparison. [[Russian#^ru-Q0941|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%D1%83%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BD%D0%B8%D1%87%D0%B5%D0%B3%D0%BE%20%D0%BD%D0%B5%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE.)
^ru-Q0941-answer

**ru-Q0942** — Тому больше ничего не нужно.

Tom doesn't need anything else.

Numerals govern distinctive noun forms, with patterns for 1, 2–4 and other numbers. Gender can affect два/две. Comparatives such as лучше can be invariant in relevant uses.

Why: Quantity and comparison. [[Russian#^ru-Q0942|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%D1%83%20%D0%B1%D0%BE%D0%BB%D1%8C%D1%88%D0%B5%20%D0%BD%D0%B8%D1%87%D0%B5%D0%B3%D0%BE%20%D0%BD%D0%B5%20%D0%BD%D1%83%D0%B6%D0%BD%D0%BE.)
^ru-Q0942-answer

**ru-Q0943** — У неё две дочери.

She has two daughters.

Expected form: **две**

Why: Quantity and comparison. [[Russian#^ru-Q0943|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%20%D0%BD%D0%B5%D1%91%20%D0%B4%D0%B2%D0%B5%20%D0%B4%D0%BE%D1%87%D0%B5%D1%80%D0%B8.)
^ru-Q0943-answer

**ru-Q0944** — У неё две дочери.

She has two daughters.

Expected form: **две**

Why: Quantity and comparison. [[Russian#^ru-Q0944|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%20%D0%BD%D0%B5%D1%91%20%D0%B4%D0%B2%D0%B5%20%D0%B4%D0%BE%D1%87%D0%B5%D1%80%D0%B8.)
^ru-Q0944-answer

**ru-Q0945** — Я женился три года назад.

I got married three years ago.

Expected form: **три**

Why: Quantity and comparison. [[Russian#^ru-Q0945|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B6%D0%B5%D0%BD%D0%B8%D0%BB%D1%81%D1%8F%20%D1%82%D1%80%D0%B8%20%D0%B3%D0%BE%D0%B4%D0%B0%20%D0%BD%D0%B0%D0%B7%D0%B0%D0%B4.)
^ru-Q0945-answer

**ru-Q0946** — Я женился три года назад.

I got married three years ago.

Why: Quantity and comparison. [[Russian#^ru-Q0946|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%AF%20%D0%B6%D0%B5%D0%BD%D0%B8%D0%BB%D1%81%D1%8F%20%D1%82%D1%80%D0%B8%20%D0%B3%D0%BE%D0%B4%D0%B0%20%D0%BD%D0%B0%D0%B7%D0%B0%D0%B4.)
^ru-Q0946-answer

**ru-Q0947** — Мэри играет на гитаре приблизительно три часа в день.

Mary plays her guitar about three hours a day.

Why: Quantity and comparison. [[Russian#^ru-Q0947|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8D%D1%80%D0%B8%20%D0%B8%D0%B3%D1%80%D0%B0%D0%B5%D1%82%20%D0%BD%D0%B0%20%D0%B3%D0%B8%D1%82%D0%B0%D1%80%D0%B5%20%D0%BF%D1%80%D0%B8%D0%B1%D0%BB%D0%B8%D0%B7%D0%B8%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE%20%D1%82%D1%80%D0%B8%20%D1%87%D0%B0%D1%81%D0%B0%20%D0%B2%20%D0%B4%D0%B5%D0%BD%D1%8C.)
^ru-Q0947-answer

**ru-Q0948** — Мэри играет на гитаре приблизительно три часа в день.

Mary plays her guitar about three hours a day.

Numerals govern distinctive noun forms, with patterns for 1, 2–4 and other numbers. Gender can affect два/две. Comparatives such as лучше can be invariant in relevant uses.

Why: Quantity and comparison. [[Russian#^ru-Q0948|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D1%8D%D1%80%D0%B8%20%D0%B8%D0%B3%D1%80%D0%B0%D0%B5%D1%82%20%D0%BD%D0%B0%20%D0%B3%D0%B8%D1%82%D0%B0%D1%80%D0%B5%20%D0%BF%D1%80%D0%B8%D0%B1%D0%BB%D0%B8%D0%B7%D0%B8%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE%20%D1%82%D1%80%D0%B8%20%D1%87%D0%B0%D1%81%D0%B0%20%D0%B2%20%D0%B4%D0%B5%D0%BD%D1%8C.)
^ru-Q0948-answer

**ru-Q0949** — В этой коробке три яблока.

There are three apples in this box.

Expected form: **три**

Why: Quantity and comparison. [[Russian#^ru-Q0949|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%20%D1%8D%D1%82%D0%BE%D0%B9%20%D0%BA%D0%BE%D1%80%D0%BE%D0%B1%D0%BA%D0%B5%20%D1%82%D1%80%D0%B8%20%D1%8F%D0%B1%D0%BB%D0%BE%D0%BA%D0%B0.)
^ru-Q0949-answer

**ru-Q0950** — В этой коробке три яблока.

There are three apples in this box.

Expected form: **три**

Why: Quantity and comparison. [[Russian#^ru-Q0950|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%20%D1%8D%D1%82%D0%BE%D0%B9%20%D0%BA%D0%BE%D1%80%D0%BE%D0%B1%D0%BA%D0%B5%20%D1%82%D1%80%D0%B8%20%D1%8F%D0%B1%D0%BB%D0%BE%D0%BA%D0%B0.)
^ru-Q0950-answer


### Answers 951–1000

**ru-Q0951** — Оставь его, пожалуйста, в покое.

Leave him alone, please.

Expected form: **пожалуйста**

Why: Professional stance and courtesy. [[Russian#^ru-Q0951|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D1%81%D1%82%D0%B0%D0%B2%D1%8C%20%D0%B5%D0%B3%D0%BE%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%B2%20%D0%BF%D0%BE%D0%BA%D0%BE%D0%B5.)
^ru-Q0951-answer

**ru-Q0952** — Оставь его, пожалуйста, в покое.

Leave him alone, please.

Why: Professional stance and courtesy. [[Russian#^ru-Q0952|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D1%81%D1%82%D0%B0%D0%B2%D1%8C%20%D0%B5%D0%B3%D0%BE%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%B2%20%D0%BF%D0%BE%D0%BA%D0%BE%D0%B5.)
^ru-Q0952-answer

**ru-Q0953** — Приходи ещё, пожалуйста.

Please come again.

Why: Professional stance and courtesy. [[Russian#^ru-Q0953|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D1%80%D0%B8%D1%85%D0%BE%D0%B4%D0%B8%20%D0%B5%D1%89%D1%91%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0.)
^ru-Q0953-answer

**ru-Q0954** — Приходи ещё, пожалуйста.

Please come again.

Пожалуйста supports courteous requests. Возможно/вероятно limit certainty; следует/необходимо express recommendations or necessity. Distinguish a documented claim from a possibility.

Why: Professional stance and courtesy. [[Russian#^ru-Q0954|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D1%80%D0%B8%D1%85%D0%BE%D0%B4%D0%B8%20%D0%B5%D1%89%D1%91%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0.)
^ru-Q0954-answer

**ru-Q0955** — Подвинь стол влево, пожалуйста.

Please move the desk to the left.

Expected form: **пожалуйста**

Why: Professional stance and courtesy. [[Russian#^ru-Q0955|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%B4%D0%B2%D0%B8%D0%BD%D1%8C%20%D1%81%D1%82%D0%BE%D0%BB%20%D0%B2%D0%BB%D0%B5%D0%B2%D0%BE%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0.)
^ru-Q0955-answer

**ru-Q0956** — Подвинь стол влево, пожалуйста.

Please move the desk to the left.

Expected form: **пожалуйста**

Why: Professional stance and courtesy. [[Russian#^ru-Q0956|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%B4%D0%B2%D0%B8%D0%BD%D1%8C%20%D1%81%D1%82%D0%BE%D0%BB%20%D0%B2%D0%BB%D0%B5%D0%B2%D0%BE%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0.)
^ru-Q0956-answer

**ru-Q0957** — Не оставляйте меня одну, пожалуйста.

Please don't leave me alone.

Expected form: **пожалуйста**

Why: Professional stance and courtesy. [[Russian#^ru-Q0957|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%20%D0%BE%D1%81%D1%82%D0%B0%D0%B2%D0%BB%D1%8F%D0%B9%D1%82%D0%B5%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D0%BE%D0%B4%D0%BD%D1%83%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0.)
^ru-Q0957-answer

**ru-Q0958** — Не оставляйте меня одну, пожалуйста.

Please don't leave me alone.

Why: Professional stance and courtesy. [[Russian#^ru-Q0958|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9D%D0%B5%20%D0%BE%D1%81%D1%82%D0%B0%D0%B2%D0%BB%D1%8F%D0%B9%D1%82%D0%B5%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D0%BE%D0%B4%D0%BD%D1%83%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0.)
^ru-Q0958-answer

**ru-Q0959** — Передайте мне соль и перец, пожалуйста.

Please pass me the salt and pepper.

Why: Professional stance and courtesy. [[Russian#^ru-Q0959|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%B5%D1%80%D0%B5%D0%B4%D0%B0%D0%B9%D1%82%D0%B5%20%D0%BC%D0%BD%D0%B5%20%D1%81%D0%BE%D0%BB%D1%8C%20%D0%B8%20%D0%BF%D0%B5%D1%80%D0%B5%D1%86%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0.)
^ru-Q0959-answer

**ru-Q0960** — Передайте мне соль и перец, пожалуйста.

Please pass me the salt and pepper.

Пожалуйста supports courteous requests. Возможно/вероятно limit certainty; следует/необходимо express recommendations or necessity. Distinguish a documented claim from a possibility.

Why: Professional stance and courtesy. [[Russian#^ru-Q0960|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%B5%D1%80%D0%B5%D0%B4%D0%B0%D0%B9%D1%82%D0%B5%20%D0%BC%D0%BD%D0%B5%20%D1%81%D0%BE%D0%BB%D1%8C%20%D0%B8%20%D0%BF%D0%B5%D1%80%D0%B5%D1%86%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0.)
^ru-Q0960-answer

**ru-Q0961** — Пожалуйста, не тратьтесь на меня.

Please don't go to any expense on my account.

Expected form: **Пожалуйста**

Why: Professional stance and courtesy. [[Russian#^ru-Q0961|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%BD%D0%B5%20%D1%82%D1%80%D0%B0%D1%82%D1%8C%D1%82%D0%B5%D1%81%D1%8C%20%D0%BD%D0%B0%20%D0%BC%D0%B5%D0%BD%D1%8F.)
^ru-Q0961-answer

**ru-Q0962** — Пожалуйста, не тратьтесь на меня.

Please don't go to any expense on my account.

Expected form: **Пожалуйста**

Why: Professional stance and courtesy. [[Russian#^ru-Q0962|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%BD%D0%B5%20%D1%82%D1%80%D0%B0%D1%82%D1%8C%D1%82%D0%B5%D1%81%D1%8C%20%D0%BD%D0%B0%20%D0%BC%D0%B5%D0%BD%D1%8F.)
^ru-Q0962-answer

**ru-Q0963** — Пожалуйста, не заставляй меня это делать.

Please don't force me to do this.

Expected form: **Пожалуйста**

Why: Professional stance and courtesy. [[Russian#^ru-Q0963|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%BD%D0%B5%20%D0%B7%D0%B0%D1%81%D1%82%D0%B0%D0%B2%D0%BB%D1%8F%D0%B9%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D1%8D%D1%82%D0%BE%20%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C.)
^ru-Q0963-answer

**ru-Q0964** — Пожалуйста, не заставляй меня это делать.

Please don't force me to do this.

Why: Professional stance and courtesy. [[Russian#^ru-Q0964|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%BD%D0%B5%20%D0%B7%D0%B0%D1%81%D1%82%D0%B0%D0%B2%D0%BB%D1%8F%D0%B9%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D1%8D%D1%82%D0%BE%20%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C.)
^ru-Q0964-answer

**ru-Q0965** — Тому следует прекратить фиглярничать.

Tom should stop his tomfoolery.

Why: Professional stance and courtesy. [[Russian#^ru-Q0965|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%D1%83%20%D1%81%D0%BB%D0%B5%D0%B4%D1%83%D0%B5%D1%82%20%D0%BF%D1%80%D0%B5%D0%BA%D1%80%D0%B0%D1%82%D0%B8%D1%82%D1%8C%20%D1%84%D0%B8%D0%B3%D0%BB%D1%8F%D1%80%D0%BD%D0%B8%D1%87%D0%B0%D1%82%D1%8C.)
^ru-Q0965-answer

**ru-Q0966** — Тому следует прекратить фиглярничать.

Tom should stop his tomfoolery.

Пожалуйста supports courteous requests. Возможно/вероятно limit certainty; следует/необходимо express recommendations or necessity. Distinguish a documented claim from a possibility.

Why: Professional stance and courtesy. [[Russian#^ru-Q0966|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A2%D0%BE%D0%BC%D1%83%20%D1%81%D0%BB%D0%B5%D0%B4%D1%83%D0%B5%D1%82%20%D0%BF%D1%80%D0%B5%D0%BA%D1%80%D0%B0%D1%82%D0%B8%D1%82%D1%8C%20%D1%84%D0%B8%D0%B3%D0%BB%D1%8F%D1%80%D0%BD%D0%B8%D1%87%D0%B0%D1%82%D1%8C.)
^ru-Q0966-answer

**ru-Q0967** — Откройте мне эту банку, пожалуйста.

Open this jar for me, please.

Expected form: **пожалуйста**

Why: Professional stance and courtesy. [[Russian#^ru-Q0967|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D1%82%D0%BA%D1%80%D0%BE%D0%B9%D1%82%D0%B5%20%D0%BC%D0%BD%D0%B5%20%D1%8D%D1%82%D1%83%20%D0%B1%D0%B0%D0%BD%D0%BA%D1%83%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0.)
^ru-Q0967-answer

**ru-Q0968** — Откройте мне эту банку, пожалуйста.

Open this jar for me, please.

Expected form: **пожалуйста**

Why: Professional stance and courtesy. [[Russian#^ru-Q0968|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9E%D1%82%D0%BA%D1%80%D0%BE%D0%B9%D1%82%D0%B5%20%D0%BC%D0%BD%D0%B5%20%D1%8D%D1%82%D1%83%20%D0%B1%D0%B0%D0%BD%D0%BA%D1%83%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0.)
^ru-Q0968-answer

**ru-Q0969** — Скажи мне, пожалуйста, что случилось с Томом.

Please tell me what happened to Tom.

Expected form: **пожалуйста**

Why: Professional stance and courtesy. [[Russian#^ru-Q0969|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BA%D0%B0%D0%B6%D0%B8%20%D0%BC%D0%BD%D0%B5%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D1%87%D1%82%D0%BE%20%D1%81%D0%BB%D1%83%D1%87%D0%B8%D0%BB%D0%BE%D1%81%D1%8C%20%D1%81%20%D0%A2%D0%BE%D0%BC%D0%BE%D0%BC.)
^ru-Q0969-answer

**ru-Q0970** — Скажи мне, пожалуйста, что случилось с Томом.

Please tell me what happened to Tom.

Why: Professional stance and courtesy. [[Russian#^ru-Q0970|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BA%D0%B0%D0%B6%D0%B8%20%D0%BC%D0%BD%D0%B5%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D1%87%D1%82%D0%BE%20%D1%81%D0%BB%D1%83%D1%87%D0%B8%D0%BB%D0%BE%D1%81%D1%8C%20%D1%81%20%D0%A2%D0%BE%D0%BC%D0%BE%D0%BC.)
^ru-Q0970-answer

**ru-Q0971** — Положи его, пожалуйста, на место.

Please put it back in its place.

Why: Professional stance and courtesy. [[Russian#^ru-Q0971|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%BB%D0%BE%D0%B6%D0%B8%20%D0%B5%D0%B3%D0%BE%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%BD%D0%B0%20%D0%BC%D0%B5%D1%81%D1%82%D0%BE.)
^ru-Q0971-answer

**ru-Q0972** — Положи его, пожалуйста, на место.

Please put it back in its place.

Пожалуйста supports courteous requests. Возможно/вероятно limit certainty; следует/необходимо express recommendations or necessity. Distinguish a documented claim from a possibility.

Why: Professional stance and courtesy. [[Russian#^ru-Q0972|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%BB%D0%BE%D0%B6%D0%B8%20%D0%B5%D0%B3%D0%BE%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%BD%D0%B0%20%D0%BC%D0%B5%D1%81%D1%82%D0%BE.)
^ru-Q0972-answer

**ru-Q0973** — "Да, апельсиновый сок, пожалуйста", - сказал Майк.

"Yes, orange juice please," Mike said.

Expected form: **пожалуйста**

Why: Professional stance and courtesy. [[Russian#^ru-Q0973|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%22%D0%94%D0%B0%2C%20%D0%B0%D0%BF%D0%B5%D0%BB%D1%8C%D1%81%D0%B8%D0%BD%D0%BE%D0%B2%D1%8B%D0%B9%20%D1%81%D0%BE%D0%BA%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%22%2C%20-%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%20%D0%9C%D0%B0%D0%B9%D0%BA.)
^ru-Q0973-answer

**ru-Q0974** — "Да, апельсиновый сок, пожалуйста", - сказал Майк.

"Yes, orange juice please," Mike said.

Expected form: **пожалуйста**

Why: Professional stance and courtesy. [[Russian#^ru-Q0974|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%22%D0%94%D0%B0%2C%20%D0%B0%D0%BF%D0%B5%D0%BB%D1%8C%D1%81%D0%B8%D0%BD%D0%BE%D0%B2%D1%8B%D0%B9%20%D1%81%D0%BE%D0%BA%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%22%2C%20-%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D0%BB%20%D0%9C%D0%B0%D0%B9%D0%BA.)
^ru-Q0974-answer

**ru-Q0975** — Пожалуйста, соедините меня с господином Брауном.

Please put me through to Mr Brown.

Expected form: **Пожалуйста**

Why: Professional stance and courtesy. [[Russian#^ru-Q0975|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D1%81%D0%BE%D0%B5%D0%B4%D0%B8%D0%BD%D0%B8%D1%82%D0%B5%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D1%81%20%D0%B3%D0%BE%D1%81%D0%BF%D0%BE%D0%B4%D0%B8%D0%BD%D0%BE%D0%BC%20%D0%91%D1%80%D0%B0%D1%83%D0%BD%D0%BE%D0%BC.)
^ru-Q0975-answer

**ru-Q0976** — Пожалуйста, соедините меня с господином Брауном.

Please put me through to Mr Brown.

Why: Professional stance and courtesy. [[Russian#^ru-Q0976|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D1%81%D0%BE%D0%B5%D0%B4%D0%B8%D0%BD%D0%B8%D1%82%D0%B5%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D1%81%20%D0%B3%D0%BE%D1%81%D0%BF%D0%BE%D0%B4%D0%B8%D0%BD%D0%BE%D0%BC%20%D0%91%D1%80%D0%B0%D1%83%D0%BD%D0%BE%D0%BC.)
^ru-Q0976-answer

**ru-Q0977** — Сделайте, пожалуйста, музыку потише.

Please turn the music down a bit.

Why: Professional stance and courtesy. [[Russian#^ru-Q0977|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%B4%D0%B5%D0%BB%D0%B0%D0%B9%D1%82%D0%B5%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%BC%D1%83%D0%B7%D1%8B%D0%BA%D1%83%20%D0%BF%D0%BE%D1%82%D0%B8%D1%88%D0%B5.)
^ru-Q0977-answer

**ru-Q0978** — Сделайте, пожалуйста, музыку потише.

Please turn the music down a bit.

Пожалуйста supports courteous requests. Возможно/вероятно limit certainty; следует/необходимо express recommendations or necessity. Distinguish a documented claim from a possibility.

Why: Professional stance and courtesy. [[Russian#^ru-Q0978|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%B4%D0%B5%D0%BB%D0%B0%D0%B9%D1%82%D0%B5%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%BC%D1%83%D0%B7%D1%8B%D0%BA%D1%83%20%D0%BF%D0%BE%D1%82%D0%B8%D1%88%D0%B5.)
^ru-Q0978-answer

**ru-Q0979** — Возможно, Том может нам что-нибудь рассказать.

Maybe Tom can tell us something.

Expected form: **Возможно**

Why: Professional stance and courtesy. [[Russian#^ru-Q0979|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D0%BE%D0%B7%D0%BC%D0%BE%D0%B6%D0%BD%D0%BE%2C%20%D0%A2%D0%BE%D0%BC%20%D0%BC%D0%BE%D0%B6%D0%B5%D1%82%20%D0%BD%D0%B0%D0%BC%20%D1%87%D1%82%D0%BE-%D0%BD%D0%B8%D0%B1%D1%83%D0%B4%D1%8C%20%D1%80%D0%B0%D1%81%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C.)
^ru-Q0979-answer

**ru-Q0980** — Возможно, Том может нам что-нибудь рассказать.

Maybe Tom can tell us something.

Expected form: **Возможно**

Why: Professional stance and courtesy. [[Russian#^ru-Q0980|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D0%BE%D0%B7%D0%BC%D0%BE%D0%B6%D0%BD%D0%BE%2C%20%D0%A2%D0%BE%D0%BC%20%D0%BC%D0%BE%D0%B6%D0%B5%D1%82%20%D0%BD%D0%B0%D0%BC%20%D1%87%D1%82%D0%BE-%D0%BD%D0%B8%D0%B1%D1%83%D0%B4%D1%8C%20%D1%80%D0%B0%D1%81%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C.)
^ru-Q0980-answer

**ru-Q0981** — Пожалуйста, скажите нам правду.

Please tell us the truth.

Expected form: **Пожалуйста**

Why: Professional stance and courtesy. [[Russian#^ru-Q0981|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D1%81%D0%BA%D0%B0%D0%B6%D0%B8%D1%82%D0%B5%20%D0%BD%D0%B0%D0%BC%20%D0%BF%D1%80%D0%B0%D0%B2%D0%B4%D1%83.)
^ru-Q0981-answer

**ru-Q0982** — Пожалуйста, скажите нам правду.

Please tell us the truth.

Why: Professional stance and courtesy. [[Russian#^ru-Q0982|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D1%81%D0%BA%D0%B0%D0%B6%D0%B8%D1%82%D0%B5%20%D0%BD%D0%B0%D0%BC%20%D0%BF%D1%80%D0%B0%D0%B2%D0%B4%D1%83.)
^ru-Q0982-answer

**ru-Q0983** — Возможно, тебе следует ей сказать.

Maybe you should tell her.

Why: Professional stance and courtesy. [[Russian#^ru-Q0983|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D0%BE%D0%B7%D0%BC%D0%BE%D0%B6%D0%BD%D0%BE%2C%20%D1%82%D0%B5%D0%B1%D0%B5%20%D1%81%D0%BB%D0%B5%D0%B4%D1%83%D0%B5%D1%82%20%D0%B5%D0%B9%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C.)
^ru-Q0983-answer

**ru-Q0984** — Возможно, тебе следует ей сказать.

Maybe you should tell her.

Пожалуйста supports courteous requests. Возможно/вероятно limit certainty; следует/необходимо express recommendations or necessity. Distinguish a documented claim from a possibility.

Why: Professional stance and courtesy. [[Russian#^ru-Q0984|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D0%BE%D0%B7%D0%BC%D0%BE%D0%B6%D0%BD%D0%BE%2C%20%D1%82%D0%B5%D0%B1%D0%B5%20%D1%81%D0%BB%D0%B5%D0%B4%D1%83%D0%B5%D1%82%20%D0%B5%D0%B9%20%D1%81%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C.)
^ru-Q0984-answer

**ru-Q0985** — "Том, ты знаешь, что это за письменность?" "Возможно тибетская, но я не могу прочитать и символа."

"Tom, do you know what kind of script this is?" "Probably Tibetan, but I can't read a bit of it."

Expected form: **Возможно**

Why: Professional stance and courtesy. [[Russian#^ru-Q0985|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%22%D0%A2%D0%BE%D0%BC%2C%20%D1%82%D1%8B%20%D0%B7%D0%BD%D0%B0%D0%B5%D1%88%D1%8C%2C%20%D1%87%D1%82%D0%BE%20%D1%8D%D1%82%D0%BE%20%D0%B7%D0%B0%20%D0%BF%D0%B8%D1%81%D1%8C%D0%BC%D0%B5%D0%BD%D0%BD%D0%BE%D1%81%D1%82%D1%8C%3F%22%20%22%D0%92%D0%BE%D0%B7%D0%BC%D0%BE%D0%B6%D0%BD%D0%BE%20%D1%82%D0%B8%D0%B1%D0%B5%D1%82%D1%81%D0%BA%D0%B0%D1%8F%2C%20%D0%BD%D0%BE%20%D1%8F%20%D0%BD%D0%B5%20%D0%BC%D0%BE%D0%B3%D1%83%20%D0%BF%D1%80%D0%BE%D1%87%D0%B8%D1%82%D0%B0%D1%82%D1%8C%20%D0%B8%20%D1%81%D0%B8%D0%BC%D0%B2%D0%BE%D0%BB%D0%B0.%22)
^ru-Q0985-answer

**ru-Q0986** — "Том, ты знаешь, что это за письменность?" "Возможно тибетская, но я не могу прочитать и символа."

"Tom, do you know what kind of script this is?" "Probably Tibetan, but I can't read a bit of it."

Expected form: **Возможно**

Why: Professional stance and courtesy. [[Russian#^ru-Q0986|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%22%D0%A2%D0%BE%D0%BC%2C%20%D1%82%D1%8B%20%D0%B7%D0%BD%D0%B0%D0%B5%D1%88%D1%8C%2C%20%D1%87%D1%82%D0%BE%20%D1%8D%D1%82%D0%BE%20%D0%B7%D0%B0%20%D0%BF%D0%B8%D1%81%D1%8C%D0%BC%D0%B5%D0%BD%D0%BD%D0%BE%D1%81%D1%82%D1%8C%3F%22%20%22%D0%92%D0%BE%D0%B7%D0%BC%D0%BE%D0%B6%D0%BD%D0%BE%20%D1%82%D0%B8%D0%B1%D0%B5%D1%82%D1%81%D0%BA%D0%B0%D1%8F%2C%20%D0%BD%D0%BE%20%D1%8F%20%D0%BD%D0%B5%20%D0%BC%D0%BE%D0%B3%D1%83%20%D0%BF%D1%80%D0%BE%D1%87%D0%B8%D1%82%D0%B0%D1%82%D1%8C%20%D0%B8%20%D1%81%D0%B8%D0%BC%D0%B2%D0%BE%D0%BB%D0%B0.%22)
^ru-Q0986-answer

**ru-Q0987** — Вам следует читать книги, написанные на английском языке.

You should read books written in English.

Expected form: **следует**

Why: Professional stance and courtesy. [[Russian#^ru-Q0987|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D0%B0%D0%BC%20%D1%81%D0%BB%D0%B5%D0%B4%D1%83%D0%B5%D1%82%20%D1%87%D0%B8%D1%82%D0%B0%D1%82%D1%8C%20%D0%BA%D0%BD%D0%B8%D0%B3%D0%B8%2C%20%D0%BD%D0%B0%D0%BF%D0%B8%D1%81%D0%B0%D0%BD%D0%BD%D1%8B%D0%B5%20%D0%BD%D0%B0%20%D0%B0%D0%BD%D0%B3%D0%BB%D0%B8%D0%B9%D1%81%D0%BA%D0%BE%D0%BC%20%D1%8F%D0%B7%D1%8B%D0%BA%D0%B5.)
^ru-Q0987-answer

**ru-Q0988** — Вам следует читать книги, написанные на английском языке.

You should read books written in English.

Why: Professional stance and courtesy. [[Russian#^ru-Q0988|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%92%D0%B0%D0%BC%20%D1%81%D0%BB%D0%B5%D0%B4%D1%83%D0%B5%D1%82%20%D1%87%D0%B8%D1%82%D0%B0%D1%82%D1%8C%20%D0%BA%D0%BD%D0%B8%D0%B3%D0%B8%2C%20%D0%BD%D0%B0%D0%BF%D0%B8%D1%81%D0%B0%D0%BD%D0%BD%D1%8B%D0%B5%20%D0%BD%D0%B0%20%D0%B0%D0%BD%D0%B3%D0%BB%D0%B8%D0%B9%D1%81%D0%BA%D0%BE%D0%BC%20%D1%8F%D0%B7%D1%8B%D0%BA%D0%B5.)
^ru-Q0988-answer

**ru-Q0989** — Скажи, пожалуйста, где ты это купил.

Please tell me where you bought that.

Why: Professional stance and courtesy. [[Russian#^ru-Q0989|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BA%D0%B0%D0%B6%D0%B8%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%B3%D0%B4%D0%B5%20%D1%82%D1%8B%20%D1%8D%D1%82%D0%BE%20%D0%BA%D1%83%D0%BF%D0%B8%D0%BB.)
^ru-Q0989-answer

**ru-Q0990** — Скажи, пожалуйста, где ты это купил.

Please tell me where you bought that.

Пожалуйста supports courteous requests. Возможно/вероятно limit certainty; следует/необходимо express recommendations or necessity. Distinguish a documented claim from a possibility.

Why: Professional stance and courtesy. [[Russian#^ru-Q0990|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A1%D0%BA%D0%B0%D0%B6%D0%B8%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%B3%D0%B4%D0%B5%20%D1%82%D1%8B%20%D1%8D%D1%82%D0%BE%20%D0%BA%D1%83%D0%BF%D0%B8%D0%BB.)
^ru-Q0990-answer

**ru-Q0991** — Пожалуйста, не трогай цветы.

Please don't touch the flowers.

Expected form: **Пожалуйста**

Why: Professional stance and courtesy. [[Russian#^ru-Q0991|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%BD%D0%B5%20%D1%82%D1%80%D0%BE%D0%B3%D0%B0%D0%B9%20%D1%86%D0%B2%D0%B5%D1%82%D1%8B.)
^ru-Q0991-answer

**ru-Q0992** — Пожалуйста, не трогай цветы.

Please don't touch the flowers.

Expected form: **Пожалуйста**

Why: Professional stance and courtesy. [[Russian#^ru-Q0992|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D0%BD%D0%B5%20%D1%82%D1%80%D0%BE%D0%B3%D0%B0%D0%B9%20%D1%86%D0%B2%D0%B5%D1%82%D1%8B.)
^ru-Q0992-answer

**ru-Q0993** — Если увидите Тома, пожалуйста, сразу скажите нам.

If you see Tom, please tell us immediately.

Expected form: **пожалуйста**

Why: Professional stance and courtesy. [[Russian#^ru-Q0993|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D0%BB%D0%B8%20%D1%83%D0%B2%D0%B8%D0%B4%D0%B8%D1%82%D0%B5%20%D0%A2%D0%BE%D0%BC%D0%B0%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D1%81%D1%80%D0%B0%D0%B7%D1%83%20%D1%81%D0%BA%D0%B0%D0%B6%D0%B8%D1%82%D0%B5%20%D0%BD%D0%B0%D0%BC.)
^ru-Q0993-answer

**ru-Q0994** — Если увидите Тома, пожалуйста, сразу скажите нам.

If you see Tom, please tell us immediately.

Why: Professional stance and courtesy. [[Russian#^ru-Q0994|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%95%D1%81%D0%BB%D0%B8%20%D1%83%D0%B2%D0%B8%D0%B4%D0%B8%D1%82%D0%B5%20%D0%A2%D0%BE%D0%BC%D0%B0%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0%2C%20%D1%81%D1%80%D0%B0%D0%B7%D1%83%20%D1%81%D0%BA%D0%B0%D0%B6%D0%B8%D1%82%D0%B5%20%D0%BD%D0%B0%D0%BC.)
^ru-Q0994-answer

**ru-Q0995** — Мой муж был, вероятно, пьян, когда это подписал.

My husband was probably drunk when he signed this.

Why: Professional stance and courtesy. [[Russian#^ru-Q0995|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D0%B9%20%D0%BC%D1%83%D0%B6%20%D0%B1%D1%8B%D0%BB%2C%20%D0%B2%D0%B5%D1%80%D0%BE%D1%8F%D1%82%D0%BD%D0%BE%2C%20%D0%BF%D1%8C%D1%8F%D0%BD%2C%20%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D1%8D%D1%82%D0%BE%20%D0%BF%D0%BE%D0%B4%D0%BF%D0%B8%D1%81%D0%B0%D0%BB.)
^ru-Q0995-answer

**ru-Q0996** — Мой муж был, вероятно, пьян, когда это подписал.

My husband was probably drunk when he signed this.

Пожалуйста supports courteous requests. Возможно/вероятно limit certainty; следует/необходимо express recommendations or necessity. Distinguish a documented claim from a possibility.

Why: Professional stance and courtesy. [[Russian#^ru-Q0996|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9C%D0%BE%D0%B9%20%D0%BC%D1%83%D0%B6%20%D0%B1%D1%8B%D0%BB%2C%20%D0%B2%D0%B5%D1%80%D0%BE%D1%8F%D1%82%D0%BD%D0%BE%2C%20%D0%BF%D1%8C%D1%8F%D0%BD%2C%20%D0%BA%D0%BE%D0%B3%D0%B4%D0%B0%20%D1%8D%D1%82%D0%BE%20%D0%BF%D0%BE%D0%B4%D0%BF%D0%B8%D1%81%D0%B0%D0%BB.)
^ru-Q0996-answer

**ru-Q0997** — Передай мясо, пожалуйста.

Pass the meat please.

Expected form: **пожалуйста**

Why: Professional stance and courtesy. [[Russian#^ru-Q0997|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%B5%D1%80%D0%B5%D0%B4%D0%B0%D0%B9%20%D0%BC%D1%8F%D1%81%D0%BE%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0.)
^ru-Q0997-answer

**ru-Q0998** — Передай мясо, пожалуйста.

Pass the meat please.

Expected form: **пожалуйста**

Why: Professional stance and courtesy. [[Russian#^ru-Q0998|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%9F%D0%B5%D1%80%D0%B5%D0%B4%D0%B0%D0%B9%20%D0%BC%D1%8F%D1%81%D0%BE%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0.)
^ru-Q0998-answer

**ru-Q0999** — Убавь музыку, пожалуйста.

Please turn down the music.

Expected form: **пожалуйста**

Why: Professional stance and courtesy. [[Russian#^ru-Q0999|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%D0%B1%D0%B0%D0%B2%D1%8C%20%D0%BC%D1%83%D0%B7%D1%8B%D0%BA%D1%83%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0.)
^ru-Q0999-answer

**ru-Q1000** — Убавь музыку, пожалуйста.

Please turn down the music.

Why: Professional stance and courtesy. [[Russian#^ru-Q1000|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=rus&query=%D0%A3%D0%B1%D0%B0%D0%B2%D1%8C%20%D0%BC%D1%83%D0%B7%D1%8B%D0%BA%D1%83%2C%20%D0%BF%D0%BE%D0%B6%D0%B0%D0%BB%D1%83%D0%B9%D1%81%D1%82%D0%B0.)
^ru-Q1000-answer


## Read and speak

Read the native sentence first, identify its predicate and one grammar form, then check the translation. Say it aloud and change one detail.

### Learning with a clear purpose

Я изучаю новый язык. Каждый день я читаю короткий текст и слушаю понятные примеры. Я записываю полезные слова в тетрадь. Когда я делаю ошибку, я проверяю правило и пробую ещё раз. Моя цель — понимать людей и ясно выражать свои мысли.

I am learning a new language. Each day, I read a short text and listen to clear examples. I write useful words in a notebook. When I make a mistake, I check the rule and try again. My goal is to understand people and express my ideas clearly.

![[Resources/Audio/ru/Reading passage.mp3]]

**Ты должен сделать своих родителей счастливыми.**

You must make your parents happy.

**Сделайте это осторожно.**

Do it gently.

**Тебя, по идее, здесь быть не должно.**

You're not supposed to be here.

**Вы расскажете Тому?**

Will you tell Tom?

**Пойди поговори с ними.**

Go talk to them.

**Тебе не кажется, что это слишком далеко зашло?**

Don't you think this has gone far enough?

**Я хочу выполнить план любой ценой.**

I want to execute the plan by all means.

**Я должен приготовить ей завтрак.**

I must cook breakfast for her.

**Я бы сказал тебе, если бы мог.**

I would tell you if I could.

**Нам нужно её протестировать.**

We need to test it.

**Как ты собираешься это чинить?**

How are you going to fix that?

**Она самая высокая в классе.**

She's the tallest in her class.

**Том был напуган до смерти.**

Tom was scared to death.

**Я никогда не разрешаю кому-нибудь другому кормить свою собаку.**

I never let anyone else feed my dog.

**Почему я должен с ней разговаривать?**

Why do I have to talk to her?

## Professional writing

Write an introduction, a polite request, an explanation of a finding, a summary of a passage and a tactful disagreement. Use the professional/advanced lessons for models.

## PDF edition

[[Resources/PDFs/Russian.pdf|Open the complete printable book]]


<!-- individual-letter-audio -->
## Hear each letter separately

Play each letter’s own synthetic recording. English has separate US and UK models.

### А а · а

![[Resources/Audio/ru/Letters/001.mp3]]

### Б б · бэ

![[Resources/Audio/ru/Letters/002.mp3]]

### В в · вэ

![[Resources/Audio/ru/Letters/003.mp3]]

### Г г · гэ

![[Resources/Audio/ru/Letters/004.mp3]]

### Д д · дэ

![[Resources/Audio/ru/Letters/005.mp3]]

### Е е · е

![[Resources/Audio/ru/Letters/006.mp3]]

### Ё ё · ё

![[Resources/Audio/ru/Letters/007.mp3]]

### Ж ж · жэ

![[Resources/Audio/ru/Letters/008.mp3]]

### З з · зэ

![[Resources/Audio/ru/Letters/009.mp3]]

### И и · и

![[Resources/Audio/ru/Letters/010.mp3]]

### Й й · и краткое

![[Resources/Audio/ru/Letters/011.mp3]]

### К к · ка

![[Resources/Audio/ru/Letters/012.mp3]]

### Л л · эль

![[Resources/Audio/ru/Letters/013.mp3]]

### М м · эм

![[Resources/Audio/ru/Letters/014.mp3]]

### Н н · эн

![[Resources/Audio/ru/Letters/015.mp3]]

### О о · о

![[Resources/Audio/ru/Letters/016.mp3]]

### П п · пэ

![[Resources/Audio/ru/Letters/017.mp3]]

### Р р · эр

![[Resources/Audio/ru/Letters/018.mp3]]

### С с · эс

![[Resources/Audio/ru/Letters/019.mp3]]

### Т т · тэ

![[Resources/Audio/ru/Letters/020.mp3]]

### У у · у

![[Resources/Audio/ru/Letters/021.mp3]]

### Ф ф · эф

![[Resources/Audio/ru/Letters/022.mp3]]

### Х х · ха

![[Resources/Audio/ru/Letters/023.mp3]]

### Ц ц · цэ

![[Resources/Audio/ru/Letters/024.mp3]]

### Ч ч · че

![[Resources/Audio/ru/Letters/025.mp3]]

### Ш ш · ша

![[Resources/Audio/ru/Letters/026.mp3]]

### Щ щ · ща

![[Resources/Audio/ru/Letters/027.mp3]]

### Ъ ъ · твёрдый знак

![[Resources/Audio/ru/Letters/028.mp3]]

### Ы ы · ы

![[Resources/Audio/ru/Letters/029.mp3]]

### Ь ь · мягкий знак

![[Resources/Audio/ru/Letters/030.mp3]]

### Э э · э

![[Resources/Audio/ru/Letters/031.mp3]]

### Ю ю · ю

![[Resources/Audio/ru/Letters/032.mp3]]

### Я я · я

![[Resources/Audio/ru/Letters/033.mp3]]
<!-- /individual-letter-audio -->
