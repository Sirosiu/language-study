# German study

[[German|Open the complete German course note]]

Audio and the printable PDF are in Resources. This vault contains one language.

[[Sources and licenses]]
