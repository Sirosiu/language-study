# German

Near-native ambition - C2-oriented study

Everything for this language is in this note. Open a rule, read its examples and follow its practice link. Answers stay in this same note.

[[Start Here|All languages]] · [[Sources and licenses|Sources]]

## Start reading

### das Alphabet

| Written form | Name / reading | Related forms |
|---|---|---|
| A a | a  |  ·  ·  |
| B b | be  |  ·  ·  |
| C c | ce  |  ·  ·  |
| D d | de  |  ·  ·  |
| E e | e  |  ·  ·  |
| F f | ef  |  ·  ·  |
| G g | ge  |  ·  ·  |
| H h | ha  |  ·  ·  |
| I i | i  |  ·  ·  |
| J j | jot  |  ·  ·  |
| K k | ka  |  ·  ·  |
| L l | el  |  ·  ·  |
| M m | em  |  ·  ·  |
| N n | en  |  ·  ·  |
| O o | o  |  ·  ·  |
| P p | pe  |  ·  ·  |
| Q q | ku  |  ·  ·  |
| R r | er  |  ·  ·  |
| S s | es  |  ·  ·  |
| T t | te  |  ·  ·  |
| U u | u  |  ·  ·  |
| V v | fau  |  ·  ·  |
| W w | we  |  ·  ·  |
| X x | iks  |  ·  ·  |
| Y y | ypsilon  |  ·  ·  |
| Z z | zett  |  ·  ·  |
| Ä ä | ä  |  ·  ·  |
| Ö ö | ö  |  ·  ·  |
| Ü ü | ü  |  ·  ·  |
| ẞ ß | Eszett (scharfes S)  |  ·  ·  |

![[Resources/Audio/de/Script and first phrases.mp3]]

The player above is synthetic speech. Word tracks below work offline.

### Read letters, then sounds

The core alphabet has 26 letters. Ä, Ö and Ü are umlaut letters; ß is an additional character. Letter names are for spelling aloud. In words, J usually sounds like English y, W like English v, V often like f, and Z like /ts/. Learn each noun with its article and plural: das Buch, die Bücher.

### Vowels and combinations

Long and short vowels can distinguish words. ie usually represents long /iː/; ei sounds like English eye; eu and äu like the vowel in boy. sch is /ʃ/. After a, o, u, ch is the back sound /x/; after front vowels it is often /ç/. Round the lips while saying e for ö and i for ü; an English spelling approximation cannot replace hearing them.

### Spelling habits

Nouns start with a capital letter. Double consonants often signal a preceding short vowel. ß generally follows a long vowel or diphthong; ss generally follows a short vowel. In Switzerland, ss replaces ß. Stress is often early, but borrowed words and prefixes can change it.

### Build a compound

Haus + Tür → Haustür = front door. The last noun is the head and determines gender: die Tür → die Haustür. Some compounds need linking material: Arbeit + s + Zimmer → Arbeitszimmer.

### Build a derived word

freundlich = friendly; unfreundlich = unfriendly; Freundlichkeit = friendliness. Record the suffix with its meaning and word class: -keit usually makes a feminine noun.

### Build a sentence

Ich lerne Deutsch. = I am learning German. Heute lerne ich Deutsch. = Today I am learning German. A first-position time expression does not move the finite verb out of second position.

**Guten Tag.**

Hello / good day.

**Ich lerne Deutsch.**

I am learning German.

**Könnten Sie das bitte wiederholen?**

Could you repeat that, please?

**Was bedeutet dieses Wort?**

What does this word mean?

### Grammar terms in plain English

**Noun** — A word naming a person, thing or idea: student, book, freedom.

**Verb** — A word describing an action or state: read, know, be.

**Subject** — The participant linked to the main verb’s subject pattern. In The student reads a book, the student is the subject.

**Object** — A participant selected by a verb. In The student reads a book, a book is the direct object.

**Agreement** — One word changes to match another, for example an adjective matching a noun’s gender and number.

**Case** — A noun/pronoun form marking its relationship in a sentence. Cases can mark subjects, objects, possession or relations usually expressed by English prepositions.

**Gender** — A grammatical noun class. It does not always describe the sex of a person or any physical property.

**Tense** — A verb system that relates a situation to a time, often past or non-past.

**Aspect** — How a situation is viewed: unfolding, completed, habitual, experienced or in a resulting state.

**Infinitive** — A non-finite verb form often used for a dictionary entry or a complement. It does not by itself give the ordinary person/tense pattern.

**Participle** — A verb-derived form used in compound predicates or as a modifier; its exact function depends on the language and construction.

**Clause** — A unit organised around a predicate. One sentence can contain several clauses.

**Register** — Language choices suited to a situation: casual conversation, polite requests, academic writing or another context.

## Grammar, examples and practice

### Sounds, spelling and noun inventory

German vowel length can distinguish words, and umlauts are separate vowel qualities rather than decorative marks. Learn /y/ for ü and /ø/ or /œ/ for ö by rounding the lips while keeping a front-vowel tongue position. The ich-Laut /ç/ and ach-Laut /x/ occur in different environments, with regional variation. Final obstruent devoicing means written d, b and g can be pronounced like their voiceless partners at the end of a syllable.
Nouns are capitalised. Learn der Tisch, die Tische; die Frage, die Fragen; das Buch, die Bücher. Gender is partly predictable from suffixes, such as feminine -ung and neuter -chen, but semantic gender and grammatical gender are not identical. Plural patterns require lexical learning. Do not infer a noun's gender from its English translation.

**die Entscheidung, die Entscheidungen**

decision, decisions -ung is a productive feminine noun ending.

**das Mädchen, die Mädchen**

girl, girls -chen makes the grammatical gender neuter; the plural is unchanged.

<details><summary>What information belongs on a German noun card?</summary>

Article, singular, plural, meaning and one useful collocation. Include relevant pronunciation if spelling is misleading.

</details>

<details><summary>Why is das Mädchen grammatically possible?</summary>

The diminutive suffix -chen determines neuter gender, independently of the person's natural gender.

</details>

### Cases and determiners

German cases show grammatical relationships. Nominative normally marks the subject; accusative many direct objects; dative many indirect objects and prepositional complements; genitive possession or other formal relationships. Verb and preposition government must be learned: helfen takes dative; sehen normally takes accusative. Masculine singular articles show der, den, dem, des. Feminine: die, die, der, der. Neuter: das, das, dem, des. Plural: die, die, den, der; dative plural often adds -n to the noun where possible.
With two-way prepositions such as in, an and auf, accusative marks a directed change into a spatial relation, dative a location within it. Movement alone is not the deciding test: Ich laufe im Park describes running inside the park with dative. Other prepositions have fixed case: mit, nach, bei, seit, von, zu with dative; durch, für, gegen, ohne, um with accusative.

**Ich lege das Buch auf den Tisch.**

I put the book onto the table. Accusative marks the directed placement.

**Das Buch liegt auf dem Tisch.**

The book lies on the table. Dative marks the location.

#### Articles in context

A German article marks gender, number and case together. Die can be feminine singular or plural; der can occur in several case/gender combinations. Identify the noun and its sentence role before choosing an ending.

**Zwingen Sie mich nicht, das zu essen!**

Don't make me eat this.

**Der Vater geht im Park spazieren.**

My father is taking a walk in the park.

![[Resources/Audio/de/Rule 01.mp3]]

[[German#^de-Q0001|Practise this rule (50 questions)]]

#### Indefinite articles

Ein introduces an indefinite singular noun. Its endings depend on gender and case; some forms have no overt ending. There is no ordinary plural ein article. Learn a noun together with gender and plural.

**Japaner und Briten warten an Bushaltestellen normalerweise in einer Schlange.**

Japanese and British people usually wait at a bus stop in a queue.

**Ich bin es gewohnt, einen Lastwagen zu fahren.**

I am used to driving a truck.

![[Resources/Audio/de/Rule 02.mp3]]

[[German#^de-Q0051|Practise this rule (50 questions)]]

#### Personal pronoun forms

Pronouns change form with their grammatical role. Ich is nominative, mich accusative, mir dative. Sie can mean she, they or polite you; spelling and context distinguish the uses.

**Hast du Vorsätze fürs neue Jahr?**

Have you made any New Year's resolutions?

**Tom gab seinen Freunden gegenüber damit an, mit wie vielen Mädchen er schon geschlafen habe.**

Tom bragged to his friends about all the girls he had slept with.

![[Resources/Audio/de/Rule 03.mp3]]

[[German#^de-Q0101|Practise this rule (50 questions)]]

#### Prepositions with case

Mit, bei, nach, seit, von, zu and aus normally govern dative. Für, ohne and durch normally govern accusative. A preposition selects the case of its complement, not the case of every noun nearby.

**Tom wusste von nichts.**

Tom knew nothing.

**Ich verspreche, von nun an nett zu euch zu sein.**

I promise I'll be nice to you from now on.

![[Resources/Audio/de/Rule 11.mp3]]

[[German#^de-Q0501|Practise this rule (50 questions)]]

#### Two-way prepositions

Many spatial uses take dative for location and accusative for a destination or change of spatial relation. The distinction is not simply movement versus no movement. A movement within a location can still take dative.

**Schauen Sie sich diese Fische im Teich an.**

Look at those fish in the pond.

**Tom sollte in Kürze hier sein.**

Tom should be here shortly.

![[Resources/Audio/de/Rule 12.mp3]]

[[German#^de-Q0551|Practise this rule (50 questions)]]

<details><summary>Choose: Ich helfe der / die Kollegin.</summary>

Der Kollegin. Helfen governs dative, and feminine dative singular is der.

</details>

<details><summary>Why is Ich laufe im Park dative although running is movement?</summary>

The action occurs within an existing location. The sentence does not express a change into that spatial relation.

</details>

### Adjective endings and noun phrases

Adjective endings distribute grammatical information across the noun phrase. After a definite article, the article usually carries the strongest case/gender marking, leaving the adjective with -e or -en. After ein, the adjective must sometimes supply a missing ending: ein guter Plan, ein gutes Buch. Without an article, the adjective normally carries a strong ending: mit gutem Grund.
Read phrases as systems rather than memorising an isolated ending. Der gute Plan is nominative masculine; den guten Plan is accusative masculine; mit einem guten Plan is dative. Nominalised adjectives retain adjectival inflection: etwas Neues, die Verantwortlichen. Long formal noun phrases can contain multiple modifiers, so identify the head noun before interpreting the whole phrase.

**mit einem klaren Ziel**

with a clear goal Mit requires dative; einem marks neuter dative; klaren uses -en.

**ein überzeugendes Ergebnis**

a convincing result The adjective supplies neuter nominative/accusative -es after ein.

#### Adjectives in noun phrases

Attributive adjectives take endings after the determiner. Compare ein gutes Buch, das gute Buch and mit einem guten Buch. Predicative adjectives normally stay uninflected: Das Buch ist gut.

**Tom verglich ein drei Jahre altes Foto von Mary mit einem aktuellen.**

Tom compared a picture taken of Mary three years ago with one that had been taken recently.

**Zuerst fiel mir das große Sofa auf. Der Lederbezug war in einem schlichten Farbton gehalten, die Sitzfläche und Rückenlehne sahen bequem aus.**

The first thing that came to my attention was the large sofa. It was covered in sober coloured leather, the seat and the back both looked wide and comfortable.

![[Resources/Audio/de/Rule 04.mp3]]

[[German#^de-Q0151|Practise this rule (50 questions)]]

<details><summary>Complete: wegen des neu__ Gesetzes.</summary>

Wegen des neuen Gesetzes. After des, the adjective takes -en; Gesetz has genitive -es.

</details>

<details><summary>Explain etwas Wichtiges.</summary>

Wichtig is nominalised after etwas and receives the appropriate strong ending; the noun-like adjective is capitalised.

</details>

### Verb position and clause architecture

In a declarative main clause, the finite verb occupies the second constituent position, not necessarily the second word. Heute beginnt die Sitzung; Die Sitzung beginnt heute. A fronted multiword phrase still counts as one constituent. Yes/no questions commonly place the finite verb first. In many subordinate clauses introduced by weil, dass or obwohl, the finite verb appears at the end.
The sentence bracket separates the finite verb from an infinitive, participle or separable prefix: Wir haben den Bericht geprüft; Wir rufen morgen an. Formal verb clusters with modals and perfect tense require additional study, including the replacement infinitive. Do not apply an English subject-verb-object template inside every German clause. Identify the finite verb and clause boundary before translating.

**Obwohl die Daten unvollständig sind, beginnt die Prüfung.**

Although the data are incomplete, the review begins. The subordinate clause occupies the first main-clause constituent; beginnt remains second.

**Wir müssen den Bericht sorgfältig prüfen.**

We must examine the report carefully. Finite modal in second position; lexical infinitive closes the bracket.

#### Present forms of sein

Sein is irregular: ich bin, du bist, er/sie/es ist, wir/sie sind, ihr seid. A finite verb agrees with the subject. In a main statement it normally occupies the second constituent position.

**Warum sind einige Übersetzungen ausgegraut?**

Why are some translations in grey?

**Tom ist faul.**

Tom is lazy.

![[Resources/Audio/de/Rule 05.mp3]]

[[German#^de-Q0201|Practise this rule (50 questions)]]

#### Present forms of haben

Haben can express possession or serve as a perfect auxiliary. Identify whether a participle is also present. The finite form agrees with the subject even when an infinitive or participle stands later.

**Wie viele Bundesstaaten hat Indien?**

How many states does India have?

**Ich habe nicht viel Geld auf meinem Konto.**

I don't have much money in my bank account.

![[Resources/Audio/de/Rule 06.mp3]]

[[German#^de-Q0251|Practise this rule (50 questions)]]

#### Negation with nicht and kein

Kein negates many indefinite noun phrases; nicht negates a predicate or another constituent. Placement controls scope. Compare Ich kaufe kein Buch with Ich kaufe das Buch nicht.

**Tom konnte sich nicht vorstellen, jemanden zu erschießen.**

Tom couldn't imagine himself shooting anyone.

**Tom konnte nicht alle Fragen Marias beantworten.**

Tom couldn't answer all of Mary's questions.

![[Resources/Audio/de/Rule 08.mp3]]

[[German#^de-Q0351|Practise this rule (50 questions)]]

#### Subordinate clause connectors

A subordinating connector introduces a clause whose finite verb normally comes at the end. Ob introduces an indirect yes/no question. Wenn and als differ in temporal uses; als normally locates a single past occasion.

**Du wusstest, dass da passieren wird, stimmt's?**

You knew this was going to happen, right?

**Tom kam gerade, als ich ging.**

Tom came just as I was leaving.

![[Resources/Audio/de/Rule 09.mp3]]

[[German#^de-Q0401|Practise this rule (50 questions)]]

#### Coordinating connectors

Coordinating connectors do not impose subordinate verb-final order. Sondern corrects a preceding negated alternative. Denn gives a reason with main-clause order.

**Tom und Maria liefen ins Wasser.**

Tom and Mary ran into the water.

**Das Mädchen wurde abgelenkt und verlor ihre Eltern aus den Augen.**

The girl got distracted and lost sight of her parents.

![[Resources/Audio/de/Rule 10.mp3]]

[[German#^de-Q0451|Practise this rule (50 questions)]]

<details><summary>Reorder: Morgen / wir / beginnen / mit der Arbeit.</summary>

Morgen beginnen wir mit der Arbeit. Fronted morgen is followed by the finite verb.

</details>

<details><summary>Combine using weil: Ich bleibe. Ich brauche weitere Informationen.</summary>

Ich bleibe, weil ich weitere Informationen brauche. Brauche closes the subordinate clause.

</details>

### Tense, passive and reported speech

German conversational narration often uses Perfekt, while written narration often favours Präteritum; sein, haben and modal verbs commonly use Präteritum in speech too. These are tendencies, not rigid genre bans. Future meaning frequently uses present tense with a time expression. Futur I can also express an inference.
The event passive uses werden + past participle: Der Bericht wird geprüft. The state passive uses sein: Der Bericht ist geprüft. In the perfect event passive, worden differs from the ordinary geworden. Konjunktiv I can mark reported speech without committing the writer to its truth: Sie erklärt, die Daten seien vollständig. Where forms are ambiguous, Konjunktiv II or other reporting strategies can help; the register and context matter.

**Die Daten werden geprüft / Die Daten sind geprüft.**

The data are being checked / The data have the status of being checked. Process passive contrasts with a resulting state.

**Der Autor schreibt, das Ergebnis sei vorläufig.**

The author writes that the result is provisional. Sei is Konjunktiv I of sein and marks reported speech.

#### Past forms of sein and haben

War and hatte are past forms of sein and haben. They occur frequently in spoken as well as written German. They also help construct pluperfect forms when a past participle follows.

**Wie waren eure letzten Prüfungen?**

How were your last exams?

**Das war äußerst lustig.**

It was extremely funny.

![[Resources/Audio/de/Rule 13.mp3]]

[[German#^de-Q0601|Practise this rule (50 questions)]]

#### Participles in context

A past participle can occur in a perfect, passive or adjective phrase. The auxiliary and context determine the construction. Gehen often forms its perfect with sein; many transitive verbs use haben.

**Weißt du, wie beschäftigt ich gewesen bin?**

Do you know how busy I've been?

**Wer hat es ihm gesagt? Nicht vielleicht du?**

Who told him? Not you, perhaps?

![[Resources/Audio/de/Rule 14.mp3]]

[[German#^de-Q0651|Practise this rule (50 questions)]]

#### Werden: future and passive

Werden plus infinitive can mark future or prediction; werden plus past participle can mark an event passive. The form alone is not enough: inspect the later verb and the whole meaning.

**Langsam werde ich neidisch.**

I'm beginning to get jealous.

**Tom wird Vater sein.**

Tom is going to be a father.

![[Resources/Audio/de/Rule 15.mp3]]

[[German#^de-Q0701|Practise this rule (50 questions)]]

<details><summary>Make a passive: Das Team prüft den Bericht.</summary>

Der Bericht wird vom Team geprüft. The former object becomes the subject.

</details>

<details><summary>Report without endorsing: Sie sagt: Ich habe keine Fehler gefunden.</summary>

Sie sagt, sie habe keine Fehler gefunden. Habe marks indirect report; it does not independently verify the claim.

</details>

### Conditionals, modality and polite disagreement

Konjunktiv II expresses irreality, hypothetical reasoning and politeness. Wäre, hätte and könnte are central forms. Würde + infinitive is common but should not displace every established simple form. Past counterfactuals combine hätte or wäre with the participle: Wenn ich das gewusst hätte, wäre ich geblieben.
Modal particles such as doch, ja, eben and wohl shape interpersonal meaning and inference. Their translation depends on context; do not assign one English equivalent to each. Das ist ja interessant may signal a reaction to newly encountered information, not simply yes. For professional disagreement, give the point of agreement and the precise reservation before proposing a change.

**Könnten Sie erläutern, wie dieser Wert berechnet wurde?**

Could you explain how this value was calculated? Konjunktiv II softens the request; the embedded clause is verb-final.

**Wenn die Stichprobe größer gewesen wäre, hätten wir präzisere Schätzungen erhalten.**

If the sample had been larger, we would have obtained more precise estimates. Past counterfactual; the conclusion remains hypothetical.

#### Modal verbs

Modals express ability, necessity, permission, reported obligation or intention. A following ordinary infinitive normally has no zu and goes late in the clause. Nicht müssen means lack of necessity; nicht dürfen means prohibition.

**Tom will sich entschuldigen.**

Tom is going to apologize.

**In diesem Buch steht, dass Elefanten über hundert Jahre alt werden können.**

This book says that elephants live to be over 100 years old.

![[Resources/Audio/de/Rule 07.mp3]]

[[German#^de-Q0301|Practise this rule (50 questions)]]

#### Conditional and polite forms

Konjunktiv II marks hypothetical meaning and polite distance. Würde often combines with an infinitive; wäre and hätte are common direct forms. A hypothetical past uses hätte/wäre plus participle.

**Sie sagte, sie würde im nächsten Monat sechzehn.**

She said she would be sixteen next month.

**Könnten Sie das noch einmal erklären?**

Would you explain it again?

![[Resources/Audio/de/Rule 16.mp3]]

[[German#^de-Q0751|Practise this rule (50 questions)]]

#### Comparison and quantity

Comparatives normally use als, while equal comparison uses so ... wie. Mehr and weniger do not take the ordinary attributive adjective endings. Viel/viele distinguish some uncountable and countable uses.

**Wie viele Instrumente kannst du spielen?**

How many instruments do you know how to play?

**Tom hat nicht sehr viel geholfen.**

Tom didn't help much.

![[Resources/Audio/de/Rule 19.mp3]]

[[German#^de-Q0901|Practise this rule (50 questions)]]

<details><summary>Write a polite request with könnte.</summary>

Könnten Sie mir bitte die Unterlagen schicken? A conventional concise request; other phrasings are valid.

</details>

<details><summary>What does wohl do in Das wird wohl stimmen?</summary>

It commonly marks a tentative inference: that is probably correct. Context can change the nuance.

</details>

### Relative clauses and compressed academic prose

A relative pronoun agrees in gender and number with its antecedent, but its case comes from its role inside the relative clause. Der Bericht, den ich gelesen habe uses accusative den because the pronoun is the object of gelesen. Die Person, mit der ich gesprochen habe uses dative after mit. Do not choose case from the antecedent's role in the main clause.
Formal German often compresses information into participial noun modifiers: die unter bestimmten Bedingungen erhobenen Daten. Expand the phrase into a relative clause to check understanding. Nominalisation can make prose compact but conceal agents or temporal relationships. Identify compounds from the rightmost head: Forschungsfrage is a kind of Frage, not a kind of Forschung.

**die unter kontrollierten Bedingungen erhobenen Daten**

the data collected under controlled conditions The participial modifier precedes the noun; erhoben is the past participle of erheben.

**Die Methode, deren Grenzen bekannt sind, wurde angepasst.**

The method whose limitations are known was adapted. Deren marks the genitive relationship inside the relative clause.

#### Relative words

A relative pronoun relates a clause to an antecedent. Its gender and number follow the antecedent, but its case follows its role inside the relative clause. The relative clause normally has verb-final order.

**Es lebe die Republik!**

Long live the Republic!

**Du solltest die Menschen respektvoller behandeln.**

You should treat people with more respect.

![[Resources/Audio/de/Rule 17.mp3]]

[[German#^de-Q0801|Practise this rule (50 questions)]]

#### Infinitives with zu

Many infinitive complements use zu. Um ... zu expresses purpose when the understood subject fits. Zu can also be a preposition, so check whether a verb infinitive is present before analysing it as an infinitive marker.

**John ist zu dick, um schnell zu rennen.**

John is too fat to run fast.

**Wir haben unser Leben zu leben.**

We have our lives to live.

![[Resources/Audio/de/Rule 18.mp3]]

[[German#^de-Q0851|Practise this rule (50 questions)]]

<details><summary>Expand die gestern veröffentlichten Ergebnisse.</summary>

Die Ergebnisse, die gestern veröffentlicht wurden. A relative clause makes the passive event explicit.

</details>

<details><summary>Choose: Der Kollege, dem / den ich vertraue.</summary>

Dem. Vertrauen governs dative inside the relative clause.

</details>

### Argument, register and advanced reading

Distinguish daher for consequence, dennoch for concession, hingegen for contrast and insofern for a limited respect or conditional relationship. Technical nouns need conventional collocations: eine Hypothese aufstellen, eine Entscheidung treffen, eine Untersuchung durchführen. Neutral standard writing differs from colloquial regional speech; both deserve exposure.
Original teaching passage: Eine Erklärung kann plausibel sein, ohne dass sie durch die verfügbaren Daten eindeutig bestätigt wird. Entscheidend ist daher nicht nur, ob eine Hypothese zu den Beobachtungen passt, sondern auch, welche alternativen Erklärungen ausgeschlossen werden können. Je genauer die Voraussetzungen beschrieben werden, desto leichter lässt sich beurteilen, wie weit die Ergebnisse verallgemeinert werden dürfen.
The passage separates plausibility from evidential confirmation, then limits generalisation. Je ... desto expresses a proportional comparison. Dürfen here concerns what inference is warranted, not an ordinary permission request.

**Je genauer die Voraussetzungen beschrieben werden, desto leichter lässt sich die Aussage beurteilen.**

The more precisely the assumptions are described, the easier the claim is to assess. Paired comparative structure plus lässt sich + infinitive for assessability.

**Die Befunde deuten auf einen Zusammenhang hin.**

The findings suggest an association. Hindeuten auf is weaker than proving a causal relation.

#### Concession and argument

Obwohl introduces a subordinate concession. Trotzdem, deshalb and jedoch can link main clauses as adverbials, so they interact with verb-second order. Distinguish concession from consequence in the translation.

**Du bist ein Hornochse, aber ich liebe dich trotzdem.**

You're an idiot, but I still love you.

**Ich besitze keinen CD-Spieler, aber ich habe die CD trotzdem gekauft.**

I don't have a CD player, but I bought the CD anyway.

![[Resources/Audio/de/Rule 20.mp3]]

[[German#^de-Q0951|Practise this rule (50 questions)]]

<details><summary>Translate the main caution in the passage.</summary>

A plausible explanation is not necessarily unambiguously confirmed by the available evidence. Alternative explanations and scope must be assessed.

</details>

<details><summary>Write a 120-word critique using dennoch and hingegen.</summary>

Check connector logic, verb-second main clauses, accurate cases and a distinction between evidence and interpretation. Use the revision rubric in the study guide.

</details>

## Word bank and recordings

1,000 study entries, based on dictionary selections and authored teaching glosses. Learn a word in a phrase; consult the linked entry for additional senses.

<details><summary>Words 1–50</summary>

![[Resources/Audio/de/Words 0001-0050.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [der](https://en.wiktionary.org/wiki/der#German) | the (masculine nominative); other case forms and relative uses | /deːr/ · article |
| [und](https://en.wiktionary.org/wiki/und#German) | and | /ʊnt/ · conj |
| [in](https://en.wiktionary.org/wiki/in#German) | [with dative] in, inside, within, at (inside a building) | /ʔɪn/ · prep |
| [das](https://en.wiktionary.org/wiki/das#German) | the (neuter singular); that/which in other uses | /das/ · article |
| [Wortschatz](https://en.wiktionary.org/wiki/Wortschatz) | vocabulary |  · noun |
| [ich](https://en.wiktionary.org/wiki/ich#German) | I (first person singular nominative (subject) pronoun) | /ɪç/ · pron |
| [nicht](https://en.wiktionary.org/wiki/nicht#German) | not, non- (negates the meaning of a verb, adjective, or adverb) | /nɪçt/ · adv |
| [zu](https://en.wiktionary.org/wiki/zu#German) | to; too before an adjective | /t͡suː/ · prep |
| [den](https://en.wiktionary.org/wiki/den#German) | that; whom; accusative masculine singular of der | /de(ː)n/ · pron |
| [von](https://en.wiktionary.org/wiki/von#German) | from | /fɔn/ · prep |
| [mit](https://en.wiktionary.org/wiki/mit#German) | with (in the company of, alongside) | /mɪt/ · prep |
| [Es](https://en.wiktionary.org/wiki/Es#German) | E-flat | /ɛs/ · noun |
| [es](https://en.wiktionary.org/wiki/es#German) | it, they | /ɛs/ · pron |
| [ein](https://en.wiktionary.org/wiki/ein#German) | a/an (masculine or neuter); one | /aɪ̯n/ · det |
| [auf](https://en.wiktionary.org/wiki/auf#German) | [with dative] on, upon (positioned at the top of) | /aʊ̯f/ · prep |
| [sie](https://en.wiktionary.org/wiki/sie#German) | she; her | /ziː/ · pron |
| [Des](https://en.wiktionary.org/wiki/Des#German) | D-flat |  · noun |
| [Er](https://en.wiktionary.org/wiki/Er#German) | a person or animal of male gender, a male | /eːɐ̯/ · noun |
| [als](https://en.wiktionary.org/wiki/als#German) | at (approximately) the same moment, when, while, as | /als/ · conj |
| [er](https://en.wiktionary.org/wiki/er#German) | he | /eːr/ · pron |
| [an](https://en.wiktionary.org/wiki/an#German) | on, upon, at, in, against | /an/ · prep |
| [dass](https://en.wiktionary.org/wiki/dass#German) | that | /das/ · conj |
| [so](https://en.wiktionary.org/wiki/so#German) | so, such, that | /zoː/ · adv |
| [bei](https://en.wiktionary.org/wiki/bei#German) | by, near | /baɪ̯/ · prep |
| [wie](https://en.wiktionary.org/wiki/wie#German) | how | /viː/ · adv |
| [Aber](https://en.wiktionary.org/wiki/Aber#German) | an objection, a but | /ˈaːbɐ/ · noun |
| [aber](https://en.wiktionary.org/wiki/aber#German) | but; however; though | /ˈaːbɐ/ · conj |
| [Aus](https://en.wiktionary.org/wiki/Aus#German) | an out; the end of play for an individual or a team |  · noun |
| [aus](https://en.wiktionary.org/wiki/aus#German) | out | /aʊ̯s/ · adv |
| [nach](https://en.wiktionary.org/wiki/nach#German) | after, past (later in time) | /naːx/ · prep |
| [wir](https://en.wiktionary.org/wiki/wir#German) | we | /viːɐ̯/ · pron |
| [Du](https://en.wiktionary.org/wiki/Du#German) | the thou, the you (singular) |  · noun |
| [du](https://en.wiktionary.org/wiki/du#German) | you (singular familiar), thou | /duː/ · pron |
| [nur](https://en.wiktionary.org/wiki/nur#German) | only, just, merely, simply | /nuːɐ̯/ · adv |
| [was](https://en.wiktionary.org/wiki/was#German) | what | /vas/ · pron |
| [einen](https://en.wiktionary.org/wiki/einen#German) | to unite | /ˈaɪ̯nən/ · verb |
| [am](https://en.wiktionary.org/wiki/am#German) | Precedes the superlative in adverbial and predicate use. | /am/ · particle |
| [man](https://en.wiktionary.org/wiki/man#German) | one, you, they (indefinite pronoun, referring to people at large; construed as a third-person singular) | /man/ · pron |
| [um](https://en.wiktionary.org/wiki/um#German) | about | /ʊm/ · prep |
| [über](https://en.wiktionary.org/wiki/%C3%BCber#German) | [with accusative or dative] above, over (spatially) | /ˈyːbɐ/ · prep |
| [da](https://en.wiktionary.org/wiki/da#German) | there | /daː/ · adv |
| [Mehr](https://en.wiktionary.org/wiki/Mehr#German) | increase, excess |  · noun |
| [ja](https://en.wiktionary.org/wiki/ja#German) | obviously; certainly; of course; as you know; as is generally known (indicates and emphasises that one is expressing an established fact) | [jäː] · adv |
| [mehr](https://en.wiktionary.org/wiki/mehr#German) | something more | /meːr/ · pron |
| [sein](https://en.wiktionary.org/wiki/sein#German) | forms the present perfect and past perfect tenses of certain verbs | /zaɪ̯n/ · verb |
| [vor](https://en.wiktionary.org/wiki/vor#German) | in front of, ahead of (relative location in space) | /foːr/ · prep |
| [Mal](https://en.wiktionary.org/wiki/Mal#German) | time (as in the first time; many times) | /maːl/ · noun |
| [mal](https://en.wiktionary.org/wiki/mal#German) | times (indicating multiplication of two numbers) | /maːl/ · adv |
| [hier](https://en.wiktionary.org/wiki/hier#German) | here; in this place; refers to an environment one is currently in, or to something within reach | /hiːr/ · adv |
| [bis](https://en.wiktionary.org/wiki/bis#German) | until | /bɪs/ · conj |

</details>

<details><summary>Words 51–100</summary>

![[Resources/Audio/de/Words 0051-0100.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [Ihr](https://en.wiktionary.org/wiki/Ihr#German) | your (that belongs to you (when formally or politely addressing one or more people)) | /ʔiːɐ̯/ · det |
| [ihr](https://en.wiktionary.org/wiki/ihr#German) | you, ye (plural, familiar) | /iːr/ · pron |
| [alle](https://en.wiktionary.org/wiki/alle#German) | finished; gone | /ˈalə/ · adj |
| [unter](https://en.wiktionary.org/wiki/unter#German) | under | /ˈʊntɐ/ · prep |
| [Gut](https://en.wiktionary.org/wiki/Gut#German) | property, possession, good, chattel | /ɡuːt/ · noun |
| [gut](https://en.wiktionary.org/wiki/gut#German) | good (acting in the interest of what is beneficial, ethical, or moral) | /ɡuːt/ · adj |
| [also](https://en.wiktionary.org/wiki/also#German) | so, therefore | /ˈʔalzoː/ · conj |
| [Zeit](https://en.wiktionary.org/wiki/Zeit#German) | time (as a concept) | [t͡saɪ̯t] · noun |
| [ab](https://en.wiktionary.org/wiki/ab#German) | beginning at that time or location; from | /ap/ · prep |
| [ganz](https://en.wiktionary.org/wiki/ganz#German) | entire, whole, complete | /ɡan(t)s/ · adj |
| [denn](https://en.wiktionary.org/wiki/denn#German) | for; because; since | /dɛn/ · conj |
| [ohne](https://en.wiktionary.org/wiki/ohne#German) | without | /ˈoːnə/ · conj |
| [etwas](https://en.wiktionary.org/wiki/etwas#German) | something | /ˈɛtvas/ · pron |
| [zwei](https://en.wiktionary.org/wiki/zwei#German) | two (numerical value represented by the Arabic numeral 2; or describing a set with two components) | /t͡svaɪ̯/ · num |
| [seit](https://en.wiktionary.org/wiki/seit#German) | since | /zaɪ̯t/ · conj |
| [wo](https://en.wiktionary.org/wiki/wo#German) | where (at what place) | /voː/ · adv |
| [nichts](https://en.wiktionary.org/wiki/nichts#German) | nothing | [nɪçt͡s] · pron |
| [nun](https://en.wiktionary.org/wiki/nun#German) | now, at this moment | /nuːn/ · adv |
| [gut durch](https://en.wiktionary.org/wiki/gut%20durch#German) | well done |  · adj |
| [über alles](https://en.wiktionary.org/wiki/%C3%BCber%20alles#German) | above all |  · adv |
| [wer](https://en.wiktionary.org/wiki/wer#German) | who (what person or people) | /veːr/ · pron |
| [ob](https://en.wiktionary.org/wiki/ob#German) | Introduces an indirect question, a doubt. if, whether. | /ɔp/ · conj |
| [zwischen](https://en.wiktionary.org/wiki/zwischen#German) | between | /ˈtsvɪʃən/ · prep |
| [A](https://en.wiktionary.org/wiki/A#German) | A | /ʔaː/ · noun |
| [dort](https://en.wiktionary.org/wiki/dort#German) | there, yonder | /dɔʁt/ · adv |
| [Hast](https://en.wiktionary.org/wiki/Hast#German) | haste | /hast/ · noun |
| [warum](https://en.wiktionary.org/wiki/warum#German) | why; for what reason | /vaˈʁʊm/ · adv |
| [weiß](https://en.wiktionary.org/wiki/wei%C3%9F#German) | white | /vaɪ̯s/ · adj |
| [Mann](https://en.wiktionary.org/wiki/Mann#German) | man, male human being | /man/ · noun |
| [Drei](https://en.wiktionary.org/wiki/Drei#German) | three (digit/figure 3) | /ˈdʁaɪ̯/ · noun |
| [drei](https://en.wiktionary.org/wiki/drei#German) | three (numerical value represented by the Arabic numeral 3; or describing a set with three elements) | /dʁaɪ̯/ · num |
| [kommen](https://en.wiktionary.org/wiki/kommen#German) | to come; to arrive | /ˈkɔmən/ · verb |
| [Bitte](https://en.wiktionary.org/wiki/Bitte#German) | request, plea | /ˈbɪtə/ · noun |
| [bitte](https://en.wiktionary.org/wiki/bitte#German) | please, if you please (used to make a polite request or affirm an offer) | /ˈbɪtə/ · adv |
| [sehen](https://en.wiktionary.org/wiki/sehen#German) | to see; to have sight | /ˈzeː.ən/ · verb |
| [Uhr](https://en.wiktionary.org/wiki/Uhr#German) | hours, o'clock (indicates the time within a twelve- or twenty-four-hour period) | /uːr/ · noun |
| [bereits](https://en.wiktionary.org/wiki/bereits#German) | already | [bəˈʁaɪ̯ts] · adv |
| [nie](https://en.wiktionary.org/wiki/nie#German) | never, never at all (referring to an indefinite period of time) | /niː/ · adv |
| [weg](https://en.wiktionary.org/wiki/weg#German) | away | /vɛk/ · adv |
| [Frau](https://en.wiktionary.org/wiki/Frau#German) | woman (adult female human) | /fʁaʊ̯/ · noun |
| [Stadt](https://en.wiktionary.org/wiki/Stadt#German) | city (a large settlement) | /ʃtat/ · noun |
| [Welt](https://en.wiktionary.org/wiki/Welt#German) | world | /vɛlt/ · noun |
| [D](https://en.wiktionary.org/wiki/D#German) | D | /deː/ · noun |
| [gehen](https://en.wiktionary.org/wiki/gehen#German) | to go, to walk | /ˈɡeːən/ · verb |
| [danke](https://en.wiktionary.org/wiki/danke#German) | thanks, thank you | [ˈdaŋkə] · intj |
| [gar](https://en.wiktionary.org/wiki/gar#German) | cooked, done (of food such as meat or vegetables: ready for consumption) | /ɡaːr/ · adj |
| [recht](https://en.wiktionary.org/wiki/recht#German) | right, right-hand (direction) | /ʁɛçt/ · adj |
| [M](https://en.wiktionary.org/wiki/M#German) | M | /ʔɛm/ · noun |
| [geben](https://en.wiktionary.org/wiki/geben#German) | to give (changing ownership) | [ˈɡeːb(ə)n] · verb |
| [Geld](https://en.wiktionary.org/wiki/Geld#German) | money | /ɡɛlt/ · noun |

</details>

<details><summary>Words 101–150</summary>

![[Resources/Audio/de/Words 0101-0150.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [gleich](https://en.wiktionary.org/wiki/gleich#German) | equal | /ɡlaɪ̯ç/ · adj |
| [davon](https://en.wiktionary.org/wiki/davon#German) | from it, from that, therefrom, off it, off that | /daˈfɔn/ · adv |
| [fast](https://en.wiktionary.org/wiki/fast#German) | almost; nearly | /fast/ · adv |
| [tun](https://en.wiktionary.org/wiki/tun#German) | to do (to perform or execute an action) | /tuːn/ · verb |
| [zurück](https://en.wiktionary.org/wiki/zur%C3%BCck#German) | back, backward, backwards, to the rear. | /t͡suˈʁʏk/ · adv |
| [jedoch](https://en.wiktionary.org/wiki/jedoch#German) | however, yet, nevertheless | /jeːˈdɔx/ · adv |
| [paar](https://en.wiktionary.org/wiki/paar#German) | some; few; a few | /paːr/ · det |
| [Fall](https://en.wiktionary.org/wiki/Fall#German) | fall, drop (the act of falling or an instance thereof) | /fal/ · noun |
| [I](https://en.wiktionary.org/wiki/I#German) | I | /iː/ · noun |
| [sicher](https://en.wiktionary.org/wiki/sicher#German) | safe, secure (not dangerous or in danger) | /ˈzɪçər/ · adj |
| [E](https://en.wiktionary.org/wiki/E#German) | E | /ʔeː/ · noun |
| [nein](https://en.wiktionary.org/wiki/nein#German) | no | /naɪ̯n/ · intj |
| [schön](https://en.wiktionary.org/wiki/sch%C3%B6n#German) | beautiful, lovely, pretty, handsome | /ʃøːn/ · adj |
| [Art](https://en.wiktionary.org/wiki/Art#German) | kind, sort, type | /aːrt/ · noun |
| [schnell](https://en.wiktionary.org/wiki/schnell#German) | quick, fast | /ʃnɛl/ · adj |
| [B](https://en.wiktionary.org/wiki/B#German) | B-flat | /beː/ · noun |
| [Liebe](https://en.wiktionary.org/wiki/Liebe#German) | love (tender feeling of affection) | /ˈliːbə/ · noun |
| [oft](https://en.wiktionary.org/wiki/oft#German) | often | /ɔft/ · adv |
| [Land](https://en.wiktionary.org/wiki/Land#German) | country (territory of a nation) | /lant/ · noun |
| [neben](https://en.wiktionary.org/wiki/neben#German) | next to, beside, alongside, adjacent to, near, near to | /ˈneːbən/ · prep |
| [dein](https://en.wiktionary.org/wiki/dein#German) | thy, your (esp. to friends, relatives, children, etc.). | /daɪ̯n/ · det |
| [besonders](https://en.wiktionary.org/wiki/besonders#German) | especially, particularly | [bəˈzɔndɐs] · adv |
| [ne](https://en.wiktionary.org/wiki/ne#German) | right?; is it?; is it not?; tag question | /nə/ · particle |
| [nehmen](https://en.wiktionary.org/wiki/nehmen#German) | to take (something into one's possession or on one's body) | /ˈneːmən/ · verb |
| [vier](https://en.wiktionary.org/wiki/vier#German) | four (numerical value represented by the Arabic numeral 4; or describing a set with four elements) | /fiːr/ · num |
| [kurz](https://en.wiktionary.org/wiki/kurz#German) | short, quick, brief | /kʊʁt͡s/ · adj |
| [Euro](https://en.wiktionary.org/wiki/Euro#German) | euro (currency) | /ˈɔʏ̯ro/ · noun |
| [spielen](https://en.wiktionary.org/wiki/spielen#German) | to play (engage in some activity for fun or entertainment) | /ˈʃpiːlən/ · verb |
| [C](https://en.wiktionary.org/wiki/C#German) | C | /tseː/ · noun |
| [Familie](https://en.wiktionary.org/wiki/Familie#German) | family | /faˈmiːli̯ə/ · noun |
| [Haus](https://en.wiktionary.org/wiki/Haus#German) | house, building | [haʊ̯s] · noun |
| [c.](https://en.wiktionary.org/wiki/c.#German) | circa |  · prep |
| [Bild](https://en.wiktionary.org/wiki/Bild#German) | digital photograph | /bɪlt/ · noun |
| [arbeiten](https://en.wiktionary.org/wiki/arbeiten#German) | to work (to do a specific task by employing physical or mental powers) | /ˈaʁbaɪ̯tən/ · verb |
| [je](https://en.wiktionary.org/wiki/je#German) | ever | /jeː/ · adv |
| [online](https://en.wiktionary.org/wiki/online#German) | online | /ˈɔnlaɪ̯n/ · adj |
| [Grund](https://en.wiktionary.org/wiki/Grund#German) | ground, land (usually as someone's property) | /ɡʁʊnt/ · noun |
| [Halt](https://en.wiktionary.org/wiki/Halt#German) | hold; adhesion | /halt/ · noun |
| [Nacht](https://en.wiktionary.org/wiki/Nacht#German) | night | /naxt/ · noun |
| [halt](https://en.wiktionary.org/wiki/halt#German) | stop!, wait! | /halt/ · intj |
| [neu](https://en.wiktionary.org/wiki/neu#German) | new | /nɔʏ̯/ · adj |
| [echt](https://en.wiktionary.org/wiki/echt#German) | authentic, genuine, true | /ɛçt/ · adj |
| [Essen](https://en.wiktionary.org/wiki/Essen#German) | meal | [ˈʔɛsn̩] · noun |
| [essen](https://en.wiktionary.org/wiki/essen#German) | to eat | /ˈɛsən/ · verb |
| [lang](https://en.wiktionary.org/wiki/lang#German) | long; lengthy (in space or time) | /laŋ(k)/ · adj |
| [Abend](https://en.wiktionary.org/wiki/Abend#German) | evening; the time from dusk until midnight | /ˈaːbənt/ · noun |
| [Dank](https://en.wiktionary.org/wiki/Dank#German) | thanks, gratitude, appreciation | /daŋk/ · noun |
| [H](https://en.wiktionary.org/wiki/H#German) | H | /h/ · noun |
| [Wasser](https://en.wiktionary.org/wiki/Wasser#German) | water (H₂O) | /ˈvasər/ · noun |
| [dank](https://en.wiktionary.org/wiki/dank#German) | thanks to, because of, courtesy of |  · prep |

</details>

<details><summary>Words 151–200</summary>

![[Resources/Audio/de/Words 0151-0200.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [h](https://en.wiktionary.org/wiki/h#German) | hour | /uːɐ̯/ · noun |
| [hinter](https://en.wiktionary.org/wiki/hinter#German) | behind, after | /ˈhɪntər/ · prep |
| [pro](https://en.wiktionary.org/wiki/pro#German) | per, each |  · prep |
| [Junge](https://en.wiktionary.org/wiki/Junge#German) | boy | /ˈjʊŋə/ · noun |
| [bald](https://en.wiktionary.org/wiki/bald#German) | soon (near in time) | /balt/ · adv |
| [Auto](https://en.wiktionary.org/wiki/Auto#German) | car | /ˈaʊ̯to/ · noun |
| [Hand](https://en.wiktionary.org/wiki/Hand#German) | hand | /hant/ · noun |
| [Kopf](https://en.wiktionary.org/wiki/Kopf#German) | head | /kɔpf/ · noun |
| [bringen](https://en.wiktionary.org/wiki/bringen#German) | to bring, to fetch, to take, to convey, to bear | /ˈbrɪŋən/ · verb |
| [fünf](https://en.wiktionary.org/wiki/f%C3%BCnf#German) | five (numerical value represented by the Arabic numeral 5; or describing a set with five elements) | /fʏnf/ · num |
| [schwer](https://en.wiktionary.org/wiki/schwer#German) | heavy, weighty | /ʃveːr/ · adj |
| [wichtig](https://en.wiktionary.org/wiki/wichtig#German) | important, relevant, significant, weighty | /ˈvɪçtɪç/ · adj |
| [zeigen](https://en.wiktionary.org/wiki/zeigen#German) | to point | /ˈt͡saɪ̯ɡən/ · verb |
| [stark](https://en.wiktionary.org/wiki/stark#German) | strong (intense, powerful, unyielding) | /ʃtark/ · adj |
| [Alter](https://en.wiktionary.org/wiki/Alter#German) | age, old age | /ˈaltər/ · noun |
| [Kind](https://en.wiktionary.org/wiki/Kind#German) | kid; child (young person) | /kɪnt/ · noun |
| [Straße](https://en.wiktionary.org/wiki/Stra%C3%9Fe#German) | street; road (a way wide enough to be passable for vehicles, generally paved, in or outside a settlement) | /ˈʃtʁaːsə/ · noun |
| [Los](https://en.wiktionary.org/wiki/Los#German) | lottery ticket | /loːs/ · noun |
| [los](https://en.wiktionary.org/wiki/los#German) | rid of, free of | /loːs/ · adv |
| [Gruppe](https://en.wiktionary.org/wiki/Gruppe#German) | group | /ˈɡʁʊpə/ · noun |
| [her](https://en.wiktionary.org/wiki/her#German) | hither, to this place, to here, to me/us | /heːr/ · adv |
| [Herr](https://en.wiktionary.org/wiki/Herr#German) | man, gentleman | /hɛr/ · noun |
| [deutsch](https://en.wiktionary.org/wiki/deutsch#German) | German (of or pertaining to the German people) | /dɔʏ̯t͡ʃ/ · adj |
| [guten Tag](https://en.wiktionary.org/wiki/guten%20Tag#German) | hello; hullo; good day; good afternoon (greeting said when meeting or acknowledging someone) | /ˌɡuːtn̩ ˈtaːk/ · intj |
| [Film](https://en.wiktionary.org/wiki/Film#German) | film (a thin layer of some substance) | /ˈfɪlm/ · noun |
| [oh](https://en.wiktionary.org/wiki/oh#German) | oh | /oː/ · intj |
| [Buch](https://en.wiktionary.org/wiki/Buch#German) | book (collection of sheets of paper bound together to hinge at one edge; long work fit for publication) | /buːx/ · noun |
| [L](https://en.wiktionary.org/wiki/L#German) | L | /ʔɛl/ · noun |
| [Mensch](https://en.wiktionary.org/wiki/Mensch#German) | human, human being, person, man | /mɛnʃ/ · noun |
| [Mädchen](https://en.wiktionary.org/wiki/M%C3%A4dchen#German) | girl | /ˈmɛːtçən/ · noun |
| [Vater](https://en.wiktionary.org/wiki/Vater#German) | father | /ˈfaːtər/ · noun |
| [groß](https://en.wiktionary.org/wiki/gro%C3%9F#German) | big, large, large-scale | /ɡʁoːs/ · adj |
| [o](https://en.wiktionary.org/wiki/o#German) | O |  · intj |
| [All](https://en.wiktionary.org/wiki/All#German) | cosmos | /al/ · noun |
| [Fest](https://en.wiktionary.org/wiki/Fest#German) | feast, celebration, festival, party | /fɛst/ · noun |
| [Form](https://en.wiktionary.org/wiki/Form#German) | shape | /fɔʁm/ · noun |
| [all](https://en.wiktionary.org/wiki/all#German) | all | /al/ · det |
| [fahren](https://en.wiktionary.org/wiki/fahren#German) | to go at speed | [ˈfaːʁən] · verb |
| [fest](https://en.wiktionary.org/wiki/fest#German) | firm; compact; hard | /fɛst/ · adj |
| [frei](https://en.wiktionary.org/wiki/frei#German) | free; unenslaved; unimprisoned | /fʁaɪ̯/ · adj |
| [super](https://en.wiktionary.org/wiki/super#German) | super, great, awesome | /ˈzuːpɐ/ · adj |
| [wert](https://en.wiktionary.org/wiki/wert#German) | worth, worthy of | /veːrt/ · adj |
| [helfen](https://en.wiktionary.org/wiki/helfen#German) | to help (someone); to assist; to aid | /ˈhɛlfn̩/ · verb |
| [Angst](https://en.wiktionary.org/wiki/Angst#German) | fear; fright; anxiety | /aŋst/ · noun |
| [Krieg](https://en.wiktionary.org/wiki/Krieg#German) | war, warfare | [kʁiːk] · noun |
| [Mai](https://en.wiktionary.org/wiki/Mai#German) | May (the fifth month of the Gregorian calendar, following April and preceding June) | /maɪ̯/ · noun |
| [September](https://en.wiktionary.org/wiki/September#German) | September (the ninth month of the Gregorian calendar, following August and preceding October, containing the southward equinox) | /zɛpˈtɛmbɐ/ · noun |
| [verstehen](https://en.wiktionary.org/wiki/verstehen#German) | to hear and interpret (speech) | /fərˈʃteːən/ · verb |
| [voll](https://en.wiktionary.org/wiki/voll#German) | full; filled | /fɔl/ · adj |
| [wann](https://en.wiktionary.org/wiki/wann#German) | when | /van/ · adv |

</details>

<details><summary>Words 201–250</summary>

![[Resources/Audio/de/Words 0201-0250.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [Alt](https://en.wiktionary.org/wiki/Alt#German) | alto (musical voice; person or instrument that performs the alto part) | /ʔalt/ · noun |
| [alt](https://en.wiktionary.org/wiki/alt#German) | old | /alt/ · adj |
| [rein](https://en.wiktionary.org/wiki/rein#German) | pure, clear, plain | /ʁaɪn/ · adj |
| [zu Hause](https://en.wiktionary.org/wiki/zu%20Hause#German) | home, at home (stationary) | [t͡suˈhaʊ̯zə] · adv |
| [ach](https://en.wiktionary.org/wiki/ach#German) | oh, alas (expressing surprise, sorrow, or understanding) | /ax/ · intj |
| [gestern](https://en.wiktionary.org/wiki/gestern#German) | yesterday | /ˈɡɛstərn/ · adv |
| [meist](https://en.wiktionary.org/wiki/meist#German) | mostly, most often, usually | /maɪ̯st/ · adv |
| [na](https://en.wiktionary.org/wiki/na#German) | well!, so!; used to introduce a statement | /na(ː)/ · intj |
| [nach Hause](https://en.wiktionary.org/wiki/nach%20Hause#German) | home, homeward (mobile, goal-oriented) | /naxˈhauzə/ · adv |
| [zahlen](https://en.wiktionary.org/wiki/zahlen#German) | to pay | /ˈtsaːln̩/ · verb |
| [reden](https://en.wiktionary.org/wiki/reden#German) | to talk, to speak, to orate | /ˈʁeːdən/ · verb |
| [Moment](https://en.wiktionary.org/wiki/Moment#German) | moment | /moˈmɛnt/ · noun |
| [X](https://en.wiktionary.org/wiki/X#German) | X | /ʔɪks/ · noun |
| [sechs](https://en.wiktionary.org/wiki/sechs#German) | six (numerical value represented by the Arabic numeral 6; or describing a set with six elements) | /zɛks/ · num |
| [sprechen](https://en.wiktionary.org/wiki/sprechen#German) | to speak (some language, the truth, etc.) | /ˈʃprɛçən/ · verb |
| [August](https://en.wiktionary.org/wiki/August#German) | August (the eighth month of the Roman, Julian, and Gregorian calendars, following July and preceding September) | /aʊ̯ˈɡʊst/ · noun |
| [November](https://en.wiktionary.org/wiki/November#German) | November (the eleventh month of the Gregorian calendar, following October and preceding December) | /noˈfɛmbɐ/ · noun |
| [glauben](https://en.wiktionary.org/wiki/glauben#German) | to believe something (to consider true) | /ˈɡlaʊ̯bən/ · verb |
| [April](https://en.wiktionary.org/wiki/April#German) | April (the fourth month of the Gregorian calendar, following March and preceding May) | /aˈpʁɪl/ · noun |
| [Freund](https://en.wiktionary.org/wiki/Freund#German) | friend | /frɔʏ̯nt/ · noun |
| [Raum](https://en.wiktionary.org/wiki/Raum#German) | space | /ʁaʊ̯m/ · noun |
| [per](https://en.wiktionary.org/wiki/per#German) | by, by means of, through, via | /pɛr/ · prep |
| [Juli](https://en.wiktionary.org/wiki/Juli#German) | July (the seventh month of the Gregorian calendar, following June and preceding August) | /ˈjuːli/ · noun |
| [Juni](https://en.wiktionary.org/wiki/Juni#German) | June (the sixth month of the Gregorian calendar, following May and preceding July, containing the northern solstice) | /ˈjuːni/ · noun |
| [links](https://en.wiktionary.org/wiki/links#German) | on the left | /lɪŋks/ · adv |
| [F](https://en.wiktionary.org/wiki/F#German) | F | /ɛf/ · noun |
| [falls](https://en.wiktionary.org/wiki/falls#German) | if, in the event that | /fals/ · conj |
| [rechts](https://en.wiktionary.org/wiki/rechts#German) | on the right | /ʁɛçt͡s/ · adv |
| [Job](https://en.wiktionary.org/wiki/Job#German) | job, position, employment | /dʒɔp/ · noun |
| [Sommer](https://en.wiktionary.org/wiki/Sommer#German) | summer | /ˈzɔmɐ/ · noun |
| [Sprache](https://en.wiktionary.org/wiki/Sprache#German) | language (body of words, and set of methods of combining them) | /ˈʃpʁaːxə/ · noun |
| [Bad](https://en.wiktionary.org/wiki/Bad#German) | bath | /baːt/ · noun |
| [Band](https://en.wiktionary.org/wiki/Band#German) | tape, ribbon | /bant/ · noun |
| [G](https://en.wiktionary.org/wiki/G#German) | G | /ɡeː/ · noun |
| [Menge](https://en.wiktionary.org/wiki/Menge#German) | quantity | /ˈmɛŋə/ · noun |
| [hallo](https://en.wiktionary.org/wiki/hallo#German) | a general greeting used when meeting someone | /ˈhalo/ · intj |
| [hinaus](https://en.wiktionary.org/wiki/hinaus#German) | out (away from the speaker) | /hɪˈnaʊ̯s/ · adv |
| [langsam](https://en.wiktionary.org/wiki/langsam#German) | slow (taking a long time to move or travel; not happening in a short time) | /ˈlaŋzaːm/ · adj |
| [Gefühl](https://en.wiktionary.org/wiki/Gef%C3%BChl#German) | feeling (either physical sensation or emotion) | /ɡəˈfyːl/ · noun |
| [laufen](https://en.wiktionary.org/wiki/laufen#German) | to walk; to jog; to run (to move on foot; either at a normal or an increased speed) | /ˈlaʊ̯fən/ · verb |
| [überall](https://en.wiktionary.org/wiki/%C3%BCberall#German) | everywhere | /ˌyːbɐˈʔal/ · adv |
| [Dezember](https://en.wiktionary.org/wiki/Dezember#German) | December (the twelfth and last month of the Gregorian calendar, following November and preceding the January of the following year, containing the southern solstice) | /deˈtsɛmbɐ/ · noun |
| [toll](https://en.wiktionary.org/wiki/toll#German) | great, nice, wonderful | /tɔl/ · adj |
| [Januar](https://en.wiktionary.org/wiki/Januar#German) | January (the first month of the Gregorian calendar, following the December of the previous year and preceding February) | /ˈjanuaːr/ · noun |
| [gehören](https://en.wiktionary.org/wiki/geh%C3%B6ren#German) | to belong to, be the property of | /ɡəˈhøːʁən/ · verb |
| [Luft](https://en.wiktionary.org/wiki/Luft#German) | air, atmosphere | /lʊft/ · noun |
| [Boden](https://en.wiktionary.org/wiki/Boden#German) | ground, soil | /ˈboːdn̩/ · noun |
| [Februar](https://en.wiktionary.org/wiki/Februar#German) | February (the short month following January and preceding March in the Roman, Julian, and Gregorian calendars, used in all three calendars for intercalation or addition of leap days) | /ˈfeːbruaːr/ · noun |
| [Kritik](https://en.wiktionary.org/wiki/Kritik#German) | criticism (negative judgement) | /kʁiˈtiːk/ · noun |
| [heraus](https://en.wiktionary.org/wiki/heraus#German) | out of (in the direction of the speaker); out over here; out from there | [hɛˈʁaus] · adv |

</details>

<details><summary>Words 251–300</summary>

![[Resources/Audio/de/Words 0251-0300.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [schwarz](https://en.wiktionary.org/wiki/schwarz#German) | black, reflecting little or no light | /ʃvarts/ · adj |
| [Deutscher](https://en.wiktionary.org/wiki/Deutscher#German) | German (male or unspecified) | /ˈdɔɪ̯t͡ʃɐ/ · noun |
| [Firma](https://en.wiktionary.org/wiki/Firma#German) | A company, a business. | /fɪrma/ · noun |
| [lass](https://en.wiktionary.org/wiki/lass#German) | powerless, tired, lazy, idle, sluggish, weak, weary, slack, limp; insufficiently diligent | /las/ · adj |
| [Licht](https://en.wiktionary.org/wiki/Licht#German) | light (electromagnetic radiation in the visible spectrum) | /lɪçt/ · noun |
| [Acht](https://en.wiktionary.org/wiki/Acht#German) | the natural number eight | /axt/ · noun |
| [Verbindung](https://en.wiktionary.org/wiki/Verbindung#German) | connection | /fɛɐ̯ˈbɪndʊŋ(k)/ · noun |
| [acht](https://en.wiktionary.org/wiki/acht#German) | eight (numerical value represented by the Arabic numeral 8; or describing a set with eight elements) | /axt/ · num |
| [zuvor](https://en.wiktionary.org/wiki/zuvor#German) | before, previously | /t͡suˈfoːɐ̯/ · adv |
| [Eins](https://en.wiktionary.org/wiki/Eins#German) | one (digit or figure) | /ˈaɪ̯ns/ · noun |
| [Grad](https://en.wiktionary.org/wiki/Grad#German) | degree | /ɡʁaːt/ · noun |
| [Präsident](https://en.wiktionary.org/wiki/Pr%C3%A4sident#German) | president; chairman, chairperson, chair (male or of unspecified gender) | [pʁɛziˈdɛnt] · noun |
| [Zimmer](https://en.wiktionary.org/wiki/Zimmer#German) | room (separate part of a building, enclosed by walls, a floor and a ceiling) | /ˈt͡sɪmɐ/ · noun |
| [eins](https://en.wiktionary.org/wiki/eins#German) | one (numerical value represented by the Arabic numeral 1; first positive number in the set of natural numbers) | /aɪ̯ns/ · num |
| [okay](https://en.wiktionary.org/wiki/okay#German) | OK | /oˈkeː/ · intj |
| [Unterstützung](https://en.wiktionary.org/wiki/Unterst%C3%BCtzung#German) | support, assistance, backing, also endorsement | /ʊntɐˈʃtʏt͡sʊŋ/ · noun |
| [fallen](https://en.wiktionary.org/wiki/fallen#German) | to fall, to drop | /ˈfalən/ · verb |
| [klein](https://en.wiktionary.org/wiki/klein#German) | small, little, wee (in physical size or extent) | /klaɪ̯n/ · adj |
| [top](https://en.wiktionary.org/wiki/top#German) | top (of the highest quality or rank) | /tɔp/ · adj |
| [K](https://en.wiktionary.org/wiki/K#German) | K | /kaː/ · noun |
| [Ordnung](https://en.wiktionary.org/wiki/Ordnung#German) | arrangement, regulation | /ˈɔrdnʊŋ/ · noun |
| [Samstag](https://en.wiktionary.org/wiki/Samstag#German) | Saturday | /ˈzamstaːk/ · noun |
| [etc.](https://en.wiktionary.org/wiki/etc.#German) | etc. |  · adv |
| [live](https://en.wiktionary.org/wiki/live#German) | live (as it happens, in real time, directly; of broadcasts) | /laɪ̯f/ · adv |
| [reich](https://en.wiktionary.org/wiki/reich#German) | rich, wealthy (having a lot of money and possessions) | /ʁaɪ̯ç/ · adj |
| [rot](https://en.wiktionary.org/wiki/rot#German) | red (colour) | /roːt/ · adj |
| [Chef](https://en.wiktionary.org/wiki/Chef#German) | boss, chief | [ʃɛf] · noun |
| [Dollar](https://en.wiktionary.org/wiki/Dollar#German) | dollar | /ˈdɔlaʁ/ · noun |
| [total](https://en.wiktionary.org/wiki/total#German) | total, absolute, complete, utter (not used in the sense of “entire”) | /toˈtaːl/ · adj |
| [Bank](https://en.wiktionary.org/wiki/Bank#German) | bench (which people sit on); pew | /baŋk/ · noun |
| [Freitag](https://en.wiktionary.org/wiki/Freitag#German) | Friday | /ˈfʁaɪ̯taːk/ · noun |
| [Hotel](https://en.wiktionary.org/wiki/Hotel#German) | hotel | /hoˈtɛl/ · noun |
| [U-Bahn](https://en.wiktionary.org/wiki/U-Bahn#German) | underground railway; subway | /ˈʔuːbaːn/ · noun |
| [Zug](https://en.wiktionary.org/wiki/Zug#German) | train (multiple vehicles one behind the other, particularly travelling on rails) | /t͡suːk/ · noun |
| [Gold](https://en.wiktionary.org/wiki/Gold#German) | gold (chemical element, Au) | /ɡɔlt/ · noun |
| [Verhalten](https://en.wiktionary.org/wiki/Verhalten#German) | behaviour | /fɛɐ̯ˈhaltn̩/ · noun |
| [nix](https://en.wiktionary.org/wiki/nix#German) | no way! | /nɪks/ · intj |
| [Aktiv](https://en.wiktionary.org/wiki/Aktiv#German) | active voice (the form in which the subject of a verb carries out some action) | /ˈaktiːf/ · noun |
| [Besuch](https://en.wiktionary.org/wiki/Besuch#German) | visit, call | /bəˈzuːχ/ · noun |
| [aktiv](https://en.wiktionary.org/wiki/aktiv#German) | active | [akˈtiːf] · adj |
| [eh](https://en.wiktionary.org/wiki/eh#German) | before | /ʔeː/ · conj |
| [englisch](https://en.wiktionary.org/wiki/englisch#German) | English | /ˈɛŋ.lɪʃ/ · adj |
| [hart](https://en.wiktionary.org/wiki/hart#German) | hard | /hart/ · adj |
| [Fenster](https://en.wiktionary.org/wiki/Fenster#German) | window | /ˈfɛnstɐ/ · noun |
| [Freude](https://en.wiktionary.org/wiki/Freude#German) | joy, delight, glee | /ˈfʁɔɪ̯də/ · noun |
| [J](https://en.wiktionary.org/wiki/J#German) | J | /jɔt/ · noun |
| [Montag](https://en.wiktionary.org/wiki/Montag#German) | Monday | /ˈmoːnˌtaːk/ · noun |
| [absolut](https://en.wiktionary.org/wiki/absolut#German) | absolute | /ap.zoˈluːt/ · adj |
| [lieben](https://en.wiktionary.org/wiki/lieben#German) | to love, to have a strong affection for (someone or something) | /ˈliːbən/ · verb |
| [plan](https://en.wiktionary.org/wiki/plan#German) | planar, flat, level, smooth | /plaːn/ · adj |

</details>

<details><summary>Words 301–350</summary>

![[Resources/Audio/de/Words 0301-0350.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [Arzt](https://en.wiktionary.org/wiki/Arzt#German) | doctor, physician (male or of unspecified gender) (without necessarily having a postgraduate degree) | [aːɐ̯tst] · noun |
| [Hund](https://en.wiktionary.org/wiki/Hund#German) | dog, hound | /hʊnt/ · noun |
| [Lust](https://en.wiktionary.org/wiki/Lust#German) | desire; the wish to do or have something | /lʊst/ · noun |
| [Meister](https://en.wiktionary.org/wiki/Meister#German) | master | /ˈmaɪ̯stɐ/ · noun |
| [baden](https://en.wiktionary.org/wiki/baden#German) | to bathe, to give a bath to or have a bath. | /ˈbaːdn̩/ · verb |
| [bloß](https://en.wiktionary.org/wiki/blo%C3%9F#German) | mere, sole | /bloːs/ · adj |
| [sonne](https://en.wiktionary.org/wiki/sonne#German) | Ungrammatical synonym of solch in plural. | /ˈzɔnə/ · pron |
| [Handy](https://en.wiktionary.org/wiki/Handy#German) | mobile phone, mobile, cell phone, phone (portable, wireless telephone) | /ˈhɛndi/ · noun |
| [Kaffee](https://en.wiktionary.org/wiki/Kaffee#German) | coffee (beverage made by infusing coffee beans in hot water) | /ˈkafe/ · noun |
| [Laden](https://en.wiktionary.org/wiki/Laden#German) | shop, store (establishment that sells goods or services to the public; originally only a physical location, but now a virtual establishment as well) | /ˈlaːdən/ · noun |
| [laden](https://en.wiktionary.org/wiki/laden#German) | to load (something) e.g. into a container or onto a vehicle, to load up | /ˈlaːdən/ · verb |
| [Tisch](https://en.wiktionary.org/wiki/Tisch#German) | dining table, dinner table | /tɪʃ/ · noun |
| [heißen](https://en.wiktionary.org/wiki/hei%C3%9Fen#German) | to have a name; to be named; to be called; but implying that one “owns” this name, not necessarily that one goes by it | /ˈhaɪ̯sən/ · verb |
| [legen](https://en.wiktionary.org/wiki/legen#German) | to lie down | /ˈleːɡən/ · verb |
| [Auge](https://en.wiktionary.org/wiki/Auge#German) | eye | /ˈaʊ̯ɡə/ · noun |
| [Bier](https://en.wiktionary.org/wiki/Bier#German) | beer (alcoholic beverage fermented from starch material; a serving of this beverage) | /biːr/ · noun |
| [Club](https://en.wiktionary.org/wiki/Club#German) | club (association of members) | /klʊp/ · noun |
| [Himmel](https://en.wiktionary.org/wiki/Himmel#German) | sky | /ˈhɪməl/ · noun |
| [willkommen](https://en.wiktionary.org/wiki/willkommen#German) | welcome (received with gladness) | /vɪlˈkɔmən/ · adj |
| [Fuß](https://en.wiktionary.org/wiki/Fu%C3%9F#German) | foot (body part) | /fuːs/ · noun |
| [Wald](https://en.wiktionary.org/wiki/Wald#German) | forest; woods; woodland | /valt/ · noun |
| [Basis](https://en.wiktionary.org/wiki/Basis#German) | basis (foundation, principle) | /ˈbaːzɪs/ · noun |
| [täglich](https://en.wiktionary.org/wiki/t%C3%A4glich#German) | daily | /ˈtɛːklɪç/ · adj |
| [Haut](https://en.wiktionary.org/wiki/Haut#German) | skin, hide of a person, animal or (part of a) plant | /haʊt/ · noun |
| [Minute](https://en.wiktionary.org/wiki/Minute#German) | minute (unit of time; unit of angle) | /miˈnuːtə/ · noun |
| [cool](https://en.wiktionary.org/wiki/cool#German) | cool (in its informal senses) | /kuːl/ · adj |
| [Fort](https://en.wiktionary.org/wiki/Fort#German) | fort (fortified defensive structure stationed with troops) | [foːɐ̯] · noun |
| [fort](https://en.wiktionary.org/wiki/fort#German) | away | [fɔɐ̯t] · adv |
| [rennen](https://en.wiktionary.org/wiki/rennen#German) | to run; to race; to sprint (said of competing sportsmen, animals etc.) | [ˈʁɛnən] · verb |
| [schade](https://en.wiktionary.org/wiki/schade#German) | a pity, a shame; bummer; unfortunate; disappointing | /ˈʃaːdə/ · adj |
| [Geburtstag](https://en.wiktionary.org/wiki/Geburtstag#German) | birthday | /ɡəˈbuːɐ̯t͡sˌtaːk/ · noun |
| [Insel](https://en.wiktionary.org/wiki/Insel#German) | an island, an isle | /ˈɪnzəl/ · noun |
| [normal](https://en.wiktionary.org/wiki/normal#German) | ordinary, normal | /nɔrˈmaːl/ · adj |
| [Autor](https://en.wiktionary.org/wiki/Autor#German) | author | /ˈaʊ̯toːɐ̯/ · noun |
| [Feuer](https://en.wiktionary.org/wiki/Feuer#German) | fire (chemical process) | /ˈfɔʏ̯ər/ · noun |
| [Interview](https://en.wiktionary.org/wiki/Interview#German) | interview (journalistic dialogue) | /ˈɪntɐˌvjuː/ · noun |
| [Kamera](https://en.wiktionary.org/wiki/Kamera#German) | camera (device for taking photographs or filming) | [ˈkaməʁa] · noun |
| [dumm](https://en.wiktionary.org/wiki/dumm#German) | dumb, stupid | /dʊm/ · adj |
| [lachen](https://en.wiktionary.org/wiki/lachen#German) | to laugh | /ˈlaxən/ · verb |
| [trinken](https://en.wiktionary.org/wiki/trinken#German) | to drink (to drink liquids (in bottles, glasses, etc.) by mouth) | /ˈtʁɪŋkən/ · verb |
| [unterstützen](https://en.wiktionary.org/wiki/unterst%C3%BCtzen#German) | to support, to assist, to help, to aid | /ʊntɐˈʃtʏt͡sən/ · verb |
| [Album](https://en.wiktionary.org/wiki/Album#German) | album |  · noun |
| [Grün](https://en.wiktionary.org/wiki/Gr%C3%BCn#German) | green (color) | [ɡryːn] · noun |
| [Link](https://en.wiktionary.org/wiki/Link#German) | hyperlink | /ˈliŋk/ · noun |
| [grün](https://en.wiktionary.org/wiki/gr%C3%BCn#German) | green (in colour) | /ɡʁyːn/ · adj |
| [kostenlos](https://en.wiktionary.org/wiki/kostenlos#German) | without cost, free | /ˈkɔstn̩loːs/ · adj |
| [link](https://en.wiktionary.org/wiki/link#German) | left | /lɪŋk/ · adj |
| [tot](https://en.wiktionary.org/wiki/tot#German) | dead, deceased | /toːt/ · adj |
| [Arm](https://en.wiktionary.org/wiki/Arm#German) | an arm | /arm/ · noun |
| [Böse](https://en.wiktionary.org/wiki/B%C3%B6se#German) | evil, malice, wickedness | /ˈbøːzə/ · noun |

</details>

<details><summary>Words 351–400</summary>

![[Resources/Audio/de/Words 0351-0400.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [Herbst](https://en.wiktionary.org/wiki/Herbst#German) | autumn, fall | /hɛʁpst/ · noun |
| [arm](https://en.wiktionary.org/wiki/arm#German) | poor (having little money) | [aʁm] · adj |
| [böse](https://en.wiktionary.org/wiki/b%C3%B6se#German) | evil; malicious; wicked | /ˈbøːzə/ · adj |
| [plus](https://en.wiktionary.org/wiki/plus#German) | plus, increased by | /plʊs/ · adv |
| [wesentlich](https://en.wiktionary.org/wiki/wesentlich#German) | essential (concerning the essence or true nature of something) | /ˈveːzəntlɪç/ · adj |
| [Blut](https://en.wiktionary.org/wiki/Blut#German) | blood | /bluːt/ · noun |
| [Farbe](https://en.wiktionary.org/wiki/Farbe#German) | colour | /ˈfarbə/ · noun |
| [Garten](https://en.wiktionary.org/wiki/Garten#German) | garden, yard (grounds at the front or back of a house) | /ˈɡaʁ.tən/ · noun |
| [Lied](https://en.wiktionary.org/wiki/Lied#German) | song (musical composition sung with vocals or vocal lyrics) | /ˈliːt/ · noun |
| [Westen](https://en.wiktionary.org/wiki/Westen#German) | west | /ˈvɛstən/ · noun |
| [Be](https://en.wiktionary.org/wiki/Be#German) | flat sign, ♭ |  · noun |
| [Finale](https://en.wiktionary.org/wiki/Finale#German) | final | /fiˈnaːlə/ · noun |
| [General](https://en.wiktionary.org/wiki/General#German) | general (officer in any general rank) | /ˌɡe(ː).nəˈʁaːl/ · noun |
| [Kaiser](https://en.wiktionary.org/wiki/Kaiser#German) | emperor (ruler of certain monarchies; highest monarch) | /ˈkaɪ̯zər/ · noun |
| [Leiter](https://en.wiktionary.org/wiki/Leiter#German) | ladder | /ˈlaɪ̯tər/ · noun |
| [Meer](https://en.wiktionary.org/wiki/Meer#German) | sea | /meːr/ · noun |
| [Traum](https://en.wiktionary.org/wiki/Traum#German) | dream | /tʁaʊ̯m/ · noun |
| [Baby](https://en.wiktionary.org/wiki/Baby#German) | baby (infant) | /ˈbeːbi/ · noun |
| [Brief](https://en.wiktionary.org/wiki/Brief#German) | letter (written message) | /ˈbʁiːf/ · noun |
| [wow](https://en.wiktionary.org/wiki/wow#German) | wow (exclaims surprise or amazement) |  · intj |
| [Mark](https://en.wiktionary.org/wiki/Mark#German) | mark (any of various European monetary units) | [maʁk] · noun |
| [Material](https://en.wiktionary.org/wiki/Material#German) | material (matter) | /mat(e)ˈri̯aːl/ · noun |
| [Seele](https://en.wiktionary.org/wiki/Seele#German) | soul | /ˈzeːlə/ · noun |
| [Mittwoch](https://en.wiktionary.org/wiki/Mittwoch#German) | Wednesday | /ˈmɪtvɔx/ · noun |
| [Rom](https://en.wiktionary.org/wiki/Rom#German) | Rom (member of the Roma people), Romani | /ʁɔm/ · noun |
| [Gesundheit](https://en.wiktionary.org/wiki/Gesundheit#German) | health (state of being in good physical condition and free from illness) | /ɡəˈzʊnthaɪ̯t/ · noun |
| [Mama](https://en.wiktionary.org/wiki/Mama#German) | mum, mummy, mom, mommy | /ˈmama/ · noun |
| [Wissenschaft](https://en.wiktionary.org/wiki/Wissenschaft#German) | science (a branch of knowledge or academic discipline dealing with a systematic body of facts or truths) | /ˈvɪsənʃaft/ · noun |
| [extra](https://en.wiktionary.org/wiki/extra#German) | separate (not included in or directly connected to the object being discussed) | /ˈɛks.tʁa/ · adj |
| [ha](https://en.wiktionary.org/wiki/ha#German) | Expresses laughter. |  · intj |
| [international](https://en.wiktionary.org/wiki/international#German) | international | /ˌɪntɐnat͡si̯oˈnaːl/ · adj |
| [not](https://en.wiktionary.org/wiki/not#German) | only used in nottun | /noːt/ · adv |
| [sorry](https://en.wiktionary.org/wiki/sorry#German) | sorry (expressing regret) | /ˈzɔʁi/ · intj |
| [Bedarf](https://en.wiktionary.org/wiki/Bedarf#German) | need (that which is desired or required) | /bəˈdaʁf/ · noun |
| [Generation](https://en.wiktionary.org/wiki/Generation#German) | generation | /ˌɡeːnəʁaˈt͡si̯oːn/ · noun |
| [Küche](https://en.wiktionary.org/wiki/K%C3%BCche#German) | kitchen (room) | /ˈkʏçə/ · noun |
| [at](https://en.wiktionary.org/wiki/at#German) | at, at-sign | /ɛt/ · noun |
| [mitten](https://en.wiktionary.org/wiki/mitten#German) | In the middle. |  · adv |
| [Computer](https://en.wiktionary.org/wiki/Computer#German) | computer (programmable electronic device that performs mathematical calculations, logical operations, and usually also data retrieval/storage) | /kɔmˈpjuːtɐ/ · noun |
| [Finger](https://en.wiktionary.org/wiki/Finger#German) | finger | /ˈfɪŋɐ/ · noun |
| [Fleisch](https://en.wiktionary.org/wiki/Fleisch#German) | flesh | /flaɪ̯ʃ/ · noun |
| [Geist](https://en.wiktionary.org/wiki/Geist#German) | spirit | /ɡaɪ̯st/ · noun |
| [PC](https://en.wiktionary.org/wiki/PC#German) | PC (personal computer) | /peːˈtseː/ · noun |
| [Verhältnis](https://en.wiktionary.org/wiki/Verh%C3%A4ltnis#German) | relation, ratio | /fɛɐ̯ˈhɛltnɪs/ · noun |
| [ah](https://en.wiktionary.org/wiki/ah#German) | expressing understanding | /ʔaː/ · intj |
| [offiziell](https://en.wiktionary.org/wiki/offiziell#German) | official | /ˌɔfiˈtsjɛl/ · adj |
| [unabhängig](https://en.wiktionary.org/wiki/unabh%C3%A4ngig#German) | independent | /ˈʊn.apˌhɛŋɪç/ · adj |
| [Blau](https://en.wiktionary.org/wiki/Blau#German) | the colour blue (as a whole) | [blaʊ̯] · noun |
| [Bund](https://en.wiktionary.org/wiki/Bund#German) | alliance, federation, league | /bʊnt/ · noun |
| [Donnerstag](https://en.wiktionary.org/wiki/Donnerstag#German) | Thursday | /ˈdɔnɐsˌtaːk/ · noun |

</details>

<details><summary>Words 401–450</summary>

![[Resources/Audio/de/Words 0401-0450.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [Lager](https://en.wiktionary.org/wiki/Lager#German) | place where one sleeps, such as a bed or a spot in a barn, etc. | /ˈlaːɡɐ/ · noun |
| [blau](https://en.wiktionary.org/wiki/blau#German) | blue (color/colour) | /blaʊ̯/ · adj |
| [Aufmerksamkeit](https://en.wiktionary.org/wiki/Aufmerksamkeit#German) | attention, mindfulness, attentiveness | /ˈaʊ̯fˌmɛʁkzaːmkaɪ̯t/ · noun |
| [Ball](https://en.wiktionary.org/wiki/Ball#German) | ball (round or roundish object, most commonly used in games) | /bal/ · noun |
| [Dienstag](https://en.wiktionary.org/wiki/Dienstag#German) | Tuesday | /ˈdiːnsˌtaːk/ · noun |
| [Wein](https://en.wiktionary.org/wiki/Wein#German) | wine | /vaɪ̯n/ · noun |
| [traurig](https://en.wiktionary.org/wiki/traurig#German) | sad | /ˈtʁaʊ̯.ʁɪç/ · adj |
| [Information](https://en.wiktionary.org/wiki/Information#German) | a piece of information; (in the plural) information, intelligence (things to be known about a topic) | /ˌɪnfɔʁmaˈtsjoːn/ · noun |
| [Nase](https://en.wiktionary.org/wiki/Nase#German) | nose | /ˈnaːzə/ · noun |
| [original](https://en.wiktionary.org/wiki/original#German) | original | /oʁiɡiˈnaːl/ · adj |
| [regen](https://en.wiktionary.org/wiki/regen#German) | to move (a small amount or unconsciously) |  · verb |
| [zählen](https://en.wiktionary.org/wiki/z%C3%A4hlen#German) | to count (to determine the number of objects in a group) | /ˈtsɛːlən/ · verb |
| [Baum](https://en.wiktionary.org/wiki/Baum#German) | tree | /baʊ̯m/ · noun |
| [Berg](https://en.wiktionary.org/wiki/Berg#German) | a mountain, hill | /bɛrk/ · noun |
| [City](https://en.wiktionary.org/wiki/City#German) | city center, downtown, central business district | /ˈsɪti/ · noun |
| [Parlament](https://en.wiktionary.org/wiki/Parlament#German) | parliament | /paʁlaˈmɛnt/ · noun |
| [steuern](https://en.wiktionary.org/wiki/steuern#German) | to steer, to navigate, to pilot, to operate, to control | /ˈʃtɔɪ̯ɐn/ · verb |
| [zwölf](https://en.wiktionary.org/wiki/zw%C3%B6lf#German) | twelve | /t͡svœlf/ · num |
| [Analyse](https://en.wiktionary.org/wiki/Analyse#German) | analysis | [ʔanaˈlyːzə] · noun |
| [Glas](https://en.wiktionary.org/wiki/Glas#German) | glass | /ɡlaːs/ · noun |
| [real](https://en.wiktionary.org/wiki/real#German) | real (that has physical existence) | /ʁeˈal/ · adj |
| [Charakter](https://en.wiktionary.org/wiki/Charakter#German) | character; the totality of someone's personal qualities | /kaˈraktər/ · noun |
| [Gang](https://en.wiktionary.org/wiki/Gang#German) | motion, movement, progress, way, going | /ɡaŋ/ · noun |
| [Hamburger](https://en.wiktionary.org/wiki/Hamburger#German) | of Hamburg | /ˈhamˌbʊʁɡɐ/ · adj |
| [Witz](https://en.wiktionary.org/wiki/Witz#German) | joke | /vɪt͡s/ · noun |
| [leer](https://en.wiktionary.org/wiki/leer#German) | empty | /leːɐ̯/ · adj |
| [verboten](https://en.wiktionary.org/wiki/verboten#German) | forbidden, prohibited, banned | /fɛɐ̯ˈboːtn̩/ · adj |
| [Eis](https://en.wiktionary.org/wiki/Eis#German) | ice | /aɪ̯s/ · noun |
| [Fan](https://en.wiktionary.org/wiki/Fan#German) | fan, devotee | [fɛn] · noun |
| [Gast](https://en.wiktionary.org/wiki/Gast#German) | guest | [ɡast] · noun |
| [Homepage](https://en.wiktionary.org/wiki/Homepage#German) | homepage | /ˈhɔʊ̯mpeːt͡ʃ/ · noun |
| [pflanzen](https://en.wiktionary.org/wiki/pflanzen#German) | to plant | /ˈpflantsən/ · verb |
| [Dame](https://en.wiktionary.org/wiki/Dame#German) | lady (woman of good breeding and manners) | /ˈdaːmə/ · noun |
| [Design](https://en.wiktionary.org/wiki/Design#German) | design (creative profession or art) | /diˈzaɪn/ · noun |
| [As](https://en.wiktionary.org/wiki/As#German) | as, a unit and a Roman coin |  · noun |
| [Gewicht](https://en.wiktionary.org/wiki/Gewicht#German) | weight | /ɡəˈvɪçt/ · noun |
| [Minister](https://en.wiktionary.org/wiki/Minister#German) | minister (a person who is commissioned by the government for public service) | /miˈnɪstɐ/ · noun |
| [eng](https://en.wiktionary.org/wiki/eng#German) | narrow, tight | /ɛŋ/ · adj |
| [kaputt](https://en.wiktionary.org/wiki/kaputt#German) | destroyed, broken, out of order | /kaˈpʊt/ · adj |
| [Abteilung](https://en.wiktionary.org/wiki/Abteilung#German) | department | /apˈtaɪ̯lʊŋ/ · noun |
| [Adresse](https://en.wiktionary.org/wiki/Adresse#German) | address |  · noun |
| [Mission](https://en.wiktionary.org/wiki/Mission#German) | mission (set of tasks) | /mɪˈsjoːn/ · noun |
| [hi](https://en.wiktionary.org/wiki/hi#German) | hi | /ˈhaɪ̯/ · intj |
| [high](https://en.wiktionary.org/wiki/high#German) | high (intoxicated with a drug other than alcohol) | /haɪ̯/ · adj |
| [kalt](https://en.wiktionary.org/wiki/kalt#German) | cold, chilly; the physical perception of something (objects, weather, body etc.) to have a low temperature | /kalt/ · adj |
| [null](https://en.wiktionary.org/wiki/null#German) | zero; nil; nought; (tennis) love (integer number between −1 and 1, denoting no quantity at all) | /nʊl/ · num |
| [Bar](https://en.wiktionary.org/wiki/Bar#German) | bar (desk) | [baːɐ] · noun |
| [Manager](https://en.wiktionary.org/wiki/Manager#German) | manager (see usage notes below) (male or of unspecified sex, sometimes female) | /ˈmɛnɛd͡ʒɐ/ · noun |
| [Media](https://en.wiktionary.org/wiki/Media#German) | media | [ˈmeːdi̯a] · noun |
| [bar](https://en.wiktionary.org/wiki/bar#German) | bare |  · adj |

</details>

<details><summary>Words 451–500</summary>

![[Resources/Audio/de/Words 0451-0500.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [breit](https://en.wiktionary.org/wiki/breit#German) | broad, wide | /bʁaɪ̯t/ · adj |
| [nah](https://en.wiktionary.org/wiki/nah#German) | near (in space or time or in an abstract sense), close, nearby | /naː/ · adj |
| [uni](https://en.wiktionary.org/wiki/uni#German) | unicolour, single-colour | /ˈʏni/ · adj |
| [Integration](https://en.wiktionary.org/wiki/Integration#German) | integration |  · noun |
| [ausgezeichnet](https://en.wiktionary.org/wiki/ausgezeichnet#German) | excellent, outstanding | [ˈaʊ̯sɡəˌtsaɪ̯̯çnət] · adj |
| [Übersetzung](https://en.wiktionary.org/wiki/%C3%9Cbersetzung#German) | translation | /ˌyːbɐˈzɛtsʊŋ(k)/ · noun |
| [Code](https://en.wiktionary.org/wiki/Code#German) | code | [koːt] · noun |
| [Forum](https://en.wiktionary.org/wiki/Forum#German) | forum | /ˈfoːʁʊm/ · noun |
| [Gas](https://en.wiktionary.org/wiki/Gas#German) | gas (matter in a physical state between liquid and plasma) | /ɡaːs/ · noun |
| [au](https://en.wiktionary.org/wiki/au#German) | ouch, ow (expression of one's own physical pain) |  · intj |
| [gratis](https://en.wiktionary.org/wiki/gratis#German) | free, without charge | /ˈɡʁaːtɪs/ · adv |
| [ohnehin](https://en.wiktionary.org/wiki/ohnehin#German) | in any case, anyway, either way | /oːnəˈhɪn/ · adv |
| [personal](https://en.wiktionary.org/wiki/personal#German) | personal | /pɛʁzoˈnaːl/ · adj |
| [Achtung](https://en.wiktionary.org/wiki/Achtung#German) | attention | /ˈaxtʊŋ/ · noun |
| [Boot](https://en.wiktionary.org/wiki/Boot#German) | boat | /boːt/ · noun |
| [Fahrzeug](https://en.wiktionary.org/wiki/Fahrzeug#German) | vehicle | /ˈfaː(ɐ̯)tsɔʏ̯k/ · noun |
| [hm](https://en.wiktionary.org/wiki/hm#German) | hm |  · intj |
| [Braun](https://en.wiktionary.org/wiki/Braun#German) | brown (color) | /braʊ̯n/ · noun |
| [Engel](https://en.wiktionary.org/wiki/Engel#German) | angel | /ˈɛŋl̩/ · noun |
| [Mist](https://en.wiktionary.org/wiki/Mist#German) | manure (domestic animals’ excrement mixed with hay) | /ˈmɪst/ · noun |
| [bitten](https://en.wiktionary.org/wiki/bitten#German) | to ask, to beg, to plead, to bid, to request | /ˈbɪtn̩/ · verb |
| [braun](https://en.wiktionary.org/wiki/braun#German) | brown | /bʁaʊ̯n/ · adj |
| [via](https://en.wiktionary.org/wiki/via#German) | via, by way of |  · prep |
| [warm](https://en.wiktionary.org/wiki/warm#German) | warm; mildly hot | /varm/ · adj |
| [Elf](https://en.wiktionary.org/wiki/Elf#German) | eleven | /ʔɛlf/ · noun |
| [Kern](https://en.wiktionary.org/wiki/Kern#German) | kernel | /kɛrn/ · noun |
| [Schicksal](https://en.wiktionary.org/wiki/Schicksal#German) | destiny, fate (irresistible power that predetermines events) | /ˈʃɪk.zaːl/ · noun |
| [Verbrechen](https://en.wiktionary.org/wiki/Verbrechen#German) | a felony, indictable offence | /fərˈbrɛçən/ · noun |
| [elf](https://en.wiktionary.org/wiki/elf#German) | eleven | /ɛlf/ · num |
| [müde](https://en.wiktionary.org/wiki/m%C3%BCde#German) | tired | /ˈmyːdə/ · adj |
| [nerven](https://en.wiktionary.org/wiki/nerven#German) | to annoy, to irritate | /ˈnɛʁfən/ · verb |
| [wild](https://en.wiktionary.org/wiki/wild#German) | wild (of animals, etc.) | /vɪlt/ · adj |
| [German](https://en.wiktionary.org/wiki/German#German) | germane |  · noun |
| [Katze](https://en.wiktionary.org/wiki/Katze#German) | house cat, Felis silvestris catus | /ˈkatsə/ · noun |
| [Botschaft](https://en.wiktionary.org/wiki/Botschaft#German) | message | [ˈboːt.ʃaft] · noun |
| [CD](https://en.wiktionary.org/wiki/CD#German) | CD (compact disc) | /tseˈdeː/ · noun |
| [Fahrrad](https://en.wiktionary.org/wiki/Fahrrad#German) | bicycle | /ˈfaːrˌra(ː)t/ · noun |
| [Festival](https://en.wiktionary.org/wiki/Festival#German) | festival |  · noun |
| [Humor](https://en.wiktionary.org/wiki/Humor#German) | humor (something funny) | [huˈmoːɐ̯] · noun |
| [Marketing](https://en.wiktionary.org/wiki/Marketing#German) | marketing (promotion, distribution and selling of a product or service) |  · noun |
| [quasi](https://en.wiktionary.org/wiki/quasi#German) | as it were, so to speak, effectively, essentially; used to mark a description as figurative, simplified or otherwise not to be taken as absolute, but illustrative of an important point | /ˈkvaːzi/ · adv |
| [Bord](https://en.wiktionary.org/wiki/Bord#German) | shelf (board fixed to the wall) | /bɔʁt/ · noun |
| [hinein](https://en.wiktionary.org/wiki/hinein#German) | in (away from the speaker) | [hɪˈnaɪ̯n] · adv |
| [Bock](https://en.wiktionary.org/wiki/Bock#German) | buck, ram; the male of certain animals, especially goat, sheep, and roedeer | /bɔk/ · noun |
| [Führer](https://en.wiktionary.org/wiki/F%C3%BChrer#German) | guide (person who assists people by providing information, giving directions, etc.) | /ˈfyː.ʁɐ/ · noun |
| [Hals](https://en.wiktionary.org/wiki/Hals#German) | neck | /hals/ · noun |
| [Hunger](https://en.wiktionary.org/wiki/Hunger#German) | hunger | /ˈhʊŋɐ/ · noun |
| [Management](https://en.wiktionary.org/wiki/Management#German) | management (administration; the process or practice of managing) | /ˈmɛnɪt͡ʃmənt/ · noun |
| [Brand](https://en.wiktionary.org/wiki/Brand#German) | fire, blaze (destructive occurrence) | /bʁant/ · noun |
| [Engagement](https://en.wiktionary.org/wiki/Engagement#German) | commitment, dedication | /ãɡaʒ(ə)ˈmãː/ · noun |

</details>

<details><summary>Words 501–550</summary>

![[Resources/Audio/de/Words 0501-0550.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [Last](https://en.wiktionary.org/wiki/Last#German) | load, burden | /last/ · noun |
| [Schnee](https://en.wiktionary.org/wiki/Schnee#German) | snow | /ʃneː/ · noun |
| [Vogel](https://en.wiktionary.org/wiki/Vogel#German) | a bird | /ˈfoːɡəl/ · noun |
| [en masse](https://en.wiktionary.org/wiki/en%20masse#German) | en masse, in large amounts | [ɑ̃ˈmas] · adv |
| [sichtbar](https://en.wiktionary.org/wiki/sichtbar#German) | visible | /ˈzɪçtbaːɐ̯/ · adj |
| [Öl](https://en.wiktionary.org/wiki/%C3%96l#German) | oil | /øːl/ · noun |
| [Hose](https://en.wiktionary.org/wiki/Hose#German) | trousers | /ˈhoːzə/ · noun |
| [still](https://en.wiktionary.org/wiki/still#German) | quiet, silent | /ʃtɪl/ · adj |
| [vorgehen](https://en.wiktionary.org/wiki/vorgehen#German) | to walk to the front (of a room or area) | [ˈfoːɐ̯ˌɡeː.ən] · verb |
| [Autobahn](https://en.wiktionary.org/wiki/Autobahn#German) | motorway (Britain, Ireland, New Zealand), freeway (Australia, Canada, US), highway (parts of the US), expressway (parts of Canada, parts of the US), controlled-access highway | [ˈʔaʊ̯toˌbaːn] · noun |
| [Gymnasium](https://en.wiktionary.org/wiki/Gymnasium#German) | grammar school (UK), prep school (US) (school used to prepare students for university) | /ɡʏmˈnaːziʊm/ · noun |
| [Loch](https://en.wiktionary.org/wiki/Loch#German) | hole; perforation | /lɔx/ · noun |
| [Million](https://en.wiktionary.org/wiki/Million#German) | million (10⁶) | /mɪˈli̯oːn/ · noun |
| [Zucker](https://en.wiktionary.org/wiki/Zucker#German) | sugar | /ˈt͡sʊ.kɐ/ · noun |
| [parallel](https://en.wiktionary.org/wiki/parallel#German) | parallel | /paʁaˈleːl/ · adj |
| [Ei](https://en.wiktionary.org/wiki/Ei#German) | egg (all biological senses) | /aɪ̯/ · noun |
| [Liter](https://en.wiktionary.org/wiki/Liter#German) | liter, litre | /ˈlɪtɐ/ · noun |
| [Marie](https://en.wiktionary.org/wiki/Marie#German) | money | /maˈʁiː/ · noun |
| [Schlüssel](https://en.wiktionary.org/wiki/Schl%C3%BCssel#German) | a key | /ˈʃlʏsl̩/ · noun |
| [Unterhaltung](https://en.wiktionary.org/wiki/Unterhaltung#German) | conversation |  · noun |
| [ei](https://en.wiktionary.org/wiki/ei#German) | whoa, hey (expression of surprise) | /aɪ̯/ · intj |
| [sexy](https://en.wiktionary.org/wiki/sexy#German) | sexy | /ˈzɛksi/ · adj |
| [Ansatz](https://en.wiktionary.org/wiki/Ansatz#German) | addition | /ˈanzats/ · noun |
| [Chat](https://en.wiktionary.org/wiki/Chat#German) | A chat, exchange of text or voice messages in real time, notably by Internet | /tʃɛt/ · noun |
| [Flasche](https://en.wiktionary.org/wiki/Flasche#German) | bottle; flask; flagon | /ˈflaʃə/ · noun |
| [Format](https://en.wiktionary.org/wiki/Format#German) | stature | /fɔʁˈmaːt/ · noun |
| [Go](https://en.wiktionary.org/wiki/Go#German) | go (board game) | /ɡoː/ · noun |
| [Waffe](https://en.wiktionary.org/wiki/Waffe#German) | weapon, arm | /ˈvafə/ · noun |
| [dick](https://en.wiktionary.org/wiki/dick#German) | thick | /dɪk/ · adj |
| [out](https://en.wiktionary.org/wiki/out#German) | out of fashion | /aʊ̯t/ · adj |
| [übel](https://en.wiktionary.org/wiki/%C3%BCbel#German) | bad, evil, terrible (not good, in quality or morality) | /ˈyːbəl/ · adj |
| [Haar](https://en.wiktionary.org/wiki/Haar#German) | hair (a singular hair, not limited to the head) | /haːr/ · noun |
| [Hammer](https://en.wiktionary.org/wiki/Hammer#German) | hammer, mallet | /ˈhamɐ/ · noun |
| [Datum](https://en.wiktionary.org/wiki/Datum#German) | date (specific day for an event to take place) | /ˈdaːtʊm/ · noun |
| [Deal](https://en.wiktionary.org/wiki/Deal#German) | deal (often implying a dubious nature) | /diːl/ · noun |
| [Definition](https://en.wiktionary.org/wiki/Definition#German) | definition | /definiˈtsjoːn/ · noun |
| [Hut](https://en.wiktionary.org/wiki/Hut#German) | hat | /huːt/ · noun |
| [Mode](https://en.wiktionary.org/wiki/Mode#German) | fashion, trend | /ˈmoːdə/ · noun |
| [Teufel](https://en.wiktionary.org/wiki/Teufel#German) | the Devil, Satan (supreme evil spirit in the Abrahamic religions) | /ˈtɔɪ̯fəl/ · noun |
| [fair](https://en.wiktionary.org/wiki/fair#German) | fair (just, honest, equitable, adequate) | /fɛːr/ · adj |
| [jener](https://en.wiktionary.org/wiki/jener#German) | that, that one | /ˈjeːnɐ/ · pron |
| [Bio](https://en.wiktionary.org/wiki/Bio#German) | organic products | /ˈbiːo/ · noun |
| [Blatt](https://en.wiktionary.org/wiki/Blatt#German) | leaf (green and flat organ of a plant) | /blat/ · noun |
| [Französisch](https://en.wiktionary.org/wiki/Franz%C3%B6sisch#German) | French, fellatio | /fʁanˈtsøːzɪʃ/ · noun |
| [Front](https://en.wiktionary.org/wiki/Front#German) | the front end or side of something. | /fʁɔnt/ · noun |
| [Versorgung](https://en.wiktionary.org/wiki/Versorgung#German) | supply | [fɛɐ̯ˈzɔʁɡʊŋ] · noun |
| [beenden](https://en.wiktionary.org/wiki/beenden#German) | to finish, to complete, to (bring/put to an) end | [bəˈʔɛndn̩] · verb |
| [französisch](https://en.wiktionary.org/wiki/franz%C3%B6sisch#German) | French | /fʁanˈt͡søːzɪʃ/ · adj |
| [Android](https://en.wiktionary.org/wiki/Android#German) | android | /andʁoˈiːt/ · noun |
| [Cent](https://en.wiktionary.org/wiki/Cent#German) | cent, the smaller unit of the euro | /(t)sɛnt/ · noun |

</details>

<details><summary>Words 551–600</summary>

![[Resources/Audio/de/Words 0551-0600.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [Henry](https://en.wiktionary.org/wiki/Henry#German) | henry (unit of electrical inductance) |  · noun |
| [Schatz](https://en.wiktionary.org/wiki/Schatz#German) | treasure | /ʃat͡s/ · noun |
| [Schmerz](https://en.wiktionary.org/wiki/Schmerz#German) | physical pain, ache (practically, as a sensation) | /ʃmɛʁts/ · noun |
| [jo](https://en.wiktionary.org/wiki/jo#German) | yes; expresses firm agreement. | /joː/ · intj |
| [rosa](https://en.wiktionary.org/wiki/rosa#German) | coloured in a pale shade of pink | /ˈʁoːza/ · adj |
| [Decke](https://en.wiktionary.org/wiki/Decke#German) | any cloth or cushion used as a covering; a tablecloth, blanket, quilt, duvet, etc. | /ˈdɛkə/ · noun |
| [he](https://en.wiktionary.org/wiki/he#German) | An exclamation to get attention; hey | /he/ · intj |
| [Chaos](https://en.wiktionary.org/wiki/Chaos#German) | chaos | [ˈkaːɔs] · noun |
| [Ersatz](https://en.wiktionary.org/wiki/Ersatz#German) | replacement, substitute | /ʔɛɐ̯ˈzats/ · noun |
| [Kontext](https://en.wiktionary.org/wiki/Kontext#German) | context |  · noun |
| [Lady](https://en.wiktionary.org/wiki/Lady#German) | lady, Lady (British noblewoman) | /ˈlɛɪ̯di/ · noun |
| [Master](https://en.wiktionary.org/wiki/Master#German) | master's degree | /ˈmaːstɐ/ · noun |
| [Mobile](https://en.wiktionary.org/wiki/Mobile#German) | mobile | /ˈmoːbileː/ · noun |
| [Mond](https://en.wiktionary.org/wiki/Mond#German) | moon (a natural satellite that is orbiting its corresponding planet) | /moːnt/ · noun |
| [Ohr](https://en.wiktionary.org/wiki/Ohr#German) | ear (the auditory organ) | /oːr/ · noun |
| [nackt](https://en.wiktionary.org/wiki/nackt#German) | nude; not wearing any clothes | /nakt/ · adj |
| [Box](https://en.wiktionary.org/wiki/Box#German) | box (cuboid container); but not as widely used as in English in formal language, perhaps most common for plastic boxes | /bɔks/ · noun |
| [Don](https://en.wiktionary.org/wiki/Don#German) | don (honorific title, especially in Spain and Italy) |  · noun |
| [Fisch](https://en.wiktionary.org/wiki/Fisch#German) | fish (cold-blooded vertebrates living in water) | /fɪʃ/ · noun |
| [Krone](https://en.wiktionary.org/wiki/Krone#German) | crown | /ˈkʁoːnə/ · noun |
| [Level](https://en.wiktionary.org/wiki/Level#German) | level (degree or amount) | /ˈlɛvl̩/ · noun |
| [fit](https://en.wiktionary.org/wiki/fit#German) | fit (in good overall physical shape) | /fɪt/ · adj |
| [Architektur](https://en.wiktionary.org/wiki/Architektur#German) | architecture | /aʁçitɛkˈtuːɐ̯/ · noun |
| [Bachelor](https://en.wiktionary.org/wiki/Bachelor#German) | bachelor's degree | /ˈbɛ.t͡ʃə.lɐ/ · noun |
| [Golf](https://en.wiktionary.org/wiki/Golf#German) | bay, gulf | /ɡɔlf/ · noun |
| [Heft](https://en.wiktionary.org/wiki/Heft#German) | notebook, writing booklet, cahier, composition book (book in which notes or memoranda are written) | /hɛft/ · noun |
| [Käse](https://en.wiktionary.org/wiki/K%C3%A4se#German) | cheese | /ˈkɛːzə/ · noun |
| [Logo](https://en.wiktionary.org/wiki/Logo#German) | logo, logotype | /ˈloːɡo/ · noun |
| [Reifen](https://en.wiktionary.org/wiki/Reifen#German) | tyre; tire | /ˈraɪ̯fən/ · noun |
| [landen](https://en.wiktionary.org/wiki/landen#German) | to land (to reach solid ground in an air, water or space vessel) | /ˈlandən/ · verb |
| [logo](https://en.wiktionary.org/wiki/logo#German) | of course, absolutely, certainly | [ˈloːɡo] · adv |
| [umsonst](https://en.wiktionary.org/wiki/umsonst#German) | free of charge, gratis | /ʊmˈzɔnst/ · adv |
| [Ehefrau](https://en.wiktionary.org/wiki/Ehefrau#German) | married woman, wife | /ˈeːəˌfʁaʊ̯/ · noun |
| [Mercedes](https://en.wiktionary.org/wiki/Mercedes#German) | Mercedes (car manufactured by Mercedes-Benz) | /mɛʁˈt͡seːdəs/ · noun |
| [einander](https://en.wiktionary.org/wiki/einander#German) | Reciprocal pronoun of all three plural persons: each other | /aɪ̯ˈnandɐ/ · pron |
| [entdecken](https://en.wiktionary.org/wiki/entdecken#German) | to discover, to spot, to learn for the first time | /ɛntˈdɛkən/ · verb |
| [weinen](https://en.wiktionary.org/wiki/weinen#German) | to weep, cry | /ˈvaɪ̯nən/ · verb |
| [Bestandteil](https://en.wiktionary.org/wiki/Bestandteil#German) | component, element |  · noun |
| [Drama](https://en.wiktionary.org/wiki/Drama#German) | drama | /ˈdʁaː.ma/ · noun |
| [ran](https://en.wiktionary.org/wiki/ran#German) | near, close to, over to | [ʁan] · adv |
| [Block](https://en.wiktionary.org/wiki/Block#German) | bloc | /blɔk/ · noun |
| [Dialog](https://en.wiktionary.org/wiki/Dialog#German) | dialogue | /diaˈloːk/ · noun |
| [Grab](https://en.wiktionary.org/wiki/Grab#German) | grave | /ɡʁaːp/ · noun |
| [Sekunde](https://en.wiktionary.org/wiki/Sekunde#German) | A unit of time; a second. | /zeˈkʊndə/ · noun |
| [bergen](https://en.wiktionary.org/wiki/bergen#German) | to recover, salvage, rescue; with regard to living beings this can mean dead or alive, for the latter retten is the normal word | /ˈbɛrɡən/ · verb |
| [hell](https://en.wiktionary.org/wiki/hell#German) | clear, bright, light | /hɛl/ · adj |
| [mega](https://en.wiktionary.org/wiki/mega#German) | very, super, mega | /meɡa/ · adv |
| [Are](https://en.wiktionary.org/wiki/Are#German) | synonym of Ar | /ˈaːʁə/ · noun |
| [Mittag](https://en.wiktionary.org/wiki/Mittag#German) | noon, midday, late morning, early afternoon (time from about 11 a.m. to 2 p.m) | /ˈmɪtaːk/ · noun |
| [fuck](https://en.wiktionary.org/wiki/fuck#German) | fuck! | /fak/ · intj |

</details>

<details><summary>Words 601–650</summary>

![[Resources/Audio/de/Words 0601-0650.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [national](https://en.wiktionary.org/wiki/national#German) | national (being part of a nation's identity or character) | /ˌnatsi̯oˈnaːl/ · adj |
| [porno](https://en.wiktionary.org/wiki/porno#German) | awesome |  · adj |
| [zerstören](https://en.wiktionary.org/wiki/zerst%C3%B6ren#German) | to destroy, demolish, devastate, eliminate | /t͡sɛɐ̯ˈʃtøːʁən/ · verb |
| [DVD](https://en.wiktionary.org/wiki/DVD#German) | DVD (optical disc) | /ˌdeːfaʊ̯ˈdeː/ · noun |
| [Dreck](https://en.wiktionary.org/wiki/Dreck#German) | dirt | /dʁɛk/ · noun |
| [Entschuldigung](https://en.wiktionary.org/wiki/Entschuldigung#German) | apology (expression of remorse or regret) | /ɛntˈʃʊldiɡʊŋ/ · noun |
| [Index](https://en.wiktionary.org/wiki/Index#German) | index | /ˈɪndɛks/ · noun |
| [Knochen](https://en.wiktionary.org/wiki/Knochen#German) | bone | [ˈknɔχn̩] · noun |
| [Logik](https://en.wiktionary.org/wiki/Logik#German) | logic | /ˈloːɡɪk/ · noun |
| [digital](https://en.wiktionary.org/wiki/digital#German) | digital | /diɡiˈtaːl/ · adj |
| [Armut](https://en.wiktionary.org/wiki/Armut#German) | poverty | /ˈaʁmuːt/ · noun |
| [First](https://en.wiktionary.org/wiki/First#German) | ridge (of a roof) | /fɪʁst/ · noun |
| [House](https://en.wiktionary.org/wiki/House#German) | house music, house | /haʊ̯s/ · noun |
| [Leo](https://en.wiktionary.org/wiki/Leo#German) | base (a safe zone in the children's game of tag) | [ˈleːo] · noun |
| [fern](https://en.wiktionary.org/wiki/fern#German) | remote | /fɛʁn/ · adj |
| [power](https://en.wiktionary.org/wiki/power#German) | poor, miserable | /ˈpoːvər/ · adj |
| [werken](https://en.wiktionary.org/wiki/werken#German) | to do handicraft, especially woodwork | [ˈvɛʁkn̩] · verb |
| [Bonus](https://en.wiktionary.org/wiki/Bonus#German) | bonus (premium or advantage) | /ˈboːnʊs/ · noun |
| [Gras](https://en.wiktionary.org/wiki/Gras#German) | grass (plant) | /ɡʁaːs/ · noun |
| [Welle](https://en.wiktionary.org/wiki/Welle#German) | wave (of water) | /ˈvɛlə/ · noun |
| [blind](https://en.wiktionary.org/wiki/blind#German) | blind | /blɪnt/ · adj |
| [fangen](https://en.wiktionary.org/wiki/fangen#German) | to catch (grab something flying in the air) | /ˈfaŋən/ · verb |
| [Argument](https://en.wiktionary.org/wiki/Argument#German) | proof, reason, point | /arɡuˈmɛnt/ · noun |
| [Frühling](https://en.wiktionary.org/wiki/Fr%C3%BChling#German) | spring | /ˈfʁyːlɪŋ/ · noun |
| [Hobby](https://en.wiktionary.org/wiki/Hobby#German) | a hobby (activity) | /ˈhɔbi/ · noun |
| [Instrument](https://en.wiktionary.org/wiki/Instrument#German) | instrument | [ˌɪnstʁuˈmɛnt] · noun |
| [hmm](https://en.wiktionary.org/wiki/hmm#German) | elongated form of hm |  · intj |
| [mieten](https://en.wiktionary.org/wiki/mieten#German) | to hire, to rent | /ˈmiːtn̩/ · verb |
| [Lee](https://en.wiktionary.org/wiki/Lee#German) | leeward side of a ship (the side away from the wind direction) | /leː/ · noun |
| [Model](https://en.wiktionary.org/wiki/Model#German) | model | [ˈmɔ.dl̩] · noun |
| [Vielzahl](https://en.wiktionary.org/wiki/Vielzahl#German) | multitude | [ˈfiːlt͡saːl] · noun |
| [happy](https://en.wiktionary.org/wiki/happy#German) | glad; satisfied; momentarily happy | /ˈhɛpi/ · adj |
| [modern](https://en.wiktionary.org/wiki/modern#German) | to rot, to molder | /ˈmoːdɐn/ · verb |
| [Café](https://en.wiktionary.org/wiki/Caf%C3%A9#German) | a café, a coffee shop | /kaˈfeː/ · noun |
| [Detail](https://en.wiktionary.org/wiki/Detail#German) | detail | /deˈtaɪ̯/ · noun |
| [Journalist](https://en.wiktionary.org/wiki/Journalist#German) | journalist (male or of unspecified gender) | /ˌʒʊʁnaˈlɪst/ · noun |
| [Maul](https://en.wiktionary.org/wiki/Maul#German) | mouth of an animal | /maʊ̯l/ · noun |
| [SMS](https://en.wiktionary.org/wiki/SMS#German) | SMS (text message) | /ˌɛsʔɛmˈʔɛs/ · noun |
| [aufstehen](https://en.wiktionary.org/wiki/aufstehen#German) | to get up (move from a sitting or lying position to a standing position; to get up from bed) | /ˈʔaufˌʃteːən/ · verb |
| [Benjamin](https://en.wiktionary.org/wiki/Benjamin#German) | youngest child | /ˈbɛnjaˌmiːn/ · noun |
| [DJ](https://en.wiktionary.org/wiki/DJ#German) | DJ, disc jockey | /ˈdiːd͡ʒɛɪ̯/ · noun |
| [Diesel](https://en.wiktionary.org/wiki/Diesel#German) | diesel (vehicle powered by a diesel engine) | [ˈdiːzl̩] · noun |
| [Held](https://en.wiktionary.org/wiki/Held#German) | hero | /hɛlt/ · noun |
| [Lord](https://en.wiktionary.org/wiki/Lord#German) | lord, Lord (British nobleman) | /lɔrt/ · noun |
| [Maus](https://en.wiktionary.org/wiki/Maus#German) | mouse (animal) | /maʊ̯s/ · noun |
| [Monster](https://en.wiktionary.org/wiki/Monster#German) | monster | /ˈmɔnstər/ · noun |
| [just](https://en.wiktionary.org/wiki/just#German) | just | /jʊst/ · adv |
| [Bob](https://en.wiktionary.org/wiki/Bob#German) | bobsleigh, bob (sled used in the sport of bobsleigh) | /bɔp/ · noun |
| [Esse](https://en.wiktionary.org/wiki/Esse#German) | existence | /ˈɛsə/ · noun |
| [Fuchs](https://en.wiktionary.org/wiki/Fuchs#German) | fox (animal) | /fʊks/ · noun |

</details>

<details><summary>Words 651–700</summary>

![[Resources/Audio/de/Words 0651-0700.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [Ideal](https://en.wiktionary.org/wiki/Ideal#German) | ideal (perfect standard, standard of excellence) |  · noun |
| [Kilo](https://en.wiktionary.org/wiki/Kilo#German) | kilo | /ˈkiːlo/ · noun |
| [Kugel](https://en.wiktionary.org/wiki/Kugel#German) | a ball, usually solid | /ˈkuːɡəl/ · noun |
| [Zerstörung](https://en.wiktionary.org/wiki/Zerst%C3%B6rung#German) | destruction, demolition |  · noun |
| [ideal](https://en.wiktionary.org/wiki/ideal#German) | ideal (optimal, perfect) | /ideˈaːl/ · adj |
| [ungewöhnlich](https://en.wiktionary.org/wiki/ungew%C3%B6hnlich#German) | uncommon, unusual, unordinary | /ˈʊnɡəˌvøːnlɪç/ · adj |
| [Besetzung](https://en.wiktionary.org/wiki/Besetzung#German) | occupation; invasion (of a country) | /bəˈzɛtsʊŋ/ · noun |
| [Burger](https://en.wiktionary.org/wiki/Burger#German) | A burger; a hamburger, cheeseburger, or similar American-style sandwich. | /ˈbœʁɡɐ/ · noun |
| [Maler](https://en.wiktionary.org/wiki/Maler#German) | painter (artist who paints pictures) | /ˈmaːlər/ · noun |
| [aha](https://en.wiktionary.org/wiki/aha#German) | aha | /ʔaˈha/ · intj |
| [prima](https://en.wiktionary.org/wiki/prima#German) | great, super | [ˈpʁiːma] · adj |
| [schreien](https://en.wiktionary.org/wiki/schreien#German) | to shout; to yell; to cry; to scream; to howl | /ˈʃʁaɪ̯ən/ · verb |
| [à](https://en.wiktionary.org/wiki/%C3%A0#German) | at (a specified price or rate of exchange per item) | /aː/ · prep |
| [Adler](https://en.wiktionary.org/wiki/Adler#German) | eagle | /ˈaːdlər/ · noun |
| [Bogen](https://en.wiktionary.org/wiki/Bogen#German) | bow (weapon) | /ˈboːɡən/ · noun |
| [Faust](https://en.wiktionary.org/wiki/Faust#German) | fist | /faʊ̯st/ · noun |
| [Fonds](https://en.wiktionary.org/wiki/Fonds#German) | fund | /fɔ̃ː/ · noun |
| [Jazz](https://en.wiktionary.org/wiki/Jazz#German) | jazz (musical art form) | /d͡ʒɛ(ː)s/ · noun |
| [Koffer](https://en.wiktionary.org/wiki/Koffer#German) | a case; a suitcase or briefcase | /ˈkɔfɐ/ · noun |
| [Lob](https://en.wiktionary.org/wiki/Lob#German) | praise | /loːp/ · noun |
| [Luxus](https://en.wiktionary.org/wiki/Luxus#German) | luxury | /ˈlʊksʊs/ · noun |
| [Turm](https://en.wiktionary.org/wiki/Turm#German) | tower, spire (very tall building or structure, especially with a tapering top) | /tʊʁm/ · noun |
| [spanisch](https://en.wiktionary.org/wiki/spanisch#German) | Spanish | /ˈʃpaːnɪʃ/ · adj |
| [Außenminister](https://en.wiktionary.org/wiki/Au%C3%9Fenminister#German) | foreign minister (male or of unspecified gender) | [ˈʔaʊ̯sn̩miˌnɪstɐ] · noun |
| [Bande](https://en.wiktionary.org/wiki/Bande#German) | gang (group of people united for some immoral or criminal objective) | /ˈbandə/ · noun |
| [Boy](https://en.wiktionary.org/wiki/Boy#German) | bellboy; pageboy | /bɔɪ̯/ · noun |
| [Dom](https://en.wiktionary.org/wiki/Dom#German) | cathedral (church serving as seat of a bishop, by extension, any large church) | /doːm/ · noun |
| [Pfund](https://en.wiktionary.org/wiki/Pfund#German) | a metric pound, 500 grams, half a kilogram | /pfʊnt/ · noun |
| [down](https://en.wiktionary.org/wiki/down#German) | down, depressed |  · adj |
| [Beck](https://en.wiktionary.org/wiki/Beck#German) | baker |  · noun |
| [Budget](https://en.wiktionary.org/wiki/Budget#German) | budget | /byˈd͡ʒeː/ · noun |
| [Element](https://en.wiktionary.org/wiki/Element#German) | element | /e.leˈmɛnt/ · noun |
| [Miss](https://en.wiktionary.org/wiki/Miss#German) | Miss (form of address) | /mɪs/ · noun |
| [Tafel](https://en.wiktionary.org/wiki/Tafel#German) | panel, board (e.g., wooden panel) | /ˈtaːfl̩/ · noun |
| [erheben](https://en.wiktionary.org/wiki/erheben#German) | to raise, lift (one's arm, voice, glass, etc.) | [ʔɛʁˈheːbn̩] · verb |
| [fake](https://en.wiktionary.org/wiki/fake#German) | fake, sham, counterfeit | /fɛɪ̯k/ · adj |
| [global](https://en.wiktionary.org/wiki/global#German) | global (worldwide) | /ɡloˈbaːl/ · adj |
| [wider](https://en.wiktionary.org/wiki/wider#German) | against | /ˈviːdər/ · prep |
| [Funk](https://en.wiktionary.org/wiki/Funk#German) | radio (technology) | /fʊŋk/ · noun |
| [Klub](https://en.wiktionary.org/wiki/Klub#German) | The continuation of a political party in the National Council of Austria and the parliament of an Austrian federal state, in other parliaments called Fraktion | /klʊp/ · noun |
| [regional](https://en.wiktionary.org/wiki/regional#German) | regional | /ʁeɡi̯oˈnaːl/ · adj |
| [solo](https://en.wiktionary.org/wiki/solo#German) | alone |  · adj |
| [Basketball](https://en.wiktionary.org/wiki/Basketball#German) | basketball | /ˈbaːskətˌbal/ · noun |
| [Diagnose](https://en.wiktionary.org/wiki/Diagnose#German) | diagnosis |  · noun |
| [Green](https://en.wiktionary.org/wiki/Green#German) | green, putting green | /ɡʁiːn/ · noun |
| [Image](https://en.wiktionary.org/wiki/Image#German) | image (characteristic of a person, group or company etc., style, manner of dress, how one is, or wishes to be, perceived by others) | /ˈɪmɪt͡ʃ/ · noun |
| [Matt](https://en.wiktionary.org/wiki/Matt#German) | mate, checkmate | /mat/ · noun |
| [Medium](https://en.wiktionary.org/wiki/Medium#German) | media, medium (format for communicating or presenting information) | /ˈmeːdi̯ʊm/ · noun |
| [genial](https://en.wiktionary.org/wiki/genial#German) | genius, ingenious, genial (in the sense of genius) | /ɡeˈni̯aːl/ · adj |
| [matt](https://en.wiktionary.org/wiki/matt#German) | dull (not shiny) | /mat/ · adj |

</details>

<details><summary>Words 701–750</summary>

![[Resources/Audio/de/Words 0701-0750.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [orange](https://en.wiktionary.org/wiki/orange#German) | orange | /oˈʁãːʃ/ · adj |
| [schwul](https://en.wiktionary.org/wiki/schwul#German) | gay | /ʃvuːl/ · adj |
| [Abendessen](https://en.wiktionary.org/wiki/Abendessen#German) | dinner, supper (the evening meal) | [ˈʔaːbəntˌʔɛsn̩] · noun |
| [Episode](https://en.wiktionary.org/wiki/Episode#German) | episode (something that took place) | /epiˈzoːdə/ · noun |
| [Marine](https://en.wiktionary.org/wiki/Marine#German) | navy | /maˈʁiːnə/ · noun |
| [Panzer](https://en.wiktionary.org/wiki/Panzer#German) | armour, armour plating, shield | /ˈpant͡sər/ · noun |
| [Sau](https://en.wiktionary.org/wiki/Sau#German) | sow (female pig) | /zaʊ̯/ · noun |
| [Zelle](https://en.wiktionary.org/wiki/Zelle#German) | in a monastery or convent | /ˈtsɛlə/ · noun |
| [abendessen](https://en.wiktionary.org/wiki/abendessen#German) | to sup, to have supper (the evening meal) | /ˈaːbəntˌɛsən/ · verb |
| [premium](https://en.wiktionary.org/wiki/premium#German) | premium | /ˈpʁeːmi̯ʊm/ · adj |
| [à la](https://en.wiktionary.org/wiki/%C3%A0%20la#German) | à la |  · prep |
| [Experiment](https://en.wiktionary.org/wiki/Experiment#German) | experiment | /ɛkspeʁiˈmɛnt/ · noun |
| [Pflanze](https://en.wiktionary.org/wiki/Pflanze#German) | plant | /ˈpflan(t)sə/ · noun |
| [gewöhnlich](https://en.wiktionary.org/wiki/gew%C3%B6hnlich#German) | usual, normal, ordinary, everyday | /ɡəˈvøːnlɪç/ · adj |
| [illegal](https://en.wiktionary.org/wiki/illegal#German) | illegal | /ˈɪleɡaːl/ · adj |
| [Agenda](https://en.wiktionary.org/wiki/Agenda#German) | agenda (a temporally organized plan or list of things to be addressed) | /aˈɡɛnda/ · noun |
| [Eisen](https://en.wiktionary.org/wiki/Eisen#German) | iron (chemical element, Fe) | /ˈʔaɪ̯zn̩/ · noun |
| [Metal](https://en.wiktionary.org/wiki/Metal#German) | metal (music) |  · noun |
| [Nebel](https://en.wiktionary.org/wiki/Nebel#German) | fog, mist, haze | /ˈneːbəl/ · noun |
| [gemütlich](https://en.wiktionary.org/wiki/gem%C3%BCtlich#German) | cosy, gemütlich | /ɡəˈmyːtlɪç/ · adj |
| [Charlotte](https://en.wiktionary.org/wiki/Charlotte#German) | charlotte (dessert consisting of sponge cake filled with fruit) | /ʃaʁˈlɔtə/ · noun |
| [Datenbank](https://en.wiktionary.org/wiki/Datenbank#German) | database | /ˈdaːtn̩ˌbaŋk/ · noun |
| [Schlange](https://en.wiktionary.org/wiki/Schlange#German) | snake | /ˈʃlaŋə/ · noun |
| [Schwein](https://en.wiktionary.org/wiki/Schwein#German) | swine, pig | /ʃvaɪ̯n/ · noun |
| [auf Wiedersehen](https://en.wiktionary.org/wiki/auf%20Wiedersehen#German) | goodbye | /aʊ̯f ˈviːdɐˌzeː(ə)n/ · intj |
| [erwachsen](https://en.wiktionary.org/wiki/erwachsen#German) | to grow up, to grow |  · verb |
| [Alarm](https://en.wiktionary.org/wiki/Alarm#German) | alert, alarm | /aˈlaʁm/ · noun |
| [Cover](https://en.wiktionary.org/wiki/Cover#German) | cover version, cover song | [ˈkavɐ] · noun |
| [DNA](https://en.wiktionary.org/wiki/DNA#German) | DNA, synonym of Desoxyribonukleinsäure | [deːʔɛnˈʔaː] · noun |
| [Duo](https://en.wiktionary.org/wiki/Duo#German) | duo, pair |  · noun |
| [Gattung](https://en.wiktionary.org/wiki/Gattung#German) | type, kind, sort | /ˈɡatʊŋ/ · noun |
| [Journal](https://en.wiktionary.org/wiki/Journal#German) | magazine (non-academic publication, usually heavily illustrated) | /ʒʊrˈnaːl/ · noun |
| [Kai](https://en.wiktionary.org/wiki/Kai#German) | wharf, quay | /kaɪ̯/ · noun |
| [Kapitalismus](https://en.wiktionary.org/wiki/Kapitalismus#German) | capitalism | /ka.pi.taˈlɪs.mʊs/ · noun |
| [Schwert](https://en.wiktionary.org/wiki/Schwert#German) | sword | /ʃveːrt/ · noun |
| [Sehnsucht](https://en.wiktionary.org/wiki/Sehnsucht#German) | yearning, longing; pining | /ˈzeːnˌzʊxt/ · noun |
| [Cola](https://en.wiktionary.org/wiki/Cola#German) | Coke, Coca-Cola, cola (beverage made with caramel and carbonated water) | /ˈkoːla/ · noun |
| [Demonstration](https://en.wiktionary.org/wiki/Demonstration#German) | demonstration (act of demonstrating) | [demɔnstʁaˈt͡si̯oːn] · noun |
| [Entdeckung](https://en.wiktionary.org/wiki/Entdeckung#German) | discovery | [ʔɛntˈdɛkʊŋ(k)] · noun |
| [Filter](https://en.wiktionary.org/wiki/Filter#German) | filter (device that lets gases and fluids pass, but catches solid components) |  · noun |
| [Horn](https://en.wiktionary.org/wiki/Horn#German) | horn (musical instrument) | /hɔrn/ · noun |
| [Labor](https://en.wiktionary.org/wiki/Labor#German) | laboratory | [laˈboːɐ̯] · noun |
| [Migration](https://en.wiktionary.org/wiki/Migration#German) | migration |  · noun |
| [Russisch](https://en.wiktionary.org/wiki/Russisch#German) | thighing, intercrural sex | /ˈʁʊsɪʃ/ · noun |
| [circa](https://en.wiktionary.org/wiki/circa#German) | circa | [ˈt͡sɪʁka] · adv |
| [dünn](https://en.wiktionary.org/wiki/d%C3%BCnn#German) | thin, slender, slim | /dʏn/ · adj |
| [listen](https://en.wiktionary.org/wiki/listen#German) | to list | [ˈlɪstn̩] · verb |
| [nice](https://en.wiktionary.org/wiki/nice#German) | good, nice | /naɪ̯s/ · adj |
| [Ass](https://en.wiktionary.org/wiki/Ass#German) | ace (a playing card) | /as/ · noun |
| [Bestellung](https://en.wiktionary.org/wiki/Bestellung#German) | order, request for a product | /bəˈʃtɛlʊŋ/ · noun |

</details>

<details><summary>Words 751–800</summary>

![[Resources/Audio/de/Words 0751-0800.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [Marathon](https://en.wiktionary.org/wiki/Marathon#German) | marathon | /ˈmaʁatɔn/ · noun |
| [Mars](https://en.wiktionary.org/wiki/Mars#German) | crow's nest |  · noun |
| [Minus](https://en.wiktionary.org/wiki/Minus#German) | minus (negative quantity) | /ˈmiːnʊs/ · noun |
| [minus](https://en.wiktionary.org/wiki/minus#German) | minus, less | [ˈmiːnʊs] · adv |
| [Atem](https://en.wiktionary.org/wiki/Atem#German) | breath | /ˈaːtəm/ · noun |
| [Helm](https://en.wiktionary.org/wiki/Helm#German) | helmet | /hɛlm/ · noun |
| [Saudi](https://en.wiktionary.org/wiki/Saudi#German) | Saudi (person from Saudi-Arabia) | /ˈzaʊ̯di/ · noun |
| [Backen](https://en.wiktionary.org/wiki/Backen#German) | Substantivised form of backen: baking |  · noun |
| [Bass](https://en.wiktionary.org/wiki/Bass#German) | bass (low spectrum of sound) | /bas/ · noun |
| [Belohnung](https://en.wiktionary.org/wiki/Belohnung#German) | reward, bounty | /bəˈloːnʊŋ/ · noun |
| [Enkel](https://en.wiktionary.org/wiki/Enkel#German) | ankle | /ˈɛŋkəl/ · noun |
| [Ergänzung](https://en.wiktionary.org/wiki/Erg%C3%A4nzung#German) | supplement, addition, complement, supplementation | /ɛɐ̯ˈɡɛnt͡sʊŋ/ · noun |
| [Handball](https://en.wiktionary.org/wiki/Handball#German) | handball (Olympic team sport) | /ˈhantbal/ · noun |
| [LED](https://en.wiktionary.org/wiki/LED#German) | LED (light-emitting diode) | /ˌɛl ˌeː ˈdeː/ · noun |
| [Schuh](https://en.wiktionary.org/wiki/Schuh#German) | shoe | /ʃuː/ · noun |
| [backen](https://en.wiktionary.org/wiki/backen#German) | to bake; to roast | /ˈbakən/ · verb |
| [bass](https://en.wiktionary.org/wiki/bass#German) | greatly, totally, immensely; used with erstaunt (“astonished”) or, less often, other words expressing a sudden reaction/emotion | /bas/ · adv |
| [bitter](https://en.wiktionary.org/wiki/bitter#German) | bitter (having a bitter taste) | /ˈbɪ.tɐ/ · adj |
| [bunt](https://en.wiktionary.org/wiki/bunt#German) | multi-colored; colorful; variegated | /bʊnt/ · adj |
| [smart](https://en.wiktionary.org/wiki/smart#German) | smart (exhibiting social ability or cleverness) | /smaːɐ̯t/ · adj |
| [Echo](https://en.wiktionary.org/wiki/Echo#German) | echo (reflected sound) | /ˈɛço/ · noun |
| [Explosion](https://en.wiktionary.org/wiki/Explosion#German) | explosion | /ɛks.ploˈzjoːn/ · noun |
| [Garage](https://en.wiktionary.org/wiki/Garage#German) | garage (building used to store cars, tools, etc.) | /ɡaˈʁaːʒə/ · noun |
| [Hall](https://en.wiktionary.org/wiki/Hall#German) | echo, resonance, reverberation | /hal/ · noun |
| [Honig](https://en.wiktionary.org/wiki/Honig#German) | honey | /ˈhoːnɪç/ · noun |
| [legal](https://en.wiktionary.org/wiki/legal#German) | legal | [leːˈɡaːl] · adj |
| [mobil](https://en.wiktionary.org/wiki/mobil#German) | mobile | /moˈbiːl/ · adj |
| [royal](https://en.wiktionary.org/wiki/royal#German) | royal | /rɔˈjaːl/ · adj |
| [Blase](https://en.wiktionary.org/wiki/Blase#German) | bubble | /ˈblaːzə/ · noun |
| [Kuh](https://en.wiktionary.org/wiki/Kuh#German) | cow (female bovine animal at or near adulthood) | /kuː/ · noun |
| [dat](https://en.wiktionary.org/wiki/dat#German) | it | /dat/ · pron |
| [strafen](https://en.wiktionary.org/wiki/strafen#German) | to punish | [ˈʃtʁaːfn̩] · verb |
| [Amateur](https://en.wiktionary.org/wiki/Amateur#German) | amateur | [amaˈtøːɐ̯] · noun |
| [Apfel](https://en.wiktionary.org/wiki/Apfel#German) | apple (fruit) | /ˈapfəl/ · noun |
| [Gruß](https://en.wiktionary.org/wiki/Gru%C3%9F#German) | greeting | /ɡʁuːs/ · noun |
| [Holocaust](https://en.wiktionary.org/wiki/Holocaust#German) | a holocaust | /ˈhoːloˌkaʊ̯st/ · noun |
| [Orden](https://en.wiktionary.org/wiki/Orden#German) | order (awarded decoration) | /ˈɔʁdn̩/ · noun |
| [analog](https://en.wiktionary.org/wiki/analog#German) | analogous | /anaˈloːk/ · adj |
| [emotional](https://en.wiktionary.org/wiki/emotional#German) | emotional |  · adj |
| [ka](https://en.wiktionary.org/wiki/ka#German) | no idea (alternative spelling of k. A. – abbreviation of keine Ahnung) |  · phrase |
| [verschieden](https://en.wiktionary.org/wiki/verschieden#German) | different | /fɛɐ̯ˈʃiːdn̩/ · adj |
| [Browser](https://en.wiktionary.org/wiki/Browser#German) | A browser program | /ˈbʁaʊ̯zɐ/ · noun |
| [Fang](https://en.wiktionary.org/wiki/Fang#German) | catch, capture | /faŋ/ · noun |
| [Gift](https://en.wiktionary.org/wiki/Gift#German) | poison; toxin; venom | /ɡɪft/ · noun |
| [Jura](https://en.wiktionary.org/wiki/Jura#German) | law (study) |  · noun |
| [Sony](https://en.wiktionary.org/wiki/Sony#German) | Sony (a device produced by Sony) | /ˈzoːni/ · noun |
| [brav](https://en.wiktionary.org/wiki/brav#German) | good, well-behaved or reliable, obedient | /bʁaːf/ · adj |
| [fix](https://en.wiktionary.org/wiki/fix#German) | fixed (costs, salary) | [fɪks] · adj |
| [safe](https://en.wiktionary.org/wiki/safe#German) | safe | /sɛɪ̯f/ · adj |
| [ur](https://en.wiktionary.org/wiki/ur#German) | very, quite, really, total, totally, absolutely |  · adv |

</details>

<details><summary>Words 801–850</summary>

![[Resources/Audio/de/Words 0801-0850.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [Übersetzer](https://en.wiktionary.org/wiki/%C3%9Cbersetzer#German) | translator (one who translates completed texts; male or of unspecified sex) | /yːbərˈzɛtsər/ · noun |
| [Abt](https://en.wiktionary.org/wiki/Abt#German) | abbot | /apt/ · noun |
| [Alpha](https://en.wiktionary.org/wiki/Alpha#German) | alpha (Greek letter) | [ˈalfa] · noun |
| [Ausblick](https://en.wiktionary.org/wiki/Ausblick#German) | outlook, view, vista |  · noun |
| [Depression](https://en.wiktionary.org/wiki/Depression#German) | depression | /depʁɛˈsi̯oːn/ · noun |
| [Weisheit](https://en.wiktionary.org/wiki/Weisheit#German) | wisdom | /ˈvaɪ̯shaɪ̯t/ · noun |
| [hip](https://en.wiktionary.org/wiki/hip#German) | hip, trendy | /hɪp/ · adj |
| [widersprechen](https://en.wiktionary.org/wiki/widersprechen#German) | to object; to disagree | /ˌviːdɐˈʃpʁɛçn̩/ · verb |
| [Asche](https://en.wiktionary.org/wiki/Asche#German) | ash; ashes | /ˈaʃə/ · noun |
| [Bär](https://en.wiktionary.org/wiki/B%C3%A4r#German) | bear (animal) | /bɛːr/ · noun |
| [Christ](https://en.wiktionary.org/wiki/Christ#German) | a Christian | /kʁɪst/ · noun |
| [Dimension](https://en.wiktionary.org/wiki/Dimension#German) | dimension |  · noun |
| [Hardware](https://en.wiktionary.org/wiki/Hardware#German) | hardware | /ˈhaːɐ̯tvɛːɐ̯/ · noun |
| [brutal](https://en.wiktionary.org/wiki/brutal#German) | brutal | /bʁuˈtaːl/ · adj |
| [Fusion](https://en.wiktionary.org/wiki/Fusion#German) | merger (legal union of two or more corporations into a single entity) | /fuˈzi̯oːn/ · noun |
| [Hubschrauber](https://en.wiktionary.org/wiki/Hubschrauber#German) | helicopter | /ˈhuːpˌʃraʊ̯bər/ · noun |
| [Innovation](https://en.wiktionary.org/wiki/Innovation#German) | innovation |  · noun |
| [Manchester](https://en.wiktionary.org/wiki/Manchester#German) | synonym of Cord (“corduroy”) | /ˈmɛnt͡ʃɛstɐ/ · noun |
| [USB](https://en.wiktionary.org/wiki/USB#German) | USB |  · noun |
| [anonym](https://en.wiktionary.org/wiki/anonym#German) | anonymous | [ˌanoˈnyːm] · adj |
| [mutig](https://en.wiktionary.org/wiki/mutig#German) | courageous | /ˈmuːtɪç/ · adj |
| [permanent](https://en.wiktionary.org/wiki/permanent#German) | permanent | /pɛʁmaˈnɛnt/ · adj |
| [Anime](https://en.wiktionary.org/wiki/Anime#German) | anime (A style of art that originated in Japan) | /ˈanime/ · noun |
| [Baron](https://en.wiktionary.org/wiki/Baron#German) | baron | [baˈʁoːn] · noun |
| [Blitz](https://en.wiktionary.org/wiki/Blitz#German) | a bolt of lightning | /blɪts/ · noun |
| [Evolution](https://en.wiktionary.org/wiki/Evolution#German) | evolution | /ʔevoluˈtsi̯oːn/ · noun |
| [Kater](https://en.wiktionary.org/wiki/Kater#German) | tomcat, tom, male cat | /ˈkaː.tɐ/ · noun |
| [Made](https://en.wiktionary.org/wiki/Made#German) | maggot (soft, legless larva) | /ˈmaːdə/ · noun |
| [Zahn](https://en.wiktionary.org/wiki/Zahn#German) | tooth | /t͡saːn/ · noun |
| [anal](https://en.wiktionary.org/wiki/anal#German) | anal | /aˈnaːl/ · adj |
| [nu](https://en.wiktionary.org/wiki/nu#German) | yes; yeah; expresses agreement or understanding | [nɵ] · intj |
| [optimal](https://en.wiktionary.org/wiki/optimal#German) | optimal (perfect) | /ɔptiˈmaːl/ · adj |
| [Fotograf](https://en.wiktionary.org/wiki/Fotograf#German) | photographer | [fotoˈɡʀaːf] · noun |
| [Horizont](https://en.wiktionary.org/wiki/Horizont#German) | horizon (line where the sky appears to meet the earth; (figurative) range of someone’s thinking or insight) | /ho.ʁiˈtsɔnt/ · noun |
| [Zorn](https://en.wiktionary.org/wiki/Zorn#German) | anger; wrath | /tsɔrn/ · noun |
| [erleichtern](https://en.wiktionary.org/wiki/erleichtern#German) | to facilitate, make easier | /ʔɛɐ̯ˈlaɪ̯çtɐn/ · verb |
| [pink](https://en.wiktionary.org/wiki/pink#German) | coloured in a strong shade of pink | /pɪŋk/ · adj |
| [weiblich](https://en.wiktionary.org/wiki/weiblich#German) | female | /ˈvaɪ̯plɪç/ · adj |
| [Brett](https://en.wiktionary.org/wiki/Brett#German) | board, plank | /bʁɛt/ · noun |
| [Cannabis](https://en.wiktionary.org/wiki/Cannabis#German) | cannabis | /ˈkanabɪs/ · noun |
| [Diplom](https://en.wiktionary.org/wiki/Diplom#German) | diploma (higher education only, e.g., Master’s degree). |  · noun |
| [Division](https://en.wiktionary.org/wiki/Division#German) | division (arithmetic: process of dividing a number by another) | /diviˈzi̯oːn/ · noun |
| [Gabe](https://en.wiktionary.org/wiki/Gabe#German) | gift, present, donation, alms | /ˈɡaːbə/ · noun |
| [Horror](https://en.wiktionary.org/wiki/Horror#German) | horror | /ˈhɔroːr/ · noun |
| [Iris](https://en.wiktionary.org/wiki/Iris#German) | iris | /ˈiːʁɪs/ · noun |
| [Leber](https://en.wiktionary.org/wiki/Leber#German) | liver | /ˈleːbɐ/ · noun |
| [Londoner](https://en.wiktionary.org/wiki/Londoner#German) | A Londoner, a person from, or an inhabitant of, London (male or of unspecified gender). | /ˈlɔndɔnɐ/ · noun |
| [Schiedsrichter](https://en.wiktionary.org/wiki/Schiedsrichter#German) | judge, referee, umpire | /ˈʃiːt͡sˌʁɪçtɐ/ · noun |
| [absurd](https://en.wiktionary.org/wiki/absurd#German) | absurd | /apˈzʊʁt/ · adj |
| [urban](https://en.wiktionary.org/wiki/urban#German) | urban | /ʊʁˈbaːn/ · adj |

</details>

<details><summary>Words 851–900</summary>

![[Resources/Audio/de/Words 0851-0900.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [Blume](https://en.wiktionary.org/wiki/Blume#German) | flower (small, often woodless plant with blossoms; a stalk thereof) | /ˈbluːmə/ · noun |
| [Feststellung](https://en.wiktionary.org/wiki/Feststellung#German) | finding, assessment, discovery | /ˈfɛstˌʃtɛlʊŋ/ · noun |
| [Fleck](https://en.wiktionary.org/wiki/Fleck#German) | stain, spot, blot, fleck, smear | /flɛk/ · noun |
| [Hang](https://en.wiktionary.org/wiki/Hang#German) | slope, hill, hillside | /haŋ/ · noun |
| [Homo](https://en.wiktionary.org/wiki/Homo#German) | human | /ˈhoːmo/ · noun |
| [Zigarette](https://en.wiktionary.org/wiki/Zigarette#German) | cigarette | /ˌtsi(ː).ɡaˈʁɛ.tə/ · noun |
| [herein](https://en.wiktionary.org/wiki/herein#German) | in (in the direction of the speaker) | [hɛˈʁaɪ̯n] · adv |
| [vegan](https://en.wiktionary.org/wiki/vegan#German) | vegan | /veˈɡaːn/ · adj |
| [Chip](https://en.wiktionary.org/wiki/Chip#German) | chip | /tʃɪp/ · noun |
| [Flora](https://en.wiktionary.org/wiki/Flora#German) | flora (plants as a group; microorganisms) |  · noun |
| [Genie](https://en.wiktionary.org/wiki/Genie#German) | genius | /ʒeˈniː/ · noun |
| [His](https://en.wiktionary.org/wiki/His#German) | B-sharp |  · noun |
| [Inflation](https://en.wiktionary.org/wiki/Inflation#German) | inflation | [ɪnflaˈt͡si̯oːn] · noun |
| [New Yorker](https://en.wiktionary.org/wiki/New%20Yorker#German) | New Yorker (native or inhabitant of New York state or city) | /njuːˈjɔːkɐ/ · noun |
| [heilig](https://en.wiktionary.org/wiki/heilig#German) | holy |  · adj |
| [och](https://en.wiktionary.org/wiki/och#German) | expressing endearment, pity, consideration, etc. | /ɔx/ · intj |
| [Agent](https://en.wiktionary.org/wiki/Agent#German) | agent (male or of unspecified gender) (intermediary for certain services, such as for artistic performances or public relations) |  · noun |
| [Altar](https://en.wiktionary.org/wiki/Altar#German) | altar (table or similar structure used for religious rites) | /alˈtaː(ɐ̯)/ · noun |
| [Bit](https://en.wiktionary.org/wiki/Bit#German) | bit (eighth of a dollar) | /bɪt/ · noun |
| [Diabetes](https://en.wiktionary.org/wiki/Diabetes#German) | diabetes | /diaˈbeːtəs/ · noun |
| [Export](https://en.wiktionary.org/wiki/Export#German) | export (the act of exporting) | /ɛksˈpɔrt/ · noun |
| [Hacker](https://en.wiktionary.org/wiki/Hacker#German) | hacker | /ˈhɛkɐ/ · noun |
| [Junges](https://en.wiktionary.org/wiki/Junges#German) | nominalization of junges: the immature young of an animal species other than humans | [ˈjʊŋəs] · noun |
| [Steven](https://en.wiktionary.org/wiki/Steven#German) | stem. |  · noun |
| [final](https://en.wiktionary.org/wiki/final#German) | final, expressing purpose | /fiˈnaːl/ · adj |
| [human](https://en.wiktionary.org/wiki/human#German) | humane | /huˈmaːn/ · adj |
| [lose](https://en.wiktionary.org/wiki/lose#German) | loose, slack | /ˈloːzə/ · adj |
| [netto](https://en.wiktionary.org/wiki/netto#German) | net (as in net profit or net weight) |  · adv |
| [relevant](https://en.wiktionary.org/wiki/relevant#German) | relevant |  · adj |
| [After](https://en.wiktionary.org/wiki/After#German) | anus | /ˈaftɐ/ · noun |
| [Dose](https://en.wiktionary.org/wiki/Dose#German) | box (container made from metal or plastic, less often wood) | /ˈdoːzə/ · noun |
| [Feder](https://en.wiktionary.org/wiki/Feder#German) | feather | /ˈfeːdər/ · noun |
| [Fund](https://en.wiktionary.org/wiki/Fund#German) | discovery, finding, find (an instance of finding; something that is found) | /fʊnt/ · noun |
| [Genre](https://en.wiktionary.org/wiki/Genre#German) | genre |  · noun |
| [Mandat](https://en.wiktionary.org/wiki/Mandat#German) | mandate (official command) | /manˈdaːt/ · noun |
| [Monitor](https://en.wiktionary.org/wiki/Monitor#German) | monitor (display) | [ˈmoːnitoːɐ̯] · noun |
| [after](https://en.wiktionary.org/wiki/after#German) | after |  · prep |
| [golden](https://en.wiktionary.org/wiki/golden#German) | golden; gold (made of gold) | /ˈɡɔl.dən/ · adj |
| [homosexuell](https://en.wiktionary.org/wiki/homosexuell#German) | homosexual | /ˌhomozɛksuˈɛl/ · adj |
| [intelligent](https://en.wiktionary.org/wiki/intelligent#German) | intelligent | /ʔɪntɛliˈɡɛnt/ · adj |
| [überwachen](https://en.wiktionary.org/wiki/%C3%BCberwachen#German) | to control, to monitor, to supervise | /ˌyːbəʁˈvaχən/ · verb |
| [Angel](https://en.wiktionary.org/wiki/Angel#German) | tackle, fishing rod (angler's tool consisting of hook (Haken), line (Schnur), and rod (Rute)) | /ˈaŋəl/ · noun |
| [Assistent](https://en.wiktionary.org/wiki/Assistent#German) | assistant | /asɪstˈɛnt/ · noun |
| [Banner](https://en.wiktionary.org/wiki/Banner#German) | banner | /ˈbanɐ/ · noun |
| [Blues](https://en.wiktionary.org/wiki/Blues#German) | blues (musical form) | /bluːs/ · noun |
| [Container](https://en.wiktionary.org/wiki/Container#German) | a big container made of metal | /kɔnˈtɛːnɐ/ · noun |
| [Ego](https://en.wiktionary.org/wiki/Ego#German) | ego | /ˈeːɡo/ · noun |
| [Wörterbuch](https://en.wiktionary.org/wiki/W%C3%B6rterbuch#German) | dictionary (reference work with a list of words from one or more languages, and their definitions or translations) | /ˈvœʁtɐˌbuːx/ · noun |
| [mies](https://en.wiktionary.org/wiki/mies#German) | mean, wretched | /miːs/ · adj |
| [umfassen](https://en.wiktionary.org/wiki/umfassen#German) | to encompass | /ʔʊmˈfasn̩/ · verb |

</details>

<details><summary>Words 901–950</summary>

![[Resources/Audio/de/Words 0901-0950.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [übersetzen](https://en.wiktionary.org/wiki/%C3%BCbersetzen#German) | to translate, to interpret | /ˌyːbərˈzɛtsən/ · verb |
| [Fell](https://en.wiktionary.org/wiki/Fell#German) | fur, coat, pelt (hairy skin of an animal) | /fɛl/ · noun |
| [Fotze](https://en.wiktionary.org/wiki/Fotze#German) | cunt (vulva, also vagina) | /ˈfɔtsə/ · noun |
| [Frost](https://en.wiktionary.org/wiki/Frost#German) | frost; freezing weather (weather conditions below 0 °C) | /frɔst/ · noun |
| [Laser](https://en.wiktionary.org/wiki/Laser#German) | laser (beam of light) | /ˈlɛɪ̯zər/ · noun |
| [Löwe](https://en.wiktionary.org/wiki/L%C3%B6we#German) | lion | /ˈløːvə/ · noun |
| [RAM](https://en.wiktionary.org/wiki/RAM#German) | RAM (random-access memory) | /ʁam/ · noun |
| [Zahnarzt](https://en.wiktionary.org/wiki/Zahnarzt#German) | dentist | /ˈt͡saːnʔaɐ̯t͡st/ · noun |
| [neutral](https://en.wiktionary.org/wiki/neutral#German) | not taking sides, not joining alliances | /nɔʏ̯ˈtʁaːl/ · adj |
| [Aussprache](https://en.wiktionary.org/wiki/Aussprache#German) | pronunciation | /ˈaʊ̯sʃpʁaːxə/ · noun |
| [Räuber](https://en.wiktionary.org/wiki/R%C3%A4uber#German) | robber, thief | /ˈʁɔʏ̯bɐ/ · noun |
| [eigen](https://en.wiktionary.org/wiki/eigen#German) | own, peculiar or private to someone, idiosyncratic, proper or proprietary | /ˈaɪ̯ɡən/ · adj |
| [Ärztin](https://en.wiktionary.org/wiki/%C3%84rztin#German) | doctor, physician (female) |  · noun |
| [Aluminium](https://en.wiktionary.org/wiki/Aluminium#German) | aluminium (atomic number 13) | /aluˈmiːni̯ʊm/ · noun |
| [Beta](https://en.wiktionary.org/wiki/Beta#German) | beta (Greek letter) | /beːta/ · noun |
| [GPS](https://en.wiktionary.org/wiki/GPS#German) | GPS |  · noun |
| [Herd](https://en.wiktionary.org/wiki/Herd#German) | cooker; stove | /heːrt/ · noun |
| [List](https://en.wiktionary.org/wiki/List#German) | cunning, craft | /lɪst/ · noun |
| [Madame](https://en.wiktionary.org/wiki/Madame#German) | madam | /maˈdam/ · noun |
| [klettern](https://en.wiktionary.org/wiki/klettern#German) | to climb (e.g. up a tree) | /ˈklɛtɐn/ · verb |
| [Ar](https://en.wiktionary.org/wiki/Ar#German) | are (unit of area) | /aːɐ̯/ · noun |
| [Balance](https://en.wiktionary.org/wiki/Balance#German) | balance | /baˈlɑ̃ːs/ · noun |
| [Bann](https://en.wiktionary.org/wiki/Bann#German) | jurisdiction | /ban/ · noun |
| [Einstein](https://en.wiktionary.org/wiki/Einstein#German) | an Einstein (an extremely intelligent person) | /ˈaɪ̯nˌʃtaɪ̯n/ · noun |
| [Erika](https://en.wiktionary.org/wiki/Erika#German) | heath (genus Erica). |  · noun |
| [Farm](https://en.wiktionary.org/wiki/Farm#German) | farm (see usage notes) | /farm/ · noun |
| [Illusion](https://en.wiktionary.org/wiki/Illusion#German) | illusion | /ɪluˈzi̯oːn/ · noun |
| [AI](https://en.wiktionary.org/wiki/AI#German) | synonym of künstliche Intelligenz (“AI”) | /ɛɪ̯ ˈaɪ̯/ · noun |
| [Aufzug](https://en.wiktionary.org/wiki/Aufzug#German) | winding (of a watch) | /ˈʔaʊ̯ftsuːk/ · noun |
| [Cousin](https://en.wiktionary.org/wiki/Cousin#German) | male cousin | /kuˈzɛ̃/ · noun |
| [Inspiration](https://en.wiktionary.org/wiki/Inspiration#German) | inspiration (exercising an elevating or stimulating influence upon the intellect or emotions) | /ʔɪnspiʁaˈtsi̯oːn/ · noun |
| [Lade](https://en.wiktionary.org/wiki/Lade#German) | drawer |  · noun |
| [Mais](https://en.wiktionary.org/wiki/Mais#German) | maize; corn (US) | /maɪ̯s/ · noun |
| [unfair](https://en.wiktionary.org/wiki/unfair#German) | unfair | /ˈʊnˌfɛːr/ · adj |
| [Base](https://en.wiktionary.org/wiki/Base#German) | base (compound that will neutralize an acid) | /ˈbaːzə/ · noun |
| [Boom](https://en.wiktionary.org/wiki/Boom#German) | boom | /buːm/ · noun |
| [Doctor](https://en.wiktionary.org/wiki/Doctor#German) | Former spelling of Doktor which is no longer standard. |  · noun |
| [Frucht](https://en.wiktionary.org/wiki/Frucht#German) | fruit (seed-bearing part of a plant) | /frʊxt/ · noun |
| [Minimum](https://en.wiktionary.org/wiki/Minimum#German) | minimum | /ˈminimʊm/ · noun |
| [deep](https://en.wiktionary.org/wiki/deep#German) | deep (intellectually profound) | /ˈdiːp/ · adj |
| [solar](https://en.wiktionary.org/wiki/solar#German) | solar | /zoˈlaːɐ̯/ · adj |
| [ä](https://en.wiktionary.org/wiki/%C3%A4#German) | A letter of the German alphabet, written in the Latin script, the letter a with an umlaut. |  · noun |
| [Badewanne](https://en.wiktionary.org/wiki/Badewanne#German) | bathtub | /ˈbaːdəˌvanə/ · noun |
| [Clan](https://en.wiktionary.org/wiki/Clan#German) | clan |  · noun |
| [Cross](https://en.wiktionary.org/wiki/Cross#German) | groundstroke that is played diagonally | /kʁɔs/ · noun |
| [Gattin](https://en.wiktionary.org/wiki/Gattin#German) | married woman, wife; female form of Gatte | /ˈɡatɪn/ · noun |
| [Hygiene](https://en.wiktionary.org/wiki/Hygiene#German) | hygiene | /hyˈɡi̯eːnə/ · noun |
| [Latte](https://en.wiktionary.org/wiki/Latte#German) | batten; lath; slat (narrow board or strip, usually of wood) | /ˈlatə/ · noun |
| [Marina](https://en.wiktionary.org/wiki/Marina#German) | marina (harbor for small boats) | /maˈʁiːna/ · noun |
| [Säule](https://en.wiktionary.org/wiki/S%C3%A4ule#German) | column, pillar | /ˈzɔʏ̯lə/ · noun |

</details>

<details><summary>Words 951–1000</summary>

![[Resources/Audio/de/Words 0951-1000.mp3]]

| Word | English meaning | Pronunciation / class |
|---|---|---|
| [trans](https://en.wiktionary.org/wiki/trans#German) | trans, transgender | /tʁans/ · adj |
| [transparent](https://en.wiktionary.org/wiki/transparent#German) | translucent (allowing light to pass through) | /ˌtʁanspaˈʁɛnt/ · adj |
| [Dad](https://en.wiktionary.org/wiki/Dad#German) | dad; Dad | /dɛːt/ · noun |
| [Deck](https://en.wiktionary.org/wiki/Deck#German) | deck (of a ship or boat) | /dɛk/ · noun |
| [Delegation](https://en.wiktionary.org/wiki/Delegation#German) | delegation (act of delegating) | [deleɡaˈt͡si̯oːn] · noun |
| [Invasion](https://en.wiktionary.org/wiki/Invasion#German) | invasion | /ˌɪnvaˈzi̯oːn/ · noun |
| [Luke](https://en.wiktionary.org/wiki/Luke#German) | hatch (opening in the ceiling/floor of a room, in the deck of a ship, etc.) | /ˈluːkə/ · noun |
| [Matrix](https://en.wiktionary.org/wiki/Matrix#German) | matrix | /maːtrɪks/ · noun |
| [Mercedes-Benz](https://en.wiktionary.org/wiki/Mercedes-Benz#German) | Mercedes-Benz (car of that brand) |  · noun |
| [bestrafen](https://en.wiktionary.org/wiki/bestrafen#German) | to punish | /bəˈʃtʁaːfən/ · verb |
| [formal](https://en.wiktionary.org/wiki/formal#German) | formal (being in accord with established forms) | /fɔʁˈmaːl/ · adj |
| [tafeln](https://en.wiktionary.org/wiki/tafeln#German) | to feast | /ˈtaːfəln/ · verb |
| [Abkürzung](https://en.wiktionary.org/wiki/Abk%C3%BCrzung#German) | abbreviation | /ˈapˌkʏʁtsʊŋ/ · noun |
| [Atelier](https://en.wiktionary.org/wiki/Atelier#German) | studio (artist's or photographer's workshop) | /atəˈli̯eː/ · noun |
| [Drive](https://en.wiktionary.org/wiki/Drive#German) | drive (self-motivation) | /dʁaɪf/ · noun |
| [Expedition](https://en.wiktionary.org/wiki/Expedition#German) | expedition | /ʔɛkspediˈtsi̯oːn/ · noun |
| [Flut](https://en.wiktionary.org/wiki/Flut#German) | flow, flood, high tide (rising movement of the tide; the time around when it reaches its peak) | /fluːt/ · noun |
| [Husten](https://en.wiktionary.org/wiki/Husten#German) | cough | /ˈhuːstən/ · noun |
| [Massage](https://en.wiktionary.org/wiki/Massage#German) | massage | /maˈsaːʒə/ · noun |
| [Monarchie](https://en.wiktionary.org/wiki/Monarchie#German) | monarchy | /monaʁˈçiː/ · noun |
| [clever](https://en.wiktionary.org/wiki/clever#German) | clever | [ˈklɛvɐ] · adj |
| [erfordern](https://en.wiktionary.org/wiki/erfordern#German) | to necessitate, to require |  · verb |
| [husten](https://en.wiktionary.org/wiki/husten#German) | to cough | /ˈhuːstən/ · verb |
| [japanisch](https://en.wiktionary.org/wiki/japanisch#German) | Japanese (of or relating to Japan, the Japanese people, or the Japanese language) | /jaˈpaːnɪʃ/ · adj |
| [Adel](https://en.wiktionary.org/wiki/Adel#German) | nobility | /ˈaːdəl/ · noun |
| [Domain](https://en.wiktionary.org/wiki/Domain#German) | domain; domain name | /doˈmeɪ̯n/ · noun |
| [Investor](https://en.wiktionary.org/wiki/Investor#German) | investor | /ɪnˈvɛstoɐ/ · noun |
| [Käfer](https://en.wiktionary.org/wiki/K%C3%A4fer#German) | beetle | /ˈkɛː.fɐ/ · noun |
| [Lost](https://en.wiktionary.org/wiki/Lost#German) | mustard gas |  · noun |
| [Manga](https://en.wiktionary.org/wiki/Manga#German) | manga (comic originating in Japan) | /ˈmaŋ.ɡa/ · noun |
| [alias](https://en.wiktionary.org/wiki/alias#German) | alias, also known as | /ˈaːli̯as/ · adv |
| [bang](https://en.wiktionary.org/wiki/bang#German) | scared, frightened, afraid, fearful | /baŋ/ · adj |
| [kleben](https://en.wiktionary.org/wiki/kleben#German) | to glue | [ˈkleːbm̩] · verb |
| [lost](https://en.wiktionary.org/wiki/lost#German) | clueless, confused; lost; vain | /lɔst/ · adj |
| [Es-Dur](https://en.wiktionary.org/wiki/Es-Dur#German) | E-flat major |  · noun |
| [Essay](https://en.wiktionary.org/wiki/Essay#German) | essay, usually on scientific, cultural or sociological subjects for publication in a newspaper or magazine |  · noun |
| [Joint](https://en.wiktionary.org/wiki/Joint#German) | marijuana cigarette; joint | /dʒɔɪ̯nt/ · noun |
| [Karma](https://en.wiktionary.org/wiki/Karma#German) | karma | /ˈkaʀma/ · noun |
| [Lexikon](https://en.wiktionary.org/wiki/Lexikon#German) | reference book (a book, usually alphabetically ordered, in which definitions and facts can be looked up, such as an encyclopaedia, dictionary, etc.) | /ˈlɛksikɔn/ · noun |
| [Montage](https://en.wiktionary.org/wiki/Montage#German) | installation, mounting, construction | /mɔnˈtaːʒə/ · noun |
| [fame](https://en.wiktionary.org/wiki/fame#German) | famous, well-known (of a person) | /fɛɪ̯m/ · adj |
| [minimal](https://en.wiktionary.org/wiki/minimal#German) | minimal | /miniˈmaːl/ · adj |
| [prost](https://en.wiktionary.org/wiki/prost#German) | cheers (the usual toast when drinking alcohol) | /pʁoːst/ · intj |
| [universal](https://en.wiktionary.org/wiki/universal#German) | universal | /univɛʁˈzaːl/ · adj |
| [Celsius](https://en.wiktionary.org/wiki/Celsius#German) | Celsius | /ˈt͡sɛlzi̯ʊs/ · noun |
| [Ente](https://en.wiktionary.org/wiki/Ente#German) | duck (aquatic bird of the family Anatidae) | /ˈɛntə/ · noun |
| [Koran](https://en.wiktionary.org/wiki/Koran#German) | Qur'an | /koˈʁaːn/ · noun |
| [Kummer](https://en.wiktionary.org/wiki/Kummer#German) | grief, sorrow | /ˈkʊmɐ/ · noun |
| [Luftwaffe](https://en.wiktionary.org/wiki/Luftwaffe#German) | air force | /ˈlʊftˌvafə/ · noun |
| [Metro](https://en.wiktionary.org/wiki/Metro#German) | metro |  · noun |

</details>

## Question bank

Try before opening the answers. Different tasks use the same sentence to practise complementary skills. Open translation and explanation tasks can have valid alternatives.

### Articles in context · 50 questions

**de-Q0001 · Fill the gap**

Zwingen Sie mich nicht, ____ zu essen!

Don't make me eat this.

[[German#^de-Q0001-answer|Compare the answer]]
^de-Q0001

**de-Q0002 · Choose the form**

Zwingen Sie mich nicht, ____ zu essen!

Don't make me eat this.

Choices: die / das / der / den

[[German#^de-Q0002-answer|Compare the answer]]
^de-Q0002

**de-Q0003 · Edit the changed sentence**

【die】 Vater geht im Park spazieren.

My father is taking a walk in the park.

[[German#^de-Q0003-answer|Compare the answer]]
^de-Q0003

**de-Q0004 · Build the sentence**

Arrange: geht / spazieren. / im / Park / Vater / Der

My father is taking a walk in the park.

[[German#^de-Q0004-answer|Compare the answer]]
^de-Q0004

**de-Q0005 · Write a translation**

Write this in German: He was the only one drunk at the party.

[[German#^de-Q0005-answer|Compare the answer]]
^de-Q0005

**de-Q0006 · Explain the grammar**

Er war 【der】 einzige Betrunkene auf der Feier.

He was the only one drunk at the party.

[[German#^de-Q0006-answer|Compare the answer]]
^de-Q0006

**de-Q0007 · Fill the gap**

Anstatt aufzuhören, wurde ____ Regen stärker.

Instead of stopping, the rain increased.

[[German#^de-Q0007-answer|Compare the answer]]
^de-Q0007

**de-Q0008 · Choose the form**

Anstatt aufzuhören, wurde ____ Regen stärker.

Instead of stopping, the rain increased.

Choices: den / der / das / die

[[German#^de-Q0008-answer|Compare the answer]]
^de-Q0008

**de-Q0009 · Edit the changed sentence**

Jeder Satz, 【die】 mit "Ich bin kein Rassist, aber..." beginnt, ist höchstwahrscheinlich sehr rassistisch.

Every sentence that starts with "I'm not racist, but" is likely to be very racist indeed.

[[German#^de-Q0009-answer|Compare the answer]]
^de-Q0009

**de-Q0010 · Build the sentence**

Arrange: ist / Satz, / mit / Rassist, / Jeder / rassistisch. / beginnt, / kein / "Ich / höchstwahrscheinlich / sehr / der / bin / aber..."

Every sentence that starts with "I'm not racist, but" is likely to be very racist indeed.

[[German#^de-Q0010-answer|Compare the answer]]
^de-Q0010

**de-Q0011 · Write a translation**

Write this in German: Which school is the best?

[[German#^de-Q0011-answer|Compare the answer]]
^de-Q0011

**de-Q0012 · Explain the grammar**

Welche Schule ist 【die】 beste?

Which school is the best?

[[German#^de-Q0012-answer|Compare the answer]]
^de-Q0012

**de-Q0013 · Fill the gap**

Können ____ ihre Familien für sie sagen? Einige halten das für eine gute Idee.

Can their families say this for them? Some people think this is a good idea.

[[German#^de-Q0013-answer|Compare the answer]]
^de-Q0013

**de-Q0014 · Choose the form**

Können ____ ihre Familien für sie sagen? Einige halten das für eine gute Idee.

Can their families say this for them? Some people think this is a good idea.

Choices: den / die / der / das

[[German#^de-Q0014-answer|Compare the answer]]
^de-Q0014

**de-Q0015 · Edit the changed sentence**

【der】 verheißt nichts Gutes für unseren weiteren Dialog.

That does not augur well for the rest of our dialogue.

[[German#^de-Q0015-answer|Compare the answer]]
^de-Q0015

**de-Q0016 · Build the sentence**

Arrange: Dialog. / nichts / verheißt / für / Das / unseren / Gutes / weiteren

That does not augur well for the rest of our dialogue.

[[German#^de-Q0016-answer|Compare the answer]]
^de-Q0016

**de-Q0017 · Write a translation**

Write this in German: Do you want me to turn on the light?

[[German#^de-Q0017-answer|Compare the answer]]
^de-Q0017

**de-Q0018 · Explain the grammar**

Willst du, dass ich 【das】 Licht einschalte?

Do you want me to turn on the light?

[[German#^de-Q0018-answer|Compare the answer]]
^de-Q0018

**de-Q0019 · Fill the gap**

____ hast du nicht deutlich gemacht.

You didn't make it clear.

[[German#^de-Q0019-answer|Compare the answer]]
^de-Q0019

**de-Q0020 · Choose the form**

____ hast du nicht deutlich gemacht.

You didn't make it clear.

Choices: Das / der / die / den

[[German#^de-Q0020-answer|Compare the answer]]
^de-Q0020

**de-Q0021 · Edit the changed sentence**

Fünfzehn Jahre sind vergangen, seit wir 【der】 letzte Mal dort waren.

Fifteen years have passed since we went there last.

[[German#^de-Q0021-answer|Compare the answer]]
^de-Q0021

**de-Q0022 · Build the sentence**

Arrange: waren. / Fünfzehn / Jahre / dort / letzte / seit / Mal / sind / vergangen, / wir / das

Fifteen years have passed since we went there last.

[[German#^de-Q0022-answer|Compare the answer]]
^de-Q0022

**de-Q0023 · Write a translation**

Write this in German: Where do you want the piano?

[[German#^de-Q0023-answer|Compare the answer]]
^de-Q0023

**de-Q0024 · Explain the grammar**

Wo soll 【das】 Klavier hin?

Where do you want the piano?

[[German#^de-Q0024-answer|Compare the answer]]
^de-Q0024

**de-Q0025 · Fill the gap**

Er hatte ____ ganzen Tag nichts gegessen und war hungrig.

He hadn't eaten anything the whole day and was hungry.

[[German#^de-Q0025-answer|Compare the answer]]
^de-Q0025

**de-Q0026 · Choose the form**

Er hatte ____ ganzen Tag nichts gegessen und war hungrig.

He hadn't eaten anything the whole day and was hungry.

Choices: den / die / der / das

[[German#^de-Q0026-answer|Compare the answer]]
^de-Q0026

**de-Q0027 · Edit the changed sentence**

【der】 Zeit rinnt einfach wie die Körner des Meeressandes durch unsere Finger.

Time just slips through our fingers like the grains of sand found near the sea.

[[German#^de-Q0027-answer|Compare the answer]]
^de-Q0027

**de-Q0028 · Build the sentence**

Arrange: die / wie / Finger. / Die / des / durch / einfach / rinnt / Zeit / unsere / Meeressandes / Körner

Time just slips through our fingers like the grains of sand found near the sea.

[[German#^de-Q0028-answer|Compare the answer]]
^de-Q0028

**de-Q0029 · Write a translation**

Write this in German: Next Tuesday is a bank holiday.

[[German#^de-Q0029-answer|Compare the answer]]
^de-Q0029

**de-Q0030 · Explain the grammar**

【Der】 nächste Dienstag ist ein gesetzlicher Feiertag.

Next Tuesday is a bank holiday.

[[German#^de-Q0030-answer|Compare the answer]]
^de-Q0030

**de-Q0031 · Fill the gap**

____ Mann, der da drüben steht, ist Tom.

The man standing over there is Tom.

[[German#^de-Q0031-answer|Compare the answer]]
^de-Q0031

**de-Q0032 · Choose the form**

____ Mann, der da drüben steht, ist Tom.

The man standing over there is Tom.

Choices: den / das / Der / die

[[German#^de-Q0032-answer|Compare the answer]]
^de-Q0032

**de-Q0033 · Edit the changed sentence**

Er ist so groß, dass er 【der】 Decke berühren kann.

He is such a tall man that he can touch the ceiling.

[[German#^de-Q0033-answer|Compare the answer]]
^de-Q0033

**de-Q0034 · Build the sentence**

Arrange: Er / kann. / berühren / so / Decke / groß, / dass / die / ist / er

He is such a tall man that he can touch the ceiling.

[[German#^de-Q0034-answer|Compare the answer]]
^de-Q0034

**de-Q0035 · Write a translation**

Write this in German: Except for Tom, the family was all watching TV in silence.

[[German#^de-Q0035-answer|Compare the answer]]
^de-Q0035

**de-Q0036 · Explain the grammar**

Mit Ausnahme Toms sah 【die】 ganze Familie schweigend fern.

Except for Tom, the family was all watching TV in silence.

[[German#^de-Q0036-answer|Compare the answer]]
^de-Q0036

**de-Q0037 · Fill the gap**

Tom hat ____ Feuer gelöscht.

Tom extinguished the fire.

[[German#^de-Q0037-answer|Compare the answer]]
^de-Q0037

**de-Q0038 · Choose the form**

Tom hat ____ Feuer gelöscht.

Tom extinguished the fire.

Choices: die / den / das / der

[[German#^de-Q0038-answer|Compare the answer]]
^de-Q0038

**de-Q0039 · Edit the changed sentence**

Stell 【der】 Leiter an die Wand.

Place the ladder against the wall.

[[German#^de-Q0039-answer|Compare the answer]]
^de-Q0039

**de-Q0040 · Build the sentence**

Arrange: die / Stell / Wand. / die / Leiter / an

Place the ladder against the wall.

[[German#^de-Q0040-answer|Compare the answer]]
^de-Q0040

**de-Q0041 · Write a translation**

Write this in German: Are these your gloves?

[[German#^de-Q0041-answer|Compare the answer]]
^de-Q0041

**de-Q0042 · Explain the grammar**

Sind 【das】 hier deine Handschuhe?

Are these your gloves?

[[German#^de-Q0042-answer|Compare the answer]]
^de-Q0042

**de-Q0043 · Fill the gap**

____ Vertrag ist ungültig, wenn Sie zur Unterschrift gezwungen wurden.

The contract, if you were forced to sign it, is invalid.

[[German#^de-Q0043-answer|Compare the answer]]
^de-Q0043

**de-Q0044 · Choose the form**

____ Vertrag ist ungültig, wenn Sie zur Unterschrift gezwungen wurden.

The contract, if you were forced to sign it, is invalid.

Choices: Der / das / den / die

[[German#^de-Q0044-answer|Compare the answer]]
^de-Q0044

**de-Q0045 · Edit the changed sentence**

Sie könnte in 【die】 Lage sein, dir zu helfen.

She might be able to help you.

[[German#^de-Q0045-answer|Compare the answer]]
^de-Q0045

**de-Q0046 · Build the sentence**

Arrange: Sie / könnte / dir / in / helfen. / sein, / Lage / zu / der

She might be able to help you.

[[German#^de-Q0046-answer|Compare the answer]]
^de-Q0046

**de-Q0047 · Write a translation**

Write this in German: To make a long story short, we buried the hatchet.

[[German#^de-Q0047-answer|Compare the answer]]
^de-Q0047

**de-Q0048 · Explain the grammar**

【Der】 langen Rede kurzer Sinn: Wir haben das Kriegsbeil begraben.

To make a long story short, we buried the hatchet.

[[German#^de-Q0048-answer|Compare the answer]]
^de-Q0048

**de-Q0049 · Fill the gap**

„In dich war ich verliebt, nicht in Maria.“ – „Warum hast du mich ____ denn nie spüren lassen?“

"I fell in love with you, not Maria." - "Why have you not let me feel that?"

[[German#^de-Q0049-answer|Compare the answer]]
^de-Q0049

**de-Q0050 · Choose the form**

„In dich war ich verliebt, nicht in Maria.“ – „Warum hast du mich ____ denn nie spüren lassen?“

"I fell in love with you, not Maria." - "Why have you not let me feel that?"

Choices: der / das / die / den

[[German#^de-Q0050-answer|Compare the answer]]
^de-Q0050


### Indefinite articles · 50 questions

**de-Q0051 · Edit the changed sentence**

Japaner und Briten warten an Bushaltestellen normalerweise in 【ein】 Schlange.

Japanese and British people usually wait at a bus stop in a queue.

[[German#^de-Q0051-answer|Compare the answer]]
^de-Q0051

**de-Q0052 · Build the sentence**

Arrange: und / Schlange. / normalerweise / warten / Briten / an / Bushaltestellen / in / Japaner / einer

Japanese and British people usually wait at a bus stop in a queue.

[[German#^de-Q0052-answer|Compare the answer]]
^de-Q0052

**de-Q0053 · Write a translation**

Write this in German: I am used to driving a truck.

[[German#^de-Q0053-answer|Compare the answer]]
^de-Q0053

**de-Q0054 · Explain the grammar**

Ich bin es gewohnt, 【einen】 Lastwagen zu fahren.

I am used to driving a truck.

[[German#^de-Q0054-answer|Compare the answer]]
^de-Q0054

**de-Q0055 · Fill the gap**

Tom trägt ____ Sonnenbrille.

Tom is wearing sunglasses.

[[German#^de-Q0055-answer|Compare the answer]]
^de-Q0055

**de-Q0056 · Choose the form**

Tom trägt ____ Sonnenbrille.

Tom is wearing sunglasses.

Choices: eine / ein / einen / einem

[[German#^de-Q0056-answer|Compare the answer]]
^de-Q0056

**de-Q0057 · Edit the changed sentence**

Ich habe 【ein】 LKW.

I have a truck.

[[German#^de-Q0057-answer|Compare the answer]]
^de-Q0057

**de-Q0058 · Build the sentence**

Arrange: einen / LKW. / Ich / habe

I have a truck.

[[German#^de-Q0058-answer|Compare the answer]]
^de-Q0058

**de-Q0059 · Write a translation**

Write this in German: Tom never mentioned you once.

[[German#^de-Q0059-answer|Compare the answer]]
^de-Q0059

**de-Q0060 · Explain the grammar**

Tom hat dich nicht 【ein】 einziges Mal erwähnt.

Tom never mentioned you once.

[[German#^de-Q0060-answer|Compare the answer]]
^de-Q0060

**de-Q0061 · Fill the gap**

Ich habe ____ Treffen mit ihr um fünf Uhr am Bahnhof arrangiert.

I arranged a meeting on the train station with her at five o'clock

[[German#^de-Q0061-answer|Compare the answer]]
^de-Q0061

**de-Q0062 · Choose the form**

Ich habe ____ Treffen mit ihr um fünf Uhr am Bahnhof arrangiert.

I arranged a meeting on the train station with her at five o'clock

Choices: eine / ein / einem / einen

[[German#^de-Q0062-answer|Compare the answer]]
^de-Q0062

**de-Q0063 · Edit the changed sentence**

Was hältst du von 【ein】 Spaziergang?

How about taking a walk?

[[German#^de-Q0063-answer|Compare the answer]]
^de-Q0063

**de-Q0064 · Build the sentence**

Arrange: du / Spaziergang? / von / Was / hältst / einem

How about taking a walk?

[[German#^de-Q0064-answer|Compare the answer]]
^de-Q0064

**de-Q0065 · Write a translation**

Write this in German: Unfortunately, a Japanese dub of the film is not included on this DVD, but at least there are Japanese subtitles.

[[German#^de-Q0065-answer|Compare the answer]]
^de-Q0065

**de-Q0066 · Explain the grammar**

【Eine】 japanische Synchronisation des Films ist auf dieser DVD bedauerlicherweise nicht enthalten, aber immerhin gibt es japanische Untertitel.

Unfortunately, a Japanese dub of the film is not included on this DVD, but at least there are Japanese subtitles.

[[German#^de-Q0066-answer|Compare the answer]]
^de-Q0066

**de-Q0067 · Fill the gap**

In deinem Zimmer sieht es wie in ____ Saustall aus.

Your room looks like a pigsty.

[[German#^de-Q0067-answer|Compare the answer]]
^de-Q0067

**de-Q0068 · Choose the form**

In deinem Zimmer sieht es wie in ____ Saustall aus.

Your room looks like a pigsty.

Choices: einen / einem / eine / ein

[[German#^de-Q0068-answer|Compare the answer]]
^de-Q0068

**de-Q0069 · Edit the changed sentence**

Ich wusste, dass Tom 【ein】 Dummheit begehen würde.

I knew Tom would do something stupid.

[[German#^de-Q0069-answer|Compare the answer]]
^de-Q0069

**de-Q0070 · Build the sentence**

Arrange: Ich / Dummheit / Tom / wusste, / eine / würde. / dass / begehen

I knew Tom would do something stupid.

[[German#^de-Q0070-answer|Compare the answer]]
^de-Q0070

**de-Q0071 · Write a translation**

Write this in German: The dog pursued a rabbit into the forest.

[[German#^de-Q0071-answer|Compare the answer]]
^de-Q0071

**de-Q0072 · Explain the grammar**

Der Hund verfolgte 【ein】 Kaninchen in den Wald.

The dog pursued a rabbit into the forest.

[[German#^de-Q0072-answer|Compare the answer]]
^de-Q0072

**de-Q0073 · Fill the gap**

Das ist auch ____ guter Film.

That's a good movie, too.

[[German#^de-Q0073-answer|Compare the answer]]
^de-Q0073

**de-Q0074 · Choose the form**

Das ist auch ____ guter Film.

That's a good movie, too.

Choices: eine / einem / ein / einen

[[German#^de-Q0074-answer|Compare the answer]]
^de-Q0074

**de-Q0075 · Edit the changed sentence**

Das ist 【eine】 großer Fehler.

That's a big mistake.

[[German#^de-Q0075-answer|Compare the answer]]
^de-Q0075

**de-Q0076 · Build the sentence**

Arrange: ist / Fehler. / ein / Das / großer

That's a big mistake.

[[German#^de-Q0076-answer|Compare the answer]]
^de-Q0076

**de-Q0077 · Write a translation**

Write this in German: It's a democratic government.

[[German#^de-Q0077-answer|Compare the answer]]
^de-Q0077

**de-Q0078 · Explain the grammar**

Es handelt sich um 【eine】 demokratische Regierung.

It's a democratic government.

[[German#^de-Q0078-answer|Compare the answer]]
^de-Q0078

**de-Q0079 · Fill the gap**

Was du über Batman wissen musst, ist dies: Er ist ____ Superheld.

The thing you have to know about Batman is, he's a superhero.

[[German#^de-Q0079-answer|Compare the answer]]
^de-Q0079

**de-Q0080 · Choose the form**

Was du über Batman wissen musst, ist dies: Er ist ____ Superheld.

The thing you have to know about Batman is, he's a superhero.

Choices: ein / einen / einem / eine

[[German#^de-Q0080-answer|Compare the answer]]
^de-Q0080

**de-Q0081 · Edit the changed sentence**

Der Boden ist mit 【ein】 dicken Teppich bedeckt.

The floor is covered with a thick carpet.

[[German#^de-Q0081-answer|Compare the answer]]
^de-Q0081

**de-Q0082 · Build the sentence**

Arrange: Boden / mit / bedeckt. / ist / Der / Teppich / einem / dicken

The floor is covered with a thick carpet.

[[German#^de-Q0082-answer|Compare the answer]]
^de-Q0082

**de-Q0083 · Write a translation**

Write this in German: A bulldozer was used to level the lane.

[[German#^de-Q0083-answer|Compare the answer]]
^de-Q0083

**de-Q0084 · Explain the grammar**

【Ein】 Bulldozer wurde eingesetzt, um die Fahrbahn zu ebnen.

A bulldozer was used to level the lane.

[[German#^de-Q0084-answer|Compare the answer]]
^de-Q0084

**de-Q0085 · Fill the gap**

Man kann ____ Spiegel aus Metall oder Glas herstellen.

A mirror can be made out of metal or glass.

[[German#^de-Q0085-answer|Compare the answer]]
^de-Q0085

**de-Q0086 · Choose the form**

Man kann ____ Spiegel aus Metall oder Glas herstellen.

A mirror can be made out of metal or glass.

Choices: eine / ein / einem / einen

[[German#^de-Q0086-answer|Compare the answer]]
^de-Q0086

**de-Q0087 · Edit the changed sentence**

Ekkehard wünscht sich 【ein】 Modelleisenbahn zu Weihnachten.

Ekkehard wants a model train for Christmas.

[[German#^de-Q0087-answer|Compare the answer]]
^de-Q0087

**de-Q0088 · Build the sentence**

Arrange: sich / eine / wünscht / Ekkehard / zu / Modelleisenbahn / Weihnachten.

Ekkehard wants a model train for Christmas.

[[German#^de-Q0088-answer|Compare the answer]]
^de-Q0088

**de-Q0089 · Write a translation**

Write this in German: The man was no better than a horse.

[[German#^de-Q0089-answer|Compare the answer]]
^de-Q0089

**de-Q0090 · Explain the grammar**

Der Mann war nicht besser als 【ein】 Pferd.

The man was no better than a horse.

[[German#^de-Q0090-answer|Compare the answer]]
^de-Q0090

**de-Q0091 · Fill the gap**

Ich brauche ____ guten Rat.

I need some good advice.

[[German#^de-Q0091-answer|Compare the answer]]
^de-Q0091

**de-Q0092 · Choose the form**

Ich brauche ____ guten Rat.

I need some good advice.

Choices: einen / einem / ein / eine

[[German#^de-Q0092-answer|Compare the answer]]
^de-Q0092

**de-Q0093 · Edit the changed sentence**

Bist du schon zu 【ein】 Entscheidung gelangt?

Have you made your decision yet?

[[German#^de-Q0093-answer|Compare the answer]]
^de-Q0093

**de-Q0094 · Build the sentence**

Arrange: zu / einer / Bist / du / Entscheidung / schon / gelangt?

Have you made your decision yet?

[[German#^de-Q0094-answer|Compare the answer]]
^de-Q0094

**de-Q0095 · Write a translation**

Write this in German: It is one thing to know and another to teach.

[[German#^de-Q0095-answer|Compare the answer]]
^de-Q0095

**de-Q0096 · Explain the grammar**

Wissen ist 【eine】 Sache, unterrichten eine andere.

It is one thing to know and another to teach.

[[German#^de-Q0096-answer|Compare the answer]]
^de-Q0096

**de-Q0097 · Fill the gap**

____ Herr Jones ist gekommen, dich zu sehen.

A Mr Jones has come to see you.

[[German#^de-Q0097-answer|Compare the answer]]
^de-Q0097

**de-Q0098 · Choose the form**

____ Herr Jones ist gekommen, dich zu sehen.

A Mr Jones has come to see you.

Choices: einem / eine / Ein / einen

[[German#^de-Q0098-answer|Compare the answer]]
^de-Q0098

**de-Q0099 · Edit the changed sentence**

Jeden Freitagabend gingen sie 【ein】 trinken.

Every Friday night they went and got liquored up.

[[German#^de-Q0099-answer|Compare the answer]]
^de-Q0099

**de-Q0100 · Build the sentence**

Arrange: Jeden / trinken. / Freitagabend / einen / sie / gingen

Every Friday night they went and got liquored up.

[[German#^de-Q0100-answer|Compare the answer]]
^de-Q0100


### Personal pronoun forms · 50 questions

**de-Q0101 · Write a translation**

Write this in German: Have you made any New Year's resolutions?

[[German#^de-Q0101-answer|Compare the answer]]
^de-Q0101

**de-Q0102 · Explain the grammar**

Hast 【du】 Vorsätze fürs neue Jahr?

Have you made any New Year's resolutions?

[[German#^de-Q0102-answer|Compare the answer]]
^de-Q0102

**de-Q0103 · Fill the gap**

Tom gab seinen Freunden gegenüber damit an, mit wie vielen Mädchen ____ schon geschlafen habe.

Tom bragged to his friends about all the girls he had slept with.

[[German#^de-Q0103-answer|Compare the answer]]
^de-Q0103

**de-Q0104 · Choose the form**

Tom gab seinen Freunden gegenüber damit an, mit wie vielen Mädchen ____ schon geschlafen habe.

Tom bragged to his friends about all the girls he had slept with.

Choices: mir / er / mich / ich

[[German#^de-Q0104-answer|Compare the answer]]
^de-Q0104

**de-Q0105 · Edit the changed sentence**

【mich】 werde Tom nicht erlauben zu gehen.

I won't allow Tom to go.

[[German#^de-Q0105-answer|Compare the answer]]
^de-Q0105

**de-Q0106 · Build the sentence**

Arrange: Tom / erlauben / zu / werde / Ich / gehen. / nicht

I won't allow Tom to go.

[[German#^de-Q0106-answer|Compare the answer]]
^de-Q0106

**de-Q0107 · Write a translation**

Write this in German: You're respected by everybody.

[[German#^de-Q0107-answer|Compare the answer]]
^de-Q0107

**de-Q0108 · Explain the grammar**

【Du】 wirst von jedem respektiert.

You're respected by everybody.

[[German#^de-Q0108-answer|Compare the answer]]
^de-Q0108

**de-Q0109 · Fill the gap**

____ habe es nicht bemerkt.

I didn't notice it.

[[German#^de-Q0109-answer|Compare the answer]]
^de-Q0109

**de-Q0110 · Choose the form**

____ habe es nicht bemerkt.

I didn't notice it.

Choices: Ich / mir / du / mich

[[German#^de-Q0110-answer|Compare the answer]]
^de-Q0110

**de-Q0111 · Edit the changed sentence**

Bring 【ich】 meine Kleidung.

Bring me my clothes.

[[German#^de-Q0111-answer|Compare the answer]]
^de-Q0111

**de-Q0112 · Build the sentence**

Arrange: Kleidung. / mir / meine / Bring

Bring me my clothes.

[[German#^de-Q0112-answer|Compare the answer]]
^de-Q0112

**de-Q0113 · Write a translation**

Write this in German: I know precisely what you are feeling.

[[German#^de-Q0113-answer|Compare the answer]]
^de-Q0113

**de-Q0114 · Explain the grammar**

【Ich】 weiß genau, wie ihr euch fühlt.

I know precisely what you are feeling.

[[German#^de-Q0114-answer|Compare the answer]]
^de-Q0114

**de-Q0115 · Fill the gap**

____ will nicht zur Arbeit.

I don't want to go to work.

[[German#^de-Q0115-answer|Compare the answer]]
^de-Q0115

**de-Q0116 · Choose the form**

____ will nicht zur Arbeit.

I don't want to go to work.

Choices: mir / du / mich / Ich

[[German#^de-Q0116-answer|Compare the answer]]
^de-Q0116

**de-Q0117 · Edit the changed sentence**

Am Ende ist 【ich】 wieder zurück nach England gezogen.

In the end, she moved back to England.

[[German#^de-Q0117-answer|Compare the answer]]
^de-Q0117

**de-Q0118 · Build the sentence**

Arrange: England / zurück / sie / nach / Am / ist / gezogen. / wieder / Ende

In the end, she moved back to England.

[[German#^de-Q0118-answer|Compare the answer]]
^de-Q0118

**de-Q0119 · Write a translation**

Write this in German: I think we need to go back to Boston.

[[German#^de-Q0119-answer|Compare the answer]]
^de-Q0119

**de-Q0120 · Explain the grammar**

【Ich】 glaube, wir müssen zurück nach Boston gehen.

I think we need to go back to Boston.

[[German#^de-Q0120-answer|Compare the answer]]
^de-Q0120

**de-Q0121 · Fill the gap**

Haben ____ beide sich gut amüsiert, während ich fort war?

Did you two have fun while I was gone?

[[German#^de-Q0121-answer|Compare the answer]]
^de-Q0121

**de-Q0122 · Choose the form**

Haben ____ beide sich gut amüsiert, während ich fort war?

Did you two have fun while I was gone?

Choices: mir / Sie / ich / mich

[[German#^de-Q0122-answer|Compare the answer]]
^de-Q0122

**de-Q0123 · Edit the changed sentence**

【ich】 nannten sie Jane.

They named her Jane.

[[German#^de-Q0123-answer|Compare the answer]]
^de-Q0123

**de-Q0124 · Build the sentence**

Arrange: nannten / sie / Jane. / Sie

They named her Jane.

[[German#^de-Q0124-answer|Compare the answer]]
^de-Q0124

**de-Q0125 · Write a translation**

Write this in German: With the help of doctors, she got over her illness.

[[German#^de-Q0125-answer|Compare the answer]]
^de-Q0125

**de-Q0126 · Explain the grammar**

Mit ärztlicher Hilfe hat 【sie】 ihre Krankheit überwunden.

With the help of doctors, she got over her illness.

[[German#^de-Q0126-answer|Compare the answer]]
^de-Q0126

**de-Q0127 · Fill the gap**

Warum entschuldigt ____ euch nicht einfach?

Why don't you just apologize?

[[German#^de-Q0127-answer|Compare the answer]]
^de-Q0127

**de-Q0128 · Choose the form**

Warum entschuldigt ____ euch nicht einfach?

Why don't you just apologize?

Choices: ihr / mich / ich / mir

[[German#^de-Q0128-answer|Compare the answer]]
^de-Q0128

**de-Q0129 · Edit the changed sentence**

Könntest 【ich】 mir helfen, wenn ich umziehe?

Could you help me when I move?

[[German#^de-Q0129-answer|Compare the answer]]
^de-Q0129

**de-Q0130 · Build the sentence**

Arrange: mir / Könntest / helfen, / du / ich / wenn / umziehe?

Could you help me when I move?

[[German#^de-Q0130-answer|Compare the answer]]
^de-Q0130

**de-Q0131 · Write a translation**

Write this in German: No one was watching us.

[[German#^de-Q0131-answer|Compare the answer]]
^de-Q0131

**de-Q0132 · Explain the grammar**

Niemand beobachtete 【uns】.

No one was watching us.

[[German#^de-Q0132-answer|Compare the answer]]
^de-Q0132

**de-Q0133 · Fill the gap**

Urteilen ____ selbst!

Judge for yourself!

[[German#^de-Q0133-answer|Compare the answer]]
^de-Q0133

**de-Q0134 · Choose the form**

Urteilen ____ selbst!

Judge for yourself!

Choices: mir / mich / ich / Sie

[[German#^de-Q0134-answer|Compare the answer]]
^de-Q0134

**de-Q0135 · Edit the changed sentence**

【mich】 mache es nicht wie du.

I don't act like you.

[[German#^de-Q0135-answer|Compare the answer]]
^de-Q0135

**de-Q0136 · Build the sentence**

Arrange: nicht / du. / mache / Ich / wie / es

I don't act like you.

[[German#^de-Q0136-answer|Compare the answer]]
^de-Q0136

**de-Q0137 · Write a translation**

Write this in German: He comes home almost every weekend.

[[German#^de-Q0137-answer|Compare the answer]]
^de-Q0137

**de-Q0138 · Explain the grammar**

【Er】 kommt beinahe jedes Wochenende nach Hause.

He comes home almost every weekend.

[[German#^de-Q0138-answer|Compare the answer]]
^de-Q0138

**de-Q0139 · Fill the gap**

Falls ____ etwas brauchst, lass es mich wissen.

If you need anything, let me know.

[[German#^de-Q0139-answer|Compare the answer]]
^de-Q0139

**de-Q0140 · Choose the form**

Falls ____ etwas brauchst, lass es mich wissen.

If you need anything, let me know.

Choices: ich / mich / mir / du

[[German#^de-Q0140-answer|Compare the answer]]
^de-Q0140

**de-Q0141 · Edit the changed sentence**

【ich】 können doch fließend Französisch, oder?

You're fluent in French, right?

[[German#^de-Q0141-answer|Compare the answer]]
^de-Q0141

**de-Q0142 · Build the sentence**

Arrange: fließend / Sie / oder? / doch / können / Französisch,

You're fluent in French, right?

[[German#^de-Q0142-answer|Compare the answer]]
^de-Q0142

**de-Q0143 · Write a translation**

Write this in German: What you did made Tom cry.

[[German#^de-Q0143-answer|Compare the answer]]
^de-Q0143

**de-Q0144 · Explain the grammar**

【Du】 hast Tom damit zum Weinen gebracht.

What you did made Tom cry.

[[German#^de-Q0144-answer|Compare the answer]]
^de-Q0144

**de-Q0145 · Fill the gap**

____ haben zwei Ohren.

We have two ears.

[[German#^de-Q0145-answer|Compare the answer]]
^de-Q0145

**de-Q0146 · Choose the form**

____ haben zwei Ohren.

We have two ears.

Choices: ich / mir / mich / Wir

[[German#^de-Q0146-answer|Compare the answer]]
^de-Q0146

**de-Q0147 · Edit the changed sentence**

Töten ist verboten; jeder Mörder wird bestraft, es sei denn, 【ich】 hat gemeinsam mit vielen anderen Männern und zum Klang von Trompeten getötet.

Killing is forbidden; every murderer is punished, unless he has killed accompanied by many men and to the sound of trumpets.

[[German#^de-Q0147-answer|Compare the answer]]
^de-Q0147

**de-Q0148 · Build the sentence**

Arrange: Trompeten / jeder / Männern / hat / denn, / anderen / von / sei / wird / zum / Klang / mit / ist / verboten; / vielen / und / Mörder / getötet. / er / gemeinsam / es / bestraft, / Töten

Killing is forbidden; every murderer is punished, unless he has killed accompanied by many men and to the sound of trumpets.

[[German#^de-Q0148-answer|Compare the answer]]
^de-Q0148

**de-Q0149 · Write a translation**

Write this in German: I think we're going on vacation in June.

[[German#^de-Q0149-answer|Compare the answer]]
^de-Q0149

**de-Q0150 · Explain the grammar**

【Ich】 glaube, dass wir im Juni in Urlaub fahren.

I think we're going on vacation in June.

[[German#^de-Q0150-answer|Compare the answer]]
^de-Q0150


### Adjectives in noun phrases · 50 questions

**de-Q0151 · Fill the gap**

Tom verglich ein drei Jahre ____ Foto von Mary mit einem aktuellen.

Tom compared a picture taken of Mary three years ago with one that had been taken recently.

[[German#^de-Q0151-answer|Compare the answer]]
^de-Q0151

**de-Q0152 · Choose the form**

Tom verglich ein drei Jahre ____ Foto von Mary mit einem aktuellen.

Tom compared a picture taken of Mary three years ago with one that had been taken recently.

Choices: altes / gute / guten / gutem

[[German#^de-Q0152-answer|Compare the answer]]
^de-Q0152

**de-Q0153 · Edit the changed sentence**

Zuerst fiel mir das 【gute】 Sofa auf. Der Lederbezug war in einem schlichten Farbton gehalten, die Sitzfläche und Rückenlehne sahen bequem aus.

The first thing that came to my attention was the large sofa. It was covered in sober coloured leather, the seat and the back both looked wide and comfortable.

[[German#^de-Q0153-answer|Compare the answer]]
^de-Q0153

**de-Q0154 · Build the sentence**

Arrange: das / bequem / Sofa / aus. / einem / mir / gehalten, / Sitzfläche / Zuerst / in / und / fiel / schlichten / Lederbezug / auf. / große / war / die / Farbton / Rückenlehne / sahen / Der

The first thing that came to my attention was the large sofa. It was covered in sober coloured leather, the seat and the back both looked wide and comfortable.

[[German#^de-Q0154-answer|Compare the answer]]
^de-Q0154

**de-Q0155 · Write a translation**

Write this in German: These good times won't last long.

[[German#^de-Q0155-answer|Compare the answer]]
^de-Q0155

**de-Q0156 · Explain the grammar**

Diese 【gute】 Zeit wird nicht lange währen.

These good times won't last long.

[[German#^de-Q0156-answer|Compare the answer]]
^de-Q0156

**de-Q0157 · Fill the gap**

Kannst du ein ____ Buch empfehlen?

Can you recommend a good book?

[[German#^de-Q0157-answer|Compare the answer]]
^de-Q0157

**de-Q0158 · Choose the form**

Kannst du ein ____ Buch empfehlen?

Can you recommend a good book?

Choices: guten / gutem / gutes / gute

[[German#^de-Q0158-answer|Compare the answer]]
^de-Q0158

**de-Q0159 · Edit the changed sentence**

In deinem 【gute】 war ich bereits verheiratet.

When I was your age, I was already married.

[[German#^de-Q0159-answer|Compare the answer]]
^de-Q0159

**de-Q0160 · Build the sentence**

Arrange: In / Alter / bereits / verheiratet. / deinem / ich / war

When I was your age, I was already married.

[[German#^de-Q0160-answer|Compare the answer]]
^de-Q0160

**de-Q0161 · Write a translation**

Write this in German: I live close to an old bookshop.

[[German#^de-Q0161-answer|Compare the answer]]
^de-Q0161

**de-Q0162 · Explain the grammar**

Ich wohne in der Nähe eines 【alten】 Buchladens.

I live close to an old bookshop.

[[German#^de-Q0162-answer|Compare the answer]]
^de-Q0162

**de-Q0163 · Fill the gap**

Alles über Ernährung zu lernen ist genauso schwer, wie eine ____ Sprache zu lernen.

Learning everything about diet and nutrition is as difficult as learning a new language.

[[German#^de-Q0163-answer|Compare the answer]]
^de-Q0163

**de-Q0164 · Choose the form**

Alles über Ernährung zu lernen ist genauso schwer, wie eine ____ Sprache zu lernen.

Learning everything about diet and nutrition is as difficult as learning a new language.

Choices: neue / guten / gute / gutem

[[German#^de-Q0164-answer|Compare the answer]]
^de-Q0164

**de-Q0165 · Edit the changed sentence**

Tom ist immer noch ein sehr 【gute】 Tennisspieler.

Tom is still a very good tennis player.

[[German#^de-Q0165-answer|Compare the answer]]
^de-Q0165

**de-Q0166 · Build the sentence**

Arrange: noch / ein / ist / Tennisspieler. / immer / guter / sehr / Tom

Tom is still a very good tennis player.

[[German#^de-Q0166-answer|Compare the answer]]
^de-Q0166

**de-Q0167 · Write a translation**

Write this in German: She's a head shorter than I am.

[[German#^de-Q0167-answer|Compare the answer]]
^de-Q0167

**de-Q0168 · Explain the grammar**

Sie ist einen Kopf 【kleiner】 als ich.

She's a head shorter than I am.

[[German#^de-Q0168-answer|Compare the answer]]
^de-Q0168

**de-Q0169 · Fill the gap**

Viele ____ japanische Unternehmen sind vom Export abhängig.

Many large Japanese companies depend on exports.

[[German#^de-Q0169-answer|Compare the answer]]
^de-Q0169

**de-Q0170 · Choose the form**

Viele ____ japanische Unternehmen sind vom Export abhängig.

Many large Japanese companies depend on exports.

Choices: gutem / gute / große / guten

[[German#^de-Q0170-answer|Compare the answer]]
^de-Q0170

**de-Q0171 · Edit the changed sentence**

Ich mache mir 【gute】 Sorgen um euch.

I'm very worried about you.

[[German#^de-Q0171-answer|Compare the answer]]
^de-Q0171

**de-Q0172 · Build the sentence**

Arrange: mache / große / Ich / mir / Sorgen / um / euch.

I'm very worried about you.

[[German#^de-Q0172-answer|Compare the answer]]
^de-Q0172

**de-Q0173 · Write a translation**

Write this in German: She takes care of her old mother.

[[German#^de-Q0173-answer|Compare the answer]]
^de-Q0173

**de-Q0174 · Explain the grammar**

Sie passt auf ihre 【alte】 Mutter auf.

She takes care of her old mother.

[[German#^de-Q0174-answer|Compare the answer]]
^de-Q0174

**de-Q0175 · Fill the gap**

Wie können wir ____ Leute treffen?

How can we meet new people?

[[German#^de-Q0175-answer|Compare the answer]]
^de-Q0175

**de-Q0176 · Choose the form**

Wie können wir ____ Leute treffen?

How can we meet new people?

Choices: gutem / neue / guten / gute

[[German#^de-Q0176-answer|Compare the answer]]
^de-Q0176

**de-Q0177 · Edit the changed sentence**

Ihr 【gute】 Kleid gefällt ihr.

She's pleased with her new dress.

[[German#^de-Q0177-answer|Compare the answer]]
^de-Q0177

**de-Q0178 · Build the sentence**

Arrange: Ihr / gefällt / ihr. / neues / Kleid

She's pleased with her new dress.

[[German#^de-Q0178-answer|Compare the answer]]
^de-Q0178

**de-Q0179 · Write a translation**

Write this in German: The boy gathered a handful of peanuts and put them in a small box.

[[German#^de-Q0179-answer|Compare the answer]]
^de-Q0179

**de-Q0180 · Explain the grammar**

Der Junge sammelte eine Handvoll Erdnüsse und legte sie in eine 【kleine】 Schachtel.

The boy gathered a handful of peanuts and put them in a small box.

[[German#^de-Q0180-answer|Compare the answer]]
^de-Q0180

**de-Q0181 · Fill the gap**

Insekten sind sehr nahrhaft und eine ____ Eiweißquelle.

Insects are very nutritious and a good source of protein.

[[German#^de-Q0181-answer|Compare the answer]]
^de-Q0181

**de-Q0182 · Choose the form**

Insekten sind sehr nahrhaft und eine ____ Eiweißquelle.

Insects are very nutritious and a good source of protein.

Choices: guter / gute / gutem / guten

[[German#^de-Q0182-answer|Compare the answer]]
^de-Q0182

**de-Q0183 · Edit the changed sentence**

Das Erdbeben beschädigte viele 【gute】 Gebäude.

The earthquake damaged many old buildings.

[[German#^de-Q0183-answer|Compare the answer]]
^de-Q0183

**de-Q0184 · Build the sentence**

Arrange: viele / Gebäude. / Das / beschädigte / Erdbeben / alte

The earthquake damaged many old buildings.

[[German#^de-Q0184-answer|Compare the answer]]
^de-Q0184

**de-Q0185 · Write a translation**

Write this in German: He offered ten dollars for our old radio.

[[German#^de-Q0185-answer|Compare the answer]]
^de-Q0185

**de-Q0186 · Explain the grammar**

Er bot uns zehn Dollar für unser 【altes】 Radio.

He offered ten dollars for our old radio.

[[German#^de-Q0186-answer|Compare the answer]]
^de-Q0186

**de-Q0187 · Fill the gap**

Es war für sie eine ____ Erfahrung.

It was a new experience for her.

[[German#^de-Q0187-answer|Compare the answer]]
^de-Q0187

**de-Q0188 · Choose the form**

Es war für sie eine ____ Erfahrung.

It was a new experience for her.

Choices: neue / gute / guten / gutem

[[German#^de-Q0188-answer|Compare the answer]]
^de-Q0188

**de-Q0189 · Edit the changed sentence**

Alle 【gute】 Kinder weinen.

All babies cry.

[[German#^de-Q0189-answer|Compare the answer]]
^de-Q0189

**de-Q0190 · Build the sentence**

Arrange: Kinder / weinen. / Alle / kleinen

All babies cry.

[[German#^de-Q0190-answer|Compare the answer]]
^de-Q0190

**de-Q0191 · Write a translation**

Write this in German: I want to tell you a little story.

[[German#^de-Q0191-answer|Compare the answer]]
^de-Q0191

**de-Q0192 · Explain the grammar**

Ich will euch einmal eine 【kleine】 Geschichte erzählen.

I want to tell you a little story.

[[German#^de-Q0192-answer|Compare the answer]]
^de-Q0192

**de-Q0193 · Fill the gap**

Sie ist eine ____, wohlproportionierte Blondine mit blauen Augen.

She's a tall, statuesque blonde with blue eyes.

[[German#^de-Q0193-answer|Compare the answer]]
^de-Q0193

**de-Q0194 · Choose the form**

Sie ist eine ____, wohlproportionierte Blondine mit blauen Augen.

She's a tall, statuesque blonde with blue eyes.

Choices: große / gutem / gute / guten

[[German#^de-Q0194-answer|Compare the answer]]
^de-Q0194

**de-Q0195 · Edit the changed sentence**

Er ist ein sehr 【gute】 Musiker.

He's a very fine musician.

[[German#^de-Q0195-answer|Compare the answer]]
^de-Q0195

**de-Q0196 · Build the sentence**

Arrange: guter / Musiker. / Er / ein / sehr / ist

He's a very fine musician.

[[German#^de-Q0196-answer|Compare the answer]]
^de-Q0196

**de-Q0197 · Write a translation**

Write this in German: I guess you have your reasons for being angry.

[[German#^de-Q0197-answer|Compare the answer]]
^de-Q0197

**de-Q0198 · Explain the grammar**

Du hast sicher 【gute】 Gründe, ärgerlich zu sein.

I guess you have your reasons for being angry.

[[German#^de-Q0198-answer|Compare the answer]]
^de-Q0198

**de-Q0199 · Fill the gap**

Wie finden Sie seinen ____ Roman?

How do you find his new novel?

[[German#^de-Q0199-answer|Compare the answer]]
^de-Q0199

**de-Q0200 · Choose the form**

Wie finden Sie seinen ____ Roman?

How do you find his new novel?

Choices: guten / neuen / gute / gutem

[[German#^de-Q0200-answer|Compare the answer]]
^de-Q0200


### Present forms of sein · 50 questions

**de-Q0201 · Edit the changed sentence**

Warum 【bin】 einige Übersetzungen ausgegraut?

Why are some translations in grey?

[[German#^de-Q0201-answer|Compare the answer]]
^de-Q0201

**de-Q0202 · Build the sentence**

Arrange: sind / Warum / Übersetzungen / ausgegraut? / einige

Why are some translations in grey?

[[German#^de-Q0202-answer|Compare the answer]]
^de-Q0202

**de-Q0203 · Write a translation**

Write this in German: Tom is lazy.

[[German#^de-Q0203-answer|Compare the answer]]
^de-Q0203

**de-Q0204 · Explain the grammar**

Tom 【ist】 faul.

Tom is lazy.

[[German#^de-Q0204-answer|Compare the answer]]
^de-Q0204

**de-Q0205 · Fill the gap**

Tom ____ ziemlich sarkastisch.

Tom is quite sarcastic.

[[German#^de-Q0205-answer|Compare the answer]]
^de-Q0205

**de-Q0206 · Choose the form**

Tom ____ ziemlich sarkastisch.

Tom is quite sarcastic.

Choices: ist / sind / bist / bin

[[German#^de-Q0206-answer|Compare the answer]]
^de-Q0206

**de-Q0207 · Edit the changed sentence**

Es 【bin】 unklar wie viele von ihnen überlebt haben.

How many of them survived is not known.

[[German#^de-Q0207-answer|Compare the answer]]
^de-Q0207

**de-Q0208 · Build the sentence**

Arrange: haben. / ihnen / unklar / Es / ist / viele / von / wie / überlebt

How many of them survived is not known.

[[German#^de-Q0208-answer|Compare the answer]]
^de-Q0208

**de-Q0209 · Write a translation**

Write this in German: What's the use?

[[German#^de-Q0209-answer|Compare the answer]]
^de-Q0209

**de-Q0210 · Explain the grammar**

Zu was 【ist】 es gut?

What's the use?

[[German#^de-Q0210-answer|Compare the answer]]
^de-Q0210

**de-Q0211 · Fill the gap**

Sie ____ größer, als ich mir Sie vorgestellt habe.

You're taller than I imagined you'd be.

[[German#^de-Q0211-answer|Compare the answer]]
^de-Q0211

**de-Q0212 · Choose the form**

Sie ____ größer, als ich mir Sie vorgestellt habe.

You're taller than I imagined you'd be.

Choices: bin / sind / ist / bist

[[German#^de-Q0212-answer|Compare the answer]]
^de-Q0212

**de-Q0213 · Edit the changed sentence**

Sie 【bin】 kein Feigling.

You are not a coward.

[[German#^de-Q0213-answer|Compare the answer]]
^de-Q0213

**de-Q0214 · Build the sentence**

Arrange: kein / sind / Feigling. / Sie

You are not a coward.

[[German#^de-Q0214-answer|Compare the answer]]
^de-Q0214

**de-Q0215 · Write a translation**

Write this in German: We are happy to see you again.

[[German#^de-Q0215-answer|Compare the answer]]
^de-Q0215

**de-Q0216 · Explain the grammar**

Wir 【sind】 froh, dass du wieder da bist.

We are happy to see you again.

[[German#^de-Q0216-answer|Compare the answer]]
^de-Q0216

**de-Q0217 · Fill the gap**

Wie groß ____ die Bevölkerung Japans?

What is the population of Japan?

[[German#^de-Q0217-answer|Compare the answer]]
^de-Q0217

**de-Q0218 · Choose the form**

Wie groß ____ die Bevölkerung Japans?

What is the population of Japan?

Choices: sind / ist / bist / bin

[[German#^de-Q0218-answer|Compare the answer]]
^de-Q0218

**de-Q0219 · Edit the changed sentence**

Hunde 【bin】 edle Wesen.

Dogs are noble creatures.

[[German#^de-Q0219-answer|Compare the answer]]
^de-Q0219

**de-Q0220 · Build the sentence**

Arrange: edle / sind / Wesen. / Hunde

Dogs are noble creatures.

[[German#^de-Q0220-answer|Compare the answer]]
^de-Q0220

**de-Q0221 · Write a translation**

Write this in German: Which is the most populated continent in the world?

[[German#^de-Q0221-answer|Compare the answer]]
^de-Q0221

**de-Q0222 · Explain the grammar**

Was 【ist】 der bevölkerungsreichste Kontinent der Welt?

Which is the most populated continent in the world?

[[German#^de-Q0222-answer|Compare the answer]]
^de-Q0222

**de-Q0223 · Fill the gap**

Das Baby weint. Ich glaube, es ____ krank.

The baby is crying. I think it is sick.

[[German#^de-Q0223-answer|Compare the answer]]
^de-Q0223

**de-Q0224 · Choose the form**

Das Baby weint. Ich glaube, es ____ krank.

The baby is crying. I think it is sick.

Choices: ist / bist / sind / bin

[[German#^de-Q0224-answer|Compare the answer]]
^de-Q0224

**de-Q0225 · Edit the changed sentence**

Die Katze 【bin】 schwarz.

The cat is black.

[[German#^de-Q0225-answer|Compare the answer]]
^de-Q0225

**de-Q0226 · Build the sentence**

Arrange: schwarz. / ist / Die / Katze

The cat is black.

[[German#^de-Q0226-answer|Compare the answer]]
^de-Q0226

**de-Q0227 · Write a translation**

Write this in German: Tom is in the building.

[[German#^de-Q0227-answer|Compare the answer]]
^de-Q0227

**de-Q0228 · Explain the grammar**

Tom 【ist】 im Gebäude.

Tom is in the building.

[[German#^de-Q0228-answer|Compare the answer]]
^de-Q0228

**de-Q0229 · Fill the gap**

Ich frage mich, wie es ____, reich zu sein.

I wonder what it feels like to be rich.

[[German#^de-Q0229-answer|Compare the answer]]
^de-Q0229

**de-Q0230 · Choose the form**

Ich frage mich, wie es ____, reich zu sein.

I wonder what it feels like to be rich.

Choices: sind / ist / bist / bin

[[German#^de-Q0230-answer|Compare the answer]]
^de-Q0230

**de-Q0231 · Edit the changed sentence**

Bis du wieder zurück 【bin】, bin ich schon gegangen.

By the time you come back, I'll be gone.

[[German#^de-Q0231-answer|Compare the answer]]
^de-Q0231

**de-Q0232 · Build the sentence**

Arrange: ich / zurück / bin / du / Bis / schon / bist, / gegangen. / wieder

By the time you come back, I'll be gone.

[[German#^de-Q0232-answer|Compare the answer]]
^de-Q0232

**de-Q0233 · Write a translation**

Write this in German: The interview is scheduled for 10:00 a.m. tomorrow.

[[German#^de-Q0233-answer|Compare the answer]]
^de-Q0233

**de-Q0234 · Explain the grammar**

Das Vorstellungsgespräch 【ist】 für morgen früh zehn Uhr angesetzt.

The interview is scheduled for 10:00 a.m. tomorrow.

[[German#^de-Q0234-answer|Compare the answer]]
^de-Q0234

**de-Q0235 · Fill the gap**

Ich finde, dein Englisch ____ schon viel besser geworden.

I think your English has improved a lot.

[[German#^de-Q0235-answer|Compare the answer]]
^de-Q0235

**de-Q0236 · Choose the form**

Ich finde, dein Englisch ____ schon viel besser geworden.

I think your English has improved a lot.

Choices: sind / bist / ist / bin

[[German#^de-Q0236-answer|Compare the answer]]
^de-Q0236

**de-Q0237 · Edit the changed sentence**

Bilder 【bin】 die Bücher der Analphabeten.

Images are the books of the illiterate.

[[German#^de-Q0237-answer|Compare the answer]]
^de-Q0237

**de-Q0238 · Build the sentence**

Arrange: Bücher / der / sind / die / Analphabeten. / Bilder

Images are the books of the illiterate.

[[German#^de-Q0238-answer|Compare the answer]]
^de-Q0238

**de-Q0239 · Write a translation**

Write this in German: Tom is a corrections officer.

[[German#^de-Q0239-answer|Compare the answer]]
^de-Q0239

**de-Q0240 · Explain the grammar**

Tom 【ist】 Gefängnisaufseher.

Tom is a corrections officer.

[[German#^de-Q0240-answer|Compare the answer]]
^de-Q0240

**de-Q0241 · Fill the gap**

Ihr ____ niederträchtig.

You're wicked.

[[German#^de-Q0241-answer|Compare the answer]]
^de-Q0241

**de-Q0242 · Choose the form**

Ihr ____ niederträchtig.

You're wicked.

Choices: bist / ist / seid / bin

[[German#^de-Q0242-answer|Compare the answer]]
^de-Q0242

**de-Q0243 · Edit the changed sentence**

【bin】 es gut, weniger Fleisch zu essen?

Is eating less meat a good idea?

[[German#^de-Q0243-answer|Compare the answer]]
^de-Q0243

**de-Q0244 · Build the sentence**

Arrange: Fleisch / gut, / Ist / zu / es / weniger / essen?

Is eating less meat a good idea?

[[German#^de-Q0244-answer|Compare the answer]]
^de-Q0244

**de-Q0245 · Write a translation**

Write this in German: It's not his style.

[[German#^de-Q0245-answer|Compare the answer]]
^de-Q0245

**de-Q0246 · Explain the grammar**

Es 【ist】 nicht sein Stil.

It's not his style.

[[German#^de-Q0246-answer|Compare the answer]]
^de-Q0246

**de-Q0247 · Fill the gap**

Willst du wissen, warum Tom und Maria hier ____?

Do you want to know why Tom and Mary are here?

[[German#^de-Q0247-answer|Compare the answer]]
^de-Q0247

**de-Q0248 · Choose the form**

Willst du wissen, warum Tom und Maria hier ____?

Do you want to know why Tom and Mary are here?

Choices: bist / ist / bin / sind

[[German#^de-Q0248-answer|Compare the answer]]
^de-Q0248

**de-Q0249 · Edit the changed sentence**

Diese Suppe 【bin】 mir zu dünn.

This soup is too thin for me.

[[German#^de-Q0249-answer|Compare the answer]]
^de-Q0249

**de-Q0250 · Build the sentence**

Arrange: Diese / Suppe / mir / ist / dünn. / zu

This soup is too thin for me.

[[German#^de-Q0250-answer|Compare the answer]]
^de-Q0250


### Present forms of haben · 50 questions

**de-Q0251 · Write a translation**

Write this in German: How many states does India have?

[[German#^de-Q0251-answer|Compare the answer]]
^de-Q0251

**de-Q0252 · Explain the grammar**

Wie viele Bundesstaaten 【hat】 Indien?

How many states does India have?

[[German#^de-Q0252-answer|Compare the answer]]
^de-Q0252

**de-Q0253 · Fill the gap**

Ich ____ nicht viel Geld auf meinem Konto.

I don't have much money in my bank account.

[[German#^de-Q0253-answer|Compare the answer]]
^de-Q0253

**de-Q0254 · Choose the form**

Ich ____ nicht viel Geld auf meinem Konto.

I don't have much money in my bank account.

Choices: haben / hast / hat / habe

[[German#^de-Q0254-answer|Compare the answer]]
^de-Q0254

**de-Q0255 · Edit the changed sentence**

Erst gestern 【habe】 er sie wahrgenommen.

It was not until yesterday that he noticed her.

[[German#^de-Q0255-answer|Compare the answer]]
^de-Q0255

**de-Q0256 · Build the sentence**

Arrange: hat / sie / er / Erst / gestern / wahrgenommen.

It was not until yesterday that he noticed her.

[[German#^de-Q0256-answer|Compare the answer]]
^de-Q0256

**de-Q0257 · Write a translation**

Write this in German: She has psychic abilities.

[[German#^de-Q0257-answer|Compare the answer]]
^de-Q0257

**de-Q0258 · Explain the grammar**

Sie 【hat】 mediale Kräfte.

She has psychic abilities.

[[German#^de-Q0258-answer|Compare the answer]]
^de-Q0258

**de-Q0259 · Fill the gap**

____ du dir die Haare gewaschen?

Did you wash your hair?

[[German#^de-Q0259-answer|Compare the answer]]
^de-Q0259

**de-Q0260 · Choose the form**

____ du dir die Haare gewaschen?

Did you wash your hair?

Choices: haben / habe / Hast / hat

[[German#^de-Q0260-answer|Compare the answer]]
^de-Q0260

**de-Q0261 · Edit the changed sentence**

【habe】 du dazu irgendetwas zu sagen?

Do you have anything to say in connection with this?

[[German#^de-Q0261-answer|Compare the answer]]
^de-Q0261

**de-Q0262 · Build the sentence**

Arrange: dazu / irgendetwas / Hast / sagen? / du / zu

Do you have anything to say in connection with this?

[[German#^de-Q0262-answer|Compare the answer]]
^de-Q0262

**de-Q0263 · Write a translation**

Write this in German: I don't think he has anything to do with the matter.

[[German#^de-Q0263-answer|Compare the answer]]
^de-Q0263

**de-Q0264 · Explain the grammar**

Ich glaube, dass er nichts mit dieser Sache zu tun 【hat】.

I don't think he has anything to do with the matter.

[[German#^de-Q0264-answer|Compare the answer]]
^de-Q0264

**de-Q0265 · Fill the gap**

Wer ____ euch gefunden?

Who found you?

[[German#^de-Q0265-answer|Compare the answer]]
^de-Q0265

**de-Q0266 · Choose the form**

Wer ____ euch gefunden?

Who found you?

Choices: hast / habe / hat / haben

[[German#^de-Q0266-answer|Compare the answer]]
^de-Q0266

**de-Q0267 · Edit the changed sentence**

Ich hatte kein Referat vorbereitet. Also 【hast】 ich einfach improvisiert.

I didn't prepare a presentation. So I just blagged it.

[[German#^de-Q0267-answer|Compare the answer]]
^de-Q0267

**de-Q0268 · Build the sentence**

Arrange: improvisiert. / kein / Ich / Also / ich / habe / Referat / einfach / vorbereitet. / hatte

I didn't prepare a presentation. So I just blagged it.

[[German#^de-Q0268-answer|Compare the answer]]
^de-Q0268

**de-Q0269 · Write a translation**

Write this in German: When did you start studying French?

[[German#^de-Q0269-answer|Compare the answer]]
^de-Q0269

**de-Q0270 · Explain the grammar**

Wann 【haben】 Sie angefangen, Französisch zu lernen?

When did you start studying French?

[[German#^de-Q0270-answer|Compare the answer]]
^de-Q0270

**de-Q0271 · Fill the gap**

Tom weiß nicht, was Maria getan ____.

Tom doesn't know what Mary has done.

[[German#^de-Q0271-answer|Compare the answer]]
^de-Q0271

**de-Q0272 · Choose the form**

Tom weiß nicht, was Maria getan ____.

Tom doesn't know what Mary has done.

Choices: hat / habe / haben / hast

[[German#^de-Q0272-answer|Compare the answer]]
^de-Q0272

**de-Q0273 · Edit the changed sentence**

Wir 【habe】 etwas vergessen.

We've forgotten something.

[[German#^de-Q0273-answer|Compare the answer]]
^de-Q0273

**de-Q0274 · Build the sentence**

Arrange: etwas / vergessen. / Wir / haben

We've forgotten something.

[[German#^de-Q0274-answer|Compare the answer]]
^de-Q0274

**de-Q0275 · Write a translation**

Write this in German: "Where did he kiss you?" "On my lips."

[[German#^de-Q0275-answer|Compare the answer]]
^de-Q0275

**de-Q0276 · Explain the grammar**

„Wohin 【hat】 er dich geküsst?“ – „Auf den Mund.“

"Where did he kiss you?" "On my lips."

[[German#^de-Q0276-answer|Compare the answer]]
^de-Q0276

**de-Q0277 · Fill the gap**

Wir ____ seitdem nichts mehr von ihr gehört.

We haven't heard from her since then.

[[German#^de-Q0277-answer|Compare the answer]]
^de-Q0277

**de-Q0278 · Choose the form**

Wir ____ seitdem nichts mehr von ihr gehört.

We haven't heard from her since then.

Choices: haben / hast / hat / habe

[[German#^de-Q0278-answer|Compare the answer]]
^de-Q0278

**de-Q0279 · Edit the changed sentence**

Es 【habe】 mich niemand dazu gezwungen.

Nobody forced me to do that.

[[German#^de-Q0279-answer|Compare the answer]]
^de-Q0279

**de-Q0280 · Build the sentence**

Arrange: niemand / Es / hat / gezwungen. / dazu / mich

Nobody forced me to do that.

[[German#^de-Q0280-answer|Compare the answer]]
^de-Q0280

**de-Q0281 · Write a translation**

Write this in German: Peter has decided to leave tomorrow.

[[German#^de-Q0281-answer|Compare the answer]]
^de-Q0281

**de-Q0282 · Explain the grammar**

Peter 【hat】 beschlossen, morgen aufzubrechen.

Peter has decided to leave tomorrow.

[[German#^de-Q0282-answer|Compare the answer]]
^de-Q0282

**de-Q0283 · Fill the gap**

Ich wollte versuchen, an das Archiv zu kommen, aber ich ____ es vergessen.

I was going to try and get the archive, but I forgot.

[[German#^de-Q0283-answer|Compare the answer]]
^de-Q0283

**de-Q0284 · Choose the form**

Ich wollte versuchen, an das Archiv zu kommen, aber ich ____ es vergessen.

I was going to try and get the archive, but I forgot.

Choices: haben / hast / hat / habe

[[German#^de-Q0284-answer|Compare the answer]]
^de-Q0284

**de-Q0285 · Edit the changed sentence**

Ich 【hast】 Tom noch nie die Fassung verlieren sehen.

I've never seen Tom lose his temper before.

[[German#^de-Q0285-answer|Compare the answer]]
^de-Q0285

**de-Q0286 · Build the sentence**

Arrange: noch / habe / Ich / Tom / nie / Fassung / sehen. / verlieren / die

I've never seen Tom lose his temper before.

[[German#^de-Q0286-answer|Compare the answer]]
^de-Q0286

**de-Q0287 · Write a translation**

Write this in German: She said something.

[[German#^de-Q0287-answer|Compare the answer]]
^de-Q0287

**de-Q0288 · Explain the grammar**

Sie 【hat】 etwas gesagt.

She said something.

[[German#^de-Q0288-answer|Compare the answer]]
^de-Q0288

**de-Q0289 · Fill the gap**

____ ihr bemerkt, dass sie das Haus verlassen hat?

Did you notice that she left the house?

[[German#^de-Q0289-answer|Compare the answer]]
^de-Q0289

**de-Q0290 · Choose the form**

____ ihr bemerkt, dass sie das Haus verlassen hat?

Did you notice that she left the house?

Choices: hast / habe / Habt / hat

[[German#^de-Q0290-answer|Compare the answer]]
^de-Q0290

**de-Q0291 · Edit the changed sentence**

Ich 【hast】 laut gerülpst.

I burped loudly.

[[German#^de-Q0291-answer|Compare the answer]]
^de-Q0291

**de-Q0292 · Build the sentence**

Arrange: habe / laut / gerülpst. / Ich

I burped loudly.

[[German#^de-Q0292-answer|Compare the answer]]
^de-Q0292

**de-Q0293 · Write a translation**

Write this in German: Tom cried all night.

[[German#^de-Q0293-answer|Compare the answer]]
^de-Q0293

**de-Q0294 · Explain the grammar**

Tom 【hat】 die ganze Nacht über geweint.

Tom cried all night.

[[German#^de-Q0294-answer|Compare the answer]]
^de-Q0294

**de-Q0295 · Fill the gap**

Ich ____ es schon versucht.

I've already tried.

[[German#^de-Q0295-answer|Compare the answer]]
^de-Q0295

**de-Q0296 · Choose the form**

Ich ____ es schon versucht.

I've already tried.

Choices: habe / hat / haben / hast

[[German#^de-Q0296-answer|Compare the answer]]
^de-Q0296

**de-Q0297 · Edit the changed sentence**

Ich möchte wissen, warum du mich angelogen 【habe】.

I want to know why you lied to me.

[[German#^de-Q0297-answer|Compare the answer]]
^de-Q0297

**de-Q0298 · Build the sentence**

Arrange: hast. / du / möchte / wissen, / mich / angelogen / Ich / warum

I want to know why you lied to me.

[[German#^de-Q0298-answer|Compare the answer]]
^de-Q0298

**de-Q0299 · Write a translation**

Write this in German: Tom has been looking all over for you.

[[German#^de-Q0299-answer|Compare the answer]]
^de-Q0299

**de-Q0300 · Explain the grammar**

Tom 【hat】 überall nach Ihnen gesucht.

Tom has been looking all over for you.

[[German#^de-Q0300-answer|Compare the answer]]
^de-Q0300


### Modal verbs · 50 questions

**de-Q0301 · Fill the gap**

Tom ____ sich entschuldigen.

Tom is going to apologize.

[[German#^de-Q0301-answer|Compare the answer]]
^de-Q0301

**de-Q0302 · Choose the form**

Tom ____ sich entschuldigen.

Tom is going to apologize.

Choices: darf / will / kann / muss

[[German#^de-Q0302-answer|Compare the answer]]
^de-Q0302

**de-Q0303 · Edit the changed sentence**

In diesem Buch steht, dass Elefanten über hundert Jahre alt werden 【kann】.

This book says that elephants live to be over 100 years old.

[[German#^de-Q0303-answer|Compare the answer]]
^de-Q0303

**de-Q0304 · Build the sentence**

Arrange: Jahre / diesem / dass / können. / In / über / Buch / werden / alt / steht, / Elefanten / hundert

This book says that elephants live to be over 100 years old.

[[German#^de-Q0304-answer|Compare the answer]]
^de-Q0304

**de-Q0305 · Write a translation**

Write this in German: Tom has trouble keeping up with the rest of the class.

[[German#^de-Q0305-answer|Compare the answer]]
^de-Q0305

**de-Q0306 · Explain the grammar**

Tom 【kann】 nur mit Mühe mit dem Rest der Klasse Schritt halten.

Tom has trouble keeping up with the rest of the class.

[[German#^de-Q0306-answer|Compare the answer]]
^de-Q0306

**de-Q0307 · Fill the gap**

Du hättest in Boston bleiben ____.

You could've stayed in Boston.

[[German#^de-Q0307-answer|Compare the answer]]
^de-Q0307

**de-Q0308 · Choose the form**

Du hättest in Boston bleiben ____.

You could've stayed in Boston.

Choices: kann / muss / können / darf

[[German#^de-Q0308-answer|Compare the answer]]
^de-Q0308

**de-Q0309 · Edit the changed sentence**

Bedenke, was getan werden sollte, stelle fest, was getan werden 【muss】, und tu das, was getan werden muss.

Consider what should be done, determine what can be done and do what needs to be done.

[[German#^de-Q0309-answer|Compare the answer]]
^de-Q0309

**de-Q0310 · Build the sentence**

Arrange: stelle / kann, / tu / muss. / getan / was / was / Bedenke, / getan / fest, / und / was / werden / das, / getan / werden / sollte, / werden

Consider what should be done, determine what can be done and do what needs to be done.

[[German#^de-Q0310-answer|Compare the answer]]
^de-Q0310

**de-Q0311 · Write a translation**

Write this in German: It can be done in a day.

[[German#^de-Q0311-answer|Compare the answer]]
^de-Q0311

**de-Q0312 · Explain the grammar**

Das 【kann】 an einem Tag gemacht werden.

It can be done in a day.

[[German#^de-Q0312-answer|Compare the answer]]
^de-Q0312

**de-Q0313 · Fill the gap**

Sie ____ Fragen stellen und beantworten.

She can ask and answer questions.

[[German#^de-Q0313-answer|Compare the answer]]
^de-Q0313

**de-Q0314 · Choose the form**

Sie ____ Fragen stellen und beantworten.

She can ask and answer questions.

Choices: darf / kann / muss / soll

[[German#^de-Q0314-answer|Compare the answer]]
^de-Q0314

**de-Q0315 · Edit the changed sentence**

【muss】 ich spazieren gehen?

Can I go for a walk?

[[German#^de-Q0315-answer|Compare the answer]]
^de-Q0315

**de-Q0316 · Build the sentence**

Arrange: spazieren / Kann / gehen? / ich

Can I go for a walk?

[[German#^de-Q0316-answer|Compare the answer]]
^de-Q0316

**de-Q0317 · Write a translation**

Write this in German: I don't want to play golf with Tom.

[[German#^de-Q0317-answer|Compare the answer]]
^de-Q0317

**de-Q0318 · Explain the grammar**

Ich 【will】 nicht mit Tom Golf spielen.

I don't want to play golf with Tom.

[[German#^de-Q0318-answer|Compare the answer]]
^de-Q0318

**de-Q0319 · Fill the gap**

Er ____ Toms Bruder sein.

He must be Tom's brother.

[[German#^de-Q0319-answer|Compare the answer]]
^de-Q0319

**de-Q0320 · Choose the form**

Er ____ Toms Bruder sein.

He must be Tom's brother.

Choices: darf / kann / muss / soll

[[German#^de-Q0320-answer|Compare the answer]]
^de-Q0320

**de-Q0321 · Edit the changed sentence**

Metalle 【kann】 bei tiefen Temperaturen spröde werden.

Metals can become brittle at low temperatures.

[[German#^de-Q0321-answer|Compare the answer]]
^de-Q0321

**de-Q0322 · Build the sentence**

Arrange: Metalle / bei / tiefen / können / spröde / Temperaturen / werden.

Metals can become brittle at low temperatures.

[[German#^de-Q0322-answer|Compare the answer]]
^de-Q0322

**de-Q0323 · Write a translation**

Write this in German: The Filipino woman wanted to learn English so that one day she could emigrate to the Anglosphere.

[[German#^de-Q0323-answer|Compare the answer]]
^de-Q0323

**de-Q0324 · Explain the grammar**

Die Philippinerin wollte Englisch lernen, um eines Tages in den englischsprachigen Raum auswandern zu 【können】.

The Filipino woman wanted to learn English so that one day she could emigrate to the Anglosphere.

[[German#^de-Q0324-answer|Compare the answer]]
^de-Q0324

**de-Q0325 · Fill the gap**

Sie hätten zum Meeting gehen ____.

You should have attended the meeting.

[[German#^de-Q0325-answer|Compare the answer]]
^de-Q0325

**de-Q0326 · Choose the form**

Sie hätten zum Meeting gehen ____.

You should have attended the meeting.

Choices: kann / darf / muss / sollen

[[German#^de-Q0326-answer|Compare the answer]]
^de-Q0326

**de-Q0327 · Edit the changed sentence**

Wie sonst 【muss】 man das erklären?

How else can you account for it?

[[German#^de-Q0327-answer|Compare the answer]]
^de-Q0327

**de-Q0328 · Build the sentence**

Arrange: erklären? / kann / man / sonst / Wie / das

How else can you account for it?

[[German#^de-Q0328-answer|Compare the answer]]
^de-Q0328

**de-Q0329 · Write a translation**

Write this in German: Soon I'll be speaking Korean.

[[German#^de-Q0329-answer|Compare the answer]]
^de-Q0329

**de-Q0330 · Explain the grammar**

Bald 【kann】 ich Koreanisch.

Soon I'll be speaking Korean.

[[German#^de-Q0330-answer|Compare the answer]]
^de-Q0330

**de-Q0331 · Fill the gap**

Nichts ist unmöglich für den, der es nicht selbst machen ____.

Nothing is impossible for the man who doesn't have to do it himself.

[[German#^de-Q0331-answer|Compare the answer]]
^de-Q0331

**de-Q0332 · Choose the form**

Nichts ist unmöglich für den, der es nicht selbst machen ____.

Nothing is impossible for the man who doesn't have to do it himself.

Choices: darf / kann / soll / muss

[[German#^de-Q0332-answer|Compare the answer]]
^de-Q0332

**de-Q0333 · Edit the changed sentence**

Was man nicht weiß, 【muss】 einen nicht verletzen.

What you don't know can hurt you.

[[German#^de-Q0333-answer|Compare the answer]]
^de-Q0333

**de-Q0334 · Build the sentence**

Arrange: weiß, / kann / nicht / einen / verletzen. / nicht / man / Was

What you don't know can hurt you.

[[German#^de-Q0334-answer|Compare the answer]]
^de-Q0334

**de-Q0335 · Write a translation**

Write this in German: Tom and Mary are going to give it a try.

[[German#^de-Q0335-answer|Compare the answer]]
^de-Q0335

**de-Q0336 · Explain the grammar**

Tom und Maria 【wollen】 es versuchen.

Tom and Mary are going to give it a try.

[[German#^de-Q0336-answer|Compare the answer]]
^de-Q0336

**de-Q0337 · Fill the gap**

Man ____ das Buch nur auf Deutsch bekommen.

The book is only available in German.

[[German#^de-Q0337-answer|Compare the answer]]
^de-Q0337

**de-Q0338 · Choose the form**

Man ____ das Buch nur auf Deutsch bekommen.

The book is only available in German.

Choices: soll / muss / darf / kann

[[German#^de-Q0338-answer|Compare the answer]]
^de-Q0338

**de-Q0339 · Edit the changed sentence**

Wir 【kann】 schnell machen.

We must move quickly.

[[German#^de-Q0339-answer|Compare the answer]]
^de-Q0339

**de-Q0340 · Build the sentence**

Arrange: müssen / schnell / machen. / Wir

We must move quickly.

[[German#^de-Q0340-answer|Compare the answer]]
^de-Q0340

**de-Q0341 · Write a translation**

Write this in German: I don't want to become an electrician.

[[German#^de-Q0341-answer|Compare the answer]]
^de-Q0341

**de-Q0342 · Explain the grammar**

Ich 【will】 kein Elektriker werden.

I don't want to become an electrician.

[[German#^de-Q0342-answer|Compare the answer]]
^de-Q0342

**de-Q0343 · Fill the gap**

Nur sie ____ den Computer benutzen.

Only she can use the computer.

[[German#^de-Q0343-answer|Compare the answer]]
^de-Q0343

**de-Q0344 · Choose the form**

Nur sie ____ den Computer benutzen.

Only she can use the computer.

Choices: darf / kann / muss / soll

[[German#^de-Q0344-answer|Compare the answer]]
^de-Q0344

**de-Q0345 · Edit the changed sentence**

Chris konnte seine Traurigkeit nicht verbergen, als er hörte, dass Beth seine wertvolle Uhr nicht hatte finden 【kann】.

Chris could not conceal his sadness when he heard that Beth had been unable to find his valuable watch.

[[German#^de-Q0345-answer|Compare the answer]]
^de-Q0345

**de-Q0346 · Build the sentence**

Arrange: verbergen, / hörte, / Beth / er / können. / finden / als / wertvolle / Uhr / seine / nicht / nicht / Chris / Traurigkeit / dass / hatte / konnte / seine

Chris could not conceal his sadness when he heard that Beth had been unable to find his valuable watch.

[[German#^de-Q0346-answer|Compare the answer]]
^de-Q0346

**de-Q0347 · Write a translation**

Write this in German: I want to help as many people as I can.

[[German#^de-Q0347-answer|Compare the answer]]
^de-Q0347

**de-Q0348 · Explain the grammar**

Ich 【will】 so vielen Menschen wie möglich helfen.

I want to help as many people as I can.

[[German#^de-Q0348-answer|Compare the answer]]
^de-Q0348

**de-Q0349 · Fill the gap**

Sie ____ nur jeden Tag üben.

You have only to practice every day.

[[German#^de-Q0349-answer|Compare the answer]]
^de-Q0349

**de-Q0350 · Choose the form**

Sie ____ nur jeden Tag üben.

You have only to practice every day.

Choices: muss / darf / kann / müssen

[[German#^de-Q0350-answer|Compare the answer]]
^de-Q0350


### Negation with nicht and kein · 50 questions

**de-Q0351 · Edit the changed sentence**

Tom konnte sich 【kein】 vorstellen, jemanden zu erschießen.

Tom couldn't imagine himself shooting anyone.

[[German#^de-Q0351-answer|Compare the answer]]
^de-Q0351

**de-Q0352 · Build the sentence**

Arrange: nicht / jemanden / zu / vorstellen, / konnte / sich / erschießen. / Tom

Tom couldn't imagine himself shooting anyone.

[[German#^de-Q0352-answer|Compare the answer]]
^de-Q0352

**de-Q0353 · Write a translation**

Write this in German: Tom couldn't answer all of Mary's questions.

[[German#^de-Q0353-answer|Compare the answer]]
^de-Q0353

**de-Q0354 · Explain the grammar**

Tom konnte 【nicht】 alle Fragen Marias beantworten.

Tom couldn't answer all of Mary's questions.

[[German#^de-Q0354-answer|Compare the answer]]
^de-Q0354

**de-Q0355 · Fill the gap**

Dafür bezahle ich ____!

I won't pay for that.

[[German#^de-Q0355-answer|Compare the answer]]
^de-Q0355

**de-Q0356 · Choose the form**

Dafür bezahle ich ____!

I won't pay for that.

Choices: nicht / keine / keinen / kein

[[German#^de-Q0356-answer|Compare the answer]]
^de-Q0356

**de-Q0357 · Edit the changed sentence**

Tom sagte, das sei bei weitem 【kein】 gut genug.

Tom said that's far from good enough.

[[German#^de-Q0357-answer|Compare the answer]]
^de-Q0357

**de-Q0358 · Build the sentence**

Arrange: nicht / sei / weitem / gut / das / bei / sagte, / Tom / genug.

Tom said that's far from good enough.

[[German#^de-Q0358-answer|Compare the answer]]
^de-Q0358

**de-Q0359 · Write a translation**

Write this in German: Sometimes that just isn't enough.

[[German#^de-Q0359-answer|Compare the answer]]
^de-Q0359

**de-Q0360 · Explain the grammar**

Manchmal reicht das einfach 【nicht】.

Sometimes that just isn't enough.

[[German#^de-Q0360-answer|Compare the answer]]
^de-Q0360

**de-Q0361 · Fill the gap**

Maria setzte Tom davon in Kenntnis, dass sie ____ wusste, wie das ging.

Mary let Tom know she didn't know how to do that.

[[German#^de-Q0361-answer|Compare the answer]]
^de-Q0361

**de-Q0362 · Choose the form**

Maria setzte Tom davon in Kenntnis, dass sie ____ wusste, wie das ging.

Mary let Tom know she didn't know how to do that.

Choices: keinen / keine / nicht / kein

[[German#^de-Q0362-answer|Compare the answer]]
^de-Q0362

**de-Q0363 · Edit the changed sentence**

So etwas Banales kommt gar 【kein】 in Frage.

Such a trivial thing is out of the question.

[[German#^de-Q0363-answer|Compare the answer]]
^de-Q0363

**de-Q0364 · Build the sentence**

Arrange: Banales / kommt / etwas / nicht / Frage. / So / gar / in

Such a trivial thing is out of the question.

[[German#^de-Q0364-answer|Compare the answer]]
^de-Q0364

**de-Q0365 · Write a translation**

Write this in German: You don't really know, do you?

[[German#^de-Q0365-answer|Compare the answer]]
^de-Q0365

**de-Q0366 · Explain the grammar**

Ihr wisst es eigentlich gar 【nicht】, oder?

You don't really know, do you?

[[German#^de-Q0366-answer|Compare the answer]]
^de-Q0366

**de-Q0367 · Fill the gap**

Bist du sicher, dass du ____ Übersetzungsprogramm verwendest?

Are you sure you don't use machine translations?

[[German#^de-Q0367-answer|Compare the answer]]
^de-Q0367

**de-Q0368 · Choose the form**

Bist du sicher, dass du ____ Übersetzungsprogramm verwendest?

Are you sure you don't use machine translations?

Choices: nicht / keine / keinen / kein

[[German#^de-Q0368-answer|Compare the answer]]
^de-Q0368

**de-Q0369 · Edit the changed sentence**

Tom sagte, er fand es 【kein】 lustig.

Tom said he didn't find it funny.

[[German#^de-Q0369-answer|Compare the answer]]
^de-Q0369

**de-Q0370 · Build the sentence**

Arrange: es / fand / sagte, / lustig. / er / nicht / Tom

Tom said he didn't find it funny.

[[German#^de-Q0370-answer|Compare the answer]]
^de-Q0370

**de-Q0371 · Write a translation**

Write this in German: What a pity it is that you can't come!

[[German#^de-Q0371-answer|Compare the answer]]
^de-Q0371

**de-Q0372 · Explain the grammar**

Schade, dass du 【nicht】 kommen kannst!

What a pity it is that you can't come!

[[German#^de-Q0372-answer|Compare the answer]]
^de-Q0372

**de-Q0373 · Fill the gap**

Es ist ____ immer so leicht, das Richtige zu tun.

It's not always so easy to do the right thing.

[[German#^de-Q0373-answer|Compare the answer]]
^de-Q0373

**de-Q0374 · Choose the form**

Es ist ____ immer so leicht, das Richtige zu tun.

It's not always so easy to do the right thing.

Choices: nicht / kein / keinen / keine

[[German#^de-Q0374-answer|Compare the answer]]
^de-Q0374

**de-Q0375 · Edit the changed sentence**

Dieser Zug hält hier 【kein】.

That train doesn't stop here.

[[German#^de-Q0375-answer|Compare the answer]]
^de-Q0375

**de-Q0376 · Build the sentence**

Arrange: nicht. / hier / Dieser / Zug / hält

That train doesn't stop here.

[[German#^de-Q0376-answer|Compare the answer]]
^de-Q0376

**de-Q0377 · Write a translation**

Write this in German: I don't see a problem with it.

[[German#^de-Q0377-answer|Compare the answer]]
^de-Q0377

**de-Q0378 · Explain the grammar**

Ich sehe 【kein】 Problem dabei.

I don't see a problem with it.

[[German#^de-Q0378-answer|Compare the answer]]
^de-Q0378

**de-Q0379 · Fill the gap**

Ihr braucht ____ zu warten.

You don't need to wait.

[[German#^de-Q0379-answer|Compare the answer]]
^de-Q0379

**de-Q0380 · Choose the form**

Ihr braucht ____ zu warten.

You don't need to wait.

Choices: nicht / kein / keine / keinen

[[German#^de-Q0380-answer|Compare the answer]]
^de-Q0380

**de-Q0381 · Edit the changed sentence**

Tom sagte, er macht es 【kein】.

Tom said he's not doing it.

[[German#^de-Q0381-answer|Compare the answer]]
^de-Q0381

**de-Q0382 · Build the sentence**

Arrange: es / er / nicht. / Tom / macht / sagte,

Tom said he's not doing it.

[[German#^de-Q0382-answer|Compare the answer]]
^de-Q0382

**de-Q0383 · Write a translation**

Write this in German: You can lie to everyone else, but you can't lie to yourself.

[[German#^de-Q0383-answer|Compare the answer]]
^de-Q0383

**de-Q0384 · Explain the grammar**

Du kannst alle anderen, 【nicht】 aber dich selbst belügen.

You can lie to everyone else, but you can't lie to yourself.

[[German#^de-Q0384-answer|Compare the answer]]
^de-Q0384

**de-Q0385 · Fill the gap**

Entweder gehen wir alle, oder es geht ____.

Either we all go or nobody goes.

[[German#^de-Q0385-answer|Compare the answer]]
^de-Q0385

**de-Q0386 · Choose the form**

Entweder gehen wir alle, oder es geht ____.

Either we all go or nobody goes.

Choices: keine / keiner / nicht / kein

[[German#^de-Q0386-answer|Compare the answer]]
^de-Q0386

**de-Q0387 · Edit the changed sentence**

Ich verstehe 【kein】 immer, was du schreibst.

I can't always understand what you write.

[[German#^de-Q0387-answer|Compare the answer]]
^de-Q0387

**de-Q0388 · Build the sentence**

Arrange: du / was / nicht / schreibst. / immer, / verstehe / Ich

I can't always understand what you write.

[[German#^de-Q0388-answer|Compare the answer]]
^de-Q0388

**de-Q0389 · Write a translation**

Write this in German: Frankly speaking, I don't think you have what it takes to become a teacher.

[[German#^de-Q0389-answer|Compare the answer]]
^de-Q0389

**de-Q0390 · Explain the grammar**

Ehrlich gesprochen, glaube ich 【nicht】, dass Sie das Zeug zur Lehrerin haben.

Frankly speaking, I don't think you have what it takes to become a teacher.

[[German#^de-Q0390-answer|Compare the answer]]
^de-Q0390

**de-Q0391 · Fill the gap**

Sie brauchen ____ sarkastisch zu werden.

You don't have to be sarcastic.

[[German#^de-Q0391-answer|Compare the answer]]
^de-Q0391

**de-Q0392 · Choose the form**

Sie brauchen ____ sarkastisch zu werden.

You don't have to be sarcastic.

Choices: kein / keine / nicht / keinen

[[German#^de-Q0392-answer|Compare the answer]]
^de-Q0392

**de-Q0393 · Edit the changed sentence**

Sie haben Herrn Schmidt bereits getroffen, 【kein】 wahr?

You've met Mr. Smith already, haven't you?

[[German#^de-Q0393-answer|Compare the answer]]
^de-Q0393

**de-Q0394 · Build the sentence**

Arrange: bereits / Schmidt / haben / Sie / Herrn / getroffen, / wahr? / nicht

You've met Mr. Smith already, haven't you?

[[German#^de-Q0394-answer|Compare the answer]]
^de-Q0394

**de-Q0395 · Write a translation**

Write this in German: When he doesn't get his way, he sulks.

[[German#^de-Q0395-answer|Compare the answer]]
^de-Q0395

**de-Q0396 · Explain the grammar**

Wenn es 【nicht】 so läuft, wie er sich das vorgestellt hat, so schmollt er.

When he doesn't get his way, he sulks.

[[German#^de-Q0396-answer|Compare the answer]]
^de-Q0396

**de-Q0397 · Fill the gap**

Seid ____ so bescheiden!

Don't be so modest.

[[German#^de-Q0397-answer|Compare the answer]]
^de-Q0397

**de-Q0398 · Choose the form**

Seid ____ so bescheiden!

Don't be so modest.

Choices: keinen / kein / keine / nicht

[[German#^de-Q0398-answer|Compare the answer]]
^de-Q0398

**de-Q0399 · Edit the changed sentence**

Elke hatte 【nicht】 Ahnung, dass Tom bereits mit Elke verheiratet war.

Alice had no idea that Tom was already married to Mary.

[[German#^de-Q0399-answer|Compare the answer]]
^de-Q0399

**de-Q0400 · Build the sentence**

Arrange: verheiratet / hatte / war. / bereits / mit / Ahnung, / Tom / Elke / Elke / dass / keine

Alice had no idea that Tom was already married to Mary.

[[German#^de-Q0400-answer|Compare the answer]]
^de-Q0400


### Subordinate clause connectors · 50 questions

**de-Q0401 · Write a translation**

Write this in German: You knew this was going to happen, right?

[[German#^de-Q0401-answer|Compare the answer]]
^de-Q0401

**de-Q0402 · Explain the grammar**

Du wusstest, 【dass】 da passieren wird, stimmt's?

You knew this was going to happen, right?

[[German#^de-Q0402-answer|Compare the answer]]
^de-Q0402

**de-Q0403 · Fill the gap**

Tom kam gerade, ____ ich ging.

Tom came just as I was leaving.

[[German#^de-Q0403-answer|Compare the answer]]
^de-Q0403

**de-Q0404 · Choose the form**

Tom kam gerade, ____ ich ging.

Tom came just as I was leaving.

Choices: ob / weil / dass / als

[[German#^de-Q0404-answer|Compare the answer]]
^de-Q0404

**de-Q0405 · Edit the changed sentence**

Die Nachricht erwies sich 【weil】 falsch.

The news turned out false.

[[German#^de-Q0405-answer|Compare the answer]]
^de-Q0405

**de-Q0406 · Build the sentence**

Arrange: erwies / Die / sich / als / Nachricht / falsch.

The news turned out false.

[[German#^de-Q0406-answer|Compare the answer]]
^de-Q0406

**de-Q0407 · Write a translation**

Write this in German: They were so busy they didn't realize what time it was.

[[German#^de-Q0407-answer|Compare the answer]]
^de-Q0407

**de-Q0408 · Explain the grammar**

Sie waren so beschäftigt, 【dass】 sie vergaßen, wie spät es war.

They were so busy they didn't realize what time it was.

[[German#^de-Q0408-answer|Compare the answer]]
^de-Q0408

**de-Q0409 · Fill the gap**

Tom bemerkte, ____ Maria schlief.

Tom noticed that Mary was asleep.

[[German#^de-Q0409-answer|Compare the answer]]
^de-Q0409

**de-Q0410 · Choose the form**

Tom bemerkte, ____ Maria schlief.

Tom noticed that Mary was asleep.

Choices: weil / ob / dass / wenn

[[German#^de-Q0410-answer|Compare the answer]]
^de-Q0410

**de-Q0411 · Edit the changed sentence**

Tom sagte Maria, 【weil】 er glaube, was John sagte.

Tom told Mary that he believed what John said.

[[German#^de-Q0411-answer|Compare the answer]]
^de-Q0411

**de-Q0412 · Build the sentence**

Arrange: sagte / er / was / dass / Tom / Maria, / sagte. / John / glaube,

Tom told Mary that he believed what John said.

[[German#^de-Q0412-answer|Compare the answer]]
^de-Q0412

**de-Q0413 · Write a translation**

Write this in German: She became aware that her parents were watching her.

[[German#^de-Q0413-answer|Compare the answer]]
^de-Q0413

**de-Q0414 · Explain the grammar**

Ihr wurde bewusst, 【dass】 ihre Eltern sie beobachteten.

She became aware that her parents were watching her.

[[German#^de-Q0414-answer|Compare the answer]]
^de-Q0414

**de-Q0415 · Fill the gap**

____ sie das Klopfen hörte, dachte sie schon, ihre Eltern seien angekommen.

As she heard the knocking she thought her parents were coming home.

[[German#^de-Q0415-answer|Compare the answer]]
^de-Q0415

**de-Q0416 · Choose the form**

____ sie das Klopfen hörte, dachte sie schon, ihre Eltern seien angekommen.

As she heard the knocking she thought her parents were coming home.

Choices: ob / Als / dass / weil

[[German#^de-Q0416-answer|Compare the answer]]
^de-Q0416

**de-Q0417 · Edit the changed sentence**

Das ist das erste Mal, 【weil】 ich mein Auto im Wald parke.

This is the first time I've ever parked my car in the woods.

[[German#^de-Q0417-answer|Compare the answer]]
^de-Q0417

**de-Q0418 · Build the sentence**

Arrange: Mal, / mein / dass / Auto / im / Das / Wald / parke. / ich / das / erste / ist

This is the first time I've ever parked my car in the woods.

[[German#^de-Q0418-answer|Compare the answer]]
^de-Q0418

**de-Q0419 · Write a translation**

Write this in German: Is it true that nobody lives around here?

[[German#^de-Q0419-answer|Compare the answer]]
^de-Q0419

**de-Q0420 · Explain the grammar**

Stimmt es, 【dass】 in dieser Gegend niemand wohnt?

Is it true that nobody lives around here?

[[German#^de-Q0420-answer|Compare the answer]]
^de-Q0420

**de-Q0421 · Fill the gap**

Tom weiß, ____ wir hier sind.

Tom knows we're here.

[[German#^de-Q0421-answer|Compare the answer]]
^de-Q0421

**de-Q0422 · Choose the form**

Tom weiß, ____ wir hier sind.

Tom knows we're here.

Choices: ob / weil / dass / wenn

[[German#^de-Q0422-answer|Compare the answer]]
^de-Q0422

**de-Q0423 · Edit the changed sentence**

【weil】 ihr wissen wollt, woher der Wind weht, braucht ihr nur nach der Windhose zu schauen.

If you want to know which direction the wind is blowing, just look at the windsock.

[[German#^de-Q0423-answer|Compare the answer]]
^de-Q0423

**de-Q0424 · Build the sentence**

Arrange: der / wollt, / schauen. / Wind / woher / nach / ihr / zu / wissen / der / Windhose / ihr / braucht / weht, / Wenn / nur

If you want to know which direction the wind is blowing, just look at the windsock.

[[German#^de-Q0424-answer|Compare the answer]]
^de-Q0424

**de-Q0425 · Write a translation**

Write this in German: I'll miss you very much if you go.

[[German#^de-Q0425-answer|Compare the answer]]
^de-Q0425

**de-Q0426 · Explain the grammar**

Ihr werdet mir sehr fehlen, 【wenn】 ihr geht.

I'll miss you very much if you go.

[[German#^de-Q0426-answer|Compare the answer]]
^de-Q0426

**de-Q0427 · Fill the gap**

Du darfst erst gehen, ____ wir dir das sagen.

You can't leave until we say you can leave.

[[German#^de-Q0427-answer|Compare the answer]]
^de-Q0427

**de-Q0428 · Choose the form**

Du darfst erst gehen, ____ wir dir das sagen.

You can't leave until we say you can leave.

Choices: dass / wenn / ob / weil

[[German#^de-Q0428-answer|Compare the answer]]
^de-Q0428

**de-Q0429 · Edit the changed sentence**

Es ist gut, 【weil】 ich hierher gekommen bin.

It's a good thing I came here.

[[German#^de-Q0429-answer|Compare the answer]]
^de-Q0429

**de-Q0430 · Build the sentence**

Arrange: ich / gekommen / ist / hierher / Es / dass / bin. / gut,

It's a good thing I came here.

[[German#^de-Q0430-answer|Compare the answer]]
^de-Q0430

**de-Q0431 · Write a translation**

Write this in German: Tom asked Mary if she wanted to do that by herself.

[[German#^de-Q0431-answer|Compare the answer]]
^de-Q0431

**de-Q0432 · Explain the grammar**

Tom fragte Maria, 【ob】 sie das allein tun wolle.

Tom asked Mary if she wanted to do that by herself.

[[German#^de-Q0432-answer|Compare the answer]]
^de-Q0432

**de-Q0433 · Fill the gap**

Das war das letzte Mal, ____ einer von uns Tom je gesehen hat.

That was the last time any of us ever saw Tom.

[[German#^de-Q0433-answer|Compare the answer]]
^de-Q0433

**de-Q0434 · Choose the form**

Das war das letzte Mal, ____ einer von uns Tom je gesehen hat.

That was the last time any of us ever saw Tom.

Choices: wenn / dass / ob / weil

[[German#^de-Q0434-answer|Compare the answer]]
^de-Q0434

**de-Q0435 · Edit the changed sentence**

Sie sprach, 【weil】 ob sie meine Mutter wäre.

She talked as if she were my mother.

[[German#^de-Q0435-answer|Compare the answer]]
^de-Q0435

**de-Q0436 · Build the sentence**

Arrange: sie / Sie / als / wäre. / sprach, / ob / meine / Mutter

She talked as if she were my mother.

[[German#^de-Q0436-answer|Compare the answer]]
^de-Q0436

**de-Q0437 · Write a translation**

Write this in German: I expect Tom will win.

[[German#^de-Q0437-answer|Compare the answer]]
^de-Q0437

**de-Q0438 · Explain the grammar**

Ich gehe davon aus, 【dass】 Tom gewinnen wird.

I expect Tom will win.

[[German#^de-Q0438-answer|Compare the answer]]
^de-Q0438

**de-Q0439 · Fill the gap**

Ich bin froh, ____ Tom und Maria sich dazu bereit erklärt haben.

I'm glad Tom and Mary have agreed to do that.

[[German#^de-Q0439-answer|Compare the answer]]
^de-Q0439

**de-Q0440 · Choose the form**

Ich bin froh, ____ Tom und Maria sich dazu bereit erklärt haben.

I'm glad Tom and Mary have agreed to do that.

Choices: weil / dass / wenn / ob

[[German#^de-Q0440-answer|Compare the answer]]
^de-Q0440

**de-Q0441 · Edit the changed sentence**

Es gibt nichts Schöneres 【weil】 die Liebe.

There is nothing more beautiful than love.

[[German#^de-Q0441-answer|Compare the answer]]
^de-Q0441

**de-Q0442 · Build the sentence**

Arrange: nichts / gibt / Es / als / Liebe. / die / Schöneres

There is nothing more beautiful than love.

[[German#^de-Q0442-answer|Compare the answer]]
^de-Q0442

**de-Q0443 · Write a translation**

Write this in German: I know this is difficult to accept.

[[German#^de-Q0443-answer|Compare the answer]]
^de-Q0443

**de-Q0444 · Explain the grammar**

Ich weiß, 【dass】 das schwer hinzunehmen ist.

I know this is difficult to accept.

[[German#^de-Q0444-answer|Compare the answer]]
^de-Q0444

**de-Q0445 · Fill the gap**

Er verdient sich seinen Lebensunterhalt ____ Lehrer.

He earns his living by teaching.

[[German#^de-Q0445-answer|Compare the answer]]
^de-Q0445

**de-Q0446 · Choose the form**

Er verdient sich seinen Lebensunterhalt ____ Lehrer.

He earns his living by teaching.

Choices: dass / weil / ob / als

[[German#^de-Q0446-answer|Compare the answer]]
^de-Q0446

**de-Q0447 · Edit the changed sentence**

【weil】 ihr in Narita landet, wird es bereits dunkel sein.

By the time you land at Narita, it will be dark.

[[German#^de-Q0447-answer|Compare the answer]]
^de-Q0447

**de-Q0448 · Build the sentence**

Arrange: bereits / es / Wenn / ihr / in / sein. / Narita / landet, / dunkel / wird

By the time you land at Narita, it will be dark.

[[German#^de-Q0448-answer|Compare the answer]]
^de-Q0448

**de-Q0449 · Write a translation**

Write this in German: I often break things when I'm angry.

[[German#^de-Q0449-answer|Compare the answer]]
^de-Q0449

**de-Q0450 · Explain the grammar**

Ich mache oft Sachen kaputt, 【wenn】 ich wütend bin.

I often break things when I'm angry.

[[German#^de-Q0450-answer|Compare the answer]]
^de-Q0450


### Coordinating connectors · 50 questions

**de-Q0451 · Fill the gap**

Tom ____ Maria liefen ins Wasser.

Tom and Mary ran into the water.

[[German#^de-Q0451-answer|Compare the answer]]
^de-Q0451

**de-Q0452 · Choose the form**

Tom ____ Maria liefen ins Wasser.

Tom and Mary ran into the water.

Choices: denn / oder / und / aber

[[German#^de-Q0452-answer|Compare the answer]]
^de-Q0452

**de-Q0453 · Edit the changed sentence**

Das Mädchen wurde abgelenkt 【aber】 verlor ihre Eltern aus den Augen.

The girl got distracted and lost sight of her parents.

[[German#^de-Q0453-answer|Compare the answer]]
^de-Q0453

**de-Q0454 · Build the sentence**

Arrange: abgelenkt / wurde / Das / aus / Augen. / den / Eltern / und / Mädchen / ihre / verlor

The girl got distracted and lost sight of her parents.

[[German#^de-Q0454-answer|Compare the answer]]
^de-Q0454

**de-Q0455 · Write a translation**

Write this in German: Then the ghost spoke again, and his voice sounded like the sighing of the wind.

[[German#^de-Q0455-answer|Compare the answer]]
^de-Q0455

**de-Q0456 · Explain the grammar**

Dann sprach der Geist erneut, 【und】 seine Stimme klang wie das Seufzen des Windes.

Then the ghost spoke again, and his voice sounded like the sighing of the wind.

[[German#^de-Q0456-answer|Compare the answer]]
^de-Q0456

**de-Q0457 · Fill the gap**

Tom ____ ich waren abwechselnd am Steuer.

Tom and I took turns driving.

[[German#^de-Q0457-answer|Compare the answer]]
^de-Q0457

**de-Q0458 · Choose the form**

Tom ____ ich waren abwechselnd am Steuer.

Tom and I took turns driving.

Choices: denn / und / oder / aber

[[German#^de-Q0458-answer|Compare the answer]]
^de-Q0458

**de-Q0459 · Edit the changed sentence**

Was backen Sie 【und】 da?

What're you baking?

[[German#^de-Q0459-answer|Compare the answer]]
^de-Q0459

**de-Q0460 · Build the sentence**

Arrange: denn / Sie / da? / Was / backen

What're you baking?

[[German#^de-Q0460-answer|Compare the answer]]
^de-Q0460

**de-Q0461 · Write a translation**

Write this in German: I've never seen that house, but I've imagined it thousands of times.

[[German#^de-Q0461-answer|Compare the answer]]
^de-Q0461

**de-Q0462 · Explain the grammar**

Ich habe das Haus noch nie gesehen, 【aber】 ich habe es mir schon Tausende Male vorgestellt.

I've never seen that house, but I've imagined it thousands of times.

[[German#^de-Q0462-answer|Compare the answer]]
^de-Q0462

**de-Q0463 · Fill the gap**

Tom ____ Maria arbeiten beide im selben Supermarkt.

Tom and Mary both work at the same supermarket.

[[German#^de-Q0463-answer|Compare the answer]]
^de-Q0463

**de-Q0464 · Choose the form**

Tom ____ Maria arbeiten beide im selben Supermarkt.

Tom and Mary both work at the same supermarket.

Choices: oder / aber / denn / und

[[German#^de-Q0464-answer|Compare the answer]]
^de-Q0464

**de-Q0465 · Edit the changed sentence**

Was glauben Sie, wie Tom 【aber】 Maria das hinkriegen?

How do you think Tom and Mary do that?

[[German#^de-Q0465-answer|Compare the answer]]
^de-Q0465

**de-Q0466 · Build the sentence**

Arrange: Was / hinkriegen? / das / glauben / Sie, / wie / Tom / und / Maria

How do you think Tom and Mary do that?

[[German#^de-Q0466-answer|Compare the answer]]
^de-Q0466

**de-Q0467 · Write a translation**

Write this in German: Looks like Latin, but it is not.

[[German#^de-Q0467-answer|Compare the answer]]
^de-Q0467

**de-Q0468 · Explain the grammar**

Sieht aus wie Latein, ist es 【aber】 nicht.

Looks like Latin, but it is not.

[[German#^de-Q0468-answer|Compare the answer]]
^de-Q0468

**de-Q0469 · Fill the gap**

Maria liebt mich, ____ ich liebe sie auch.

Mary loves me and I love her, too.

[[German#^de-Q0469-answer|Compare the answer]]
^de-Q0469

**de-Q0470 · Choose the form**

Maria liebt mich, ____ ich liebe sie auch.

Mary loves me and I love her, too.

Choices: denn / und / aber / oder

[[German#^de-Q0470-answer|Compare the answer]]
^de-Q0470

**de-Q0471 · Edit the changed sentence**

Komm her 【aber】 hilf mit.

Come over and help out.

[[German#^de-Q0471-answer|Compare the answer]]
^de-Q0471

**de-Q0472 · Build the sentence**

Arrange: und / hilf / her / mit. / Komm

Come over and help out.

[[German#^de-Q0472-answer|Compare the answer]]
^de-Q0472

**de-Q0473 · Write a translation**

Write this in German: The ticket is good through Monday.

[[German#^de-Q0473-answer|Compare the answer]]
^de-Q0473

**de-Q0474 · Explain the grammar**

Das Billet gilt bis 【und】 mit Montag.

The ticket is good through Monday.

[[German#^de-Q0474-answer|Compare the answer]]
^de-Q0474

**de-Q0475 · Fill the gap**

Ich habe nicht ihn geküsst, ____ er mich.

I didn't kiss him. He kissed me.

[[German#^de-Q0475-answer|Compare the answer]]
^de-Q0475

**de-Q0476 · Choose the form**

Ich habe nicht ihn geküsst, ____ er mich.

I didn't kiss him. He kissed me.

Choices: und / aber / sondern / oder

[[German#^de-Q0476-answer|Compare the answer]]
^de-Q0476

**de-Q0477 · Edit the changed sentence**

Wir standen früh auf 【aber】 machten uns dran, das Haus zu putzen.

We got up early and set about cleaning our house.

[[German#^de-Q0477-answer|Compare the answer]]
^de-Q0477

**de-Q0478 · Build the sentence**

Arrange: Haus / machten / dran, / zu / das / uns / früh / auf / und / standen / putzen. / Wir

We got up early and set about cleaning our house.

[[German#^de-Q0478-answer|Compare the answer]]
^de-Q0478

**de-Q0479 · Write a translation**

Write this in German: I'm not a ghost-writer, I'm the ghost of a deceased writer.

[[German#^de-Q0479-answer|Compare the answer]]
^de-Q0479

**de-Q0480 · Explain the grammar**

Ich bin kein Geisterschreiber, 【sondern】 der Geist eines verblichenen Schreibers.

I'm not a ghost-writer, I'm the ghost of a deceased writer.

[[German#^de-Q0480-answer|Compare the answer]]
^de-Q0480

**de-Q0481 · Fill the gap**

Toms Flug wurde verschoben ____ dann gestrichen.

Tom's flight was delayed and then cancelled.

[[German#^de-Q0481-answer|Compare the answer]]
^de-Q0481

**de-Q0482 · Choose the form**

Toms Flug wurde verschoben ____ dann gestrichen.

Tom's flight was delayed and then cancelled.

Choices: oder / aber / denn / und

[[German#^de-Q0482-answer|Compare the answer]]
^de-Q0482

**de-Q0483 · Edit the changed sentence**

Ihr wollt Tom doch nicht wütend machen, 【und】?

You don't want to make Tom mad, do you?

[[German#^de-Q0483-answer|Compare the answer]]
^de-Q0483

**de-Q0484 · Build the sentence**

Arrange: wütend / nicht / wollt / machen, / doch / Ihr / Tom / oder?

You don't want to make Tom mad, do you?

[[German#^de-Q0484-answer|Compare the answer]]
^de-Q0484

**de-Q0485 · Write a translation**

Write this in German: Tom won't be skiing with us, will he?

[[German#^de-Q0485-answer|Compare the answer]]
^de-Q0485

**de-Q0486 · Explain the grammar**

Tom fährt nicht mit uns Schi, 【oder】?

Tom won't be skiing with us, will he?

[[German#^de-Q0486-answer|Compare the answer]]
^de-Q0486

**de-Q0487 · Fill the gap**

Ich bin so schnell gerannt, wie ich konnte, ____ ich habe den letzten Zug nicht mehr erreicht.

I ran as fast as possible, but I was not in time for the last train.

[[German#^de-Q0487-answer|Compare the answer]]
^de-Q0487

**de-Q0488 · Choose the form**

Ich bin so schnell gerannt, wie ich konnte, ____ ich habe den letzten Zug nicht mehr erreicht.

I ran as fast as possible, but I was not in time for the last train.

Choices: denn / aber / und / oder

[[German#^de-Q0488-answer|Compare the answer]]
^de-Q0488

**de-Q0489 · Edit the changed sentence**

Das seid ihr gewohnt, 【und】?

You're used to that, aren't you?

[[German#^de-Q0489-answer|Compare the answer]]
^de-Q0489

**de-Q0490 · Build the sentence**

Arrange: oder? / seid / gewohnt, / ihr / Das

You're used to that, aren't you?

[[German#^de-Q0490-answer|Compare the answer]]
^de-Q0490

**de-Q0491 · Write a translation**

Write this in German: The bridge between Denmark and Sweden is almost five miles long.

[[German#^de-Q0491-answer|Compare the answer]]
^de-Q0491

**de-Q0492 · Explain the grammar**

Die Brücke zwischen Dänemark 【und】 Schweden ist fast acht Kilometer lang.

The bridge between Denmark and Sweden is almost five miles long.

[[German#^de-Q0492-answer|Compare the answer]]
^de-Q0492

**de-Q0493 · Fill the gap**

Ich verstehe kein Englisch ____ Deutsch noch weniger.

I understand no English and German even less.

[[German#^de-Q0493-answer|Compare the answer]]
^de-Q0493

**de-Q0494 · Choose the form**

Ich verstehe kein Englisch ____ Deutsch noch weniger.

I understand no English and German even less.

Choices: denn / aber / oder / und

[[German#^de-Q0494-answer|Compare the answer]]
^de-Q0494

**de-Q0495 · Edit the changed sentence**

Ein Gentleman ist einer, der weiß, wie man ein Banjo spielt 【aber】 es nicht tut.

A gentleman is someone who knows how to play the banjo and doesn't.

[[German#^de-Q0495-answer|Compare the answer]]
^de-Q0495

**de-Q0496 · Build the sentence**

Arrange: spielt / ist / ein / wie / und / einer, / Gentleman / weiß, / Banjo / es / Ein / nicht / man / der / tut.

A gentleman is someone who knows how to play the banjo and doesn't.

[[German#^de-Q0496-answer|Compare the answer]]
^de-Q0496

**de-Q0497 · Write a translation**

Write this in German: In 2008, Delta and Northwest airlines united to form the world's largest airline.

[[German#^de-Q0497-answer|Compare the answer]]
^de-Q0497

**de-Q0498 · Explain the grammar**

2008 fusionierten Delta 【und】 Northwest Airlines zur weltgrößten Fluggesellschaft.

In 2008, Delta and Northwest airlines united to form the world's largest airline.

[[German#^de-Q0498-answer|Compare the answer]]
^de-Q0498

**de-Q0499 · Fill the gap**

Tom ____ Maria küssten sich im Treppenhaus.

Tom and Mary kissed in the stairwell.

[[German#^de-Q0499-answer|Compare the answer]]
^de-Q0499

**de-Q0500 · Choose the form**

Tom ____ Maria küssten sich im Treppenhaus.

Tom and Mary kissed in the stairwell.

Choices: und / aber / denn / oder

[[German#^de-Q0500-answer|Compare the answer]]
^de-Q0500


### Prepositions with case · 50 questions

**de-Q0501 · Edit the changed sentence**

Tom wusste 【mit】 nichts.

Tom knew nothing.

[[German#^de-Q0501-answer|Compare the answer]]
^de-Q0501

**de-Q0502 · Build the sentence**

Arrange: nichts. / von / wusste / Tom

Tom knew nothing.

[[German#^de-Q0502-answer|Compare the answer]]
^de-Q0502

**de-Q0503 · Write a translation**

Write this in German: I promise I'll be nice to you from now on.

[[German#^de-Q0503-answer|Compare the answer]]
^de-Q0503

**de-Q0504 · Explain the grammar**

Ich verspreche, 【von】 nun an nett zu euch zu sein.

I promise I'll be nice to you from now on.

[[German#^de-Q0504-answer|Compare the answer]]
^de-Q0504

**de-Q0505 · Fill the gap**

Ich wurde ____ Unrecht angeklagt.

I was falsely accused.

[[German#^de-Q0505-answer|Compare the answer]]
^de-Q0505

**de-Q0506 · Choose the form**

Ich wurde ____ Unrecht angeklagt.

I was falsely accused.

Choices: ohne / mit / für / zu

[[German#^de-Q0506-answer|Compare the answer]]
^de-Q0506

**de-Q0507 · Edit the changed sentence**

Am nächsten Sonntag fahren wir 【mit】.

We'll go for a drive next Sunday.

[[German#^de-Q0507-answer|Compare the answer]]
^de-Q0507

**de-Q0508 · Build the sentence**

Arrange: fahren / nächsten / aus. / wir / Sonntag / Am

We'll go for a drive next Sunday.

[[German#^de-Q0508-answer|Compare the answer]]
^de-Q0508

**de-Q0509 · Write a translation**

Write this in German: I will be leaving for Australia next month.

[[German#^de-Q0509-answer|Compare the answer]]
^de-Q0509

**de-Q0510 · Explain the grammar**

Ich fahre nächsten Monat 【nach】 Australien.

I will be leaving for Australia next month.

[[German#^de-Q0510-answer|Compare the answer]]
^de-Q0510

**de-Q0511 · Fill the gap**

Tom vergaß, sich die Hände ____ waschen.

Tom forgot to wash his hands.

[[German#^de-Q0511-answer|Compare the answer]]
^de-Q0511

**de-Q0512 · Choose the form**

Tom vergaß, sich die Hände ____ waschen.

Tom forgot to wash his hands.

Choices: für / ohne / mit / zu

[[German#^de-Q0512-answer|Compare the answer]]
^de-Q0512

**de-Q0513 · Edit the changed sentence**

Doch, ich war 【mit】 Hause!

No, I was at home!

[[German#^de-Q0513-answer|Compare the answer]]
^de-Q0513

**de-Q0514 · Build the sentence**

Arrange: zu / war / ich / Doch, / Hause!

No, I was at home!

[[German#^de-Q0514-answer|Compare the answer]]
^de-Q0514

**de-Q0515 · Write a translation**

Write this in German: I'm trying to leave a little space for dessert.

[[German#^de-Q0515-answer|Compare the answer]]
^de-Q0515

**de-Q0516 · Explain the grammar**

Ich versuche noch etwas Platz 【für】 den Nachtisch lassen.

I'm trying to leave a little space for dessert.

[[German#^de-Q0516-answer|Compare the answer]]
^de-Q0516

**de-Q0517 · Fill the gap**

Das Kind spielt gerne ____ den Katzen.

The child likes to play with the cats.

[[German#^de-Q0517-answer|Compare the answer]]
^de-Q0517

**de-Q0518 · Choose the form**

Das Kind spielt gerne ____ den Katzen.

The child likes to play with the cats.

Choices: ohne / für / bei / mit

[[German#^de-Q0518-answer|Compare the answer]]
^de-Q0518

**de-Q0519 · Edit the changed sentence**

【mit】 meinem ersten Besuch in Spanien war alles ganz aufregend für mich.

Everything was exciting to me when I visited Spain for the first time.

[[German#^de-Q0519-answer|Compare the answer]]
^de-Q0519

**de-Q0520 · Build the sentence**

Arrange: war / aufregend / für / Besuch / in / mich. / meinem / ersten / Bei / alles / Spanien / ganz

Everything was exciting to me when I visited Spain for the first time.

[[German#^de-Q0520-answer|Compare the answer]]
^de-Q0520

**de-Q0521 · Write a translation**

Write this in German: Everything depends upon your decision.

[[German#^de-Q0521-answer|Compare the answer]]
^de-Q0521

**de-Q0522 · Explain the grammar**

Alles hängt 【von】 eurer Entscheidung ab.

Everything depends upon your decision.

[[German#^de-Q0522-answer|Compare the answer]]
^de-Q0522

**de-Q0523 · Fill the gap**

Er war berühmt ____ seine Marathonreden im Parlament.

He was famous for his marathon speeches in parliament.

[[German#^de-Q0523-answer|Compare the answer]]
^de-Q0523

**de-Q0524 · Choose the form**

Er war berühmt ____ seine Marathonreden im Parlament.

He was famous for his marathon speeches in parliament.

Choices: mit / ohne / für / bei

[[German#^de-Q0524-answer|Compare the answer]]
^de-Q0524

**de-Q0525 · Edit the changed sentence**

Ich hasse es, meine Zeit 【mit】 verschwenden.

I hate to waste my time.

[[German#^de-Q0525-answer|Compare the answer]]
^de-Q0525

**de-Q0526 · Build the sentence**

Arrange: Zeit / zu / es, / hasse / Ich / verschwenden. / meine

I hate to waste my time.

[[German#^de-Q0526-answer|Compare the answer]]
^de-Q0526

**de-Q0527 · Write a translation**

Write this in German: Stop fighting. We're all on the same team here.

[[German#^de-Q0527-answer|Compare the answer]]
^de-Q0527

**de-Q0528 · Explain the grammar**

Hört auf, euch 【zu】 streiten! Wir stehen hier alle auf der gleichen Seite.

Stop fighting. We're all on the same team here.

[[German#^de-Q0528-answer|Compare the answer]]
^de-Q0528

**de-Q0529 · Fill the gap**

Übersetze, statt ____ quatschen!

Translate instead of chattering!

[[German#^de-Q0529-answer|Compare the answer]]
^de-Q0529

**de-Q0530 · Choose the form**

Übersetze, statt ____ quatschen!

Translate instead of chattering!

Choices: mit / zu / ohne / für

[[German#^de-Q0530-answer|Compare the answer]]
^de-Q0530

**de-Q0531 · Edit the changed sentence**

Tom ist 【für】 seinem Hubschrauber auf dem Dach gelandet.

Tom landed his helicopter on the roof.

[[German#^de-Q0531-answer|Compare the answer]]
^de-Q0531

**de-Q0532 · Build the sentence**

Arrange: gelandet. / dem / auf / seinem / Tom / Dach / mit / Hubschrauber / ist

Tom landed his helicopter on the roof.

[[German#^de-Q0532-answer|Compare the answer]]
^de-Q0532

**de-Q0533 · Write a translation**

Write this in German: I'll read your fortune.

[[German#^de-Q0533-answer|Compare the answer]]
^de-Q0533

**de-Q0534 · Explain the grammar**

Ich werde dir 【aus】 der Hand lesen.

I'll read your fortune.

[[German#^de-Q0534-answer|Compare the answer]]
^de-Q0534

**de-Q0535 · Fill the gap**

Mir ging der Sprit ____.

I ran out of gas.

[[German#^de-Q0535-answer|Compare the answer]]
^de-Q0535

**de-Q0536 · Choose the form**

Mir ging der Sprit ____.

I ran out of gas.

Choices: für / ohne / aus / mit

[[German#^de-Q0536-answer|Compare the answer]]
^de-Q0536

**de-Q0537 · Edit the changed sentence**

【für】 wem ist Tom beisammen?

Who's Tom with?

[[German#^de-Q0537-answer|Compare the answer]]
^de-Q0537

**de-Q0538 · Build the sentence**

Arrange: beisammen? / Tom / Mit / wem / ist

Who's Tom with?

[[German#^de-Q0538-answer|Compare the answer]]
^de-Q0538

**de-Q0539 · Write a translation**

Write this in German: It's hard to sell a fixer-upper nowadays.

[[German#^de-Q0539-answer|Compare the answer]]
^de-Q0539

**de-Q0540 · Explain the grammar**

Heutzutage ist es schwer, ein renovierungsbedürftiges Haus 【zu】 verkaufen.

It's hard to sell a fixer-upper nowadays.

[[German#^de-Q0540-answer|Compare the answer]]
^de-Q0540

**de-Q0541 · Fill the gap**

Tom verdient kaum genug, um davon ____ leben.

Tom just barely earns enough to live on.

[[German#^de-Q0541-answer|Compare the answer]]
^de-Q0541

**de-Q0542 · Choose the form**

Tom verdient kaum genug, um davon ____ leben.

Tom just barely earns enough to live on.

Choices: für / zu / ohne / mit

[[German#^de-Q0542-answer|Compare the answer]]
^de-Q0542

**de-Q0543 · Edit the changed sentence**

Tom kommt 【mit】 mir vorbei.

Tom is coming to see me.

[[German#^de-Q0543-answer|Compare the answer]]
^de-Q0543

**de-Q0544 · Build the sentence**

Arrange: bei / Tom / kommt / mir / vorbei.

Tom is coming to see me.

[[German#^de-Q0544-answer|Compare the answer]]
^de-Q0544

**de-Q0545 · Write a translation**

Write this in German: It's very hard getting a taxi in this city.

[[German#^de-Q0545-answer|Compare the answer]]
^de-Q0545

**de-Q0546 · Explain the grammar**

Es ist sehr schwer, ein Taxi in dieser Stadt 【zu】 bekommen.

It's very hard getting a taxi in this city.

[[German#^de-Q0546-answer|Compare the answer]]
^de-Q0546

**de-Q0547 · Fill the gap**

Alle auf der Feier waren ____ ihrer Anmut bezaubert.

Everybody at the party was charmed by her grace.

[[German#^de-Q0547-answer|Compare the answer]]
^de-Q0547

**de-Q0548 · Choose the form**

Alle auf der Feier waren ____ ihrer Anmut bezaubert.

Everybody at the party was charmed by her grace.

Choices: ohne / von / für / mit

[[German#^de-Q0548-answer|Compare the answer]]
^de-Q0548

**de-Q0549 · Edit the changed sentence**

Habt ihr 【für】 Tom darüber gesprochen?

Have you talked to Tom about this?

[[German#^de-Q0549-answer|Compare the answer]]
^de-Q0549

**de-Q0550 · Build the sentence**

Arrange: Habt / gesprochen? / mit / Tom / darüber / ihr

Have you talked to Tom about this?

[[German#^de-Q0550-answer|Compare the answer]]
^de-Q0550


### Two-way prepositions · 50 questions

**de-Q0551 · Write a translation**

Write this in German: Look at those fish in the pond.

[[German#^de-Q0551-answer|Compare the answer]]
^de-Q0551

**de-Q0552 · Explain the grammar**

Schauen Sie sich diese Fische im Teich 【an】.

Look at those fish in the pond.

[[German#^de-Q0552-answer|Compare the answer]]
^de-Q0552

**de-Q0553 · Fill the gap**

Tom sollte ____ Kürze hier sein.

Tom should be here shortly.

[[German#^de-Q0553-answer|Compare the answer]]
^de-Q0553

**de-Q0554 · Choose the form**

Tom sollte ____ Kürze hier sein.

Tom should be here shortly.

Choices: an / unter / in / auf

[[German#^de-Q0554-answer|Compare the answer]]
^de-Q0554

**de-Q0555 · Edit the changed sentence**

Die Jungen unterhielten sich 【in】 Videospiele.

The boys talked about video games.

[[German#^de-Q0555-answer|Compare the answer]]
^de-Q0555

**de-Q0556 · Build the sentence**

Arrange: Die / unterhielten / über / sich / Videospiele. / Jungen

The boys talked about video games.

[[German#^de-Q0556-answer|Compare the answer]]
^de-Q0556

**de-Q0557 · Write a translation**

Write this in German: Hold your breath, please.

[[German#^de-Q0557-answer|Compare the answer]]
^de-Q0557

**de-Q0558 · Explain the grammar**

Halten Sie mal den Atem 【an】.

Hold your breath, please.

[[German#^de-Q0558-answer|Compare the answer]]
^de-Q0558

**de-Q0559 · Fill the gap**

Tom gewann zehntausend Dollar ____ der Lotterie.

Tom won $10,000 in the lottery.

[[German#^de-Q0559-answer|Compare the answer]]
^de-Q0559

**de-Q0560 · Choose the form**

Tom gewann zehntausend Dollar ____ der Lotterie.

Tom won $10,000 in the lottery.

Choices: auf / in / an / unter

[[German#^de-Q0560-answer|Compare the answer]]
^de-Q0560

**de-Q0561 · Edit the changed sentence**

Ich wollte niemanden 【an】 die Irre führen.

I didn't want to mislead anyone.

[[German#^de-Q0561-answer|Compare the answer]]
^de-Q0561

**de-Q0562 · Build the sentence**

Arrange: in / die / wollte / Ich / Irre / niemanden / führen.

I didn't want to mislead anyone.

[[German#^de-Q0562-answer|Compare the answer]]
^de-Q0562

**de-Q0563 · Write a translation**

Write this in German: You should read between the lines.

[[German#^de-Q0563-answer|Compare the answer]]
^de-Q0563

**de-Q0564 · Explain the grammar**

Ihr solltet 【zwischen】 den Zeilen lesen.

You should read between the lines.

[[German#^de-Q0564-answer|Compare the answer]]
^de-Q0564

**de-Q0565 · Fill the gap**

Setz ihn ____.

Put it on.

[[German#^de-Q0565-answer|Compare the answer]]
^de-Q0565

**de-Q0566 · Choose the form**

Setz ihn ____.

Put it on.

Choices: unter / in / an / auf

[[German#^de-Q0566-answer|Compare the answer]]
^de-Q0566

**de-Q0567 · Edit the changed sentence**

Tom ist 【in】 Mary davongerannt.

Tom ran away from Mary.

[[German#^de-Q0567-answer|Compare the answer]]
^de-Q0567

**de-Q0568 · Build the sentence**

Arrange: davongerannt. / vor / Tom / Mary / ist

Tom ran away from Mary.

[[German#^de-Q0568-answer|Compare the answer]]
^de-Q0568

**de-Q0569 · Write a translation**

Write this in German: There was no one in the library.

[[German#^de-Q0569-answer|Compare the answer]]
^de-Q0569

**de-Q0570 · Explain the grammar**

【In】 der Bibliothek war niemand.

There was no one in the library.

[[German#^de-Q0570-answer|Compare the answer]]
^de-Q0570

**de-Q0571 · Fill the gap**

Sie fesselten den Dieb ____ den Baum.

They tied the thief to the tree.

[[German#^de-Q0571-answer|Compare the answer]]
^de-Q0571

**de-Q0572 · Choose the form**

Sie fesselten den Dieb ____ den Baum.

They tied the thief to the tree.

Choices: an / unter / in / auf

[[German#^de-Q0572-answer|Compare the answer]]
^de-Q0572

**de-Q0573 · Edit the changed sentence**

Er legte mir die Hand 【in】 meine Schulter.

He placed his hand on my shoulder.

[[German#^de-Q0573-answer|Compare the answer]]
^de-Q0573

**de-Q0574 · Build the sentence**

Arrange: legte / mir / Hand / meine / die / auf / Er / Schulter.

He placed his hand on my shoulder.

[[German#^de-Q0574-answer|Compare the answer]]
^de-Q0574

**de-Q0575 · Write a translation**

Write this in German: I'm a little angry with you.

[[German#^de-Q0575-answer|Compare the answer]]
^de-Q0575

**de-Q0576 · Explain the grammar**

Ich bin ein bisschen sauer 【auf】 dich.

I'm a little angry with you.

[[German#^de-Q0576-answer|Compare the answer]]
^de-Q0576

**de-Q0577 · Fill the gap**

____ der Spüle ist schmutziges Geschirr.

There are dirty dishes in the sink­.

[[German#^de-Q0577-answer|Compare the answer]]
^de-Q0577

**de-Q0578 · Choose the form**

____ der Spüle ist schmutziges Geschirr.

There are dirty dishes in the sink­.

Choices: In / unter / an / auf

[[German#^de-Q0578-answer|Compare the answer]]
^de-Q0578

**de-Q0579 · Edit the changed sentence**

Er wollte alles 【in】 Sie erfahren.

He wanted to know everything about you.

[[German#^de-Q0579-answer|Compare the answer]]
^de-Q0579

**de-Q0580 · Build the sentence**

Arrange: erfahren. / alles / wollte / Er / Sie / über

He wanted to know everything about you.

[[German#^de-Q0580-answer|Compare the answer]]
^de-Q0580

**de-Q0581 · Write a translation**

Write this in German: We'll meet you out front.

[[German#^de-Q0581-answer|Compare the answer]]
^de-Q0581

**de-Q0582 · Explain the grammar**

Wir treffen uns draußen 【vor】 dem Eingang.

We'll meet you out front.

[[German#^de-Q0582-answer|Compare the answer]]
^de-Q0582

**de-Q0583 · Fill the gap**

Hat Tom sich mit Ihnen ____ Verbindung gesetzt?

Did Tom contact you?

[[German#^de-Q0583-answer|Compare the answer]]
^de-Q0583

**de-Q0584 · Choose the form**

Hat Tom sich mit Ihnen ____ Verbindung gesetzt?

Did Tom contact you?

Choices: an / in / auf / unter

[[German#^de-Q0584-answer|Compare the answer]]
^de-Q0584

**de-Q0585 · Edit the changed sentence**

Er legte mir die Hand 【in】 die Schulter.

He placed his hand on my shoulder.

[[German#^de-Q0585-answer|Compare the answer]]
^de-Q0585

**de-Q0586 · Build the sentence**

Arrange: die / die / auf / Er / mir / Hand / Schulter. / legte

He placed his hand on my shoulder.

[[German#^de-Q0586-answer|Compare the answer]]
^de-Q0586

**de-Q0587 · Write a translation**

Write this in German: Happiness lies in contentment.

[[German#^de-Q0587-answer|Compare the answer]]
^de-Q0587

**de-Q0588 · Explain the grammar**

Glück liegt 【in】 Zufriedenheit.

Happiness lies in contentment.

[[German#^de-Q0588-answer|Compare the answer]]
^de-Q0588

**de-Q0589 · Fill the gap**

Wie heißt das ____ Italienisch?

How do you say that in Italian?

[[German#^de-Q0589-answer|Compare the answer]]
^de-Q0589

**de-Q0590 · Choose the form**

Wie heißt das ____ Italienisch?

How do you say that in Italian?

Choices: an / unter / auf / in

[[German#^de-Q0590-answer|Compare the answer]]
^de-Q0590

**de-Q0591 · Edit the changed sentence**

Der Inhalt der Schachtel ist 【in】 dem Etikett verzeichnet.

The contents of the box are indicated on the label.

[[German#^de-Q0591-answer|Compare the answer]]
^de-Q0591

**de-Q0592 · Build the sentence**

Arrange: verzeichnet. / dem / auf / ist / Schachtel / Der / der / Etikett / Inhalt

The contents of the box are indicated on the label.

[[German#^de-Q0592-answer|Compare the answer]]
^de-Q0592

**de-Q0593 · Write a translation**

Write this in German: Don't forget to return the book to the library.

[[German#^de-Q0593-answer|Compare the answer]]
^de-Q0593

**de-Q0594 · Explain the grammar**

Vergiss nicht, das Buch 【in】 der Bibliothek zurückzugeben.

Don't forget to return the book to the library.

[[German#^de-Q0594-answer|Compare the answer]]
^de-Q0594

**de-Q0595 · Fill the gap**

Ich lernte fleißig, um ____ die Schule aufgenommen zu werden.

I studied hard to enter the school.

[[German#^de-Q0595-answer|Compare the answer]]
^de-Q0595

**de-Q0596 · Choose the form**

Ich lernte fleißig, um ____ die Schule aufgenommen zu werden.

I studied hard to enter the school.

Choices: in / an / unter / auf

[[German#^de-Q0596-answer|Compare the answer]]
^de-Q0596

**de-Q0597 · Edit the changed sentence**

Er drückte seine Gefühle 【an】 Form eines Bildes aus.

He expressed his feelings in the form of a painting.

[[German#^de-Q0597-answer|Compare the answer]]
^de-Q0597

**de-Q0598 · Build the sentence**

Arrange: Form / Er / eines / Gefühle / drückte / seine / aus. / in / Bildes

He expressed his feelings in the form of a painting.

[[German#^de-Q0598-answer|Compare the answer]]
^de-Q0598

**de-Q0599 · Write a translation**

Write this in German: Isn't it strange?--A foreigner showing a local how to bargain at the bazaar.

[[German#^de-Q0599-answer|Compare the answer]]
^de-Q0599

**de-Q0600 · Explain the grammar**

Ist das nicht skurril? Ein Ausländer, der einem Einheimischen das Feilschen 【auf】 dem Basar beibringt!

Isn't it strange?--A foreigner showing a local how to bargain at the bazaar.

[[German#^de-Q0600-answer|Compare the answer]]
^de-Q0600


### Past forms of sein and haben · 50 questions

**de-Q0601 · Fill the gap**

Wie ____ eure letzten Prüfungen?

How were your last exams?

[[German#^de-Q0601-answer|Compare the answer]]
^de-Q0601

**de-Q0602 · Choose the form**

Wie ____ eure letzten Prüfungen?

How were your last exams?

Choices: hatten / waren / war / hatte

[[German#^de-Q0602-answer|Compare the answer]]
^de-Q0602

**de-Q0603 · Edit the changed sentence**

Das 【waren】 äußerst lustig.

It was extremely funny.

[[German#^de-Q0603-answer|Compare the answer]]
^de-Q0603

**de-Q0604 · Build the sentence**

Arrange: Das / lustig. / äußerst / war

It was extremely funny.

[[German#^de-Q0604-answer|Compare the answer]]
^de-Q0604

**de-Q0605 · Write a translation**

Write this in German: That was a serious mistake.

[[German#^de-Q0605-answer|Compare the answer]]
^de-Q0605

**de-Q0606 · Explain the grammar**

Das 【war】 ein schwerwiegender Fehler.

That was a serious mistake.

[[German#^de-Q0606-answer|Compare the answer]]
^de-Q0606

**de-Q0607 · Fill the gap**

Maria ____ eine außergewöhnliche Frau.

Mary was an extraordinary woman.

[[German#^de-Q0607-answer|Compare the answer]]
^de-Q0607

**de-Q0608 · Choose the form**

Maria ____ eine außergewöhnliche Frau.

Mary was an extraordinary woman.

Choices: waren / hatte / hatten / war

[[German#^de-Q0608-answer|Compare the answer]]
^de-Q0608

**de-Q0609 · Edit the changed sentence**

Das ist, wie es damals 【waren】.

That's how things were back then.

[[German#^de-Q0609-answer|Compare the answer]]
^de-Q0609

**de-Q0610 · Build the sentence**

Arrange: damals / war. / wie / es / Das / ist,

That's how things were back then.

[[German#^de-Q0610-answer|Compare the answer]]
^de-Q0610

**de-Q0611 · Write a translation**

Write this in German: Tom had already left when I arrived.

[[German#^de-Q0611-answer|Compare the answer]]
^de-Q0611

**de-Q0612 · Explain the grammar**

Tom 【war】 schon weg, als ich ankam.

Tom had already left when I arrived.

[[German#^de-Q0612-answer|Compare the answer]]
^de-Q0612

**de-Q0613 · Fill the gap**

Was ihr getan habt, ____ sehr tapfer.

What you did was very brave.

[[German#^de-Q0613-answer|Compare the answer]]
^de-Q0613

**de-Q0614 · Choose the form**

Was ihr getan habt, ____ sehr tapfer.

What you did was very brave.

Choices: waren / war / hatte / hatten

[[German#^de-Q0614-answer|Compare the answer]]
^de-Q0614

**de-Q0615 · Edit the changed sentence**

Tom erklärte im Detail, was er gesehen 【war】.

Tom explained in detail what he had seen.

[[German#^de-Q0615-answer|Compare the answer]]
^de-Q0615

**de-Q0616 · Build the sentence**

Arrange: hatte. / er / Tom / was / gesehen / im / Detail, / erklärte

Tom explained in detail what he had seen.

[[German#^de-Q0616-answer|Compare the answer]]
^de-Q0616

**de-Q0617 · Write a translation**

Write this in German: The prominent poet attempted to commit suicide in his study.

[[German#^de-Q0617-answer|Compare the answer]]
^de-Q0617

**de-Q0618 · Explain the grammar**

Der bekannte Dichter 【hatte】 in seinem Arbeitszimmer einen Selbstmordversuch unternommen.

The prominent poet attempted to commit suicide in his study.

[[German#^de-Q0618-answer|Compare the answer]]
^de-Q0618

**de-Q0619 · Fill the gap**

Maria ____ eifersüchtig.

Mary was jealous.

[[German#^de-Q0619-answer|Compare the answer]]
^de-Q0619

**de-Q0620 · Choose the form**

Maria ____ eifersüchtig.

Mary was jealous.

Choices: hatte / hatten / waren / war

[[German#^de-Q0620-answer|Compare the answer]]
^de-Q0620

**de-Q0621 · Edit the changed sentence**

Toms Mutter 【waren】 eine fromme Katholikin.

Tom's mother was a devout Catholic.

[[German#^de-Q0621-answer|Compare the answer]]
^de-Q0621

**de-Q0622 · Build the sentence**

Arrange: eine / Katholikin. / Toms / Mutter / war / fromme

Tom's mother was a devout Catholic.

[[German#^de-Q0622-answer|Compare the answer]]
^de-Q0622

**de-Q0623 · Write a translation**

Write this in German: He was stunned.

[[German#^de-Q0623-answer|Compare the answer]]
^de-Q0623

**de-Q0624 · Explain the grammar**

Er 【war】 wie gelähmt.

He was stunned.

[[German#^de-Q0624-answer|Compare the answer]]
^de-Q0624

**de-Q0625 · Fill the gap**

Maria ____ ein schüchternes Kind.

Mary was a timid child.

[[German#^de-Q0625-answer|Compare the answer]]
^de-Q0625

**de-Q0626 · Choose the form**

Maria ____ ein schüchternes Kind.

Mary was a timid child.

Choices: war / hatten / hatte / waren

[[German#^de-Q0626-answer|Compare the answer]]
^de-Q0626

**de-Q0627 · Edit the changed sentence**

Eines Nachts 【war】 er einen Traum.

One night, he had a dream.

[[German#^de-Q0627-answer|Compare the answer]]
^de-Q0627

**de-Q0628 · Build the sentence**

Arrange: einen / hatte / Nachts / Eines / Traum. / er

One night, he had a dream.

[[German#^de-Q0628-answer|Compare the answer]]
^de-Q0628

**de-Q0629 · Write a translation**

Write this in German: I was glad when I woke up and realised that it had all been just a bad dream.

[[German#^de-Q0629-answer|Compare the answer]]
^de-Q0629

**de-Q0630 · Explain the grammar**

Ich 【war】 froh, als ich erwachte und feststellte, dass alles nur ein böser Traum gewesen war.

I was glad when I woke up and realised that it had all been just a bad dream.

[[German#^de-Q0630-answer|Compare the answer]]
^de-Q0630

**de-Q0631 · Fill the gap**

Ich ____ ein Gespräch mit Tom.

I had a talk with Tom.

[[German#^de-Q0631-answer|Compare the answer]]
^de-Q0631

**de-Q0632 · Choose the form**

Ich ____ ein Gespräch mit Tom.

I had a talk with Tom.

Choices: hatte / war / waren / hatten

[[German#^de-Q0632-answer|Compare the answer]]
^de-Q0632

**de-Q0633 · Edit the changed sentence**

Die Frau benutzte ein Nasenspray, weil sie eine schwere Erkältung 【war】.

The woman used a nasal spray because she had a severe cold.

[[German#^de-Q0633-answer|Compare the answer]]
^de-Q0633

**de-Q0634 · Build the sentence**

Arrange: sie / Die / schwere / benutzte / hatte. / Frau / ein / Nasenspray, / eine / Erkältung / weil

The woman used a nasal spray because she had a severe cold.

[[German#^de-Q0634-answer|Compare the answer]]
^de-Q0634

**de-Q0635 · Write a translation**

Write this in German: When Tom woke up, Mary was gone.

[[German#^de-Q0635-answer|Compare the answer]]
^de-Q0635

**de-Q0636 · Explain the grammar**

Als Tom aufwachte, 【war】 Maria weg.

When Tom woke up, Mary was gone.

[[German#^de-Q0636-answer|Compare the answer]]
^de-Q0636

**de-Q0637 · Fill the gap**

Zuerst: Marley ____ tot.

Marley was dead: to begin with.

[[German#^de-Q0637-answer|Compare the answer]]
^de-Q0637

**de-Q0638 · Choose the form**

Zuerst: Marley ____ tot.

Marley was dead: to begin with.

Choices: hatten / hatte / waren / war

[[German#^de-Q0638-answer|Compare the answer]]
^de-Q0638

**de-Q0639 · Edit the changed sentence**

Tom 【war】 nichts zu tun; deswegen ist er nach Hause gegangen.

Tom had nothing to do, so he went home.

[[German#^de-Q0639-answer|Compare the answer]]
^de-Q0639

**de-Q0640 · Build the sentence**

Arrange: Tom / zu / tun; / hatte / nach / Hause / er / gegangen. / ist / nichts / deswegen

Tom had nothing to do, so he went home.

[[German#^de-Q0640-answer|Compare the answer]]
^de-Q0640

**de-Q0641 · Write a translation**

Write this in German: Let's be honest. That joke was about me.

[[German#^de-Q0641-answer|Compare the answer]]
^de-Q0641

**de-Q0642 · Explain the grammar**

Seien wir ehrlich! Das 【war】 ein Witz über mich.

Let's be honest. That joke was about me.

[[German#^de-Q0642-answer|Compare the answer]]
^de-Q0642

**de-Q0643 · Fill the gap**

Sie ____ viel Spaß auf meine Kosten.

They had great fun at my expense.

[[German#^de-Q0643-answer|Compare the answer]]
^de-Q0643

**de-Q0644 · Choose the form**

Sie ____ viel Spaß auf meine Kosten.

They had great fun at my expense.

Choices: hatte / hatten / war / waren

[[German#^de-Q0644-answer|Compare the answer]]
^de-Q0644

**de-Q0645 · Edit the changed sentence**

Sie 【war】 nicht mehr das Bedürfnis zu protestieren.

They no longer felt a need to protest.

[[German#^de-Q0645-answer|Compare the answer]]
^de-Q0645

**de-Q0646 · Build the sentence**

Arrange: nicht / das / protestieren. / Bedürfnis / zu / mehr / Sie / hatten

They no longer felt a need to protest.

[[German#^de-Q0646-answer|Compare the answer]]
^de-Q0646

**de-Q0647 · Write a translation**

Write this in German: I was late for the meeting with the result that I missed the most important part.

[[German#^de-Q0647-answer|Compare the answer]]
^de-Q0647

**de-Q0648 · Explain the grammar**

Ich kam zu spät zu der Besprechung mit dem Ergebnis, dass ich das Wichtigste verpasst 【hatte】.

I was late for the meeting with the result that I missed the most important part.

[[German#^de-Q0648-answer|Compare the answer]]
^de-Q0648

**de-Q0649 · Fill the gap**

Ich ____ keine andere Wahl, als anzunehmen.

I had no choice but to accept.

[[German#^de-Q0649-answer|Compare the answer]]
^de-Q0649

**de-Q0650 · Choose the form**

Ich ____ keine andere Wahl, als anzunehmen.

I had no choice but to accept.

Choices: hatte / hatten / waren / war

[[German#^de-Q0650-answer|Compare the answer]]
^de-Q0650


### Participles in context · 50 questions

**de-Q0651 · Edit the changed sentence**

Weißt du, wie beschäftigt ich 【gemacht】 bin?

Do you know how busy I've been?

[[German#^de-Q0651-answer|Compare the answer]]
^de-Q0651

**de-Q0652 · Build the sentence**

Arrange: bin? / ich / du, / wie / beschäftigt / Weißt / gewesen

Do you know how busy I've been?

[[German#^de-Q0652-answer|Compare the answer]]
^de-Q0652

**de-Q0653 · Write a translation**

Write this in German: Who told him? Not you, perhaps?

[[German#^de-Q0653-answer|Compare the answer]]
^de-Q0653

**de-Q0654 · Explain the grammar**

Wer hat es ihm 【gesagt】? Nicht vielleicht du?

Who told him? Not you, perhaps?

[[German#^de-Q0654-answer|Compare the answer]]
^de-Q0654

**de-Q0655 · Fill the gap**

Tom ist schon lange nicht mehr hier ____.

Tom hasn't been here in a long time.

[[German#^de-Q0655-answer|Compare the answer]]
^de-Q0655

**de-Q0656 · Choose the form**

Tom ist schon lange nicht mehr hier ____.

Tom hasn't been here in a long time.

Choices: gegangen / gemacht / gesagt / gewesen

[[German#^de-Q0656-answer|Compare the answer]]
^de-Q0656

**de-Q0657 · Edit the changed sentence**

Hast du 【gemacht】, was Tom Maria angetan hat?

Did you see what Tom did to Mary?

[[German#^de-Q0657-answer|Compare the answer]]
^de-Q0657

**de-Q0658 · Build the sentence**

Arrange: Hast / hat? / gesehen, / Maria / angetan / was / Tom / du

Did you see what Tom did to Mary?

[[German#^de-Q0658-answer|Compare the answer]]
^de-Q0658

**de-Q0659 · Write a translation**

Write this in German: Tom has done everything right so far.

[[German#^de-Q0659-answer|Compare the answer]]
^de-Q0659

**de-Q0660 · Explain the grammar**

Tom hat bisher alles richtig 【gemacht】.

Tom has done everything right so far.

[[German#^de-Q0660-answer|Compare the answer]]
^de-Q0660

**de-Q0661 · Fill the gap**

Ich bin noch nie in einem Flugzeug ____.

I've never gotten on a plane yet.

[[German#^de-Q0661-answer|Compare the answer]]
^de-Q0661

**de-Q0662 · Choose the form**

Ich bin noch nie in einem Flugzeug ____.

I've never gotten on a plane yet.

Choices: gesagt / gemacht / gegangen / gewesen

[[German#^de-Q0662-answer|Compare the answer]]
^de-Q0662

**de-Q0663 · Edit the changed sentence**

A propos Schweiz, sind Sie dort schon mal im Winter 【gemacht】?

Speaking of Switzerland, have you ever been there in winter?

[[German#^de-Q0663-answer|Compare the answer]]
^de-Q0663

**de-Q0664 · Build the sentence**

Arrange: A / mal / propos / schon / Schweiz, / Winter / Sie / sind / dort / gewesen? / im

Speaking of Switzerland, have you ever been there in winter?

[[German#^de-Q0664-answer|Compare the answer]]
^de-Q0664

**de-Q0665 · Write a translation**

Write this in German: He has come!

[[German#^de-Q0665-answer|Compare the answer]]
^de-Q0665

**de-Q0666 · Explain the grammar**

Er ist 【gekommen】!

He has come!

[[German#^de-Q0666-answer|Compare the answer]]
^de-Q0666

**de-Q0667 · Fill the gap**

Ich habe wohl etwas falsch ____.

I seem to have done something wrong.

[[German#^de-Q0667-answer|Compare the answer]]
^de-Q0667

**de-Q0668 · Choose the form**

Ich habe wohl etwas falsch ____.

I seem to have done something wrong.

Choices: gesehen / gemacht / gesagt / gegangen

[[German#^de-Q0668-answer|Compare the answer]]
^de-Q0668

**de-Q0669 · Edit the changed sentence**

Ich kann mich nicht erinnern, dass ich das schon mal 【gemacht】 hätte.

I don't remember seeing it before.

[[German#^de-Q0669-answer|Compare the answer]]
^de-Q0669

**de-Q0670 · Build the sentence**

Arrange: kann / Ich / mal / dass / ich / das / schon / nicht / hätte. / mich / erinnern, / gesehen

I don't remember seeing it before.

[[German#^de-Q0670-answer|Compare the answer]]
^de-Q0670

**de-Q0671 · Write a translation**

Write this in German: I still haven't found what I'm looking for.

[[German#^de-Q0671-answer|Compare the answer]]
^de-Q0671

**de-Q0672 · Explain the grammar**

Ich habe noch nicht 【gefunden】, was ich suche.

I still haven't found what I'm looking for.

[[German#^de-Q0672-answer|Compare the answer]]
^de-Q0672

**de-Q0673 · Fill the gap**

Wenn ich die Wahrheit gewusst hätte, hätte ich sie dir ____.

If I'd known the truth, I would've told it to you.

[[German#^de-Q0673-answer|Compare the answer]]
^de-Q0673

**de-Q0674 · Choose the form**

Wenn ich die Wahrheit gewusst hätte, hätte ich sie dir ____.

If I'd known the truth, I would've told it to you.

Choices: gemacht / gesehen / gegangen / gesagt

[[German#^de-Q0674-answer|Compare the answer]]
^de-Q0674

**de-Q0675 · Edit the changed sentence**

Tom bestritt, in die Affäre verwickelt 【gemacht】 zu sein.

Tom denied having been involved in the affair.

[[German#^de-Q0675-answer|Compare the answer]]
^de-Q0675

**de-Q0676 · Build the sentence**

Arrange: Affäre / verwickelt / in / die / gewesen / bestritt, / sein. / Tom / zu

Tom denied having been involved in the affair.

[[German#^de-Q0676-answer|Compare the answer]]
^de-Q0676

**de-Q0677 · Write a translation**

Write this in German: I saw Tom three weeks ago.

[[German#^de-Q0677-answer|Compare the answer]]
^de-Q0677

**de-Q0678 · Explain the grammar**

Ich habe Tom vor drei Wochen 【gesehen】.

I saw Tom three weeks ago.

[[German#^de-Q0678-answer|Compare the answer]]
^de-Q0678

**de-Q0679 · Fill the gap**

Es wäre gemeint ____ zu lachen.

It would've been mean to laugh.

[[German#^de-Q0679-answer|Compare the answer]]
^de-Q0679

**de-Q0680 · Choose the form**

Es wäre gemeint ____ zu lachen.

It would've been mean to laugh.

Choices: gegangen / gewesen / gesagt / gemacht

[[German#^de-Q0680-answer|Compare the answer]]
^de-Q0680

**de-Q0681 · Edit the changed sentence**

Überleg mal, was ich dir 【gemacht】 habe.

Think about what I said to you.

[[German#^de-Q0681-answer|Compare the answer]]
^de-Q0681

**de-Q0682 · Build the sentence**

Arrange: mal, / Überleg / habe. / gesagt / ich / dir / was

Think about what I said to you.

[[German#^de-Q0682-answer|Compare the answer]]
^de-Q0682

**de-Q0683 · Write a translation**

Write this in German: I burned all the letters that you wrote me.

[[German#^de-Q0683-answer|Compare the answer]]
^de-Q0683

**de-Q0684 · Explain the grammar**

Ich habe alle Briefe verbrannt, die du mir 【geschrieben】 hast.

I burned all the letters that you wrote me.

[[German#^de-Q0684-answer|Compare the answer]]
^de-Q0684

**de-Q0685 · Fill the gap**

Ich bin ____, um dich zu warnen.

I came to warn you.

[[German#^de-Q0685-answer|Compare the answer]]
^de-Q0685

**de-Q0686 · Choose the form**

Ich bin ____, um dich zu warnen.

I came to warn you.

Choices: gemacht / gesagt / gegangen / gekommen

[[German#^de-Q0686-answer|Compare the answer]]
^de-Q0686

**de-Q0687 · Edit the changed sentence**

Sie hat ihr Zimmer noch nicht sauber 【gesagt】.

She hasn't cleaned her room yet.

[[German#^de-Q0687-answer|Compare the answer]]
^de-Q0687

**de-Q0688 · Build the sentence**

Arrange: Zimmer / ihr / Sie / sauber / noch / gemacht. / hat / nicht

She hasn't cleaned her room yet.

[[German#^de-Q0688-answer|Compare the answer]]
^de-Q0688

**de-Q0689 · Write a translation**

Write this in German: Hello, my dear, I made two pictures and I want your opinion on them.

[[German#^de-Q0689-answer|Compare the answer]]
^de-Q0689

**de-Q0690 · Explain the grammar**

Hallo, Liebes, ich habe zwei Bilder 【gemacht】 und wüsste gerne, was du von ihnen hältst.

Hello, my dear, I made two pictures and I want your opinion on them.

[[German#^de-Q0690-answer|Compare the answer]]
^de-Q0690

**de-Q0691 · Fill the gap**

Tom ist bei einem Unfall ums Leben ____.

Tom died in an accident.

[[German#^de-Q0691-answer|Compare the answer]]
^de-Q0691

**de-Q0692 · Choose the form**

Tom ist bei einem Unfall ums Leben ____.

Tom died in an accident.

Choices: gemacht / gegangen / gekommen / gesagt

[[German#^de-Q0692-answer|Compare the answer]]
^de-Q0692

**de-Q0693 · Edit the changed sentence**

Wer hat mich 【gemacht】?

Who saw me?

[[German#^de-Q0693-answer|Compare the answer]]
^de-Q0693

**de-Q0694 · Build the sentence**

Arrange: gesehen? / Wer / mich / hat

Who saw me?

[[German#^de-Q0694-answer|Compare the answer]]
^de-Q0694

**de-Q0695 · Write a translation**

Write this in German: I didn't say a single word.

[[German#^de-Q0695-answer|Compare the answer]]
^de-Q0695

**de-Q0696 · Explain the grammar**

Ich habe kein einziges Wort 【gesagt】.

I didn't say a single word.

[[German#^de-Q0696-answer|Compare the answer]]
^de-Q0696

**de-Q0697 · Fill the gap**

Während meine Frau in der Stadt einkaufen war, habe ich in der Küche klar Schiff ____.

While my wife was shopping in town, I tidied up in the kitchen.

[[German#^de-Q0697-answer|Compare the answer]]
^de-Q0697

**de-Q0698 · Choose the form**

Während meine Frau in der Stadt einkaufen war, habe ich in der Küche klar Schiff ____.

While my wife was shopping in town, I tidied up in the kitchen.

Choices: gesagt / gesehen / gemacht / gegangen

[[German#^de-Q0698-answer|Compare the answer]]
^de-Q0698

**de-Q0699 · Edit the changed sentence**

Wir hören oft, dass 【gemacht】 wird, die Japaner seien gute Arbeiter.

We often hear it said that the Japanese are good workers.

[[German#^de-Q0699-answer|Compare the answer]]
^de-Q0699

**de-Q0700 · Build the sentence**

Arrange: Wir / dass / Arbeiter. / seien / gesagt / gute / hören / Japaner / die / wird, / oft,

We often hear it said that the Japanese are good workers.

[[German#^de-Q0700-answer|Compare the answer]]
^de-Q0700


### Werden: future and passive · 50 questions

**de-Q0701 · Write a translation**

Write this in German: I'm beginning to get jealous.

[[German#^de-Q0701-answer|Compare the answer]]
^de-Q0701

**de-Q0702 · Explain the grammar**

Langsam 【werde】 ich neidisch.

I'm beginning to get jealous.

[[German#^de-Q0702-answer|Compare the answer]]
^de-Q0702

**de-Q0703 · Fill the gap**

Tom ____ Vater sein.

Tom is going to be a father.

[[German#^de-Q0703-answer|Compare the answer]]
^de-Q0703

**de-Q0704 · Choose the form**

Tom ____ Vater sein.

Tom is going to be a father.

Choices: wird / wurden / werden / wurde

[[German#^de-Q0704-answer|Compare the answer]]
^de-Q0704

**de-Q0705 · Edit the changed sentence**

Ich 【wird】 im Krankenhaus behandelt.

I am receiving treatment at the hospital.

[[German#^de-Q0705-answer|Compare the answer]]
^de-Q0705

**de-Q0706 · Build the sentence**

Arrange: werde / im / Ich / Krankenhaus / behandelt.

I am receiving treatment at the hospital.

[[German#^de-Q0706-answer|Compare the answer]]
^de-Q0706

**de-Q0707 · Write a translation**

Write this in German: Tom will do that tomorrow, too.

[[German#^de-Q0707-answer|Compare the answer]]
^de-Q0707

**de-Q0708 · Explain the grammar**

Tom 【wird】 das morgen auch tun.

Tom will do that tomorrow, too.

[[German#^de-Q0708-answer|Compare the answer]]
^de-Q0708

**de-Q0709 · Fill the gap**

Ich ____ ihnen Bescheid geben.

I'll let them know.

[[German#^de-Q0709-answer|Compare the answer]]
^de-Q0709

**de-Q0710 · Choose the form**

Ich ____ ihnen Bescheid geben.

I'll let them know.

Choices: wurde / werden / werde / wird

[[German#^de-Q0710-answer|Compare the answer]]
^de-Q0710

**de-Q0711 · Edit the changed sentence**

Die Tür 【werden】 jeden Morgen geöffnet.

The door is opened every morning.

[[German#^de-Q0711-answer|Compare the answer]]
^de-Q0711

**de-Q0712 · Build the sentence**

Arrange: Die / Tür / geöffnet. / jeden / wird / Morgen

The door is opened every morning.

[[German#^de-Q0712-answer|Compare the answer]]
^de-Q0712

**de-Q0713 · Write a translation**

Write this in German: This diagram will illustrate what I mean.

[[German#^de-Q0713-answer|Compare the answer]]
^de-Q0713

**de-Q0714 · Explain the grammar**

Dieses Diagram 【wird】 zeigen, was ich meine.

This diagram will illustrate what I mean.

[[German#^de-Q0714-answer|Compare the answer]]
^de-Q0714

**de-Q0715 · Fill the gap**

Tom ____ 2008 in den Senat gewählt.

Tom was elected to the Senate in 2008.

[[German#^de-Q0715-answer|Compare the answer]]
^de-Q0715

**de-Q0716 · Choose the form**

Tom ____ 2008 in den Senat gewählt.

Tom was elected to the Senate in 2008.

Choices: werden / wurde / wurden / wird

[[German#^de-Q0716-answer|Compare the answer]]
^de-Q0716

**de-Q0717 · Edit the changed sentence**

Der Himmel 【wird】 immer dunkler.

The sky grew darker and darker.

[[German#^de-Q0717-answer|Compare the answer]]
^de-Q0717

**de-Q0718 · Build the sentence**

Arrange: Himmel / Der / dunkler. / immer / wurde

The sky grew darker and darker.

[[German#^de-Q0718-answer|Compare the answer]]
^de-Q0718

**de-Q0719 · Write a translation**

Write this in German: I'll take my revenge on him at all costs tomorrow.

[[German#^de-Q0719-answer|Compare the answer]]
^de-Q0719

**de-Q0720 · Explain the grammar**

Ich 【werde】 morgen Rache an ihm nehmen, egal was es koste.

I'll take my revenge on him at all costs tomorrow.

[[German#^de-Q0720-answer|Compare the answer]]
^de-Q0720

**de-Q0721 · Fill the gap**

Dennoch ____ Japan vom Ausland immer noch nicht genügend verstanden, und die Japaner finden es ihrerseits schwierig, Ausländer zu verstehen.

Yet Japan is still not sufficiently understood by other countries, and the Japanese, likewise, find foreigners difficult to understand.

[[German#^de-Q0721-answer|Compare the answer]]
^de-Q0721

**de-Q0722 · Choose the form**

Dennoch ____ Japan vom Ausland immer noch nicht genügend verstanden, und die Japaner finden es ihrerseits schwierig, Ausländer zu verstehen.

Yet Japan is still not sufficiently understood by other countries, and the Japanese, likewise, find foreigners difficult to understand.

Choices: wurde / wird / wurden / werden

[[German#^de-Q0722-answer|Compare the answer]]
^de-Q0722

**de-Q0723 · Edit the changed sentence**

Ich 【wird】 zu Mittag zurückrufen.

I'll ring back at midday.

[[German#^de-Q0723-answer|Compare the answer]]
^de-Q0723

**de-Q0724 · Build the sentence**

Arrange: zu / Ich / werde / Mittag / zurückrufen.

I'll ring back at midday.

[[German#^de-Q0724-answer|Compare the answer]]
^de-Q0724

**de-Q0725 · Write a translation**

Write this in German: No child should be left behind.

[[German#^de-Q0725-answer|Compare the answer]]
^de-Q0725

**de-Q0726 · Explain the grammar**

Kein Kind sollte zurückgelassen 【werden】.

No child should be left behind.

[[German#^de-Q0726-answer|Compare the answer]]
^de-Q0726

**de-Q0727 · Fill the gap**

Es ____ bald alles vorbei sein.

It will all be over soon.

[[German#^de-Q0727-answer|Compare the answer]]
^de-Q0727

**de-Q0728 · Choose the form**

Es ____ bald alles vorbei sein.

It will all be over soon.

Choices: wurden / wurde / wird / werden

[[German#^de-Q0728-answer|Compare the answer]]
^de-Q0728

**de-Q0729 · Edit the changed sentence**

Sie 【wird】 sich erinnern.

They'll remember.

[[German#^de-Q0729-answer|Compare the answer]]
^de-Q0729

**de-Q0730 · Build the sentence**

Arrange: erinnern. / Sie / werden / sich

They'll remember.

[[German#^de-Q0730-answer|Compare the answer]]
^de-Q0730

**de-Q0731 · Write a translation**

Write this in German: Tom said that he was going to help.

[[German#^de-Q0731-answer|Compare the answer]]
^de-Q0731

**de-Q0732 · Explain the grammar**

Tom sagte, er 【werde】 helfen.

Tom said that he was going to help.

[[German#^de-Q0732-answer|Compare the answer]]
^de-Q0732

**de-Q0733 · Fill the gap**

Ich ____ morgen nach Hokkaidō fahren.

I will go to Hokkaido tomorrow.

[[German#^de-Q0733-answer|Compare the answer]]
^de-Q0733

**de-Q0734 · Choose the form**

Ich ____ morgen nach Hokkaidō fahren.

I will go to Hokkaido tomorrow.

Choices: werden / wurde / wird / werde

[[German#^de-Q0734-answer|Compare the answer]]
^de-Q0734

**de-Q0735 · Edit the changed sentence**

Das Klonen von Übermenschen 【wird】 zum militärischen Standard.

Cloning of supermen in the military became the norm.

[[German#^de-Q0735-answer|Compare the answer]]
^de-Q0735

**de-Q0736 · Build the sentence**

Arrange: Das / von / zum / Standard. / wurde / Klonen / Übermenschen / militärischen

Cloning of supermen in the military became the norm.

[[German#^de-Q0736-answer|Compare the answer]]
^de-Q0736

**de-Q0737 · Write a translation**

Write this in German: I'll spend Christmas with my family.

[[German#^de-Q0737-answer|Compare the answer]]
^de-Q0737

**de-Q0738 · Explain the grammar**

Ich 【werde】 Weihnachten mit meiner Familie zusammen verbringen.

I'll spend Christmas with my family.

[[German#^de-Q0738-answer|Compare the answer]]
^de-Q0738

**de-Q0739 · Fill the gap**

Ich ____ dich verklagen.

I will sue you.

[[German#^de-Q0739-answer|Compare the answer]]
^de-Q0739

**de-Q0740 · Choose the form**

Ich ____ dich verklagen.

I will sue you.

Choices: wurde / werde / wird / werden

[[German#^de-Q0740-answer|Compare the answer]]
^de-Q0740

**de-Q0741 · Edit the changed sentence**

Er 【werden】 sich bald an das Klima hier gewöhnen.

He will soon get used to the climate here.

[[German#^de-Q0741-answer|Compare the answer]]
^de-Q0741

**de-Q0742 · Build the sentence**

Arrange: Er / das / gewöhnen. / Klima / an / sich / bald / wird / hier

He will soon get used to the climate here.

[[German#^de-Q0742-answer|Compare the answer]]
^de-Q0742

**de-Q0743 · Write a translation**

Write this in German: How can we do better than this?

[[German#^de-Q0743-answer|Compare the answer]]
^de-Q0743

**de-Q0744 · Explain the grammar**

Wie können wir besser 【werden】?

How can we do better than this?

[[German#^de-Q0744-answer|Compare the answer]]
^de-Q0744

**de-Q0745 · Fill the gap**

Die Hochzeit ____ verschoben.

The wedding was moved.

[[German#^de-Q0745-answer|Compare the answer]]
^de-Q0745

**de-Q0746 · Choose the form**

Die Hochzeit ____ verschoben.

The wedding was moved.

Choices: wurden / wird / werden / wurde

[[German#^de-Q0746-answer|Compare the answer]]
^de-Q0746

**de-Q0747 · Edit the changed sentence**

Wir 【wird】 um 12.30 Uhr gemeinsam zu Mittag essen.

We will have lunch together at twelve-thirty.

[[German#^de-Q0747-answer|Compare the answer]]
^de-Q0747

**de-Q0748 · Build the sentence**

Arrange: um / 12.30 / essen. / gemeinsam / Mittag / Uhr / Wir / zu / werden

We will have lunch together at twelve-thirty.

[[German#^de-Q0748-answer|Compare the answer]]
^de-Q0748

**de-Q0749 · Write a translation**

Write this in German: I'll try to meet your wishes.

[[German#^de-Q0749-answer|Compare the answer]]
^de-Q0749

**de-Q0750 · Explain the grammar**

Ich 【werde】 versuchen, deine Wünsche zu erfüllen.

I'll try to meet your wishes.

[[German#^de-Q0750-answer|Compare the answer]]
^de-Q0750


### Conditional and polite forms · 50 questions

**de-Q0751 · Fill the gap**

Sie sagte, sie ____ im nächsten Monat sechzehn.

She said she would be sixteen next month.

[[German#^de-Q0751-answer|Compare the answer]]
^de-Q0751

**de-Q0752 · Choose the form**

Sie sagte, sie ____ im nächsten Monat sechzehn.

She said she would be sixteen next month.

Choices: hätte / würde / könnte / wäre

[[German#^de-Q0752-answer|Compare the answer]]
^de-Q0752

**de-Q0753 · Edit the changed sentence**

【würde】 Sie das noch einmal erklären?

Would you explain it again?

[[German#^de-Q0753-answer|Compare the answer]]
^de-Q0753

**de-Q0754 · Build the sentence**

Arrange: einmal / Sie / noch / das / Könnten / erklären?

Would you explain it again?

[[German#^de-Q0754-answer|Compare the answer]]
^de-Q0754

**de-Q0755 · Write a translation**

Write this in German: I'll take the yellow one.

[[German#^de-Q0755-answer|Compare the answer]]
^de-Q0755

**de-Q0756 · Explain the grammar**

Ich 【würde】 das gelbe nehmen.

I'll take the yellow one.

[[German#^de-Q0756-answer|Compare the answer]]
^de-Q0756

**de-Q0757 · Fill the gap**

Mit dem Fahrrad ____ ich in 20 Minuten bei dir zu Hause sein.

With a bicycle, I could reach your house in 20 minutes.

[[German#^de-Q0757-answer|Compare the answer]]
^de-Q0757

**de-Q0758 · Choose the form**

Mit dem Fahrrad ____ ich in 20 Minuten bei dir zu Hause sein.

With a bicycle, I could reach your house in 20 minutes.

Choices: hätte / wäre / würde / könnte

[[German#^de-Q0758-answer|Compare the answer]]
^de-Q0758

**de-Q0759 · Edit the changed sentence**

Ich wünschte ich 【würde】 zaubern.

I wish I could use magic.

[[German#^de-Q0759-answer|Compare the answer]]
^de-Q0759

**de-Q0760 · Build the sentence**

Arrange: könnte / zaubern. / Ich / ich / wünschte

I wish I could use magic.

[[German#^de-Q0760-answer|Compare the answer]]
^de-Q0760

**de-Q0761 · Write a translation**

Write this in German: Would you mind if I took a break?

[[German#^de-Q0761-answer|Compare the answer]]
^de-Q0761

**de-Q0762 · Explain the grammar**

Hättet ihr etwas dagegen, wenn ich eine Pause machen 【würde】?

Would you mind if I took a break?

[[German#^de-Q0762-answer|Compare the answer]]
^de-Q0762

**de-Q0763 · Fill the gap**

____ es dir etwas ausmachen, mir das Zeug hier aus dem Weg zu räumen?

Would you mind moving this stuff out of my way?

[[German#^de-Q0763-answer|Compare the answer]]
^de-Q0763

**de-Q0764 · Choose the form**

____ es dir etwas ausmachen, mir das Zeug hier aus dem Weg zu räumen?

Would you mind moving this stuff out of my way?

Choices: hätte / Würde / wäre / könnte

[[German#^de-Q0764-answer|Compare the answer]]
^de-Q0764

**de-Q0765 · Edit the changed sentence**

【würde】 mir bitte jemand helfen?

Could someone please help me?

[[German#^de-Q0765-answer|Compare the answer]]
^de-Q0765

**de-Q0766 · Build the sentence**

Arrange: bitte / helfen? / Könnte / mir / jemand

Could someone please help me?

[[German#^de-Q0766-answer|Compare the answer]]
^de-Q0766

**de-Q0767 · Write a translation**

Write this in German: Were I you, I would apply for the job.

[[German#^de-Q0767-answer|Compare the answer]]
^de-Q0767

**de-Q0768 · Explain the grammar**

An deiner Stelle 【würde】 ich mich für den Job bewerben.

Were I you, I would apply for the job.

[[German#^de-Q0768-answer|Compare the answer]]
^de-Q0768

**de-Q0769 · Fill the gap**

Wenn er mich nur heiraten ____!

If only he would marry me!

[[German#^de-Q0769-answer|Compare the answer]]
^de-Q0769

**de-Q0770 · Choose the form**

Wenn er mich nur heiraten ____!

If only he would marry me!

Choices: wäre / hätte / würde / könnte

[[German#^de-Q0770-answer|Compare the answer]]
^de-Q0770

**de-Q0771 · Edit the changed sentence**

Tom sagte, dass er und Maria gestritten 【würde】.

Tom said that he and Mary had had a fight.

[[German#^de-Q0771-answer|Compare the answer]]
^de-Q0771

**de-Q0772 · Build the sentence**

Arrange: Maria / sagte, / er / dass / hätten. / Tom / gestritten / und

Tom said that he and Mary had had a fight.

[[German#^de-Q0772-answer|Compare the answer]]
^de-Q0772

**de-Q0773 · Write a translation**

Write this in German: What do you think I should've done?

[[German#^de-Q0773-answer|Compare the answer]]
^de-Q0773

**de-Q0774 · Explain the grammar**

Was 【hätte】 ich Ihrer Meinung nach tun sollen?

What do you think I should've done?

[[German#^de-Q0774-answer|Compare the answer]]
^de-Q0774

**de-Q0775 · Fill the gap**

Tom ist die Art Junge, in den sich ein Mädchen verlieben ____.

Tom is the kind of guy that a girl could fall in love with.

[[German#^de-Q0775-answer|Compare the answer]]
^de-Q0775

**de-Q0776 · Choose the form**

Tom ist die Art Junge, in den sich ein Mädchen verlieben ____.

Tom is the kind of guy that a girl could fall in love with.

Choices: würde / wäre / könnte / hätte

[[German#^de-Q0776-answer|Compare the answer]]
^de-Q0776

**de-Q0777 · Edit the changed sentence**

Ich 【würde】 dich am Flughafen treffen können.

I could've met you at the airport.

[[German#^de-Q0777-answer|Compare the answer]]
^de-Q0777

**de-Q0778 · Build the sentence**

Arrange: Ich / dich / am / können. / hätte / treffen / Flughafen

I could've met you at the airport.

[[German#^de-Q0778-answer|Compare the answer]]
^de-Q0778

**de-Q0779 · Write a translation**

Write this in German: We would like you to join our company.

[[German#^de-Q0779-answer|Compare the answer]]
^de-Q0779

**de-Q0780 · Explain the grammar**

Es 【würde】 uns gefallen, wenn Sie sich uns anschließen.

We would like you to join our company.

[[German#^de-Q0780-answer|Compare the answer]]
^de-Q0780

**de-Q0781 · Fill the gap**

Ich ____ laut schreien, wenn ich einen Skorpion in meinem Zimmer fände.

I would scream very loudly if I saw a scorpion in my room.

[[German#^de-Q0781-answer|Compare the answer]]
^de-Q0781

**de-Q0782 · Choose the form**

Ich ____ laut schreien, wenn ich einen Skorpion in meinem Zimmer fände.

I would scream very loudly if I saw a scorpion in my room.

Choices: könnte / wäre / hätte / würde

[[German#^de-Q0782-answer|Compare the answer]]
^de-Q0782

**de-Q0783 · Edit the changed sentence**

Wir 【würde】 bis zum Ende der Party bleiben sollen.

We should've stayed till the end of the party.

[[German#^de-Q0783-answer|Compare the answer]]
^de-Q0783

**de-Q0784 · Build the sentence**

Arrange: hätten / zum / der / sollen. / bleiben / bis / Wir / Ende / Party

We should've stayed till the end of the party.

[[German#^de-Q0784-answer|Compare the answer]]
^de-Q0784

**de-Q0785 · Write a translation**

Write this in German: Could you please bring me a clean knife?

[[German#^de-Q0785-answer|Compare the answer]]
^de-Q0785

**de-Q0786 · Explain the grammar**

【Könnten】 Sie mir bitte ein sauberes Messer bringen?

Could you please bring me a clean knife?

[[German#^de-Q0786-answer|Compare the answer]]
^de-Q0786

**de-Q0787 · Fill the gap**

Das ____ sich als nützlich erweisen.

This might prove useful.

[[German#^de-Q0787-answer|Compare the answer]]
^de-Q0787

**de-Q0788 · Choose the form**

Das ____ sich als nützlich erweisen.

This might prove useful.

Choices: hätte / könnte / würde / wäre

[[German#^de-Q0788-answer|Compare the answer]]
^de-Q0788

**de-Q0789 · Edit the changed sentence**

Ich 【würde】 Sie niemals hassen.

I could never hate you.

[[German#^de-Q0789-answer|Compare the answer]]
^de-Q0789

**de-Q0790 · Build the sentence**

Arrange: Sie / könnte / hassen. / Ich / niemals

I could never hate you.

[[German#^de-Q0790-answer|Compare the answer]]
^de-Q0790

**de-Q0791 · Write a translation**

Write this in German: I knew Tom couldn't have done this by himself.

[[German#^de-Q0791-answer|Compare the answer]]
^de-Q0791

**de-Q0792 · Explain the grammar**

Ich wusste, dass Tom das nicht alleine 【hätte】 tun können.

I knew Tom couldn't have done this by himself.

[[German#^de-Q0792-answer|Compare the answer]]
^de-Q0792

**de-Q0793 · Fill the gap**

Ich ____ gerne hören, was ihr dazu meinst.

I'd like to hear what your opinion is.

[[German#^de-Q0793-answer|Compare the answer]]
^de-Q0793

**de-Q0794 · Choose the form**

Ich ____ gerne hören, was ihr dazu meinst.

I'd like to hear what your opinion is.

Choices: könnte / hätte / wäre / würde

[[German#^de-Q0794-answer|Compare the answer]]
^de-Q0794

**de-Q0795 · Edit the changed sentence**

Wir 【würde】 sterben können.

We could've died.

[[German#^de-Q0795-answer|Compare the answer]]
^de-Q0795

**de-Q0796 · Build the sentence**

Arrange: können. / hätten / Wir / sterben

We could've died.

[[German#^de-Q0796-answer|Compare the answer]]
^de-Q0796

**de-Q0797 · Write a translation**

Write this in German: I'd like to go with you, but I really can't.

[[German#^de-Q0797-answer|Compare the answer]]
^de-Q0797

**de-Q0798 · Explain the grammar**

Ich 【würde】 gerne mit dir mitkommen, aber ich kann wirklich nicht.

I'd like to go with you, but I really can't.

[[German#^de-Q0798-answer|Compare the answer]]
^de-Q0798

**de-Q0799 · Fill the gap**

Ich ____ alles für sie tun.

I'd do anything for her.

[[German#^de-Q0799-answer|Compare the answer]]
^de-Q0799

**de-Q0800 · Choose the form**

Ich ____ alles für sie tun.

I'd do anything for her.

Choices: wäre / hätte / könnte / würde

[[German#^de-Q0800-answer|Compare the answer]]
^de-Q0800


### Relative words · 50 questions

**de-Q0801 · Edit the changed sentence**

Es lebe 【der】 Republik!

Long live the Republic!

[[German#^de-Q0801-answer|Compare the answer]]
^de-Q0801

**de-Q0802 · Build the sentence**

Arrange: lebe / Republik! / Es / die

Long live the Republic!

[[German#^de-Q0802-answer|Compare the answer]]
^de-Q0802

**de-Q0803 · Write a translation**

Write this in German: You should treat people with more respect.

[[German#^de-Q0803-answer|Compare the answer]]
^de-Q0803

**de-Q0804 · Explain the grammar**

Du solltest 【die】 Menschen respektvoller behandeln.

You should treat people with more respect.

[[German#^de-Q0804-answer|Compare the answer]]
^de-Q0804

**de-Q0805 · Fill the gap**

____ Mann droht die Todesstrafe.

The man is liable to the death penalty.

[[German#^de-Q0805-answer|Compare the answer]]
^de-Q0805

**de-Q0806 · Choose the form**

____ Mann droht die Todesstrafe.

The man is liable to the death penalty.

Choices: die / der / Dem / das

[[German#^de-Q0806-answer|Compare the answer]]
^de-Q0806

**de-Q0807 · Edit the changed sentence**

Woher wusstest du 【der】 alles?

How did you know all that?

[[German#^de-Q0807-answer|Compare the answer]]
^de-Q0807

**de-Q0808 · Build the sentence**

Arrange: wusstest / das / alles? / Woher / du

How did you know all that?

[[German#^de-Q0808-answer|Compare the answer]]
^de-Q0808

**de-Q0809 · Write a translation**

Write this in German: The expenditure totaled 200,000 yen.

[[German#^de-Q0809-answer|Compare the answer]]
^de-Q0809

**de-Q0810 · Explain the grammar**

【Die】 Ausgaben betrugen insgesamt 200.000 Yen.

The expenditure totaled 200,000 yen.

[[German#^de-Q0810-answer|Compare the answer]]
^de-Q0810

**de-Q0811 · Fill the gap**

____ Mann ging um die Ecke.

The man walked round the corner.

[[German#^de-Q0811-answer|Compare the answer]]
^de-Q0811

**de-Q0812 · Choose the form**

____ Mann ging um die Ecke.

The man walked round the corner.

Choices: das / die / dessen / Der

[[German#^de-Q0812-answer|Compare the answer]]
^de-Q0812

**de-Q0813 · Edit the changed sentence**

【der】 Rechnungen stapeln sich immer mehr.

The bills keep piling up.

[[German#^de-Q0813-answer|Compare the answer]]
^de-Q0813

**de-Q0814 · Build the sentence**

Arrange: Rechnungen / mehr. / sich / Die / stapeln / immer

The bills keep piling up.

[[German#^de-Q0814-answer|Compare the answer]]
^de-Q0814

**de-Q0815 · Write a translation**

Write this in German: Mt. Fuji is noted for its beautiful shape.

[[German#^de-Q0815-answer|Compare the answer]]
^de-Q0815

**de-Q0816 · Explain the grammar**

【Der】 Fuji ist wegen seiner schönen Form bekannt.

Mt. Fuji is noted for its beautiful shape.

[[German#^de-Q0816-answer|Compare the answer]]
^de-Q0816

**de-Q0817 · Fill the gap**

Ich sah Tom ____ Treppe heraufkommen.

I saw Tom coming up the stairs.

[[German#^de-Q0817-answer|Compare the answer]]
^de-Q0817

**de-Q0818 · Choose the form**

Ich sah Tom ____ Treppe heraufkommen.

I saw Tom coming up the stairs.

Choices: das / die / der / dessen

[[German#^de-Q0818-answer|Compare the answer]]
^de-Q0818

**de-Q0819 · Edit the changed sentence**

Ich verschob 【der】 Veranstaltung.

I postponed the event.

[[German#^de-Q0819-answer|Compare the answer]]
^de-Q0819

**de-Q0820 · Build the sentence**

Arrange: die / verschob / Veranstaltung. / Ich

I postponed the event.

[[German#^de-Q0820-answer|Compare the answer]]
^de-Q0820

**de-Q0821 · Write a translation**

Write this in German: What's the secret ingredient?

[[German#^de-Q0821-answer|Compare the answer]]
^de-Q0821

**de-Q0822 · Explain the grammar**

Was ist 【die】 Geheimzutat?

What's the secret ingredient?

[[German#^de-Q0822-answer|Compare the answer]]
^de-Q0822

**de-Q0823 · Fill the gap**

____ Ticket ist bis zum 29. April gültig.

The ticket is valid to April 29.

[[German#^de-Q0823-answer|Compare the answer]]
^de-Q0823

**de-Q0824 · Choose the form**

____ Ticket ist bis zum 29. April gültig.

The ticket is valid to April 29.

Choices: die / dessen / Das / der

[[German#^de-Q0824-answer|Compare the answer]]
^de-Q0824

**de-Q0825 · Edit the changed sentence**

【der】 sind sehr gierige Leute.

They are very greedy people.

[[German#^de-Q0825-answer|Compare the answer]]
^de-Q0825

**de-Q0826 · Build the sentence**

Arrange: gierige / Leute. / sehr / Das / sind

They are very greedy people.

[[German#^de-Q0826-answer|Compare the answer]]
^de-Q0826

**de-Q0827 · Write a translation**

Write this in German: I want to do this.

[[German#^de-Q0827-answer|Compare the answer]]
^de-Q0827

**de-Q0828 · Explain the grammar**

Ich möchte 【das】 tun.

I want to do this.

[[German#^de-Q0828-answer|Compare the answer]]
^de-Q0828

**de-Q0829 · Fill the gap**

____ Kinder beschuldigten sich gegenseitig.

The children blamed each other.

[[German#^de-Q0829-answer|Compare the answer]]
^de-Q0829

**de-Q0830 · Choose the form**

____ Kinder beschuldigten sich gegenseitig.

The children blamed each other.

Choices: das / Die / der / dessen

[[German#^de-Q0830-answer|Compare the answer]]
^de-Q0830

**de-Q0831 · Edit the changed sentence**

【der】 Klitoris ist das empfindlichste Organ einer Frau.

The clitoris is the most sensitive organ of a woman.

[[German#^de-Q0831-answer|Compare the answer]]
^de-Q0831

**de-Q0832 · Build the sentence**

Arrange: das / ist / Die / Klitoris / Organ / empfindlichste / einer / Frau.

The clitoris is the most sensitive organ of a woman.

[[German#^de-Q0832-answer|Compare the answer]]
^de-Q0832

**de-Q0833 · Write a translation**

Write this in German: Tom looked down upon the city from the dizzying height of the skyscraper.

[[German#^de-Q0833-answer|Compare the answer]]
^de-Q0833

**de-Q0834 · Explain the grammar**

Tom sah von 【der】 schwindelnden Höhe des Wolkenkratzers auf die Stadt hinab.

Tom looked down upon the city from the dizzying height of the skyscraper.

[[German#^de-Q0834-answer|Compare the answer]]
^de-Q0834

**de-Q0835 · Fill the gap**

____ ist Toms Terminkalender.

This is Tom's diary.

[[German#^de-Q0835-answer|Compare the answer]]
^de-Q0835

**de-Q0836 · Choose the form**

____ ist Toms Terminkalender.

This is Tom's diary.

Choices: die / der / dessen / Das

[[German#^de-Q0836-answer|Compare the answer]]
^de-Q0836

**de-Q0837 · Edit the changed sentence**

Er füllte 【der】 Gläser mit Wein.

He filled the glasses with wine.

[[German#^de-Q0837-answer|Compare the answer]]
^de-Q0837

**de-Q0838 · Build the sentence**

Arrange: Er / Gläser / die / mit / Wein. / füllte

He filled the glasses with wine.

[[German#^de-Q0838-answer|Compare the answer]]
^de-Q0838

**de-Q0839 · Write a translation**

Write this in German: Tom got on the airplane.

[[German#^de-Q0839-answer|Compare the answer]]
^de-Q0839

**de-Q0840 · Explain the grammar**

Tom bestieg 【das】 Flugzeug.

Tom got on the airplane.

[[German#^de-Q0840-answer|Compare the answer]]
^de-Q0840

**de-Q0841 · Fill the gap**

Portugal hat zum ersten Mal einen Sieg beim Liederwettbewerb ____ Eurovision davongetragen.

Portugal won the Eurovision Song Contest for the first time.

[[German#^de-Q0841-answer|Compare the answer]]
^de-Q0841

**de-Q0842 · Choose the form**

Portugal hat zum ersten Mal einen Sieg beim Liederwettbewerb ____ Eurovision davongetragen.

Portugal won the Eurovision Song Contest for the first time.

Choices: dessen / die / das / der

[[German#^de-Q0842-answer|Compare the answer]]
^de-Q0842

**de-Q0843 · Edit the changed sentence**

Wo haben Sie 【der】 her?

Where did you get this?

[[German#^de-Q0843-answer|Compare the answer]]
^de-Q0843

**de-Q0844 · Build the sentence**

Arrange: Wo / haben / das / her? / Sie

Where did you get this?

[[German#^de-Q0844-answer|Compare the answer]]
^de-Q0844

**de-Q0845 · Write a translation**

Write this in German: It's really annoying.

[[German#^de-Q0845-answer|Compare the answer]]
^de-Q0845

**de-Q0846 · Explain the grammar**

【Das】 stört wirklich.

It's really annoying.

[[German#^de-Q0846-answer|Compare the answer]]
^de-Q0846

**de-Q0847 · Fill the gap**

____ geht mich nichts an.

This matter does not concern me.

[[German#^de-Q0847-answer|Compare the answer]]
^de-Q0847

**de-Q0848 · Choose the form**

____ geht mich nichts an.

This matter does not concern me.

Choices: dessen / der / Das / die

[[German#^de-Q0848-answer|Compare the answer]]
^de-Q0848

**de-Q0849 · Edit the changed sentence**

Früher durften Frauen 【der】 nicht.

Women didn't use to be allowed to do that.

[[German#^de-Q0849-answer|Compare the answer]]
^de-Q0849

**de-Q0850 · Build the sentence**

Arrange: durften / nicht. / Frauen / das / Früher

Women didn't use to be allowed to do that.

[[German#^de-Q0850-answer|Compare the answer]]
^de-Q0850


### Infinitives with zu · 50 questions

**de-Q0851 · Write a translation**

Write this in German: John is too fat to run fast.

[[German#^de-Q0851-answer|Compare the answer]]
^de-Q0851

**de-Q0852 · Explain the grammar**

John ist 【zu】 dick, um schnell zu rennen.

John is too fat to run fast.

[[German#^de-Q0852-answer|Compare the answer]]
^de-Q0852

**de-Q0853 · Fill the gap**

Wir haben unser Leben ____ leben.

We have our lives to live.

[[German#^de-Q0853-answer|Compare the answer]]
^de-Q0853

**de-Q0854 · Choose the form**

Wir haben unser Leben ____ leben.

We have our lives to live.

Choices: zu / ohne / statt / um

[[German#^de-Q0854-answer|Compare the answer]]
^de-Q0854

**de-Q0855 · Edit the changed sentence**

Es bringt nichts, mit ihm 【um】 streiten.

It is vain to argue with him.

[[German#^de-Q0855-answer|Compare the answer]]
^de-Q0855

**de-Q0856 · Build the sentence**

Arrange: bringt / nichts, / streiten. / mit / zu / ihm / Es

It is vain to argue with him.

[[German#^de-Q0856-answer|Compare the answer]]
^de-Q0856

**de-Q0857 · Write a translation**

Write this in German: I spend too much time on Tatoeba.

[[German#^de-Q0857-answer|Compare the answer]]
^de-Q0857

**de-Q0858 · Explain the grammar**

Ich tatoebaisiere 【zu】 viel.

I spend too much time on Tatoeba.

[[German#^de-Q0858-answer|Compare the answer]]
^de-Q0858

**de-Q0859 · Fill the gap**

Anscheinend ist Tom nicht willens, seine Fehler ____ berichtigen.

Tom seems to be unwilling to correct his mistakes.

[[German#^de-Q0859-answer|Compare the answer]]
^de-Q0859

**de-Q0860 · Choose the form**

Anscheinend ist Tom nicht willens, seine Fehler ____ berichtigen.

Tom seems to be unwilling to correct his mistakes.

Choices: ohne / um / statt / zu

[[German#^de-Q0860-answer|Compare the answer]]
^de-Q0860

**de-Q0861 · Edit the changed sentence**

Warum hast du eingewilligt, ihr 【um】 helfen?

Why did you agree to help her?

[[German#^de-Q0861-answer|Compare the answer]]
^de-Q0861

**de-Q0862 · Build the sentence**

Arrange: hast / ihr / helfen? / eingewilligt, / Warum / du / zu

Why did you agree to help her?

[[German#^de-Q0862-answer|Compare the answer]]
^de-Q0862

**de-Q0863 · Write a translation**

Write this in German: Then the witch placed her cauldron on the fire, to prepare the magic draught.

[[German#^de-Q0863-answer|Compare the answer]]
^de-Q0863

**de-Q0864 · Explain the grammar**

Dann stellte die Hexe ihren Kessel auf das Feuer, um den Zaubertrunk 【zu】 bereiten.

Then the witch placed her cauldron on the fire, to prepare the magic draught.

[[German#^de-Q0864-answer|Compare the answer]]
^de-Q0864

**de-Q0865 · Fill the gap**

Ich habe mit der Sache nichts ____ schaffen.

I have nothing to do with the affair.

[[German#^de-Q0865-answer|Compare the answer]]
^de-Q0865

**de-Q0866 · Choose the form**

Ich habe mit der Sache nichts ____ schaffen.

I have nothing to do with the affair.

Choices: ohne / um / zu / statt

[[German#^de-Q0866-answer|Compare the answer]]
^de-Q0866

**de-Q0867 · Edit the changed sentence**

Versuch wenigstens, vorsichtig 【um】 sein.

At least try and be careful.

[[German#^de-Q0867-answer|Compare the answer]]
^de-Q0867

**de-Q0868 · Build the sentence**

Arrange: zu / Versuch / sein. / wenigstens, / vorsichtig

At least try and be careful.

[[German#^de-Q0868-answer|Compare the answer]]
^de-Q0868

**de-Q0869 · Write a translation**

Write this in German: We're winning.

[[German#^de-Q0869-answer|Compare the answer]]
^de-Q0869

**de-Q0870 · Explain the grammar**

Wir sind dabei 【zu】 gewinnen.

We're winning.

[[German#^de-Q0870-answer|Compare the answer]]
^de-Q0870

**de-Q0871 · Fill the gap**

Ich nehme mir ein Taxi, um zum Bahnhof ____ fahren.

I take a taxi to the train station.

[[German#^de-Q0871-answer|Compare the answer]]
^de-Q0871

**de-Q0872 · Choose the form**

Ich nehme mir ein Taxi, um zum Bahnhof ____ fahren.

I take a taxi to the train station.

Choices: zu / statt / ohne / um

[[German#^de-Q0872-answer|Compare the answer]]
^de-Q0872

**de-Q0873 · Edit the changed sentence**

Diese Anordnung ist buchstabengetreu 【um】 befolgen.

This order is to be obeyed to the letter.

[[German#^de-Q0873-answer|Compare the answer]]
^de-Q0873

**de-Q0874 · Build the sentence**

Arrange: Anordnung / befolgen. / Diese / zu / buchstabengetreu / ist

This order is to be obeyed to the letter.

[[German#^de-Q0874-answer|Compare the answer]]
^de-Q0874

**de-Q0875 · Write a translation**

Write this in German: To my surprise, she could not answer the question.

[[German#^de-Q0875-answer|Compare the answer]]
^de-Q0875

**de-Q0876 · Explain the grammar**

【Zu】 meiner Überraschung konnte sie die Frage nicht beantworten.

To my surprise, she could not answer the question.

[[German#^de-Q0876-answer|Compare the answer]]
^de-Q0876

**de-Q0877 · Fill the gap**

Tom machte schnell die Tür ____.

Tom quickly closed the door.

[[German#^de-Q0877-answer|Compare the answer]]
^de-Q0877

**de-Q0878 · Choose the form**

Tom machte schnell die Tür ____.

Tom quickly closed the door.

Choices: statt / zu / ohne / um

[[German#^de-Q0878-answer|Compare the answer]]
^de-Q0878

**de-Q0879 · Edit the changed sentence**

Ich bat Tom 【um】 gehen.

I asked Tom to leave.

[[German#^de-Q0879-answer|Compare the answer]]
^de-Q0879

**de-Q0880 · Build the sentence**

Arrange: bat / zu / gehen. / Tom / Ich

I asked Tom to leave.

[[German#^de-Q0880-answer|Compare the answer]]
^de-Q0880

**de-Q0881 · Write a translation**

Write this in German: I heard an interesting rumor.

[[German#^de-Q0881-answer|Compare the answer]]
^de-Q0881

**de-Q0882 · Explain the grammar**

Mir kam ein interessantes Gerücht 【zu】 Ohren.

I heard an interesting rumor.

[[German#^de-Q0882-answer|Compare the answer]]
^de-Q0882

**de-Q0883 · Fill the gap**

Es muss angenehm sein, höher gestellte Freunde ____ haben.

It must be nice to have friends in high places.

[[German#^de-Q0883-answer|Compare the answer]]
^de-Q0883

**de-Q0884 · Choose the form**

Es muss angenehm sein, höher gestellte Freunde ____ haben.

It must be nice to have friends in high places.

Choices: ohne / zu / statt / um

[[German#^de-Q0884-answer|Compare the answer]]
^de-Q0884

**de-Q0885 · Edit the changed sentence**

Versuch doch nicht, mich 【um】 verarschen! Sag mir die Wahrheit!

Don't try to bullshit me, tell me the truth.

[[German#^de-Q0885-answer|Compare the answer]]
^de-Q0885

**de-Q0886 · Build the sentence**

Arrange: mich / zu / doch / die / Sag / nicht, / mir / Versuch / Wahrheit! / verarschen!

Don't try to bullshit me, tell me the truth.

[[German#^de-Q0886-answer|Compare the answer]]
^de-Q0886

**de-Q0887 · Write a translation**

Write this in German: Stop squabbling.

[[German#^de-Q0887-answer|Compare the answer]]
^de-Q0887

**de-Q0888 · Explain the grammar**

Hört auf 【zu】 zanken.

Stop squabbling.

[[German#^de-Q0888-answer|Compare the answer]]
^de-Q0888

**de-Q0889 · Fill the gap**

Es ist gewiss nicht leicht, das ____ verstehen.

It is far from easy to understand it.

[[German#^de-Q0889-answer|Compare the answer]]
^de-Q0889

**de-Q0890 · Choose the form**

Es ist gewiss nicht leicht, das ____ verstehen.

It is far from easy to understand it.

Choices: statt / zu / um / ohne

[[German#^de-Q0890-answer|Compare the answer]]
^de-Q0890

**de-Q0891 · Edit the changed sentence**

Ihre Erklärung ist mir 【um】 abstrakt.

Your explanation is too abstract for me.

[[German#^de-Q0891-answer|Compare the answer]]
^de-Q0891

**de-Q0892 · Build the sentence**

Arrange: Ihre / abstrakt. / Erklärung / ist / zu / mir

Your explanation is too abstract for me.

[[German#^de-Q0892-answer|Compare the answer]]
^de-Q0892

**de-Q0893 · Write a translation**

Write this in German: She telephoned her best friend to vent her frustration.

[[German#^de-Q0893-answer|Compare the answer]]
^de-Q0893

**de-Q0894 · Explain the grammar**

Sie rief ihre beste Freundin an, um ihrem Ärger Luft 【zu】 machen.

She telephoned her best friend to vent her frustration.

[[German#^de-Q0894-answer|Compare the answer]]
^de-Q0894

**de-Q0895 · Fill the gap**

Wenn Sie rechts abbiegen, sehen Sie das Krankenhaus ____ Ihrer Linken.

Turning right, you'll find the hospital on your left.

[[German#^de-Q0895-answer|Compare the answer]]
^de-Q0895

**de-Q0896 · Choose the form**

Wenn Sie rechts abbiegen, sehen Sie das Krankenhaus ____ Ihrer Linken.

Turning right, you'll find the hospital on your left.

Choices: um / zu / ohne / statt

[[German#^de-Q0896-answer|Compare the answer]]
^de-Q0896

**de-Q0897 · Edit the changed sentence**

Mathe 【um】 machen ist die einzige gesellschaftlich akzeptable Art, sich in der Öffentlichkeit selbstzubefriedigen.

Doing math is the only socially acceptable way to masturbate in public.

[[German#^de-Q0897-answer|Compare the answer]]
^de-Q0897

**de-Q0898 · Build the sentence**

Arrange: ist / akzeptable / Mathe / einzige / zu / die / selbstzubefriedigen. / machen / sich / in / der / Art, / gesellschaftlich / Öffentlichkeit

Doing math is the only socially acceptable way to masturbate in public.

[[German#^de-Q0898-answer|Compare the answer]]
^de-Q0898

**de-Q0899 · Write a translation**

Write this in German: You've got what it takes to do well in this job.

[[German#^de-Q0899-answer|Compare the answer]]
^de-Q0899

**de-Q0900 · Explain the grammar**

Du hast das Zeug dazu, diese Arbeit 【zu】 meistern.

You've got what it takes to do well in this job.

[[German#^de-Q0900-answer|Compare the answer]]
^de-Q0900


### Comparison and quantity · 50 questions

**de-Q0901 · Fill the gap**

Wie ____ Instrumente kannst du spielen?

How many instruments do you know how to play?

[[German#^de-Q0901-answer|Compare the answer]]
^de-Q0901

**de-Q0902 · Choose the form**

Wie ____ Instrumente kannst du spielen?

How many instruments do you know how to play?

Choices: weniger / besser / mehr / viele

[[German#^de-Q0902-answer|Compare the answer]]
^de-Q0902

**de-Q0903 · Edit the changed sentence**

Tom hat nicht sehr 【mehr】 geholfen.

Tom didn't help much.

[[German#^de-Q0903-answer|Compare the answer]]
^de-Q0903

**de-Q0904 · Build the sentence**

Arrange: sehr / Tom / hat / nicht / geholfen. / viel

Tom didn't help much.

[[German#^de-Q0904-answer|Compare the answer]]
^de-Q0904

**de-Q0905 · Write a translation**

Write this in German: What is the total amount?

[[German#^de-Q0905-answer|Compare the answer]]
^de-Q0905

**de-Q0906 · Explain the grammar**

Wie 【viel】 ist das insgesamt?

What is the total amount?

[[German#^de-Q0906-answer|Compare the answer]]
^de-Q0906

**de-Q0907 · Fill the gap**

Wie ____ Stockwerke hat dieses Gebäude?

How many floors does this building have?

[[German#^de-Q0907-answer|Compare the answer]]
^de-Q0907

**de-Q0908 · Choose the form**

Wie ____ Stockwerke hat dieses Gebäude?

How many floors does this building have?

Choices: viele / weniger / besser / mehr

[[German#^de-Q0908-answer|Compare the answer]]
^de-Q0908

**de-Q0909 · Edit the changed sentence**

Tom tut so etwas nicht 【weniger】.

Tom doesn't do that kind of thing anymore.

[[German#^de-Q0909-answer|Compare the answer]]
^de-Q0909

**de-Q0910 · Build the sentence**

Arrange: Tom / so / etwas / nicht / mehr. / tut

Tom doesn't do that kind of thing anymore.

[[German#^de-Q0910-answer|Compare the answer]]
^de-Q0910

**de-Q0911 · Write a translation**

Write this in German: Ken learned many Japanese songs by heart.

[[German#^de-Q0911-answer|Compare the answer]]
^de-Q0911

**de-Q0912 · Explain the grammar**

Ken lernte 【viele】 japanische Lieder auswendig.

Ken learned many Japanese songs by heart.

[[German#^de-Q0912-answer|Compare the answer]]
^de-Q0912

**de-Q0913 · Fill the gap**

Es gibt so ____ Fehler, die man machen kann!

There are so many mistakes to be made.

[[German#^de-Q0913-answer|Compare the answer]]
^de-Q0913

**de-Q0914 · Choose the form**

Es gibt so ____ Fehler, die man machen kann!

There are so many mistakes to be made.

Choices: viele / weniger / mehr / besser

[[German#^de-Q0914-answer|Compare the answer]]
^de-Q0914

**de-Q0915 · Edit the changed sentence**

Er gab mir nicht 【mehr】 als fünftausend Yen.

He gave me no less than five thousand yen.

[[German#^de-Q0915-answer|Compare the answer]]
^de-Q0915

**de-Q0916 · Build the sentence**

Arrange: Er / fünftausend / Yen. / nicht / mir / als / weniger / gab

He gave me no less than five thousand yen.

[[German#^de-Q0916-answer|Compare the answer]]
^de-Q0916

**de-Q0917 · Write a translation**

Write this in German: The more you work, the more you gain.

[[German#^de-Q0917-answer|Compare the answer]]
^de-Q0917

**de-Q0918 · Explain the grammar**

Desto 【mehr】 du arbeitest, desto mehr verdienst du.

The more you work, the more you gain.

[[German#^de-Q0918-answer|Compare the answer]]
^de-Q0918

**de-Q0919 · Fill the gap**

____ Männer haben größere Brüste als Frauen.

Many men have larger breasts than women.

[[German#^de-Q0919-answer|Compare the answer]]
^de-Q0919

**de-Q0920 · Choose the form**

____ Männer haben größere Brüste als Frauen.

Many men have larger breasts than women.

Choices: weniger / Viele / besser / mehr

[[German#^de-Q0920-answer|Compare the answer]]
^de-Q0920

**de-Q0921 · Edit the changed sentence**

Der Tag hat einfach zu 【mehr】 Stunden.

There's just too few hours in the day.

[[German#^de-Q0921-answer|Compare the answer]]
^de-Q0921

**de-Q0922 · Build the sentence**

Arrange: zu / Tag / Der / hat / wenige / Stunden. / einfach

There's just too few hours in the day.

[[German#^de-Q0922-answer|Compare the answer]]
^de-Q0922

**de-Q0923 · Write a translation**

Write this in German: There are few sites in the Tatar language on the Internet.

[[German#^de-Q0923-answer|Compare the answer]]
^de-Q0923

**de-Q0924 · Explain the grammar**

Es gibt im Internet 【wenige】 Seiten auf Tatarisch.

There are few sites in the Tatar language on the Internet.

[[German#^de-Q0924-answer|Compare the answer]]
^de-Q0924

**de-Q0925 · Fill the gap**

Ich habe ____ Geld als du.

I have less money than you.

[[German#^de-Q0925-answer|Compare the answer]]
^de-Q0925

**de-Q0926 · Choose the form**

Ich habe ____ Geld als du.

I have less money than you.

Choices: besser / viel / mehr / weniger

[[German#^de-Q0926-answer|Compare the answer]]
^de-Q0926

**de-Q0927 · Edit the changed sentence**

Menschen, die Überstunden machen, bringen nicht immer 【weniger】 Arbeit zustande.

People who work longer hours don't always get more work done.

[[German#^de-Q0927-answer|Compare the answer]]
^de-Q0927

**de-Q0928 · Build the sentence**

Arrange: immer / bringen / die / Arbeit / machen, / nicht / mehr / Menschen, / Überstunden / zustande.

People who work longer hours don't always get more work done.

[[German#^de-Q0928-answer|Compare the answer]]
^de-Q0928

**de-Q0929 · Write a translation**

Write this in German: Don't take on more than you can handle!

[[German#^de-Q0929-answer|Compare the answer]]
^de-Q0929

**de-Q0930 · Explain the grammar**

Übernimm nicht 【mehr】, als du bewältigen kannst!

Don't take on more than you can handle!

[[German#^de-Q0930-answer|Compare the answer]]
^de-Q0930

**de-Q0931 · Fill the gap**

Tom wünschte mir ____ Erfolg.

Tom wished me success.

[[German#^de-Q0931-answer|Compare the answer]]
^de-Q0931

**de-Q0932 · Choose the form**

Tom wünschte mir ____ Erfolg.

Tom wished me success.

Choices: besser / weniger / viel / mehr

[[German#^de-Q0932-answer|Compare the answer]]
^de-Q0932

**de-Q0933 · Edit the changed sentence**

Bist du tatsächlich gewillt, so 【mehr】 zu bezahen?

Are you really willing to pay that much?

[[German#^de-Q0933-answer|Compare the answer]]
^de-Q0933

**de-Q0934 · Build the sentence**

Arrange: gewillt, / zu / Bist / tatsächlich / du / viel / bezahen? / so

Are you really willing to pay that much?

[[German#^de-Q0934-answer|Compare the answer]]
^de-Q0934

**de-Q0935 · Write a translation**

Write this in German: They say that girls spend more time worrying about how they look than boys do.

[[German#^de-Q0935-answer|Compare the answer]]
^de-Q0935

**de-Q0936 · Explain the grammar**

Mädchen sollen sich 【mehr】 um ihr Aussehen sorgen als Jungen.

They say that girls spend more time worrying about how they look than boys do.

[[German#^de-Q0936-answer|Compare the answer]]
^de-Q0936

**de-Q0937 · Fill the gap**

Wie ____ gebt ihr mir dafür?

How much will you give me for this?

[[German#^de-Q0937-answer|Compare the answer]]
^de-Q0937

**de-Q0938 · Choose the form**

Wie ____ gebt ihr mir dafür?

How much will you give me for this?

Choices: weniger / viel / besser / mehr

[[German#^de-Q0938-answer|Compare the answer]]
^de-Q0938

**de-Q0939 · Edit the changed sentence**

Mit ein bisschen 【weniger】 Anstrengung.

With a little more effort.

[[German#^de-Q0939-answer|Compare the answer]]
^de-Q0939

**de-Q0940 · Build the sentence**

Arrange: Mit / bisschen / ein / Anstrengung. / mehr

With a little more effort.

[[German#^de-Q0940-answer|Compare the answer]]
^de-Q0940

**de-Q0941 · Write a translation**

Write this in German: I haven't listened to the radio in a long time.

[[German#^de-Q0941-answer|Compare the answer]]
^de-Q0941

**de-Q0942 · Explain the grammar**

Ich habe schon lange kein Radio 【mehr】 gehört.

I haven't listened to the radio in a long time.

[[German#^de-Q0942-answer|Compare the answer]]
^de-Q0942

**de-Q0943 · Fill the gap**

Das Gesetz ist nicht ____ in Kraft.

The law is no longer in force.

[[German#^de-Q0943-answer|Compare the answer]]
^de-Q0943

**de-Q0944 · Choose the form**

Das Gesetz ist nicht ____ in Kraft.

The law is no longer in force.

Choices: viel / weniger / besser / mehr

[[German#^de-Q0944-answer|Compare the answer]]
^de-Q0944

**de-Q0945 · Edit the changed sentence**

Wir haben weitaus 【weniger】 Gemeinsamkeiten, als du wahrscheinlich denkst.

We have a lot more in common than you probably think we do.

[[German#^de-Q0945-answer|Compare the answer]]
^de-Q0945

**de-Q0946 · Build the sentence**

Arrange: du / Wir / Gemeinsamkeiten, / mehr / haben / als / wahrscheinlich / denkst. / weitaus

We have a lot more in common than you probably think we do.

[[German#^de-Q0946-answer|Compare the answer]]
^de-Q0946

**de-Q0947 · Write a translation**

Write this in German: That could've gone better.

[[German#^de-Q0947-answer|Compare the answer]]
^de-Q0947

**de-Q0948 · Explain the grammar**

Das hätte 【besser】 laufen können.

That could've gone better.

[[German#^de-Q0948-answer|Compare the answer]]
^de-Q0948

**de-Q0949 · Fill the gap**

Tom fand nicht ____ nach Hause.

Tom couldn't find his way back home.

[[German#^de-Q0949-answer|Compare the answer]]
^de-Q0949

**de-Q0950 · Choose the form**

Tom fand nicht ____ nach Hause.

Tom couldn't find his way back home.

Choices: besser / weniger / viel / mehr

[[German#^de-Q0950-answer|Compare the answer]]
^de-Q0950


### Concession and argument · 50 questions

**de-Q0951 · Edit the changed sentence**

Du bist ein Hornochse, aber ich liebe dich 【obwohl】.

You're an idiot, but I still love you.

[[German#^de-Q0951-answer|Compare the answer]]
^de-Q0951

**de-Q0952 · Build the sentence**

Arrange: bist / ich / Du / ein / liebe / trotzdem. / Hornochse, / aber / dich

You're an idiot, but I still love you.

[[German#^de-Q0952-answer|Compare the answer]]
^de-Q0952

**de-Q0953 · Write a translation**

Write this in German: I don't have a CD player, but I bought the CD anyway.

[[German#^de-Q0953-answer|Compare the answer]]
^de-Q0953

**de-Q0954 · Explain the grammar**

Ich besitze keinen CD-Spieler, aber ich habe die CD 【trotzdem】 gekauft.

I don't have a CD player, but I bought the CD anyway.

[[German#^de-Q0954-answer|Compare the answer]]
^de-Q0954

**de-Q0955 · Fill the gap**

____ sie alle anderen feige nennt, fehlt ihr selbst dennoch jeglicher Mut.

Although she calls all the others cowardly, she nonetheless lacks any courage herself.

[[German#^de-Q0955-answer|Compare the answer]]
^de-Q0955

**de-Q0956 · Choose the form**

____ sie alle anderen feige nennt, fehlt ihr selbst dennoch jeglicher Mut.

Although she calls all the others cowardly, she nonetheless lacks any courage herself.

Choices: deshalb / trotzdem / Obwohl / jedoch

[[German#^de-Q0956-answer|Compare the answer]]
^de-Q0956

**de-Q0957 · Edit the changed sentence**

Ist mein Freund nicht schrecklich? Er nimmt mich immer zu Horrorfilmen mit, 【trotzdem】 er weiß, dass ich sie nicht mag. Ich hasse es.

Isn't my boyfriend terrible? He always takes me to see horror movies, even though he knows I don't like them. I hate it.

[[German#^de-Q0957-answer|Compare the answer]]
^de-Q0957

**de-Q0958 · Build the sentence**

Arrange: Freund / mich / weiß, / sie / Horrorfilmen / mein / mit, / mag. / ich / obwohl / hasse / dass / Ist / nicht / Ich / zu / immer / nicht / schrecklich? / Er / nimmt / er / es.

Isn't my boyfriend terrible? He always takes me to see horror movies, even though he knows I don't like them. I hate it.

[[German#^de-Q0958-answer|Compare the answer]]
^de-Q0958

**de-Q0959 · Write a translation**

Write this in German: It is none the less true.

[[German#^de-Q0959-answer|Compare the answer]]
^de-Q0959

**de-Q0960 · Explain the grammar**

【Trotzdem】 ist es wahr.

It is none the less true.

[[German#^de-Q0960-answer|Compare the answer]]
^de-Q0960

**de-Q0961 · Fill the gap**

Tom sagte Maria, dass ihm ihre Schuhe sehr gefielen, ____ er sie eigentlich hässlich fand.

Tom told Mary that he loved her shoes even though he thought they were ugly.

[[German#^de-Q0961-answer|Compare the answer]]
^de-Q0961

**de-Q0962 · Choose the form**

Tom sagte Maria, dass ihm ihre Schuhe sehr gefielen, ____ er sie eigentlich hässlich fand.

Tom told Mary that he loved her shoes even though he thought they were ugly.

Choices: obwohl / trotzdem / deshalb / jedoch

[[German#^de-Q0962-answer|Compare the answer]]
^de-Q0962

**de-Q0963 · Edit the changed sentence**

Starke Behaarung ist für mich ein Symbol für Männlichkeit, 【obwohl】 mag ich das sehr.

I think hairiness is a symbol of masculinity, so I really like it.

[[German#^de-Q0963-answer|Compare the answer]]
^de-Q0963

**de-Q0964 · Build the sentence**

Arrange: für / ich / sehr. / mich / Männlichkeit, / Behaarung / das / deshalb / mag / Symbol / ein / ist / für / Starke

I think hairiness is a symbol of masculinity, so I really like it.

[[German#^de-Q0964-answer|Compare the answer]]
^de-Q0964

**de-Q0965 · Write a translation**

Write this in German: I'm not Tom, though I do resemble him somewhat.

[[German#^de-Q0965-answer|Compare the answer]]
^de-Q0965

**de-Q0966 · Explain the grammar**

Ich bin nicht Tom, 【allerdings】 sehe ich ihm ein bisschen ähnlich.

I'm not Tom, though I do resemble him somewhat.

[[German#^de-Q0966-answer|Compare the answer]]
^de-Q0966

**de-Q0967 · Fill the gap**

____ es ein umfangreiches Buch mit über eintausend Seiten ist, werde ich es bis nächste Woche um diese Zeit gelesen haben.

Though this is a bulky book with over 1000 pages, I will have read it all by this time next week.

[[German#^de-Q0967-answer|Compare the answer]]
^de-Q0967

**de-Q0968 · Choose the form**

____ es ein umfangreiches Buch mit über eintausend Seiten ist, werde ich es bis nächste Woche um diese Zeit gelesen haben.

Though this is a bulky book with over 1000 pages, I will have read it all by this time next week.

Choices: jedoch / Obwohl / trotzdem / deshalb

[[German#^de-Q0968-answer|Compare the answer]]
^de-Q0968

**de-Q0969 · Edit the changed sentence**

Und 【obwohl】 schaffte er das Examen.

And yet he could pass the exam.

[[German#^de-Q0969-answer|Compare the answer]]
^de-Q0969

**de-Q0970 · Build the sentence**

Arrange: Examen. / er / Und / das / schaffte / trotzdem

And yet he could pass the exam.

[[German#^de-Q0970-answer|Compare the answer]]
^de-Q0970

**de-Q0971 · Write a translation**

Write this in German: The kitchen knife wasn't sharp enough to cut the meat, so I used my pocket knife.

[[German#^de-Q0971-answer|Compare the answer]]
^de-Q0971

**de-Q0972 · Explain the grammar**

Das Küchenmesser war zum Schneiden des Fleischs nicht scharf genug; 【daher】 nahm ich mein Taschenmesser.

The kitchen knife wasn't sharp enough to cut the meat, so I used my pocket knife.

[[German#^de-Q0972-answer|Compare the answer]]
^de-Q0972

**de-Q0973 · Fill the gap**

Ich spreche nicht gut Englisch, ____ ich es sechs Jahre in der Schule gelernt habe.

I don't speak English well even though I took it for six years at school.

[[German#^de-Q0973-answer|Compare the answer]]
^de-Q0973

**de-Q0974 · Choose the form**

Ich spreche nicht gut Englisch, ____ ich es sechs Jahre in der Schule gelernt habe.

I don't speak English well even though I took it for six years at school.

Choices: deshalb / jedoch / obwohl / trotzdem

[[German#^de-Q0974-answer|Compare the answer]]
^de-Q0974

**de-Q0975 · Edit the changed sentence**

【obwohl】 ist er wütend geworden.

That's why he got angry.

[[German#^de-Q0975-answer|Compare the answer]]
^de-Q0975

**de-Q0976 · Build the sentence**

Arrange: Deshalb / wütend / ist / geworden. / er

That's why he got angry.

[[German#^de-Q0976-answer|Compare the answer]]
^de-Q0976

**de-Q0977 · Write a translation**

Write this in German: I had enough time, so I didn't need to hurry.

[[German#^de-Q0977-answer|Compare the answer]]
^de-Q0977

**de-Q0978 · Explain the grammar**

Ich hatte genug Zeit; 【daher】 brauchte ich mich nicht zu beeilen.

I had enough time, so I didn't need to hurry.

[[German#^de-Q0978-answer|Compare the answer]]
^de-Q0978

**de-Q0979 · Fill the gap**

Das ist zwar viel, aber ____ nicht genug.

It is a lot, but still it's not enough.

[[German#^de-Q0979-answer|Compare the answer]]
^de-Q0979

**de-Q0980 · Choose the form**

Das ist zwar viel, aber ____ nicht genug.

It is a lot, but still it's not enough.

Choices: trotzdem / jedoch / deshalb / obwohl

[[German#^de-Q0980-answer|Compare the answer]]
^de-Q0980

**de-Q0981 · Edit the changed sentence**

【trotzdem】 er so groß ist, finden Frauen ihn recht attraktiv.

Despite his being so tall, women find him quite attractive.

[[German#^de-Q0981-answer|Compare the answer]]
^de-Q0981

**de-Q0982 · Build the sentence**

Arrange: finden / recht / ihn / Frauen / attraktiv. / groß / so / ist, / Obwohl / er

Despite his being so tall, women find him quite attractive.

[[German#^de-Q0982-answer|Compare the answer]]
^de-Q0982

**de-Q0983 · Write a translation**

Write this in German: I'm tired. I just want to go on the teacup ride and take it easy.

[[German#^de-Q0983-answer|Compare the answer]]
^de-Q0983

**de-Q0984 · Explain the grammar**

Ich bin erschöpft, 【deshalb】 werde ich es ruhig angehen lassen und ins Teetassenkarussel einsteigen.

I'm tired. I just want to go on the teacup ride and take it easy.

[[German#^de-Q0984-answer|Compare the answer]]
^de-Q0984

**de-Q0985 · Fill the gap**

____ er in England geboren wurde, spricht er sehr schlecht Englisch.

Although he was born in England, he speaks English very badly.

[[German#^de-Q0985-answer|Compare the answer]]
^de-Q0985

**de-Q0986 · Choose the form**

____ er in England geboren wurde, spricht er sehr schlecht Englisch.

Although he was born in England, he speaks English very badly.

Choices: jedoch / deshalb / trotzdem / Obwohl

[[German#^de-Q0986-answer|Compare the answer]]
^de-Q0986

**de-Q0987 · Edit the changed sentence**

Wie ihr bereits wisst, spreche ich nicht allzu gut Französisch. 【obwohl】 zöge ich es vor, keine Rede auf Französisch zu halten.

As you already know, I don't speak French very well, so I'd rather not give a speech in French.

[[German#^de-Q0987-answer|Compare the answer]]
^de-Q0987

**de-Q0988 · Build the sentence**

Arrange: es / ich / ich / zu / halten. / auf / nicht / Rede / Französisch. / vor, / bereits / wisst, / spreche / zöge / ihr / Daher / keine / gut / Französisch / Wie / allzu

As you already know, I don't speak French very well, so I'd rather not give a speech in French.

[[German#^de-Q0988-answer|Compare the answer]]
^de-Q0988

**de-Q0989 · Write a translation**

Write this in German: In spite of the fact that he's 38, he's still dependent on his parents.

[[German#^de-Q0989-answer|Compare the answer]]
^de-Q0989

**de-Q0990 · Explain the grammar**

【Obwohl】 er schon 38 ist, ist er noch immer von seinen Eltern abhängig.

In spite of the fact that he's 38, he's still dependent on his parents.

[[German#^de-Q0990-answer|Compare the answer]]
^de-Q0990

**de-Q0991 · Fill the gap**

____ bin ich nicht gekommen.

That's not why I came.

[[German#^de-Q0991-answer|Compare the answer]]
^de-Q0991

**de-Q0992 · Choose the form**

____ bin ich nicht gekommen.

That's not why I came.

Choices: jedoch / trotzdem / Deshalb / obwohl

[[German#^de-Q0992-answer|Compare the answer]]
^de-Q0992

**de-Q0993 · Edit the changed sentence**

【trotzdem】 Tom mein Nachbar ist, kenne ich ihn nicht allzu gut.

Even though Tom is my neighbor, I don't know him very well.

[[German#^de-Q0993-answer|Compare the answer]]
^de-Q0993

**de-Q0994 · Build the sentence**

Arrange: ihn / ist, / Nachbar / Obwohl / nicht / Tom / gut. / allzu / mein / kenne / ich

Even though Tom is my neighbor, I don't know him very well.

[[German#^de-Q0994-answer|Compare the answer]]
^de-Q0994

**de-Q0995 · Write a translation**

Write this in German: You always have the right to refuse treatment, however, I must explain the potential consequences if that will be your choice.

[[German#^de-Q0995-answer|Compare the answer]]
^de-Q0995

**de-Q0996 · Explain the grammar**

Sie können die Behandlung jederzeit ablehnen; 【allerdings】 muss ich Sie in diesem Fall über die möglichen Auswirkungen aufklären.

You always have the right to refuse treatment, however, I must explain the potential consequences if that will be your choice.

[[German#^de-Q0996-answer|Compare the answer]]
^de-Q0996

**de-Q0997 · Fill the gap**

Ärgerst du dich ____?

Is that why you're upset?

[[German#^de-Q0997-answer|Compare the answer]]
^de-Q0997

**de-Q0998 · Choose the form**

Ärgerst du dich ____?

Is that why you're upset?

Choices: trotzdem / deshalb / obwohl / jedoch

[[German#^de-Q0998-answer|Compare the answer]]
^de-Q0998

**de-Q0999 · Edit the changed sentence**

【trotzdem】 sie Zwillinge sind, teilen sie nicht viele Interessen.

Though they're twins, they don't have many interests in common.

[[German#^de-Q0999-answer|Compare the answer]]
^de-Q0999

**de-Q1000 · Build the sentence**

Arrange: Zwillinge / nicht / Obwohl / sind, / viele / teilen / Interessen. / sie / sie

Though they're twins, they don't have many interests in common.

[[German#^de-Q1000-answer|Compare the answer]]
^de-Q1000


## Answers

The full sentence is a model. For translation, judge whether meaning and grammar are preserved. Each grammar rule above explains the form.

### Answers 1–50

**de-Q0001** — Zwingen Sie mich nicht, das zu essen!

Don't make me eat this.

Expected form: **das**

Why: Articles in context. [[German#^de-Q0001|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Zwingen%20Sie%20mich%20nicht%2C%20das%20zu%20essen%21)
^de-Q0001-answer

**de-Q0002** — Zwingen Sie mich nicht, das zu essen!

Don't make me eat this.

Expected form: **das**

Why: Articles in context. [[German#^de-Q0002|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Zwingen%20Sie%20mich%20nicht%2C%20das%20zu%20essen%21)
^de-Q0002-answer

**de-Q0003** — Der Vater geht im Park spazieren.

My father is taking a walk in the park.

Expected form: **Der**

Why: Articles in context. [[German#^de-Q0003|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Vater%20geht%20im%20Park%20spazieren.)
^de-Q0003-answer

**de-Q0004** — Der Vater geht im Park spazieren.

My father is taking a walk in the park.

Why: Articles in context. [[German#^de-Q0004|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Vater%20geht%20im%20Park%20spazieren.)
^de-Q0004-answer

**de-Q0005** — Er war der einzige Betrunkene auf der Feier.

He was the only one drunk at the party.

Why: Articles in context. [[German#^de-Q0005|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20war%20der%20einzige%20Betrunkene%20auf%20der%20Feier.)
^de-Q0005-answer

**de-Q0006** — Er war der einzige Betrunkene auf der Feier.

He was the only one drunk at the party.

A German article marks gender, number and case together. Die can be feminine singular or plural; der can occur in several case/gender combinations. Identify the noun and its sentence role before choosing an ending.

Why: Articles in context. [[German#^de-Q0006|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20war%20der%20einzige%20Betrunkene%20auf%20der%20Feier.)
^de-Q0006-answer

**de-Q0007** — Anstatt aufzuhören, wurde der Regen stärker.

Instead of stopping, the rain increased.

Expected form: **der**

Why: Articles in context. [[German#^de-Q0007|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Anstatt%20aufzuh%C3%B6ren%2C%20wurde%20der%20Regen%20st%C3%A4rker.)
^de-Q0007-answer

**de-Q0008** — Anstatt aufzuhören, wurde der Regen stärker.

Instead of stopping, the rain increased.

Expected form: **der**

Why: Articles in context. [[German#^de-Q0008|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Anstatt%20aufzuh%C3%B6ren%2C%20wurde%20der%20Regen%20st%C3%A4rker.)
^de-Q0008-answer

**de-Q0009** — Jeder Satz, der mit "Ich bin kein Rassist, aber..." beginnt, ist höchstwahrscheinlich sehr rassistisch.

Every sentence that starts with "I'm not racist, but" is likely to be very racist indeed.

Expected form: **der**

Why: Articles in context. [[German#^de-Q0009|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Jeder%20Satz%2C%20der%20mit%20%22Ich%20bin%20kein%20Rassist%2C%20aber...%22%20beginnt%2C%20ist%20h%C3%B6chstwahrscheinlich%20sehr%20rassistisch.)
^de-Q0009-answer

**de-Q0010** — Jeder Satz, der mit "Ich bin kein Rassist, aber..." beginnt, ist höchstwahrscheinlich sehr rassistisch.

Every sentence that starts with "I'm not racist, but" is likely to be very racist indeed.

Why: Articles in context. [[German#^de-Q0010|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Jeder%20Satz%2C%20der%20mit%20%22Ich%20bin%20kein%20Rassist%2C%20aber...%22%20beginnt%2C%20ist%20h%C3%B6chstwahrscheinlich%20sehr%20rassistisch.)
^de-Q0010-answer

**de-Q0011** — Welche Schule ist die beste?

Which school is the best?

Why: Articles in context. [[German#^de-Q0011|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Welche%20Schule%20ist%20die%20beste%3F)
^de-Q0011-answer

**de-Q0012** — Welche Schule ist die beste?

Which school is the best?

A German article marks gender, number and case together. Die can be feminine singular or plural; der can occur in several case/gender combinations. Identify the noun and its sentence role before choosing an ending.

Why: Articles in context. [[German#^de-Q0012|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Welche%20Schule%20ist%20die%20beste%3F)
^de-Q0012-answer

**de-Q0013** — Können das ihre Familien für sie sagen? Einige halten das für eine gute Idee.

Can their families say this for them? Some people think this is a good idea.

Expected form: **das**

Why: Articles in context. [[German#^de-Q0013|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=K%C3%B6nnen%20das%20ihre%20Familien%20f%C3%BCr%20sie%20sagen%3F%20Einige%20halten%20das%20f%C3%BCr%20eine%20gute%20Idee.)
^de-Q0013-answer

**de-Q0014** — Können das ihre Familien für sie sagen? Einige halten das für eine gute Idee.

Can their families say this for them? Some people think this is a good idea.

Expected form: **das**

Why: Articles in context. [[German#^de-Q0014|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=K%C3%B6nnen%20das%20ihre%20Familien%20f%C3%BCr%20sie%20sagen%3F%20Einige%20halten%20das%20f%C3%BCr%20eine%20gute%20Idee.)
^de-Q0014-answer

**de-Q0015** — Das verheißt nichts Gutes für unseren weiteren Dialog.

That does not augur well for the rest of our dialogue.

Expected form: **Das**

Why: Articles in context. [[German#^de-Q0015|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20verhei%C3%9Ft%20nichts%20Gutes%20f%C3%BCr%20unseren%20weiteren%20Dialog.)
^de-Q0015-answer

**de-Q0016** — Das verheißt nichts Gutes für unseren weiteren Dialog.

That does not augur well for the rest of our dialogue.

Why: Articles in context. [[German#^de-Q0016|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20verhei%C3%9Ft%20nichts%20Gutes%20f%C3%BCr%20unseren%20weiteren%20Dialog.)
^de-Q0016-answer

**de-Q0017** — Willst du, dass ich das Licht einschalte?

Do you want me to turn on the light?

Why: Articles in context. [[German#^de-Q0017|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Willst%20du%2C%20dass%20ich%20das%20Licht%20einschalte%3F)
^de-Q0017-answer

**de-Q0018** — Willst du, dass ich das Licht einschalte?

Do you want me to turn on the light?

A German article marks gender, number and case together. Die can be feminine singular or plural; der can occur in several case/gender combinations. Identify the noun and its sentence role before choosing an ending.

Why: Articles in context. [[German#^de-Q0018|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Willst%20du%2C%20dass%20ich%20das%20Licht%20einschalte%3F)
^de-Q0018-answer

**de-Q0019** — Das hast du nicht deutlich gemacht.

You didn't make it clear.

Expected form: **Das**

Why: Articles in context. [[German#^de-Q0019|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20hast%20du%20nicht%20deutlich%20gemacht.)
^de-Q0019-answer

**de-Q0020** — Das hast du nicht deutlich gemacht.

You didn't make it clear.

Expected form: **Das**

Why: Articles in context. [[German#^de-Q0020|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20hast%20du%20nicht%20deutlich%20gemacht.)
^de-Q0020-answer

**de-Q0021** — Fünfzehn Jahre sind vergangen, seit wir das letzte Mal dort waren.

Fifteen years have passed since we went there last.

Expected form: **das**

Why: Articles in context. [[German#^de-Q0021|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=F%C3%BCnfzehn%20Jahre%20sind%20vergangen%2C%20seit%20wir%20das%20letzte%20Mal%20dort%20waren.)
^de-Q0021-answer

**de-Q0022** — Fünfzehn Jahre sind vergangen, seit wir das letzte Mal dort waren.

Fifteen years have passed since we went there last.

Why: Articles in context. [[German#^de-Q0022|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=F%C3%BCnfzehn%20Jahre%20sind%20vergangen%2C%20seit%20wir%20das%20letzte%20Mal%20dort%20waren.)
^de-Q0022-answer

**de-Q0023** — Wo soll das Klavier hin?

Where do you want the piano?

Why: Articles in context. [[German#^de-Q0023|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wo%20soll%20das%20Klavier%20hin%3F)
^de-Q0023-answer

**de-Q0024** — Wo soll das Klavier hin?

Where do you want the piano?

A German article marks gender, number and case together. Die can be feminine singular or plural; der can occur in several case/gender combinations. Identify the noun and its sentence role before choosing an ending.

Why: Articles in context. [[German#^de-Q0024|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wo%20soll%20das%20Klavier%20hin%3F)
^de-Q0024-answer

**de-Q0025** — Er hatte den ganzen Tag nichts gegessen und war hungrig.

He hadn't eaten anything the whole day and was hungry.

Expected form: **den**

Why: Articles in context. [[German#^de-Q0025|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20hatte%20den%20ganzen%20Tag%20nichts%20gegessen%20und%20war%20hungrig.)
^de-Q0025-answer

**de-Q0026** — Er hatte den ganzen Tag nichts gegessen und war hungrig.

He hadn't eaten anything the whole day and was hungry.

Expected form: **den**

Why: Articles in context. [[German#^de-Q0026|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20hatte%20den%20ganzen%20Tag%20nichts%20gegessen%20und%20war%20hungrig.)
^de-Q0026-answer

**de-Q0027** — Die Zeit rinnt einfach wie die Körner des Meeressandes durch unsere Finger.

Time just slips through our fingers like the grains of sand found near the sea.

Expected form: **Die**

Why: Articles in context. [[German#^de-Q0027|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Zeit%20rinnt%20einfach%20wie%20die%20K%C3%B6rner%20des%20Meeressandes%20durch%20unsere%20Finger.)
^de-Q0027-answer

**de-Q0028** — Die Zeit rinnt einfach wie die Körner des Meeressandes durch unsere Finger.

Time just slips through our fingers like the grains of sand found near the sea.

Why: Articles in context. [[German#^de-Q0028|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Zeit%20rinnt%20einfach%20wie%20die%20K%C3%B6rner%20des%20Meeressandes%20durch%20unsere%20Finger.)
^de-Q0028-answer

**de-Q0029** — Der nächste Dienstag ist ein gesetzlicher Feiertag.

Next Tuesday is a bank holiday.

Why: Articles in context. [[German#^de-Q0029|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20n%C3%A4chste%20Dienstag%20ist%20ein%20gesetzlicher%20Feiertag.)
^de-Q0029-answer

**de-Q0030** — Der nächste Dienstag ist ein gesetzlicher Feiertag.

Next Tuesday is a bank holiday.

A German article marks gender, number and case together. Die can be feminine singular or plural; der can occur in several case/gender combinations. Identify the noun and its sentence role before choosing an ending.

Why: Articles in context. [[German#^de-Q0030|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20n%C3%A4chste%20Dienstag%20ist%20ein%20gesetzlicher%20Feiertag.)
^de-Q0030-answer

**de-Q0031** — Der Mann, der da drüben steht, ist Tom.

The man standing over there is Tom.

Expected form: **Der**

Why: Articles in context. [[German#^de-Q0031|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Mann%2C%20der%20da%20dr%C3%BCben%20steht%2C%20ist%20Tom.)
^de-Q0031-answer

**de-Q0032** — Der Mann, der da drüben steht, ist Tom.

The man standing over there is Tom.

Expected form: **Der**

Why: Articles in context. [[German#^de-Q0032|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Mann%2C%20der%20da%20dr%C3%BCben%20steht%2C%20ist%20Tom.)
^de-Q0032-answer

**de-Q0033** — Er ist so groß, dass er die Decke berühren kann.

He is such a tall man that he can touch the ceiling.

Expected form: **die**

Why: Articles in context. [[German#^de-Q0033|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20ist%20so%20gro%C3%9F%2C%20dass%20er%20die%20Decke%20ber%C3%BChren%20kann.)
^de-Q0033-answer

**de-Q0034** — Er ist so groß, dass er die Decke berühren kann.

He is such a tall man that he can touch the ceiling.

Why: Articles in context. [[German#^de-Q0034|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20ist%20so%20gro%C3%9F%2C%20dass%20er%20die%20Decke%20ber%C3%BChren%20kann.)
^de-Q0034-answer

**de-Q0035** — Mit Ausnahme Toms sah die ganze Familie schweigend fern.

Except for Tom, the family was all watching TV in silence.

Why: Articles in context. [[German#^de-Q0035|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Mit%20Ausnahme%20Toms%20sah%20die%20ganze%20Familie%20schweigend%20fern.)
^de-Q0035-answer

**de-Q0036** — Mit Ausnahme Toms sah die ganze Familie schweigend fern.

Except for Tom, the family was all watching TV in silence.

A German article marks gender, number and case together. Die can be feminine singular or plural; der can occur in several case/gender combinations. Identify the noun and its sentence role before choosing an ending.

Why: Articles in context. [[German#^de-Q0036|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Mit%20Ausnahme%20Toms%20sah%20die%20ganze%20Familie%20schweigend%20fern.)
^de-Q0036-answer

**de-Q0037** — Tom hat das Feuer gelöscht.

Tom extinguished the fire.

Expected form: **das**

Why: Articles in context. [[German#^de-Q0037|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20hat%20das%20Feuer%20gel%C3%B6scht.)
^de-Q0037-answer

**de-Q0038** — Tom hat das Feuer gelöscht.

Tom extinguished the fire.

Expected form: **das**

Why: Articles in context. [[German#^de-Q0038|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20hat%20das%20Feuer%20gel%C3%B6scht.)
^de-Q0038-answer

**de-Q0039** — Stell die Leiter an die Wand.

Place the ladder against the wall.

Expected form: **die**

Why: Articles in context. [[German#^de-Q0039|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Stell%20die%20Leiter%20an%20die%20Wand.)
^de-Q0039-answer

**de-Q0040** — Stell die Leiter an die Wand.

Place the ladder against the wall.

Why: Articles in context. [[German#^de-Q0040|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Stell%20die%20Leiter%20an%20die%20Wand.)
^de-Q0040-answer

**de-Q0041** — Sind das hier deine Handschuhe?

Are these your gloves?

Why: Articles in context. [[German#^de-Q0041|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sind%20das%20hier%20deine%20Handschuhe%3F)
^de-Q0041-answer

**de-Q0042** — Sind das hier deine Handschuhe?

Are these your gloves?

A German article marks gender, number and case together. Die can be feminine singular or plural; der can occur in several case/gender combinations. Identify the noun and its sentence role before choosing an ending.

Why: Articles in context. [[German#^de-Q0042|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sind%20das%20hier%20deine%20Handschuhe%3F)
^de-Q0042-answer

**de-Q0043** — Der Vertrag ist ungültig, wenn Sie zur Unterschrift gezwungen wurden.

The contract, if you were forced to sign it, is invalid.

Expected form: **Der**

Why: Articles in context. [[German#^de-Q0043|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Vertrag%20ist%20ung%C3%BCltig%2C%20wenn%20Sie%20zur%20Unterschrift%20gezwungen%20wurden.)
^de-Q0043-answer

**de-Q0044** — Der Vertrag ist ungültig, wenn Sie zur Unterschrift gezwungen wurden.

The contract, if you were forced to sign it, is invalid.

Expected form: **Der**

Why: Articles in context. [[German#^de-Q0044|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Vertrag%20ist%20ung%C3%BCltig%2C%20wenn%20Sie%20zur%20Unterschrift%20gezwungen%20wurden.)
^de-Q0044-answer

**de-Q0045** — Sie könnte in der Lage sein, dir zu helfen.

She might be able to help you.

Expected form: **der**

Why: Articles in context. [[German#^de-Q0045|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20k%C3%B6nnte%20in%20der%20Lage%20sein%2C%20dir%20zu%20helfen.)
^de-Q0045-answer

**de-Q0046** — Sie könnte in der Lage sein, dir zu helfen.

She might be able to help you.

Why: Articles in context. [[German#^de-Q0046|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20k%C3%B6nnte%20in%20der%20Lage%20sein%2C%20dir%20zu%20helfen.)
^de-Q0046-answer

**de-Q0047** — Der langen Rede kurzer Sinn: Wir haben das Kriegsbeil begraben.

To make a long story short, we buried the hatchet.

Why: Articles in context. [[German#^de-Q0047|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20langen%20Rede%20kurzer%20Sinn%3A%20Wir%20haben%20das%20Kriegsbeil%20begraben.)
^de-Q0047-answer

**de-Q0048** — Der langen Rede kurzer Sinn: Wir haben das Kriegsbeil begraben.

To make a long story short, we buried the hatchet.

A German article marks gender, number and case together. Die can be feminine singular or plural; der can occur in several case/gender combinations. Identify the noun and its sentence role before choosing an ending.

Why: Articles in context. [[German#^de-Q0048|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20langen%20Rede%20kurzer%20Sinn%3A%20Wir%20haben%20das%20Kriegsbeil%20begraben.)
^de-Q0048-answer

**de-Q0049** — „In dich war ich verliebt, nicht in Maria.“ – „Warum hast du mich das denn nie spüren lassen?“

"I fell in love with you, not Maria." - "Why have you not let me feel that?"

Expected form: **das**

Why: Articles in context. [[German#^de-Q0049|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=%E2%80%9EIn%20dich%20war%20ich%20verliebt%2C%20nicht%20in%20Maria.%E2%80%9C%20%E2%80%93%20%E2%80%9EWarum%20hast%20du%20mich%20das%20denn%20nie%20sp%C3%BCren%20lassen%3F%E2%80%9C)
^de-Q0049-answer

**de-Q0050** — „In dich war ich verliebt, nicht in Maria.“ – „Warum hast du mich das denn nie spüren lassen?“

"I fell in love with you, not Maria." - "Why have you not let me feel that?"

Expected form: **das**

Why: Articles in context. [[German#^de-Q0050|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=%E2%80%9EIn%20dich%20war%20ich%20verliebt%2C%20nicht%20in%20Maria.%E2%80%9C%20%E2%80%93%20%E2%80%9EWarum%20hast%20du%20mich%20das%20denn%20nie%20sp%C3%BCren%20lassen%3F%E2%80%9C)
^de-Q0050-answer


### Answers 51–100

**de-Q0051** — Japaner und Briten warten an Bushaltestellen normalerweise in einer Schlange.

Japanese and British people usually wait at a bus stop in a queue.

Expected form: **einer**

Why: Indefinite articles. [[German#^de-Q0051|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Japaner%20und%20Briten%20warten%20an%20Bushaltestellen%20normalerweise%20in%20einer%20Schlange.)
^de-Q0051-answer

**de-Q0052** — Japaner und Briten warten an Bushaltestellen normalerweise in einer Schlange.

Japanese and British people usually wait at a bus stop in a queue.

Why: Indefinite articles. [[German#^de-Q0052|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Japaner%20und%20Briten%20warten%20an%20Bushaltestellen%20normalerweise%20in%20einer%20Schlange.)
^de-Q0052-answer

**de-Q0053** — Ich bin es gewohnt, einen Lastwagen zu fahren.

I am used to driving a truck.

Why: Indefinite articles. [[German#^de-Q0053|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20bin%20es%20gewohnt%2C%20einen%20Lastwagen%20zu%20fahren.)
^de-Q0053-answer

**de-Q0054** — Ich bin es gewohnt, einen Lastwagen zu fahren.

I am used to driving a truck.

Ein introduces an indefinite singular noun. Its endings depend on gender and case; some forms have no overt ending. There is no ordinary plural ein article. Learn a noun together with gender and plural.

Why: Indefinite articles. [[German#^de-Q0054|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20bin%20es%20gewohnt%2C%20einen%20Lastwagen%20zu%20fahren.)
^de-Q0054-answer

**de-Q0055** — Tom trägt eine Sonnenbrille.

Tom is wearing sunglasses.

Expected form: **eine**

Why: Indefinite articles. [[German#^de-Q0055|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20tr%C3%A4gt%20eine%20Sonnenbrille.)
^de-Q0055-answer

**de-Q0056** — Tom trägt eine Sonnenbrille.

Tom is wearing sunglasses.

Expected form: **eine**

Why: Indefinite articles. [[German#^de-Q0056|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20tr%C3%A4gt%20eine%20Sonnenbrille.)
^de-Q0056-answer

**de-Q0057** — Ich habe einen LKW.

I have a truck.

Expected form: **einen**

Why: Indefinite articles. [[German#^de-Q0057|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20einen%20LKW.)
^de-Q0057-answer

**de-Q0058** — Ich habe einen LKW.

I have a truck.

Why: Indefinite articles. [[German#^de-Q0058|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20einen%20LKW.)
^de-Q0058-answer

**de-Q0059** — Tom hat dich nicht ein einziges Mal erwähnt.

Tom never mentioned you once.

Why: Indefinite articles. [[German#^de-Q0059|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20hat%20dich%20nicht%20ein%20einziges%20Mal%20erw%C3%A4hnt.)
^de-Q0059-answer

**de-Q0060** — Tom hat dich nicht ein einziges Mal erwähnt.

Tom never mentioned you once.

Ein introduces an indefinite singular noun. Its endings depend on gender and case; some forms have no overt ending. There is no ordinary plural ein article. Learn a noun together with gender and plural.

Why: Indefinite articles. [[German#^de-Q0060|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20hat%20dich%20nicht%20ein%20einziges%20Mal%20erw%C3%A4hnt.)
^de-Q0060-answer

**de-Q0061** — Ich habe ein Treffen mit ihr um fünf Uhr am Bahnhof arrangiert.

I arranged a meeting on the train station with her at five o'clock

Expected form: **ein**

Why: Indefinite articles. [[German#^de-Q0061|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20ein%20Treffen%20mit%20ihr%20um%20f%C3%BCnf%20Uhr%20am%20Bahnhof%20arrangiert.)
^de-Q0061-answer

**de-Q0062** — Ich habe ein Treffen mit ihr um fünf Uhr am Bahnhof arrangiert.

I arranged a meeting on the train station with her at five o'clock

Expected form: **ein**

Why: Indefinite articles. [[German#^de-Q0062|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20ein%20Treffen%20mit%20ihr%20um%20f%C3%BCnf%20Uhr%20am%20Bahnhof%20arrangiert.)
^de-Q0062-answer

**de-Q0063** — Was hältst du von einem Spaziergang?

How about taking a walk?

Expected form: **einem**

Why: Indefinite articles. [[German#^de-Q0063|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Was%20h%C3%A4ltst%20du%20von%20einem%20Spaziergang%3F)
^de-Q0063-answer

**de-Q0064** — Was hältst du von einem Spaziergang?

How about taking a walk?

Why: Indefinite articles. [[German#^de-Q0064|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Was%20h%C3%A4ltst%20du%20von%20einem%20Spaziergang%3F)
^de-Q0064-answer

**de-Q0065** — Eine japanische Synchronisation des Films ist auf dieser DVD bedauerlicherweise nicht enthalten, aber immerhin gibt es japanische Untertitel.

Unfortunately, a Japanese dub of the film is not included on this DVD, but at least there are Japanese subtitles.

Why: Indefinite articles. [[German#^de-Q0065|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Eine%20japanische%20Synchronisation%20des%20Films%20ist%20auf%20dieser%20DVD%20bedauerlicherweise%20nicht%20enthalten%2C%20aber%20immerhin%20gibt%20es%20japanische%20Untertitel.)
^de-Q0065-answer

**de-Q0066** — Eine japanische Synchronisation des Films ist auf dieser DVD bedauerlicherweise nicht enthalten, aber immerhin gibt es japanische Untertitel.

Unfortunately, a Japanese dub of the film is not included on this DVD, but at least there are Japanese subtitles.

Ein introduces an indefinite singular noun. Its endings depend on gender and case; some forms have no overt ending. There is no ordinary plural ein article. Learn a noun together with gender and plural.

Why: Indefinite articles. [[German#^de-Q0066|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Eine%20japanische%20Synchronisation%20des%20Films%20ist%20auf%20dieser%20DVD%20bedauerlicherweise%20nicht%20enthalten%2C%20aber%20immerhin%20gibt%20es%20japanische%20Untertitel.)
^de-Q0066-answer

**de-Q0067** — In deinem Zimmer sieht es wie in einem Saustall aus.

Your room looks like a pigsty.

Expected form: **einem**

Why: Indefinite articles. [[German#^de-Q0067|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=In%20deinem%20Zimmer%20sieht%20es%20wie%20in%20einem%20Saustall%20aus.)
^de-Q0067-answer

**de-Q0068** — In deinem Zimmer sieht es wie in einem Saustall aus.

Your room looks like a pigsty.

Expected form: **einem**

Why: Indefinite articles. [[German#^de-Q0068|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=In%20deinem%20Zimmer%20sieht%20es%20wie%20in%20einem%20Saustall%20aus.)
^de-Q0068-answer

**de-Q0069** — Ich wusste, dass Tom eine Dummheit begehen würde.

I knew Tom would do something stupid.

Expected form: **eine**

Why: Indefinite articles. [[German#^de-Q0069|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20wusste%2C%20dass%20Tom%20eine%20Dummheit%20begehen%20w%C3%BCrde.)
^de-Q0069-answer

**de-Q0070** — Ich wusste, dass Tom eine Dummheit begehen würde.

I knew Tom would do something stupid.

Why: Indefinite articles. [[German#^de-Q0070|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20wusste%2C%20dass%20Tom%20eine%20Dummheit%20begehen%20w%C3%BCrde.)
^de-Q0070-answer

**de-Q0071** — Der Hund verfolgte ein Kaninchen in den Wald.

The dog pursued a rabbit into the forest.

Why: Indefinite articles. [[German#^de-Q0071|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Hund%20verfolgte%20ein%20Kaninchen%20in%20den%20Wald.)
^de-Q0071-answer

**de-Q0072** — Der Hund verfolgte ein Kaninchen in den Wald.

The dog pursued a rabbit into the forest.

Ein introduces an indefinite singular noun. Its endings depend on gender and case; some forms have no overt ending. There is no ordinary plural ein article. Learn a noun together with gender and plural.

Why: Indefinite articles. [[German#^de-Q0072|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Hund%20verfolgte%20ein%20Kaninchen%20in%20den%20Wald.)
^de-Q0072-answer

**de-Q0073** — Das ist auch ein guter Film.

That's a good movie, too.

Expected form: **ein**

Why: Indefinite articles. [[German#^de-Q0073|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20ist%20auch%20ein%20guter%20Film.)
^de-Q0073-answer

**de-Q0074** — Das ist auch ein guter Film.

That's a good movie, too.

Expected form: **ein**

Why: Indefinite articles. [[German#^de-Q0074|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20ist%20auch%20ein%20guter%20Film.)
^de-Q0074-answer

**de-Q0075** — Das ist ein großer Fehler.

That's a big mistake.

Expected form: **ein**

Why: Indefinite articles. [[German#^de-Q0075|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20ist%20ein%20gro%C3%9Fer%20Fehler.)
^de-Q0075-answer

**de-Q0076** — Das ist ein großer Fehler.

That's a big mistake.

Why: Indefinite articles. [[German#^de-Q0076|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20ist%20ein%20gro%C3%9Fer%20Fehler.)
^de-Q0076-answer

**de-Q0077** — Es handelt sich um eine demokratische Regierung.

It's a democratic government.

Why: Indefinite articles. [[German#^de-Q0077|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20handelt%20sich%20um%20eine%20demokratische%20Regierung.)
^de-Q0077-answer

**de-Q0078** — Es handelt sich um eine demokratische Regierung.

It's a democratic government.

Ein introduces an indefinite singular noun. Its endings depend on gender and case; some forms have no overt ending. There is no ordinary plural ein article. Learn a noun together with gender and plural.

Why: Indefinite articles. [[German#^de-Q0078|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20handelt%20sich%20um%20eine%20demokratische%20Regierung.)
^de-Q0078-answer

**de-Q0079** — Was du über Batman wissen musst, ist dies: Er ist ein Superheld.

The thing you have to know about Batman is, he's a superhero.

Expected form: **ein**

Why: Indefinite articles. [[German#^de-Q0079|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Was%20du%20%C3%BCber%20Batman%20wissen%20musst%2C%20ist%20dies%3A%20Er%20ist%20ein%20Superheld.)
^de-Q0079-answer

**de-Q0080** — Was du über Batman wissen musst, ist dies: Er ist ein Superheld.

The thing you have to know about Batman is, he's a superhero.

Expected form: **ein**

Why: Indefinite articles. [[German#^de-Q0080|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Was%20du%20%C3%BCber%20Batman%20wissen%20musst%2C%20ist%20dies%3A%20Er%20ist%20ein%20Superheld.)
^de-Q0080-answer

**de-Q0081** — Der Boden ist mit einem dicken Teppich bedeckt.

The floor is covered with a thick carpet.

Expected form: **einem**

Why: Indefinite articles. [[German#^de-Q0081|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Boden%20ist%20mit%20einem%20dicken%20Teppich%20bedeckt.)
^de-Q0081-answer

**de-Q0082** — Der Boden ist mit einem dicken Teppich bedeckt.

The floor is covered with a thick carpet.

Why: Indefinite articles. [[German#^de-Q0082|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Boden%20ist%20mit%20einem%20dicken%20Teppich%20bedeckt.)
^de-Q0082-answer

**de-Q0083** — Ein Bulldozer wurde eingesetzt, um die Fahrbahn zu ebnen.

A bulldozer was used to level the lane.

Why: Indefinite articles. [[German#^de-Q0083|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ein%20Bulldozer%20wurde%20eingesetzt%2C%20um%20die%20Fahrbahn%20zu%20ebnen.)
^de-Q0083-answer

**de-Q0084** — Ein Bulldozer wurde eingesetzt, um die Fahrbahn zu ebnen.

A bulldozer was used to level the lane.

Ein introduces an indefinite singular noun. Its endings depend on gender and case; some forms have no overt ending. There is no ordinary plural ein article. Learn a noun together with gender and plural.

Why: Indefinite articles. [[German#^de-Q0084|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ein%20Bulldozer%20wurde%20eingesetzt%2C%20um%20die%20Fahrbahn%20zu%20ebnen.)
^de-Q0084-answer

**de-Q0085** — Man kann einen Spiegel aus Metall oder Glas herstellen.

A mirror can be made out of metal or glass.

Expected form: **einen**

Why: Indefinite articles. [[German#^de-Q0085|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Man%20kann%20einen%20Spiegel%20aus%20Metall%20oder%20Glas%20herstellen.)
^de-Q0085-answer

**de-Q0086** — Man kann einen Spiegel aus Metall oder Glas herstellen.

A mirror can be made out of metal or glass.

Expected form: **einen**

Why: Indefinite articles. [[German#^de-Q0086|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Man%20kann%20einen%20Spiegel%20aus%20Metall%20oder%20Glas%20herstellen.)
^de-Q0086-answer

**de-Q0087** — Ekkehard wünscht sich eine Modelleisenbahn zu Weihnachten.

Ekkehard wants a model train for Christmas.

Expected form: **eine**

Why: Indefinite articles. [[German#^de-Q0087|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ekkehard%20w%C3%BCnscht%20sich%20eine%20Modelleisenbahn%20zu%20Weihnachten.)
^de-Q0087-answer

**de-Q0088** — Ekkehard wünscht sich eine Modelleisenbahn zu Weihnachten.

Ekkehard wants a model train for Christmas.

Why: Indefinite articles. [[German#^de-Q0088|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ekkehard%20w%C3%BCnscht%20sich%20eine%20Modelleisenbahn%20zu%20Weihnachten.)
^de-Q0088-answer

**de-Q0089** — Der Mann war nicht besser als ein Pferd.

The man was no better than a horse.

Why: Indefinite articles. [[German#^de-Q0089|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Mann%20war%20nicht%20besser%20als%20ein%20Pferd.)
^de-Q0089-answer

**de-Q0090** — Der Mann war nicht besser als ein Pferd.

The man was no better than a horse.

Ein introduces an indefinite singular noun. Its endings depend on gender and case; some forms have no overt ending. There is no ordinary plural ein article. Learn a noun together with gender and plural.

Why: Indefinite articles. [[German#^de-Q0090|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Mann%20war%20nicht%20besser%20als%20ein%20Pferd.)
^de-Q0090-answer

**de-Q0091** — Ich brauche einen guten Rat.

I need some good advice.

Expected form: **einen**

Why: Indefinite articles. [[German#^de-Q0091|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20brauche%20einen%20guten%20Rat.)
^de-Q0091-answer

**de-Q0092** — Ich brauche einen guten Rat.

I need some good advice.

Expected form: **einen**

Why: Indefinite articles. [[German#^de-Q0092|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20brauche%20einen%20guten%20Rat.)
^de-Q0092-answer

**de-Q0093** — Bist du schon zu einer Entscheidung gelangt?

Have you made your decision yet?

Expected form: **einer**

Why: Indefinite articles. [[German#^de-Q0093|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Bist%20du%20schon%20zu%20einer%20Entscheidung%20gelangt%3F)
^de-Q0093-answer

**de-Q0094** — Bist du schon zu einer Entscheidung gelangt?

Have you made your decision yet?

Why: Indefinite articles. [[German#^de-Q0094|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Bist%20du%20schon%20zu%20einer%20Entscheidung%20gelangt%3F)
^de-Q0094-answer

**de-Q0095** — Wissen ist eine Sache, unterrichten eine andere.

It is one thing to know and another to teach.

Why: Indefinite articles. [[German#^de-Q0095|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wissen%20ist%20eine%20Sache%2C%20unterrichten%20eine%20andere.)
^de-Q0095-answer

**de-Q0096** — Wissen ist eine Sache, unterrichten eine andere.

It is one thing to know and another to teach.

Ein introduces an indefinite singular noun. Its endings depend on gender and case; some forms have no overt ending. There is no ordinary plural ein article. Learn a noun together with gender and plural.

Why: Indefinite articles. [[German#^de-Q0096|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wissen%20ist%20eine%20Sache%2C%20unterrichten%20eine%20andere.)
^de-Q0096-answer

**de-Q0097** — Ein Herr Jones ist gekommen, dich zu sehen.

A Mr Jones has come to see you.

Expected form: **Ein**

Why: Indefinite articles. [[German#^de-Q0097|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ein%20Herr%20Jones%20ist%20gekommen%2C%20dich%20zu%20sehen.)
^de-Q0097-answer

**de-Q0098** — Ein Herr Jones ist gekommen, dich zu sehen.

A Mr Jones has come to see you.

Expected form: **Ein**

Why: Indefinite articles. [[German#^de-Q0098|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ein%20Herr%20Jones%20ist%20gekommen%2C%20dich%20zu%20sehen.)
^de-Q0098-answer

**de-Q0099** — Jeden Freitagabend gingen sie einen trinken.

Every Friday night they went and got liquored up.

Expected form: **einen**

Why: Indefinite articles. [[German#^de-Q0099|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Jeden%20Freitagabend%20gingen%20sie%20einen%20trinken.)
^de-Q0099-answer

**de-Q0100** — Jeden Freitagabend gingen sie einen trinken.

Every Friday night they went and got liquored up.

Why: Indefinite articles. [[German#^de-Q0100|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Jeden%20Freitagabend%20gingen%20sie%20einen%20trinken.)
^de-Q0100-answer


### Answers 101–150

**de-Q0101** — Hast du Vorsätze fürs neue Jahr?

Have you made any New Year's resolutions?

Why: Personal pronoun forms. [[German#^de-Q0101|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Hast%20du%20Vors%C3%A4tze%20f%C3%BCrs%20neue%20Jahr%3F)
^de-Q0101-answer

**de-Q0102** — Hast du Vorsätze fürs neue Jahr?

Have you made any New Year's resolutions?

Pronouns change form with their grammatical role. Ich is nominative, mich accusative, mir dative. Sie can mean she, they or polite you; spelling and context distinguish the uses.

Why: Personal pronoun forms. [[German#^de-Q0102|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Hast%20du%20Vors%C3%A4tze%20f%C3%BCrs%20neue%20Jahr%3F)
^de-Q0102-answer

**de-Q0103** — Tom gab seinen Freunden gegenüber damit an, mit wie vielen Mädchen er schon geschlafen habe.

Tom bragged to his friends about all the girls he had slept with.

Expected form: **er**

Why: Personal pronoun forms. [[German#^de-Q0103|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20gab%20seinen%20Freunden%20gegen%C3%BCber%20damit%20an%2C%20mit%20wie%20vielen%20M%C3%A4dchen%20er%20schon%20geschlafen%20habe.)
^de-Q0103-answer

**de-Q0104** — Tom gab seinen Freunden gegenüber damit an, mit wie vielen Mädchen er schon geschlafen habe.

Tom bragged to his friends about all the girls he had slept with.

Expected form: **er**

Why: Personal pronoun forms. [[German#^de-Q0104|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20gab%20seinen%20Freunden%20gegen%C3%BCber%20damit%20an%2C%20mit%20wie%20vielen%20M%C3%A4dchen%20er%20schon%20geschlafen%20habe.)
^de-Q0104-answer

**de-Q0105** — Ich werde Tom nicht erlauben zu gehen.

I won't allow Tom to go.

Expected form: **Ich**

Why: Personal pronoun forms. [[German#^de-Q0105|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20werde%20Tom%20nicht%20erlauben%20zu%20gehen.)
^de-Q0105-answer

**de-Q0106** — Ich werde Tom nicht erlauben zu gehen.

I won't allow Tom to go.

Why: Personal pronoun forms. [[German#^de-Q0106|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20werde%20Tom%20nicht%20erlauben%20zu%20gehen.)
^de-Q0106-answer

**de-Q0107** — Du wirst von jedem respektiert.

You're respected by everybody.

Why: Personal pronoun forms. [[German#^de-Q0107|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Du%20wirst%20von%20jedem%20respektiert.)
^de-Q0107-answer

**de-Q0108** — Du wirst von jedem respektiert.

You're respected by everybody.

Pronouns change form with their grammatical role. Ich is nominative, mich accusative, mir dative. Sie can mean she, they or polite you; spelling and context distinguish the uses.

Why: Personal pronoun forms. [[German#^de-Q0108|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Du%20wirst%20von%20jedem%20respektiert.)
^de-Q0108-answer

**de-Q0109** — Ich habe es nicht bemerkt.

I didn't notice it.

Expected form: **Ich**

Why: Personal pronoun forms. [[German#^de-Q0109|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20es%20nicht%20bemerkt.)
^de-Q0109-answer

**de-Q0110** — Ich habe es nicht bemerkt.

I didn't notice it.

Expected form: **Ich**

Why: Personal pronoun forms. [[German#^de-Q0110|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20es%20nicht%20bemerkt.)
^de-Q0110-answer

**de-Q0111** — Bring mir meine Kleidung.

Bring me my clothes.

Expected form: **mir**

Why: Personal pronoun forms. [[German#^de-Q0111|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Bring%20mir%20meine%20Kleidung.)
^de-Q0111-answer

**de-Q0112** — Bring mir meine Kleidung.

Bring me my clothes.

Why: Personal pronoun forms. [[German#^de-Q0112|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Bring%20mir%20meine%20Kleidung.)
^de-Q0112-answer

**de-Q0113** — Ich weiß genau, wie ihr euch fühlt.

I know precisely what you are feeling.

Why: Personal pronoun forms. [[German#^de-Q0113|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20wei%C3%9F%20genau%2C%20wie%20ihr%20euch%20f%C3%BChlt.)
^de-Q0113-answer

**de-Q0114** — Ich weiß genau, wie ihr euch fühlt.

I know precisely what you are feeling.

Pronouns change form with their grammatical role. Ich is nominative, mich accusative, mir dative. Sie can mean she, they or polite you; spelling and context distinguish the uses.

Why: Personal pronoun forms. [[German#^de-Q0114|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20wei%C3%9F%20genau%2C%20wie%20ihr%20euch%20f%C3%BChlt.)
^de-Q0114-answer

**de-Q0115** — Ich will nicht zur Arbeit.

I don't want to go to work.

Expected form: **Ich**

Why: Personal pronoun forms. [[German#^de-Q0115|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20will%20nicht%20zur%20Arbeit.)
^de-Q0115-answer

**de-Q0116** — Ich will nicht zur Arbeit.

I don't want to go to work.

Expected form: **Ich**

Why: Personal pronoun forms. [[German#^de-Q0116|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20will%20nicht%20zur%20Arbeit.)
^de-Q0116-answer

**de-Q0117** — Am Ende ist sie wieder zurück nach England gezogen.

In the end, she moved back to England.

Expected form: **sie**

Why: Personal pronoun forms. [[German#^de-Q0117|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Am%20Ende%20ist%20sie%20wieder%20zur%C3%BCck%20nach%20England%20gezogen.)
^de-Q0117-answer

**de-Q0118** — Am Ende ist sie wieder zurück nach England gezogen.

In the end, she moved back to England.

Why: Personal pronoun forms. [[German#^de-Q0118|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Am%20Ende%20ist%20sie%20wieder%20zur%C3%BCck%20nach%20England%20gezogen.)
^de-Q0118-answer

**de-Q0119** — Ich glaube, wir müssen zurück nach Boston gehen.

I think we need to go back to Boston.

Why: Personal pronoun forms. [[German#^de-Q0119|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20glaube%2C%20wir%20m%C3%BCssen%20zur%C3%BCck%20nach%20Boston%20gehen.)
^de-Q0119-answer

**de-Q0120** — Ich glaube, wir müssen zurück nach Boston gehen.

I think we need to go back to Boston.

Pronouns change form with their grammatical role. Ich is nominative, mich accusative, mir dative. Sie can mean she, they or polite you; spelling and context distinguish the uses.

Why: Personal pronoun forms. [[German#^de-Q0120|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20glaube%2C%20wir%20m%C3%BCssen%20zur%C3%BCck%20nach%20Boston%20gehen.)
^de-Q0120-answer

**de-Q0121** — Haben Sie beide sich gut amüsiert, während ich fort war?

Did you two have fun while I was gone?

Expected form: **Sie**

Why: Personal pronoun forms. [[German#^de-Q0121|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Haben%20Sie%20beide%20sich%20gut%20am%C3%BCsiert%2C%20w%C3%A4hrend%20ich%20fort%20war%3F)
^de-Q0121-answer

**de-Q0122** — Haben Sie beide sich gut amüsiert, während ich fort war?

Did you two have fun while I was gone?

Expected form: **Sie**

Why: Personal pronoun forms. [[German#^de-Q0122|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Haben%20Sie%20beide%20sich%20gut%20am%C3%BCsiert%2C%20w%C3%A4hrend%20ich%20fort%20war%3F)
^de-Q0122-answer

**de-Q0123** — Sie nannten sie Jane.

They named her Jane.

Expected form: **Sie**

Why: Personal pronoun forms. [[German#^de-Q0123|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20nannten%20sie%20Jane.)
^de-Q0123-answer

**de-Q0124** — Sie nannten sie Jane.

They named her Jane.

Why: Personal pronoun forms. [[German#^de-Q0124|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20nannten%20sie%20Jane.)
^de-Q0124-answer

**de-Q0125** — Mit ärztlicher Hilfe hat sie ihre Krankheit überwunden.

With the help of doctors, she got over her illness.

Why: Personal pronoun forms. [[German#^de-Q0125|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Mit%20%C3%A4rztlicher%20Hilfe%20hat%20sie%20ihre%20Krankheit%20%C3%BCberwunden.)
^de-Q0125-answer

**de-Q0126** — Mit ärztlicher Hilfe hat sie ihre Krankheit überwunden.

With the help of doctors, she got over her illness.

Pronouns change form with their grammatical role. Ich is nominative, mich accusative, mir dative. Sie can mean she, they or polite you; spelling and context distinguish the uses.

Why: Personal pronoun forms. [[German#^de-Q0126|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Mit%20%C3%A4rztlicher%20Hilfe%20hat%20sie%20ihre%20Krankheit%20%C3%BCberwunden.)
^de-Q0126-answer

**de-Q0127** — Warum entschuldigt ihr euch nicht einfach?

Why don't you just apologize?

Expected form: **ihr**

Why: Personal pronoun forms. [[German#^de-Q0127|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Warum%20entschuldigt%20ihr%20euch%20nicht%20einfach%3F)
^de-Q0127-answer

**de-Q0128** — Warum entschuldigt ihr euch nicht einfach?

Why don't you just apologize?

Expected form: **ihr**

Why: Personal pronoun forms. [[German#^de-Q0128|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Warum%20entschuldigt%20ihr%20euch%20nicht%20einfach%3F)
^de-Q0128-answer

**de-Q0129** — Könntest du mir helfen, wenn ich umziehe?

Could you help me when I move?

Expected form: **du**

Why: Personal pronoun forms. [[German#^de-Q0129|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=K%C3%B6nntest%20du%20mir%20helfen%2C%20wenn%20ich%20umziehe%3F)
^de-Q0129-answer

**de-Q0130** — Könntest du mir helfen, wenn ich umziehe?

Could you help me when I move?

Why: Personal pronoun forms. [[German#^de-Q0130|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=K%C3%B6nntest%20du%20mir%20helfen%2C%20wenn%20ich%20umziehe%3F)
^de-Q0130-answer

**de-Q0131** — Niemand beobachtete uns.

No one was watching us.

Why: Personal pronoun forms. [[German#^de-Q0131|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Niemand%20beobachtete%20uns.)
^de-Q0131-answer

**de-Q0132** — Niemand beobachtete uns.

No one was watching us.

Pronouns change form with their grammatical role. Ich is nominative, mich accusative, mir dative. Sie can mean she, they or polite you; spelling and context distinguish the uses.

Why: Personal pronoun forms. [[German#^de-Q0132|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Niemand%20beobachtete%20uns.)
^de-Q0132-answer

**de-Q0133** — Urteilen Sie selbst!

Judge for yourself!

Expected form: **Sie**

Why: Personal pronoun forms. [[German#^de-Q0133|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Urteilen%20Sie%20selbst%21)
^de-Q0133-answer

**de-Q0134** — Urteilen Sie selbst!

Judge for yourself!

Expected form: **Sie**

Why: Personal pronoun forms. [[German#^de-Q0134|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Urteilen%20Sie%20selbst%21)
^de-Q0134-answer

**de-Q0135** — Ich mache es nicht wie du.

I don't act like you.

Expected form: **Ich**

Why: Personal pronoun forms. [[German#^de-Q0135|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20mache%20es%20nicht%20wie%20du.)
^de-Q0135-answer

**de-Q0136** — Ich mache es nicht wie du.

I don't act like you.

Why: Personal pronoun forms. [[German#^de-Q0136|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20mache%20es%20nicht%20wie%20du.)
^de-Q0136-answer

**de-Q0137** — Er kommt beinahe jedes Wochenende nach Hause.

He comes home almost every weekend.

Why: Personal pronoun forms. [[German#^de-Q0137|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20kommt%20beinahe%20jedes%20Wochenende%20nach%20Hause.)
^de-Q0137-answer

**de-Q0138** — Er kommt beinahe jedes Wochenende nach Hause.

He comes home almost every weekend.

Pronouns change form with their grammatical role. Ich is nominative, mich accusative, mir dative. Sie can mean she, they or polite you; spelling and context distinguish the uses.

Why: Personal pronoun forms. [[German#^de-Q0138|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20kommt%20beinahe%20jedes%20Wochenende%20nach%20Hause.)
^de-Q0138-answer

**de-Q0139** — Falls du etwas brauchst, lass es mich wissen.

If you need anything, let me know.

Expected form: **du**

Why: Personal pronoun forms. [[German#^de-Q0139|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Falls%20du%20etwas%20brauchst%2C%20lass%20es%20mich%20wissen.)
^de-Q0139-answer

**de-Q0140** — Falls du etwas brauchst, lass es mich wissen.

If you need anything, let me know.

Expected form: **du**

Why: Personal pronoun forms. [[German#^de-Q0140|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Falls%20du%20etwas%20brauchst%2C%20lass%20es%20mich%20wissen.)
^de-Q0140-answer

**de-Q0141** — Sie können doch fließend Französisch, oder?

You're fluent in French, right?

Expected form: **Sie**

Why: Personal pronoun forms. [[German#^de-Q0141|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20k%C3%B6nnen%20doch%20flie%C3%9Fend%20Franz%C3%B6sisch%2C%20oder%3F)
^de-Q0141-answer

**de-Q0142** — Sie können doch fließend Französisch, oder?

You're fluent in French, right?

Why: Personal pronoun forms. [[German#^de-Q0142|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20k%C3%B6nnen%20doch%20flie%C3%9Fend%20Franz%C3%B6sisch%2C%20oder%3F)
^de-Q0142-answer

**de-Q0143** — Du hast Tom damit zum Weinen gebracht.

What you did made Tom cry.

Why: Personal pronoun forms. [[German#^de-Q0143|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Du%20hast%20Tom%20damit%20zum%20Weinen%20gebracht.)
^de-Q0143-answer

**de-Q0144** — Du hast Tom damit zum Weinen gebracht.

What you did made Tom cry.

Pronouns change form with their grammatical role. Ich is nominative, mich accusative, mir dative. Sie can mean she, they or polite you; spelling and context distinguish the uses.

Why: Personal pronoun forms. [[German#^de-Q0144|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Du%20hast%20Tom%20damit%20zum%20Weinen%20gebracht.)
^de-Q0144-answer

**de-Q0145** — Wir haben zwei Ohren.

We have two ears.

Expected form: **Wir**

Why: Personal pronoun forms. [[German#^de-Q0145|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20haben%20zwei%20Ohren.)
^de-Q0145-answer

**de-Q0146** — Wir haben zwei Ohren.

We have two ears.

Expected form: **Wir**

Why: Personal pronoun forms. [[German#^de-Q0146|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20haben%20zwei%20Ohren.)
^de-Q0146-answer

**de-Q0147** — Töten ist verboten; jeder Mörder wird bestraft, es sei denn, er hat gemeinsam mit vielen anderen Männern und zum Klang von Trompeten getötet.

Killing is forbidden; every murderer is punished, unless he has killed accompanied by many men and to the sound of trumpets.

Expected form: **er**

Why: Personal pronoun forms. [[German#^de-Q0147|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=T%C3%B6ten%20ist%20verboten%3B%20jeder%20M%C3%B6rder%20wird%20bestraft%2C%20es%20sei%20denn%2C%20er%20hat%20gemeinsam%20mit%20vielen%20anderen%20M%C3%A4nnern%20und%20zum%20Klang%20von%20Trompeten%20get%C3%B6tet.)
^de-Q0147-answer

**de-Q0148** — Töten ist verboten; jeder Mörder wird bestraft, es sei denn, er hat gemeinsam mit vielen anderen Männern und zum Klang von Trompeten getötet.

Killing is forbidden; every murderer is punished, unless he has killed accompanied by many men and to the sound of trumpets.

Why: Personal pronoun forms. [[German#^de-Q0148|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=T%C3%B6ten%20ist%20verboten%3B%20jeder%20M%C3%B6rder%20wird%20bestraft%2C%20es%20sei%20denn%2C%20er%20hat%20gemeinsam%20mit%20vielen%20anderen%20M%C3%A4nnern%20und%20zum%20Klang%20von%20Trompeten%20get%C3%B6tet.)
^de-Q0148-answer

**de-Q0149** — Ich glaube, dass wir im Juni in Urlaub fahren.

I think we're going on vacation in June.

Why: Personal pronoun forms. [[German#^de-Q0149|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20glaube%2C%20dass%20wir%20im%20Juni%20in%20Urlaub%20fahren.)
^de-Q0149-answer

**de-Q0150** — Ich glaube, dass wir im Juni in Urlaub fahren.

I think we're going on vacation in June.

Pronouns change form with their grammatical role. Ich is nominative, mich accusative, mir dative. Sie can mean she, they or polite you; spelling and context distinguish the uses.

Why: Personal pronoun forms. [[German#^de-Q0150|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20glaube%2C%20dass%20wir%20im%20Juni%20in%20Urlaub%20fahren.)
^de-Q0150-answer


### Answers 151–200

**de-Q0151** — Tom verglich ein drei Jahre altes Foto von Mary mit einem aktuellen.

Tom compared a picture taken of Mary three years ago with one that had been taken recently.

Expected form: **altes**

Why: Adjectives in noun phrases. [[German#^de-Q0151|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20verglich%20ein%20drei%20Jahre%20altes%20Foto%20von%20Mary%20mit%20einem%20aktuellen.)
^de-Q0151-answer

**de-Q0152** — Tom verglich ein drei Jahre altes Foto von Mary mit einem aktuellen.

Tom compared a picture taken of Mary three years ago with one that had been taken recently.

Expected form: **altes**

Why: Adjectives in noun phrases. [[German#^de-Q0152|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20verglich%20ein%20drei%20Jahre%20altes%20Foto%20von%20Mary%20mit%20einem%20aktuellen.)
^de-Q0152-answer

**de-Q0153** — Zuerst fiel mir das große Sofa auf. Der Lederbezug war in einem schlichten Farbton gehalten, die Sitzfläche und Rückenlehne sahen bequem aus.

The first thing that came to my attention was the large sofa. It was covered in sober coloured leather, the seat and the back both looked wide and comfortable.

Expected form: **große**

Why: Adjectives in noun phrases. [[German#^de-Q0153|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Zuerst%20fiel%20mir%20das%20gro%C3%9Fe%20Sofa%20auf.%20Der%20Lederbezug%20war%20in%20einem%20schlichten%20Farbton%20gehalten%2C%20die%20Sitzfl%C3%A4che%20und%20R%C3%BCckenlehne%20sahen%20bequem%20aus.)
^de-Q0153-answer

**de-Q0154** — Zuerst fiel mir das große Sofa auf. Der Lederbezug war in einem schlichten Farbton gehalten, die Sitzfläche und Rückenlehne sahen bequem aus.

The first thing that came to my attention was the large sofa. It was covered in sober coloured leather, the seat and the back both looked wide and comfortable.

Why: Adjectives in noun phrases. [[German#^de-Q0154|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Zuerst%20fiel%20mir%20das%20gro%C3%9Fe%20Sofa%20auf.%20Der%20Lederbezug%20war%20in%20einem%20schlichten%20Farbton%20gehalten%2C%20die%20Sitzfl%C3%A4che%20und%20R%C3%BCckenlehne%20sahen%20bequem%20aus.)
^de-Q0154-answer

**de-Q0155** — Diese gute Zeit wird nicht lange währen.

These good times won't last long.

Why: Adjectives in noun phrases. [[German#^de-Q0155|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Diese%20gute%20Zeit%20wird%20nicht%20lange%20w%C3%A4hren.)
^de-Q0155-answer

**de-Q0156** — Diese gute Zeit wird nicht lange währen.

These good times won't last long.

Attributive adjectives take endings after the determiner. Compare ein gutes Buch, das gute Buch and mit einem guten Buch. Predicative adjectives normally stay uninflected: Das Buch ist gut.

Why: Adjectives in noun phrases. [[German#^de-Q0156|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Diese%20gute%20Zeit%20wird%20nicht%20lange%20w%C3%A4hren.)
^de-Q0156-answer

**de-Q0157** — Kannst du ein gutes Buch empfehlen?

Can you recommend a good book?

Expected form: **gutes**

Why: Adjectives in noun phrases. [[German#^de-Q0157|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Kannst%20du%20ein%20gutes%20Buch%20empfehlen%3F)
^de-Q0157-answer

**de-Q0158** — Kannst du ein gutes Buch empfehlen?

Can you recommend a good book?

Expected form: **gutes**

Why: Adjectives in noun phrases. [[German#^de-Q0158|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Kannst%20du%20ein%20gutes%20Buch%20empfehlen%3F)
^de-Q0158-answer

**de-Q0159** — In deinem Alter war ich bereits verheiratet.

When I was your age, I was already married.

Expected form: **Alter**

Why: Adjectives in noun phrases. [[German#^de-Q0159|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=In%20deinem%20Alter%20war%20ich%20bereits%20verheiratet.)
^de-Q0159-answer

**de-Q0160** — In deinem Alter war ich bereits verheiratet.

When I was your age, I was already married.

Why: Adjectives in noun phrases. [[German#^de-Q0160|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=In%20deinem%20Alter%20war%20ich%20bereits%20verheiratet.)
^de-Q0160-answer

**de-Q0161** — Ich wohne in der Nähe eines alten Buchladens.

I live close to an old bookshop.

Why: Adjectives in noun phrases. [[German#^de-Q0161|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20wohne%20in%20der%20N%C3%A4he%20eines%20alten%20Buchladens.)
^de-Q0161-answer

**de-Q0162** — Ich wohne in der Nähe eines alten Buchladens.

I live close to an old bookshop.

Attributive adjectives take endings after the determiner. Compare ein gutes Buch, das gute Buch and mit einem guten Buch. Predicative adjectives normally stay uninflected: Das Buch ist gut.

Why: Adjectives in noun phrases. [[German#^de-Q0162|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20wohne%20in%20der%20N%C3%A4he%20eines%20alten%20Buchladens.)
^de-Q0162-answer

**de-Q0163** — Alles über Ernährung zu lernen ist genauso schwer, wie eine neue Sprache zu lernen.

Learning everything about diet and nutrition is as difficult as learning a new language.

Expected form: **neue**

Why: Adjectives in noun phrases. [[German#^de-Q0163|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Alles%20%C3%BCber%20Ern%C3%A4hrung%20zu%20lernen%20ist%20genauso%20schwer%2C%20wie%20eine%20neue%20Sprache%20zu%20lernen.)
^de-Q0163-answer

**de-Q0164** — Alles über Ernährung zu lernen ist genauso schwer, wie eine neue Sprache zu lernen.

Learning everything about diet and nutrition is as difficult as learning a new language.

Expected form: **neue**

Why: Adjectives in noun phrases. [[German#^de-Q0164|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Alles%20%C3%BCber%20Ern%C3%A4hrung%20zu%20lernen%20ist%20genauso%20schwer%2C%20wie%20eine%20neue%20Sprache%20zu%20lernen.)
^de-Q0164-answer

**de-Q0165** — Tom ist immer noch ein sehr guter Tennisspieler.

Tom is still a very good tennis player.

Expected form: **guter**

Why: Adjectives in noun phrases. [[German#^de-Q0165|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20ist%20immer%20noch%20ein%20sehr%20guter%20Tennisspieler.)
^de-Q0165-answer

**de-Q0166** — Tom ist immer noch ein sehr guter Tennisspieler.

Tom is still a very good tennis player.

Why: Adjectives in noun phrases. [[German#^de-Q0166|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20ist%20immer%20noch%20ein%20sehr%20guter%20Tennisspieler.)
^de-Q0166-answer

**de-Q0167** — Sie ist einen Kopf kleiner als ich.

She's a head shorter than I am.

Why: Adjectives in noun phrases. [[German#^de-Q0167|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20ist%20einen%20Kopf%20kleiner%20als%20ich.)
^de-Q0167-answer

**de-Q0168** — Sie ist einen Kopf kleiner als ich.

She's a head shorter than I am.

Attributive adjectives take endings after the determiner. Compare ein gutes Buch, das gute Buch and mit einem guten Buch. Predicative adjectives normally stay uninflected: Das Buch ist gut.

Why: Adjectives in noun phrases. [[German#^de-Q0168|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20ist%20einen%20Kopf%20kleiner%20als%20ich.)
^de-Q0168-answer

**de-Q0169** — Viele große japanische Unternehmen sind vom Export abhängig.

Many large Japanese companies depend on exports.

Expected form: **große**

Why: Adjectives in noun phrases. [[German#^de-Q0169|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Viele%20gro%C3%9Fe%20japanische%20Unternehmen%20sind%20vom%20Export%20abh%C3%A4ngig.)
^de-Q0169-answer

**de-Q0170** — Viele große japanische Unternehmen sind vom Export abhängig.

Many large Japanese companies depend on exports.

Expected form: **große**

Why: Adjectives in noun phrases. [[German#^de-Q0170|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Viele%20gro%C3%9Fe%20japanische%20Unternehmen%20sind%20vom%20Export%20abh%C3%A4ngig.)
^de-Q0170-answer

**de-Q0171** — Ich mache mir große Sorgen um euch.

I'm very worried about you.

Expected form: **große**

Why: Adjectives in noun phrases. [[German#^de-Q0171|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20mache%20mir%20gro%C3%9Fe%20Sorgen%20um%20euch.)
^de-Q0171-answer

**de-Q0172** — Ich mache mir große Sorgen um euch.

I'm very worried about you.

Why: Adjectives in noun phrases. [[German#^de-Q0172|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20mache%20mir%20gro%C3%9Fe%20Sorgen%20um%20euch.)
^de-Q0172-answer

**de-Q0173** — Sie passt auf ihre alte Mutter auf.

She takes care of her old mother.

Why: Adjectives in noun phrases. [[German#^de-Q0173|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20passt%20auf%20ihre%20alte%20Mutter%20auf.)
^de-Q0173-answer

**de-Q0174** — Sie passt auf ihre alte Mutter auf.

She takes care of her old mother.

Attributive adjectives take endings after the determiner. Compare ein gutes Buch, das gute Buch and mit einem guten Buch. Predicative adjectives normally stay uninflected: Das Buch ist gut.

Why: Adjectives in noun phrases. [[German#^de-Q0174|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20passt%20auf%20ihre%20alte%20Mutter%20auf.)
^de-Q0174-answer

**de-Q0175** — Wie können wir neue Leute treffen?

How can we meet new people?

Expected form: **neue**

Why: Adjectives in noun phrases. [[German#^de-Q0175|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20k%C3%B6nnen%20wir%20neue%20Leute%20treffen%3F)
^de-Q0175-answer

**de-Q0176** — Wie können wir neue Leute treffen?

How can we meet new people?

Expected form: **neue**

Why: Adjectives in noun phrases. [[German#^de-Q0176|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20k%C3%B6nnen%20wir%20neue%20Leute%20treffen%3F)
^de-Q0176-answer

**de-Q0177** — Ihr neues Kleid gefällt ihr.

She's pleased with her new dress.

Expected form: **neues**

Why: Adjectives in noun phrases. [[German#^de-Q0177|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ihr%20neues%20Kleid%20gef%C3%A4llt%20ihr.)
^de-Q0177-answer

**de-Q0178** — Ihr neues Kleid gefällt ihr.

She's pleased with her new dress.

Why: Adjectives in noun phrases. [[German#^de-Q0178|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ihr%20neues%20Kleid%20gef%C3%A4llt%20ihr.)
^de-Q0178-answer

**de-Q0179** — Der Junge sammelte eine Handvoll Erdnüsse und legte sie in eine kleine Schachtel.

The boy gathered a handful of peanuts and put them in a small box.

Why: Adjectives in noun phrases. [[German#^de-Q0179|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Junge%20sammelte%20eine%20Handvoll%20Erdn%C3%BCsse%20und%20legte%20sie%20in%20eine%20kleine%20Schachtel.)
^de-Q0179-answer

**de-Q0180** — Der Junge sammelte eine Handvoll Erdnüsse und legte sie in eine kleine Schachtel.

The boy gathered a handful of peanuts and put them in a small box.

Attributive adjectives take endings after the determiner. Compare ein gutes Buch, das gute Buch and mit einem guten Buch. Predicative adjectives normally stay uninflected: Das Buch ist gut.

Why: Adjectives in noun phrases. [[German#^de-Q0180|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Junge%20sammelte%20eine%20Handvoll%20Erdn%C3%BCsse%20und%20legte%20sie%20in%20eine%20kleine%20Schachtel.)
^de-Q0180-answer

**de-Q0181** — Insekten sind sehr nahrhaft und eine gute Eiweißquelle.

Insects are very nutritious and a good source of protein.

Expected form: **gute**

Why: Adjectives in noun phrases. [[German#^de-Q0181|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Insekten%20sind%20sehr%20nahrhaft%20und%20eine%20gute%20Eiwei%C3%9Fquelle.)
^de-Q0181-answer

**de-Q0182** — Insekten sind sehr nahrhaft und eine gute Eiweißquelle.

Insects are very nutritious and a good source of protein.

Expected form: **gute**

Why: Adjectives in noun phrases. [[German#^de-Q0182|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Insekten%20sind%20sehr%20nahrhaft%20und%20eine%20gute%20Eiwei%C3%9Fquelle.)
^de-Q0182-answer

**de-Q0183** — Das Erdbeben beschädigte viele alte Gebäude.

The earthquake damaged many old buildings.

Expected form: **alte**

Why: Adjectives in noun phrases. [[German#^de-Q0183|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20Erdbeben%20besch%C3%A4digte%20viele%20alte%20Geb%C3%A4ude.)
^de-Q0183-answer

**de-Q0184** — Das Erdbeben beschädigte viele alte Gebäude.

The earthquake damaged many old buildings.

Why: Adjectives in noun phrases. [[German#^de-Q0184|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20Erdbeben%20besch%C3%A4digte%20viele%20alte%20Geb%C3%A4ude.)
^de-Q0184-answer

**de-Q0185** — Er bot uns zehn Dollar für unser altes Radio.

He offered ten dollars for our old radio.

Why: Adjectives in noun phrases. [[German#^de-Q0185|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20bot%20uns%20zehn%20Dollar%20f%C3%BCr%20unser%20altes%20Radio.)
^de-Q0185-answer

**de-Q0186** — Er bot uns zehn Dollar für unser altes Radio.

He offered ten dollars for our old radio.

Attributive adjectives take endings after the determiner. Compare ein gutes Buch, das gute Buch and mit einem guten Buch. Predicative adjectives normally stay uninflected: Das Buch ist gut.

Why: Adjectives in noun phrases. [[German#^de-Q0186|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20bot%20uns%20zehn%20Dollar%20f%C3%BCr%20unser%20altes%20Radio.)
^de-Q0186-answer

**de-Q0187** — Es war für sie eine neue Erfahrung.

It was a new experience for her.

Expected form: **neue**

Why: Adjectives in noun phrases. [[German#^de-Q0187|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20war%20f%C3%BCr%20sie%20eine%20neue%20Erfahrung.)
^de-Q0187-answer

**de-Q0188** — Es war für sie eine neue Erfahrung.

It was a new experience for her.

Expected form: **neue**

Why: Adjectives in noun phrases. [[German#^de-Q0188|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20war%20f%C3%BCr%20sie%20eine%20neue%20Erfahrung.)
^de-Q0188-answer

**de-Q0189** — Alle kleinen Kinder weinen.

All babies cry.

Expected form: **kleinen**

Why: Adjectives in noun phrases. [[German#^de-Q0189|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Alle%20kleinen%20Kinder%20weinen.)
^de-Q0189-answer

**de-Q0190** — Alle kleinen Kinder weinen.

All babies cry.

Why: Adjectives in noun phrases. [[German#^de-Q0190|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Alle%20kleinen%20Kinder%20weinen.)
^de-Q0190-answer

**de-Q0191** — Ich will euch einmal eine kleine Geschichte erzählen.

I want to tell you a little story.

Why: Adjectives in noun phrases. [[German#^de-Q0191|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20will%20euch%20einmal%20eine%20kleine%20Geschichte%20erz%C3%A4hlen.)
^de-Q0191-answer

**de-Q0192** — Ich will euch einmal eine kleine Geschichte erzählen.

I want to tell you a little story.

Attributive adjectives take endings after the determiner. Compare ein gutes Buch, das gute Buch and mit einem guten Buch. Predicative adjectives normally stay uninflected: Das Buch ist gut.

Why: Adjectives in noun phrases. [[German#^de-Q0192|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20will%20euch%20einmal%20eine%20kleine%20Geschichte%20erz%C3%A4hlen.)
^de-Q0192-answer

**de-Q0193** — Sie ist eine große, wohlproportionierte Blondine mit blauen Augen.

She's a tall, statuesque blonde with blue eyes.

Expected form: **große**

Why: Adjectives in noun phrases. [[German#^de-Q0193|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20ist%20eine%20gro%C3%9Fe%2C%20wohlproportionierte%20Blondine%20mit%20blauen%20Augen.)
^de-Q0193-answer

**de-Q0194** — Sie ist eine große, wohlproportionierte Blondine mit blauen Augen.

She's a tall, statuesque blonde with blue eyes.

Expected form: **große**

Why: Adjectives in noun phrases. [[German#^de-Q0194|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20ist%20eine%20gro%C3%9Fe%2C%20wohlproportionierte%20Blondine%20mit%20blauen%20Augen.)
^de-Q0194-answer

**de-Q0195** — Er ist ein sehr guter Musiker.

He's a very fine musician.

Expected form: **guter**

Why: Adjectives in noun phrases. [[German#^de-Q0195|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20ist%20ein%20sehr%20guter%20Musiker.)
^de-Q0195-answer

**de-Q0196** — Er ist ein sehr guter Musiker.

He's a very fine musician.

Why: Adjectives in noun phrases. [[German#^de-Q0196|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20ist%20ein%20sehr%20guter%20Musiker.)
^de-Q0196-answer

**de-Q0197** — Du hast sicher gute Gründe, ärgerlich zu sein.

I guess you have your reasons for being angry.

Why: Adjectives in noun phrases. [[German#^de-Q0197|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Du%20hast%20sicher%20gute%20Gr%C3%BCnde%2C%20%C3%A4rgerlich%20zu%20sein.)
^de-Q0197-answer

**de-Q0198** — Du hast sicher gute Gründe, ärgerlich zu sein.

I guess you have your reasons for being angry.

Attributive adjectives take endings after the determiner. Compare ein gutes Buch, das gute Buch and mit einem guten Buch. Predicative adjectives normally stay uninflected: Das Buch ist gut.

Why: Adjectives in noun phrases. [[German#^de-Q0198|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Du%20hast%20sicher%20gute%20Gr%C3%BCnde%2C%20%C3%A4rgerlich%20zu%20sein.)
^de-Q0198-answer

**de-Q0199** — Wie finden Sie seinen neuen Roman?

How do you find his new novel?

Expected form: **neuen**

Why: Adjectives in noun phrases. [[German#^de-Q0199|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20finden%20Sie%20seinen%20neuen%20Roman%3F)
^de-Q0199-answer

**de-Q0200** — Wie finden Sie seinen neuen Roman?

How do you find his new novel?

Expected form: **neuen**

Why: Adjectives in noun phrases. [[German#^de-Q0200|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20finden%20Sie%20seinen%20neuen%20Roman%3F)
^de-Q0200-answer


### Answers 201–250

**de-Q0201** — Warum sind einige Übersetzungen ausgegraut?

Why are some translations in grey?

Expected form: **sind**

Why: Present forms of sein. [[German#^de-Q0201|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Warum%20sind%20einige%20%C3%9Cbersetzungen%20ausgegraut%3F)
^de-Q0201-answer

**de-Q0202** — Warum sind einige Übersetzungen ausgegraut?

Why are some translations in grey?

Why: Present forms of sein. [[German#^de-Q0202|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Warum%20sind%20einige%20%C3%9Cbersetzungen%20ausgegraut%3F)
^de-Q0202-answer

**de-Q0203** — Tom ist faul.

Tom is lazy.

Why: Present forms of sein. [[German#^de-Q0203|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20ist%20faul.)
^de-Q0203-answer

**de-Q0204** — Tom ist faul.

Tom is lazy.

Sein is irregular: ich bin, du bist, er/sie/es ist, wir/sie sind, ihr seid. A finite verb agrees with the subject. In a main statement it normally occupies the second constituent position.

Why: Present forms of sein. [[German#^de-Q0204|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20ist%20faul.)
^de-Q0204-answer

**de-Q0205** — Tom ist ziemlich sarkastisch.

Tom is quite sarcastic.

Expected form: **ist**

Why: Present forms of sein. [[German#^de-Q0205|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20ist%20ziemlich%20sarkastisch.)
^de-Q0205-answer

**de-Q0206** — Tom ist ziemlich sarkastisch.

Tom is quite sarcastic.

Expected form: **ist**

Why: Present forms of sein. [[German#^de-Q0206|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20ist%20ziemlich%20sarkastisch.)
^de-Q0206-answer

**de-Q0207** — Es ist unklar wie viele von ihnen überlebt haben.

How many of them survived is not known.

Expected form: **ist**

Why: Present forms of sein. [[German#^de-Q0207|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20ist%20unklar%20wie%20viele%20von%20ihnen%20%C3%BCberlebt%20haben.)
^de-Q0207-answer

**de-Q0208** — Es ist unklar wie viele von ihnen überlebt haben.

How many of them survived is not known.

Why: Present forms of sein. [[German#^de-Q0208|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20ist%20unklar%20wie%20viele%20von%20ihnen%20%C3%BCberlebt%20haben.)
^de-Q0208-answer

**de-Q0209** — Zu was ist es gut?

What's the use?

Why: Present forms of sein. [[German#^de-Q0209|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Zu%20was%20ist%20es%20gut%3F)
^de-Q0209-answer

**de-Q0210** — Zu was ist es gut?

What's the use?

Sein is irregular: ich bin, du bist, er/sie/es ist, wir/sie sind, ihr seid. A finite verb agrees with the subject. In a main statement it normally occupies the second constituent position.

Why: Present forms of sein. [[German#^de-Q0210|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Zu%20was%20ist%20es%20gut%3F)
^de-Q0210-answer

**de-Q0211** — Sie sind größer, als ich mir Sie vorgestellt habe.

You're taller than I imagined you'd be.

Expected form: **sind**

Why: Present forms of sein. [[German#^de-Q0211|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20sind%20gr%C3%B6%C3%9Fer%2C%20als%20ich%20mir%20Sie%20vorgestellt%20habe.)
^de-Q0211-answer

**de-Q0212** — Sie sind größer, als ich mir Sie vorgestellt habe.

You're taller than I imagined you'd be.

Expected form: **sind**

Why: Present forms of sein. [[German#^de-Q0212|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20sind%20gr%C3%B6%C3%9Fer%2C%20als%20ich%20mir%20Sie%20vorgestellt%20habe.)
^de-Q0212-answer

**de-Q0213** — Sie sind kein Feigling.

You are not a coward.

Expected form: **sind**

Why: Present forms of sein. [[German#^de-Q0213|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20sind%20kein%20Feigling.)
^de-Q0213-answer

**de-Q0214** — Sie sind kein Feigling.

You are not a coward.

Why: Present forms of sein. [[German#^de-Q0214|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20sind%20kein%20Feigling.)
^de-Q0214-answer

**de-Q0215** — Wir sind froh, dass du wieder da bist.

We are happy to see you again.

Why: Present forms of sein. [[German#^de-Q0215|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20sind%20froh%2C%20dass%20du%20wieder%20da%20bist.)
^de-Q0215-answer

**de-Q0216** — Wir sind froh, dass du wieder da bist.

We are happy to see you again.

Sein is irregular: ich bin, du bist, er/sie/es ist, wir/sie sind, ihr seid. A finite verb agrees with the subject. In a main statement it normally occupies the second constituent position.

Why: Present forms of sein. [[German#^de-Q0216|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20sind%20froh%2C%20dass%20du%20wieder%20da%20bist.)
^de-Q0216-answer

**de-Q0217** — Wie groß ist die Bevölkerung Japans?

What is the population of Japan?

Expected form: **ist**

Why: Present forms of sein. [[German#^de-Q0217|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20gro%C3%9F%20ist%20die%20Bev%C3%B6lkerung%20Japans%3F)
^de-Q0217-answer

**de-Q0218** — Wie groß ist die Bevölkerung Japans?

What is the population of Japan?

Expected form: **ist**

Why: Present forms of sein. [[German#^de-Q0218|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20gro%C3%9F%20ist%20die%20Bev%C3%B6lkerung%20Japans%3F)
^de-Q0218-answer

**de-Q0219** — Hunde sind edle Wesen.

Dogs are noble creatures.

Expected form: **sind**

Why: Present forms of sein. [[German#^de-Q0219|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Hunde%20sind%20edle%20Wesen.)
^de-Q0219-answer

**de-Q0220** — Hunde sind edle Wesen.

Dogs are noble creatures.

Why: Present forms of sein. [[German#^de-Q0220|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Hunde%20sind%20edle%20Wesen.)
^de-Q0220-answer

**de-Q0221** — Was ist der bevölkerungsreichste Kontinent der Welt?

Which is the most populated continent in the world?

Why: Present forms of sein. [[German#^de-Q0221|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Was%20ist%20der%20bev%C3%B6lkerungsreichste%20Kontinent%20der%20Welt%3F)
^de-Q0221-answer

**de-Q0222** — Was ist der bevölkerungsreichste Kontinent der Welt?

Which is the most populated continent in the world?

Sein is irregular: ich bin, du bist, er/sie/es ist, wir/sie sind, ihr seid. A finite verb agrees with the subject. In a main statement it normally occupies the second constituent position.

Why: Present forms of sein. [[German#^de-Q0222|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Was%20ist%20der%20bev%C3%B6lkerungsreichste%20Kontinent%20der%20Welt%3F)
^de-Q0222-answer

**de-Q0223** — Das Baby weint. Ich glaube, es ist krank.

The baby is crying. I think it is sick.

Expected form: **ist**

Why: Present forms of sein. [[German#^de-Q0223|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20Baby%20weint.%20Ich%20glaube%2C%20es%20ist%20krank.)
^de-Q0223-answer

**de-Q0224** — Das Baby weint. Ich glaube, es ist krank.

The baby is crying. I think it is sick.

Expected form: **ist**

Why: Present forms of sein. [[German#^de-Q0224|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20Baby%20weint.%20Ich%20glaube%2C%20es%20ist%20krank.)
^de-Q0224-answer

**de-Q0225** — Die Katze ist schwarz.

The cat is black.

Expected form: **ist**

Why: Present forms of sein. [[German#^de-Q0225|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Katze%20ist%20schwarz.)
^de-Q0225-answer

**de-Q0226** — Die Katze ist schwarz.

The cat is black.

Why: Present forms of sein. [[German#^de-Q0226|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Katze%20ist%20schwarz.)
^de-Q0226-answer

**de-Q0227** — Tom ist im Gebäude.

Tom is in the building.

Why: Present forms of sein. [[German#^de-Q0227|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20ist%20im%20Geb%C3%A4ude.)
^de-Q0227-answer

**de-Q0228** — Tom ist im Gebäude.

Tom is in the building.

Sein is irregular: ich bin, du bist, er/sie/es ist, wir/sie sind, ihr seid. A finite verb agrees with the subject. In a main statement it normally occupies the second constituent position.

Why: Present forms of sein. [[German#^de-Q0228|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20ist%20im%20Geb%C3%A4ude.)
^de-Q0228-answer

**de-Q0229** — Ich frage mich, wie es ist, reich zu sein.

I wonder what it feels like to be rich.

Expected form: **ist**

Why: Present forms of sein. [[German#^de-Q0229|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20frage%20mich%2C%20wie%20es%20ist%2C%20reich%20zu%20sein.)
^de-Q0229-answer

**de-Q0230** — Ich frage mich, wie es ist, reich zu sein.

I wonder what it feels like to be rich.

Expected form: **ist**

Why: Present forms of sein. [[German#^de-Q0230|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20frage%20mich%2C%20wie%20es%20ist%2C%20reich%20zu%20sein.)
^de-Q0230-answer

**de-Q0231** — Bis du wieder zurück bist, bin ich schon gegangen.

By the time you come back, I'll be gone.

Expected form: **bist**

Why: Present forms of sein. [[German#^de-Q0231|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Bis%20du%20wieder%20zur%C3%BCck%20bist%2C%20bin%20ich%20schon%20gegangen.)
^de-Q0231-answer

**de-Q0232** — Bis du wieder zurück bist, bin ich schon gegangen.

By the time you come back, I'll be gone.

Why: Present forms of sein. [[German#^de-Q0232|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Bis%20du%20wieder%20zur%C3%BCck%20bist%2C%20bin%20ich%20schon%20gegangen.)
^de-Q0232-answer

**de-Q0233** — Das Vorstellungsgespräch ist für morgen früh zehn Uhr angesetzt.

The interview is scheduled for 10:00 a.m. tomorrow.

Why: Present forms of sein. [[German#^de-Q0233|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20Vorstellungsgespr%C3%A4ch%20ist%20f%C3%BCr%20morgen%20fr%C3%BCh%20zehn%20Uhr%20angesetzt.)
^de-Q0233-answer

**de-Q0234** — Das Vorstellungsgespräch ist für morgen früh zehn Uhr angesetzt.

The interview is scheduled for 10:00 a.m. tomorrow.

Sein is irregular: ich bin, du bist, er/sie/es ist, wir/sie sind, ihr seid. A finite verb agrees with the subject. In a main statement it normally occupies the second constituent position.

Why: Present forms of sein. [[German#^de-Q0234|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20Vorstellungsgespr%C3%A4ch%20ist%20f%C3%BCr%20morgen%20fr%C3%BCh%20zehn%20Uhr%20angesetzt.)
^de-Q0234-answer

**de-Q0235** — Ich finde, dein Englisch ist schon viel besser geworden.

I think your English has improved a lot.

Expected form: **ist**

Why: Present forms of sein. [[German#^de-Q0235|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20finde%2C%20dein%20Englisch%20ist%20schon%20viel%20besser%20geworden.)
^de-Q0235-answer

**de-Q0236** — Ich finde, dein Englisch ist schon viel besser geworden.

I think your English has improved a lot.

Expected form: **ist**

Why: Present forms of sein. [[German#^de-Q0236|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20finde%2C%20dein%20Englisch%20ist%20schon%20viel%20besser%20geworden.)
^de-Q0236-answer

**de-Q0237** — Bilder sind die Bücher der Analphabeten.

Images are the books of the illiterate.

Expected form: **sind**

Why: Present forms of sein. [[German#^de-Q0237|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Bilder%20sind%20die%20B%C3%BCcher%20der%20Analphabeten.)
^de-Q0237-answer

**de-Q0238** — Bilder sind die Bücher der Analphabeten.

Images are the books of the illiterate.

Why: Present forms of sein. [[German#^de-Q0238|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Bilder%20sind%20die%20B%C3%BCcher%20der%20Analphabeten.)
^de-Q0238-answer

**de-Q0239** — Tom ist Gefängnisaufseher.

Tom is a corrections officer.

Why: Present forms of sein. [[German#^de-Q0239|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20ist%20Gef%C3%A4ngnisaufseher.)
^de-Q0239-answer

**de-Q0240** — Tom ist Gefängnisaufseher.

Tom is a corrections officer.

Sein is irregular: ich bin, du bist, er/sie/es ist, wir/sie sind, ihr seid. A finite verb agrees with the subject. In a main statement it normally occupies the second constituent position.

Why: Present forms of sein. [[German#^de-Q0240|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20ist%20Gef%C3%A4ngnisaufseher.)
^de-Q0240-answer

**de-Q0241** — Ihr seid niederträchtig.

You're wicked.

Expected form: **seid**

Why: Present forms of sein. [[German#^de-Q0241|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ihr%20seid%20niedertr%C3%A4chtig.)
^de-Q0241-answer

**de-Q0242** — Ihr seid niederträchtig.

You're wicked.

Expected form: **seid**

Why: Present forms of sein. [[German#^de-Q0242|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ihr%20seid%20niedertr%C3%A4chtig.)
^de-Q0242-answer

**de-Q0243** — Ist es gut, weniger Fleisch zu essen?

Is eating less meat a good idea?

Expected form: **Ist**

Why: Present forms of sein. [[German#^de-Q0243|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ist%20es%20gut%2C%20weniger%20Fleisch%20zu%20essen%3F)
^de-Q0243-answer

**de-Q0244** — Ist es gut, weniger Fleisch zu essen?

Is eating less meat a good idea?

Why: Present forms of sein. [[German#^de-Q0244|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ist%20es%20gut%2C%20weniger%20Fleisch%20zu%20essen%3F)
^de-Q0244-answer

**de-Q0245** — Es ist nicht sein Stil.

It's not his style.

Why: Present forms of sein. [[German#^de-Q0245|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20ist%20nicht%20sein%20Stil.)
^de-Q0245-answer

**de-Q0246** — Es ist nicht sein Stil.

It's not his style.

Sein is irregular: ich bin, du bist, er/sie/es ist, wir/sie sind, ihr seid. A finite verb agrees with the subject. In a main statement it normally occupies the second constituent position.

Why: Present forms of sein. [[German#^de-Q0246|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20ist%20nicht%20sein%20Stil.)
^de-Q0246-answer

**de-Q0247** — Willst du wissen, warum Tom und Maria hier sind?

Do you want to know why Tom and Mary are here?

Expected form: **sind**

Why: Present forms of sein. [[German#^de-Q0247|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Willst%20du%20wissen%2C%20warum%20Tom%20und%20Maria%20hier%20sind%3F)
^de-Q0247-answer

**de-Q0248** — Willst du wissen, warum Tom und Maria hier sind?

Do you want to know why Tom and Mary are here?

Expected form: **sind**

Why: Present forms of sein. [[German#^de-Q0248|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Willst%20du%20wissen%2C%20warum%20Tom%20und%20Maria%20hier%20sind%3F)
^de-Q0248-answer

**de-Q0249** — Diese Suppe ist mir zu dünn.

This soup is too thin for me.

Expected form: **ist**

Why: Present forms of sein. [[German#^de-Q0249|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Diese%20Suppe%20ist%20mir%20zu%20d%C3%BCnn.)
^de-Q0249-answer

**de-Q0250** — Diese Suppe ist mir zu dünn.

This soup is too thin for me.

Why: Present forms of sein. [[German#^de-Q0250|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Diese%20Suppe%20ist%20mir%20zu%20d%C3%BCnn.)
^de-Q0250-answer


### Answers 251–300

**de-Q0251** — Wie viele Bundesstaaten hat Indien?

How many states does India have?

Why: Present forms of haben. [[German#^de-Q0251|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20viele%20Bundesstaaten%20hat%20Indien%3F)
^de-Q0251-answer

**de-Q0252** — Wie viele Bundesstaaten hat Indien?

How many states does India have?

Haben can express possession or serve as a perfect auxiliary. Identify whether a participle is also present. The finite form agrees with the subject even when an infinitive or participle stands later.

Why: Present forms of haben. [[German#^de-Q0252|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20viele%20Bundesstaaten%20hat%20Indien%3F)
^de-Q0252-answer

**de-Q0253** — Ich habe nicht viel Geld auf meinem Konto.

I don't have much money in my bank account.

Expected form: **habe**

Why: Present forms of haben. [[German#^de-Q0253|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20nicht%20viel%20Geld%20auf%20meinem%20Konto.)
^de-Q0253-answer

**de-Q0254** — Ich habe nicht viel Geld auf meinem Konto.

I don't have much money in my bank account.

Expected form: **habe**

Why: Present forms of haben. [[German#^de-Q0254|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20nicht%20viel%20Geld%20auf%20meinem%20Konto.)
^de-Q0254-answer

**de-Q0255** — Erst gestern hat er sie wahrgenommen.

It was not until yesterday that he noticed her.

Expected form: **hat**

Why: Present forms of haben. [[German#^de-Q0255|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Erst%20gestern%20hat%20er%20sie%20wahrgenommen.)
^de-Q0255-answer

**de-Q0256** — Erst gestern hat er sie wahrgenommen.

It was not until yesterday that he noticed her.

Why: Present forms of haben. [[German#^de-Q0256|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Erst%20gestern%20hat%20er%20sie%20wahrgenommen.)
^de-Q0256-answer

**de-Q0257** — Sie hat mediale Kräfte.

She has psychic abilities.

Why: Present forms of haben. [[German#^de-Q0257|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20hat%20mediale%20Kr%C3%A4fte.)
^de-Q0257-answer

**de-Q0258** — Sie hat mediale Kräfte.

She has psychic abilities.

Haben can express possession or serve as a perfect auxiliary. Identify whether a participle is also present. The finite form agrees with the subject even when an infinitive or participle stands later.

Why: Present forms of haben. [[German#^de-Q0258|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20hat%20mediale%20Kr%C3%A4fte.)
^de-Q0258-answer

**de-Q0259** — Hast du dir die Haare gewaschen?

Did you wash your hair?

Expected form: **Hast**

Why: Present forms of haben. [[German#^de-Q0259|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Hast%20du%20dir%20die%20Haare%20gewaschen%3F)
^de-Q0259-answer

**de-Q0260** — Hast du dir die Haare gewaschen?

Did you wash your hair?

Expected form: **Hast**

Why: Present forms of haben. [[German#^de-Q0260|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Hast%20du%20dir%20die%20Haare%20gewaschen%3F)
^de-Q0260-answer

**de-Q0261** — Hast du dazu irgendetwas zu sagen?

Do you have anything to say in connection with this?

Expected form: **Hast**

Why: Present forms of haben. [[German#^de-Q0261|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Hast%20du%20dazu%20irgendetwas%20zu%20sagen%3F)
^de-Q0261-answer

**de-Q0262** — Hast du dazu irgendetwas zu sagen?

Do you have anything to say in connection with this?

Why: Present forms of haben. [[German#^de-Q0262|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Hast%20du%20dazu%20irgendetwas%20zu%20sagen%3F)
^de-Q0262-answer

**de-Q0263** — Ich glaube, dass er nichts mit dieser Sache zu tun hat.

I don't think he has anything to do with the matter.

Why: Present forms of haben. [[German#^de-Q0263|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20glaube%2C%20dass%20er%20nichts%20mit%20dieser%20Sache%20zu%20tun%20hat.)
^de-Q0263-answer

**de-Q0264** — Ich glaube, dass er nichts mit dieser Sache zu tun hat.

I don't think he has anything to do with the matter.

Haben can express possession or serve as a perfect auxiliary. Identify whether a participle is also present. The finite form agrees with the subject even when an infinitive or participle stands later.

Why: Present forms of haben. [[German#^de-Q0264|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20glaube%2C%20dass%20er%20nichts%20mit%20dieser%20Sache%20zu%20tun%20hat.)
^de-Q0264-answer

**de-Q0265** — Wer hat euch gefunden?

Who found you?

Expected form: **hat**

Why: Present forms of haben. [[German#^de-Q0265|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wer%20hat%20euch%20gefunden%3F)
^de-Q0265-answer

**de-Q0266** — Wer hat euch gefunden?

Who found you?

Expected form: **hat**

Why: Present forms of haben. [[German#^de-Q0266|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wer%20hat%20euch%20gefunden%3F)
^de-Q0266-answer

**de-Q0267** — Ich hatte kein Referat vorbereitet. Also habe ich einfach improvisiert.

I didn't prepare a presentation. So I just blagged it.

Expected form: **habe**

Why: Present forms of haben. [[German#^de-Q0267|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20hatte%20kein%20Referat%20vorbereitet.%20Also%20habe%20ich%20einfach%20improvisiert.)
^de-Q0267-answer

**de-Q0268** — Ich hatte kein Referat vorbereitet. Also habe ich einfach improvisiert.

I didn't prepare a presentation. So I just blagged it.

Why: Present forms of haben. [[German#^de-Q0268|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20hatte%20kein%20Referat%20vorbereitet.%20Also%20habe%20ich%20einfach%20improvisiert.)
^de-Q0268-answer

**de-Q0269** — Wann haben Sie angefangen, Französisch zu lernen?

When did you start studying French?

Why: Present forms of haben. [[German#^de-Q0269|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wann%20haben%20Sie%20angefangen%2C%20Franz%C3%B6sisch%20zu%20lernen%3F)
^de-Q0269-answer

**de-Q0270** — Wann haben Sie angefangen, Französisch zu lernen?

When did you start studying French?

Haben can express possession or serve as a perfect auxiliary. Identify whether a participle is also present. The finite form agrees with the subject even when an infinitive or participle stands later.

Why: Present forms of haben. [[German#^de-Q0270|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wann%20haben%20Sie%20angefangen%2C%20Franz%C3%B6sisch%20zu%20lernen%3F)
^de-Q0270-answer

**de-Q0271** — Tom weiß nicht, was Maria getan hat.

Tom doesn't know what Mary has done.

Expected form: **hat**

Why: Present forms of haben. [[German#^de-Q0271|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20wei%C3%9F%20nicht%2C%20was%20Maria%20getan%20hat.)
^de-Q0271-answer

**de-Q0272** — Tom weiß nicht, was Maria getan hat.

Tom doesn't know what Mary has done.

Expected form: **hat**

Why: Present forms of haben. [[German#^de-Q0272|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20wei%C3%9F%20nicht%2C%20was%20Maria%20getan%20hat.)
^de-Q0272-answer

**de-Q0273** — Wir haben etwas vergessen.

We've forgotten something.

Expected form: **haben**

Why: Present forms of haben. [[German#^de-Q0273|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20haben%20etwas%20vergessen.)
^de-Q0273-answer

**de-Q0274** — Wir haben etwas vergessen.

We've forgotten something.

Why: Present forms of haben. [[German#^de-Q0274|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20haben%20etwas%20vergessen.)
^de-Q0274-answer

**de-Q0275** — „Wohin hat er dich geküsst?“ – „Auf den Mund.“

"Where did he kiss you?" "On my lips."

Why: Present forms of haben. [[German#^de-Q0275|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=%E2%80%9EWohin%20hat%20er%20dich%20gek%C3%BCsst%3F%E2%80%9C%20%E2%80%93%20%E2%80%9EAuf%20den%20Mund.%E2%80%9C)
^de-Q0275-answer

**de-Q0276** — „Wohin hat er dich geküsst?“ – „Auf den Mund.“

"Where did he kiss you?" "On my lips."

Haben can express possession or serve as a perfect auxiliary. Identify whether a participle is also present. The finite form agrees with the subject even when an infinitive or participle stands later.

Why: Present forms of haben. [[German#^de-Q0276|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=%E2%80%9EWohin%20hat%20er%20dich%20gek%C3%BCsst%3F%E2%80%9C%20%E2%80%93%20%E2%80%9EAuf%20den%20Mund.%E2%80%9C)
^de-Q0276-answer

**de-Q0277** — Wir haben seitdem nichts mehr von ihr gehört.

We haven't heard from her since then.

Expected form: **haben**

Why: Present forms of haben. [[German#^de-Q0277|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20haben%20seitdem%20nichts%20mehr%20von%20ihr%20geh%C3%B6rt.)
^de-Q0277-answer

**de-Q0278** — Wir haben seitdem nichts mehr von ihr gehört.

We haven't heard from her since then.

Expected form: **haben**

Why: Present forms of haben. [[German#^de-Q0278|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20haben%20seitdem%20nichts%20mehr%20von%20ihr%20geh%C3%B6rt.)
^de-Q0278-answer

**de-Q0279** — Es hat mich niemand dazu gezwungen.

Nobody forced me to do that.

Expected form: **hat**

Why: Present forms of haben. [[German#^de-Q0279|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20hat%20mich%20niemand%20dazu%20gezwungen.)
^de-Q0279-answer

**de-Q0280** — Es hat mich niemand dazu gezwungen.

Nobody forced me to do that.

Why: Present forms of haben. [[German#^de-Q0280|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20hat%20mich%20niemand%20dazu%20gezwungen.)
^de-Q0280-answer

**de-Q0281** — Peter hat beschlossen, morgen aufzubrechen.

Peter has decided to leave tomorrow.

Why: Present forms of haben. [[German#^de-Q0281|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Peter%20hat%20beschlossen%2C%20morgen%20aufzubrechen.)
^de-Q0281-answer

**de-Q0282** — Peter hat beschlossen, morgen aufzubrechen.

Peter has decided to leave tomorrow.

Haben can express possession or serve as a perfect auxiliary. Identify whether a participle is also present. The finite form agrees with the subject even when an infinitive or participle stands later.

Why: Present forms of haben. [[German#^de-Q0282|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Peter%20hat%20beschlossen%2C%20morgen%20aufzubrechen.)
^de-Q0282-answer

**de-Q0283** — Ich wollte versuchen, an das Archiv zu kommen, aber ich habe es vergessen.

I was going to try and get the archive, but I forgot.

Expected form: **habe**

Why: Present forms of haben. [[German#^de-Q0283|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20wollte%20versuchen%2C%20an%20das%20Archiv%20zu%20kommen%2C%20aber%20ich%20habe%20es%20vergessen.)
^de-Q0283-answer

**de-Q0284** — Ich wollte versuchen, an das Archiv zu kommen, aber ich habe es vergessen.

I was going to try and get the archive, but I forgot.

Expected form: **habe**

Why: Present forms of haben. [[German#^de-Q0284|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20wollte%20versuchen%2C%20an%20das%20Archiv%20zu%20kommen%2C%20aber%20ich%20habe%20es%20vergessen.)
^de-Q0284-answer

**de-Q0285** — Ich habe Tom noch nie die Fassung verlieren sehen.

I've never seen Tom lose his temper before.

Expected form: **habe**

Why: Present forms of haben. [[German#^de-Q0285|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20Tom%20noch%20nie%20die%20Fassung%20verlieren%20sehen.)
^de-Q0285-answer

**de-Q0286** — Ich habe Tom noch nie die Fassung verlieren sehen.

I've never seen Tom lose his temper before.

Why: Present forms of haben. [[German#^de-Q0286|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20Tom%20noch%20nie%20die%20Fassung%20verlieren%20sehen.)
^de-Q0286-answer

**de-Q0287** — Sie hat etwas gesagt.

She said something.

Why: Present forms of haben. [[German#^de-Q0287|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20hat%20etwas%20gesagt.)
^de-Q0287-answer

**de-Q0288** — Sie hat etwas gesagt.

She said something.

Haben can express possession or serve as a perfect auxiliary. Identify whether a participle is also present. The finite form agrees with the subject even when an infinitive or participle stands later.

Why: Present forms of haben. [[German#^de-Q0288|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20hat%20etwas%20gesagt.)
^de-Q0288-answer

**de-Q0289** — Habt ihr bemerkt, dass sie das Haus verlassen hat?

Did you notice that she left the house?

Expected form: **Habt**

Why: Present forms of haben. [[German#^de-Q0289|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Habt%20ihr%20bemerkt%2C%20dass%20sie%20das%20Haus%20verlassen%20hat%3F)
^de-Q0289-answer

**de-Q0290** — Habt ihr bemerkt, dass sie das Haus verlassen hat?

Did you notice that she left the house?

Expected form: **Habt**

Why: Present forms of haben. [[German#^de-Q0290|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Habt%20ihr%20bemerkt%2C%20dass%20sie%20das%20Haus%20verlassen%20hat%3F)
^de-Q0290-answer

**de-Q0291** — Ich habe laut gerülpst.

I burped loudly.

Expected form: **habe**

Why: Present forms of haben. [[German#^de-Q0291|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20laut%20ger%C3%BClpst.)
^de-Q0291-answer

**de-Q0292** — Ich habe laut gerülpst.

I burped loudly.

Why: Present forms of haben. [[German#^de-Q0292|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20laut%20ger%C3%BClpst.)
^de-Q0292-answer

**de-Q0293** — Tom hat die ganze Nacht über geweint.

Tom cried all night.

Why: Present forms of haben. [[German#^de-Q0293|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20hat%20die%20ganze%20Nacht%20%C3%BCber%20geweint.)
^de-Q0293-answer

**de-Q0294** — Tom hat die ganze Nacht über geweint.

Tom cried all night.

Haben can express possession or serve as a perfect auxiliary. Identify whether a participle is also present. The finite form agrees with the subject even when an infinitive or participle stands later.

Why: Present forms of haben. [[German#^de-Q0294|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20hat%20die%20ganze%20Nacht%20%C3%BCber%20geweint.)
^de-Q0294-answer

**de-Q0295** — Ich habe es schon versucht.

I've already tried.

Expected form: **habe**

Why: Present forms of haben. [[German#^de-Q0295|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20es%20schon%20versucht.)
^de-Q0295-answer

**de-Q0296** — Ich habe es schon versucht.

I've already tried.

Expected form: **habe**

Why: Present forms of haben. [[German#^de-Q0296|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20es%20schon%20versucht.)
^de-Q0296-answer

**de-Q0297** — Ich möchte wissen, warum du mich angelogen hast.

I want to know why you lied to me.

Expected form: **hast**

Why: Present forms of haben. [[German#^de-Q0297|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20m%C3%B6chte%20wissen%2C%20warum%20du%20mich%20angelogen%20hast.)
^de-Q0297-answer

**de-Q0298** — Ich möchte wissen, warum du mich angelogen hast.

I want to know why you lied to me.

Why: Present forms of haben. [[German#^de-Q0298|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20m%C3%B6chte%20wissen%2C%20warum%20du%20mich%20angelogen%20hast.)
^de-Q0298-answer

**de-Q0299** — Tom hat überall nach Ihnen gesucht.

Tom has been looking all over for you.

Why: Present forms of haben. [[German#^de-Q0299|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20hat%20%C3%BCberall%20nach%20Ihnen%20gesucht.)
^de-Q0299-answer

**de-Q0300** — Tom hat überall nach Ihnen gesucht.

Tom has been looking all over for you.

Haben can express possession or serve as a perfect auxiliary. Identify whether a participle is also present. The finite form agrees with the subject even when an infinitive or participle stands later.

Why: Present forms of haben. [[German#^de-Q0300|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20hat%20%C3%BCberall%20nach%20Ihnen%20gesucht.)
^de-Q0300-answer


### Answers 301–350

**de-Q0301** — Tom will sich entschuldigen.

Tom is going to apologize.

Expected form: **will**

Why: Modal verbs. [[German#^de-Q0301|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20will%20sich%20entschuldigen.)
^de-Q0301-answer

**de-Q0302** — Tom will sich entschuldigen.

Tom is going to apologize.

Expected form: **will**

Why: Modal verbs. [[German#^de-Q0302|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20will%20sich%20entschuldigen.)
^de-Q0302-answer

**de-Q0303** — In diesem Buch steht, dass Elefanten über hundert Jahre alt werden können.

This book says that elephants live to be over 100 years old.

Expected form: **können**

Why: Modal verbs. [[German#^de-Q0303|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=In%20diesem%20Buch%20steht%2C%20dass%20Elefanten%20%C3%BCber%20hundert%20Jahre%20alt%20werden%20k%C3%B6nnen.)
^de-Q0303-answer

**de-Q0304** — In diesem Buch steht, dass Elefanten über hundert Jahre alt werden können.

This book says that elephants live to be over 100 years old.

Why: Modal verbs. [[German#^de-Q0304|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=In%20diesem%20Buch%20steht%2C%20dass%20Elefanten%20%C3%BCber%20hundert%20Jahre%20alt%20werden%20k%C3%B6nnen.)
^de-Q0304-answer

**de-Q0305** — Tom kann nur mit Mühe mit dem Rest der Klasse Schritt halten.

Tom has trouble keeping up with the rest of the class.

Why: Modal verbs. [[German#^de-Q0305|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20kann%20nur%20mit%20M%C3%BChe%20mit%20dem%20Rest%20der%20Klasse%20Schritt%20halten.)
^de-Q0305-answer

**de-Q0306** — Tom kann nur mit Mühe mit dem Rest der Klasse Schritt halten.

Tom has trouble keeping up with the rest of the class.

Modals express ability, necessity, permission, reported obligation or intention. A following ordinary infinitive normally has no zu and goes late in the clause. Nicht müssen means lack of necessity; nicht dürfen means prohibition.

Why: Modal verbs. [[German#^de-Q0306|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20kann%20nur%20mit%20M%C3%BChe%20mit%20dem%20Rest%20der%20Klasse%20Schritt%20halten.)
^de-Q0306-answer

**de-Q0307** — Du hättest in Boston bleiben können.

You could've stayed in Boston.

Expected form: **können**

Why: Modal verbs. [[German#^de-Q0307|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Du%20h%C3%A4ttest%20in%20Boston%20bleiben%20k%C3%B6nnen.)
^de-Q0307-answer

**de-Q0308** — Du hättest in Boston bleiben können.

You could've stayed in Boston.

Expected form: **können**

Why: Modal verbs. [[German#^de-Q0308|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Du%20h%C3%A4ttest%20in%20Boston%20bleiben%20k%C3%B6nnen.)
^de-Q0308-answer

**de-Q0309** — Bedenke, was getan werden sollte, stelle fest, was getan werden kann, und tu das, was getan werden muss.

Consider what should be done, determine what can be done and do what needs to be done.

Expected form: **kann**

Why: Modal verbs. [[German#^de-Q0309|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Bedenke%2C%20was%20getan%20werden%20sollte%2C%20stelle%20fest%2C%20was%20getan%20werden%20kann%2C%20und%20tu%20das%2C%20was%20getan%20werden%20muss.)
^de-Q0309-answer

**de-Q0310** — Bedenke, was getan werden sollte, stelle fest, was getan werden kann, und tu das, was getan werden muss.

Consider what should be done, determine what can be done and do what needs to be done.

Why: Modal verbs. [[German#^de-Q0310|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Bedenke%2C%20was%20getan%20werden%20sollte%2C%20stelle%20fest%2C%20was%20getan%20werden%20kann%2C%20und%20tu%20das%2C%20was%20getan%20werden%20muss.)
^de-Q0310-answer

**de-Q0311** — Das kann an einem Tag gemacht werden.

It can be done in a day.

Why: Modal verbs. [[German#^de-Q0311|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20kann%20an%20einem%20Tag%20gemacht%20werden.)
^de-Q0311-answer

**de-Q0312** — Das kann an einem Tag gemacht werden.

It can be done in a day.

Modals express ability, necessity, permission, reported obligation or intention. A following ordinary infinitive normally has no zu and goes late in the clause. Nicht müssen means lack of necessity; nicht dürfen means prohibition.

Why: Modal verbs. [[German#^de-Q0312|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20kann%20an%20einem%20Tag%20gemacht%20werden.)
^de-Q0312-answer

**de-Q0313** — Sie kann Fragen stellen und beantworten.

She can ask and answer questions.

Expected form: **kann**

Why: Modal verbs. [[German#^de-Q0313|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20kann%20Fragen%20stellen%20und%20beantworten.)
^de-Q0313-answer

**de-Q0314** — Sie kann Fragen stellen und beantworten.

She can ask and answer questions.

Expected form: **kann**

Why: Modal verbs. [[German#^de-Q0314|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20kann%20Fragen%20stellen%20und%20beantworten.)
^de-Q0314-answer

**de-Q0315** — Kann ich spazieren gehen?

Can I go for a walk?

Expected form: **Kann**

Why: Modal verbs. [[German#^de-Q0315|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Kann%20ich%20spazieren%20gehen%3F)
^de-Q0315-answer

**de-Q0316** — Kann ich spazieren gehen?

Can I go for a walk?

Why: Modal verbs. [[German#^de-Q0316|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Kann%20ich%20spazieren%20gehen%3F)
^de-Q0316-answer

**de-Q0317** — Ich will nicht mit Tom Golf spielen.

I don't want to play golf with Tom.

Why: Modal verbs. [[German#^de-Q0317|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20will%20nicht%20mit%20Tom%20Golf%20spielen.)
^de-Q0317-answer

**de-Q0318** — Ich will nicht mit Tom Golf spielen.

I don't want to play golf with Tom.

Modals express ability, necessity, permission, reported obligation or intention. A following ordinary infinitive normally has no zu and goes late in the clause. Nicht müssen means lack of necessity; nicht dürfen means prohibition.

Why: Modal verbs. [[German#^de-Q0318|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20will%20nicht%20mit%20Tom%20Golf%20spielen.)
^de-Q0318-answer

**de-Q0319** — Er muss Toms Bruder sein.

He must be Tom's brother.

Expected form: **muss**

Why: Modal verbs. [[German#^de-Q0319|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20muss%20Toms%20Bruder%20sein.)
^de-Q0319-answer

**de-Q0320** — Er muss Toms Bruder sein.

He must be Tom's brother.

Expected form: **muss**

Why: Modal verbs. [[German#^de-Q0320|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20muss%20Toms%20Bruder%20sein.)
^de-Q0320-answer

**de-Q0321** — Metalle können bei tiefen Temperaturen spröde werden.

Metals can become brittle at low temperatures.

Expected form: **können**

Why: Modal verbs. [[German#^de-Q0321|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Metalle%20k%C3%B6nnen%20bei%20tiefen%20Temperaturen%20spr%C3%B6de%20werden.)
^de-Q0321-answer

**de-Q0322** — Metalle können bei tiefen Temperaturen spröde werden.

Metals can become brittle at low temperatures.

Why: Modal verbs. [[German#^de-Q0322|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Metalle%20k%C3%B6nnen%20bei%20tiefen%20Temperaturen%20spr%C3%B6de%20werden.)
^de-Q0322-answer

**de-Q0323** — Die Philippinerin wollte Englisch lernen, um eines Tages in den englischsprachigen Raum auswandern zu können.

The Filipino woman wanted to learn English so that one day she could emigrate to the Anglosphere.

Why: Modal verbs. [[German#^de-Q0323|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Philippinerin%20wollte%20Englisch%20lernen%2C%20um%20eines%20Tages%20in%20den%20englischsprachigen%20Raum%20auswandern%20zu%20k%C3%B6nnen.)
^de-Q0323-answer

**de-Q0324** — Die Philippinerin wollte Englisch lernen, um eines Tages in den englischsprachigen Raum auswandern zu können.

The Filipino woman wanted to learn English so that one day she could emigrate to the Anglosphere.

Modals express ability, necessity, permission, reported obligation or intention. A following ordinary infinitive normally has no zu and goes late in the clause. Nicht müssen means lack of necessity; nicht dürfen means prohibition.

Why: Modal verbs. [[German#^de-Q0324|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Philippinerin%20wollte%20Englisch%20lernen%2C%20um%20eines%20Tages%20in%20den%20englischsprachigen%20Raum%20auswandern%20zu%20k%C3%B6nnen.)
^de-Q0324-answer

**de-Q0325** — Sie hätten zum Meeting gehen sollen.

You should have attended the meeting.

Expected form: **sollen**

Why: Modal verbs. [[German#^de-Q0325|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20h%C3%A4tten%20zum%20Meeting%20gehen%20sollen.)
^de-Q0325-answer

**de-Q0326** — Sie hätten zum Meeting gehen sollen.

You should have attended the meeting.

Expected form: **sollen**

Why: Modal verbs. [[German#^de-Q0326|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20h%C3%A4tten%20zum%20Meeting%20gehen%20sollen.)
^de-Q0326-answer

**de-Q0327** — Wie sonst kann man das erklären?

How else can you account for it?

Expected form: **kann**

Why: Modal verbs. [[German#^de-Q0327|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20sonst%20kann%20man%20das%20erkl%C3%A4ren%3F)
^de-Q0327-answer

**de-Q0328** — Wie sonst kann man das erklären?

How else can you account for it?

Why: Modal verbs. [[German#^de-Q0328|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20sonst%20kann%20man%20das%20erkl%C3%A4ren%3F)
^de-Q0328-answer

**de-Q0329** — Bald kann ich Koreanisch.

Soon I'll be speaking Korean.

Why: Modal verbs. [[German#^de-Q0329|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Bald%20kann%20ich%20Koreanisch.)
^de-Q0329-answer

**de-Q0330** — Bald kann ich Koreanisch.

Soon I'll be speaking Korean.

Modals express ability, necessity, permission, reported obligation or intention. A following ordinary infinitive normally has no zu and goes late in the clause. Nicht müssen means lack of necessity; nicht dürfen means prohibition.

Why: Modal verbs. [[German#^de-Q0330|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Bald%20kann%20ich%20Koreanisch.)
^de-Q0330-answer

**de-Q0331** — Nichts ist unmöglich für den, der es nicht selbst machen muss.

Nothing is impossible for the man who doesn't have to do it himself.

Expected form: **muss**

Why: Modal verbs. [[German#^de-Q0331|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Nichts%20ist%20unm%C3%B6glich%20f%C3%BCr%20den%2C%20der%20es%20nicht%20selbst%20machen%20muss.)
^de-Q0331-answer

**de-Q0332** — Nichts ist unmöglich für den, der es nicht selbst machen muss.

Nothing is impossible for the man who doesn't have to do it himself.

Expected form: **muss**

Why: Modal verbs. [[German#^de-Q0332|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Nichts%20ist%20unm%C3%B6glich%20f%C3%BCr%20den%2C%20der%20es%20nicht%20selbst%20machen%20muss.)
^de-Q0332-answer

**de-Q0333** — Was man nicht weiß, kann einen nicht verletzen.

What you don't know can hurt you.

Expected form: **kann**

Why: Modal verbs. [[German#^de-Q0333|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Was%20man%20nicht%20wei%C3%9F%2C%20kann%20einen%20nicht%20verletzen.)
^de-Q0333-answer

**de-Q0334** — Was man nicht weiß, kann einen nicht verletzen.

What you don't know can hurt you.

Why: Modal verbs. [[German#^de-Q0334|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Was%20man%20nicht%20wei%C3%9F%2C%20kann%20einen%20nicht%20verletzen.)
^de-Q0334-answer

**de-Q0335** — Tom und Maria wollen es versuchen.

Tom and Mary are going to give it a try.

Why: Modal verbs. [[German#^de-Q0335|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20und%20Maria%20wollen%20es%20versuchen.)
^de-Q0335-answer

**de-Q0336** — Tom und Maria wollen es versuchen.

Tom and Mary are going to give it a try.

Modals express ability, necessity, permission, reported obligation or intention. A following ordinary infinitive normally has no zu and goes late in the clause. Nicht müssen means lack of necessity; nicht dürfen means prohibition.

Why: Modal verbs. [[German#^de-Q0336|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20und%20Maria%20wollen%20es%20versuchen.)
^de-Q0336-answer

**de-Q0337** — Man kann das Buch nur auf Deutsch bekommen.

The book is only available in German.

Expected form: **kann**

Why: Modal verbs. [[German#^de-Q0337|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Man%20kann%20das%20Buch%20nur%20auf%20Deutsch%20bekommen.)
^de-Q0337-answer

**de-Q0338** — Man kann das Buch nur auf Deutsch bekommen.

The book is only available in German.

Expected form: **kann**

Why: Modal verbs. [[German#^de-Q0338|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Man%20kann%20das%20Buch%20nur%20auf%20Deutsch%20bekommen.)
^de-Q0338-answer

**de-Q0339** — Wir müssen schnell machen.

We must move quickly.

Expected form: **müssen**

Why: Modal verbs. [[German#^de-Q0339|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20m%C3%BCssen%20schnell%20machen.)
^de-Q0339-answer

**de-Q0340** — Wir müssen schnell machen.

We must move quickly.

Why: Modal verbs. [[German#^de-Q0340|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20m%C3%BCssen%20schnell%20machen.)
^de-Q0340-answer

**de-Q0341** — Ich will kein Elektriker werden.

I don't want to become an electrician.

Why: Modal verbs. [[German#^de-Q0341|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20will%20kein%20Elektriker%20werden.)
^de-Q0341-answer

**de-Q0342** — Ich will kein Elektriker werden.

I don't want to become an electrician.

Modals express ability, necessity, permission, reported obligation or intention. A following ordinary infinitive normally has no zu and goes late in the clause. Nicht müssen means lack of necessity; nicht dürfen means prohibition.

Why: Modal verbs. [[German#^de-Q0342|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20will%20kein%20Elektriker%20werden.)
^de-Q0342-answer

**de-Q0343** — Nur sie kann den Computer benutzen.

Only she can use the computer.

Expected form: **kann**

Why: Modal verbs. [[German#^de-Q0343|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Nur%20sie%20kann%20den%20Computer%20benutzen.)
^de-Q0343-answer

**de-Q0344** — Nur sie kann den Computer benutzen.

Only she can use the computer.

Expected form: **kann**

Why: Modal verbs. [[German#^de-Q0344|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Nur%20sie%20kann%20den%20Computer%20benutzen.)
^de-Q0344-answer

**de-Q0345** — Chris konnte seine Traurigkeit nicht verbergen, als er hörte, dass Beth seine wertvolle Uhr nicht hatte finden können.

Chris could not conceal his sadness when he heard that Beth had been unable to find his valuable watch.

Expected form: **können**

Why: Modal verbs. [[German#^de-Q0345|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Chris%20konnte%20seine%20Traurigkeit%20nicht%20verbergen%2C%20als%20er%20h%C3%B6rte%2C%20dass%20Beth%20seine%20wertvolle%20Uhr%20nicht%20hatte%20finden%20k%C3%B6nnen.)
^de-Q0345-answer

**de-Q0346** — Chris konnte seine Traurigkeit nicht verbergen, als er hörte, dass Beth seine wertvolle Uhr nicht hatte finden können.

Chris could not conceal his sadness when he heard that Beth had been unable to find his valuable watch.

Why: Modal verbs. [[German#^de-Q0346|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Chris%20konnte%20seine%20Traurigkeit%20nicht%20verbergen%2C%20als%20er%20h%C3%B6rte%2C%20dass%20Beth%20seine%20wertvolle%20Uhr%20nicht%20hatte%20finden%20k%C3%B6nnen.)
^de-Q0346-answer

**de-Q0347** — Ich will so vielen Menschen wie möglich helfen.

I want to help as many people as I can.

Why: Modal verbs. [[German#^de-Q0347|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20will%20so%20vielen%20Menschen%20wie%20m%C3%B6glich%20helfen.)
^de-Q0347-answer

**de-Q0348** — Ich will so vielen Menschen wie möglich helfen.

I want to help as many people as I can.

Modals express ability, necessity, permission, reported obligation or intention. A following ordinary infinitive normally has no zu and goes late in the clause. Nicht müssen means lack of necessity; nicht dürfen means prohibition.

Why: Modal verbs. [[German#^de-Q0348|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20will%20so%20vielen%20Menschen%20wie%20m%C3%B6glich%20helfen.)
^de-Q0348-answer

**de-Q0349** — Sie müssen nur jeden Tag üben.

You have only to practice every day.

Expected form: **müssen**

Why: Modal verbs. [[German#^de-Q0349|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20m%C3%BCssen%20nur%20jeden%20Tag%20%C3%BCben.)
^de-Q0349-answer

**de-Q0350** — Sie müssen nur jeden Tag üben.

You have only to practice every day.

Expected form: **müssen**

Why: Modal verbs. [[German#^de-Q0350|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20m%C3%BCssen%20nur%20jeden%20Tag%20%C3%BCben.)
^de-Q0350-answer


### Answers 351–400

**de-Q0351** — Tom konnte sich nicht vorstellen, jemanden zu erschießen.

Tom couldn't imagine himself shooting anyone.

Expected form: **nicht**

Why: Negation with nicht and kein. [[German#^de-Q0351|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20konnte%20sich%20nicht%20vorstellen%2C%20jemanden%20zu%20erschie%C3%9Fen.)
^de-Q0351-answer

**de-Q0352** — Tom konnte sich nicht vorstellen, jemanden zu erschießen.

Tom couldn't imagine himself shooting anyone.

Why: Negation with nicht and kein. [[German#^de-Q0352|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20konnte%20sich%20nicht%20vorstellen%2C%20jemanden%20zu%20erschie%C3%9Fen.)
^de-Q0352-answer

**de-Q0353** — Tom konnte nicht alle Fragen Marias beantworten.

Tom couldn't answer all of Mary's questions.

Why: Negation with nicht and kein. [[German#^de-Q0353|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20konnte%20nicht%20alle%20Fragen%20Marias%20beantworten.)
^de-Q0353-answer

**de-Q0354** — Tom konnte nicht alle Fragen Marias beantworten.

Tom couldn't answer all of Mary's questions.

Kein negates many indefinite noun phrases; nicht negates a predicate or another constituent. Placement controls scope. Compare Ich kaufe kein Buch with Ich kaufe das Buch nicht.

Why: Negation with nicht and kein. [[German#^de-Q0354|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20konnte%20nicht%20alle%20Fragen%20Marias%20beantworten.)
^de-Q0354-answer

**de-Q0355** — Dafür bezahle ich nicht!

I won't pay for that.

Expected form: **nicht**

Why: Negation with nicht and kein. [[German#^de-Q0355|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Daf%C3%BCr%20bezahle%20ich%20nicht%21)
^de-Q0355-answer

**de-Q0356** — Dafür bezahle ich nicht!

I won't pay for that.

Expected form: **nicht**

Why: Negation with nicht and kein. [[German#^de-Q0356|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Daf%C3%BCr%20bezahle%20ich%20nicht%21)
^de-Q0356-answer

**de-Q0357** — Tom sagte, das sei bei weitem nicht gut genug.

Tom said that's far from good enough.

Expected form: **nicht**

Why: Negation with nicht and kein. [[German#^de-Q0357|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20sagte%2C%20das%20sei%20bei%20weitem%20nicht%20gut%20genug.)
^de-Q0357-answer

**de-Q0358** — Tom sagte, das sei bei weitem nicht gut genug.

Tom said that's far from good enough.

Why: Negation with nicht and kein. [[German#^de-Q0358|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20sagte%2C%20das%20sei%20bei%20weitem%20nicht%20gut%20genug.)
^de-Q0358-answer

**de-Q0359** — Manchmal reicht das einfach nicht.

Sometimes that just isn't enough.

Why: Negation with nicht and kein. [[German#^de-Q0359|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Manchmal%20reicht%20das%20einfach%20nicht.)
^de-Q0359-answer

**de-Q0360** — Manchmal reicht das einfach nicht.

Sometimes that just isn't enough.

Kein negates many indefinite noun phrases; nicht negates a predicate or another constituent. Placement controls scope. Compare Ich kaufe kein Buch with Ich kaufe das Buch nicht.

Why: Negation with nicht and kein. [[German#^de-Q0360|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Manchmal%20reicht%20das%20einfach%20nicht.)
^de-Q0360-answer

**de-Q0361** — Maria setzte Tom davon in Kenntnis, dass sie nicht wusste, wie das ging.

Mary let Tom know she didn't know how to do that.

Expected form: **nicht**

Why: Negation with nicht and kein. [[German#^de-Q0361|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Maria%20setzte%20Tom%20davon%20in%20Kenntnis%2C%20dass%20sie%20nicht%20wusste%2C%20wie%20das%20ging.)
^de-Q0361-answer

**de-Q0362** — Maria setzte Tom davon in Kenntnis, dass sie nicht wusste, wie das ging.

Mary let Tom know she didn't know how to do that.

Expected form: **nicht**

Why: Negation with nicht and kein. [[German#^de-Q0362|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Maria%20setzte%20Tom%20davon%20in%20Kenntnis%2C%20dass%20sie%20nicht%20wusste%2C%20wie%20das%20ging.)
^de-Q0362-answer

**de-Q0363** — So etwas Banales kommt gar nicht in Frage.

Such a trivial thing is out of the question.

Expected form: **nicht**

Why: Negation with nicht and kein. [[German#^de-Q0363|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=So%20etwas%20Banales%20kommt%20gar%20nicht%20in%20Frage.)
^de-Q0363-answer

**de-Q0364** — So etwas Banales kommt gar nicht in Frage.

Such a trivial thing is out of the question.

Why: Negation with nicht and kein. [[German#^de-Q0364|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=So%20etwas%20Banales%20kommt%20gar%20nicht%20in%20Frage.)
^de-Q0364-answer

**de-Q0365** — Ihr wisst es eigentlich gar nicht, oder?

You don't really know, do you?

Why: Negation with nicht and kein. [[German#^de-Q0365|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ihr%20wisst%20es%20eigentlich%20gar%20nicht%2C%20oder%3F)
^de-Q0365-answer

**de-Q0366** — Ihr wisst es eigentlich gar nicht, oder?

You don't really know, do you?

Kein negates many indefinite noun phrases; nicht negates a predicate or another constituent. Placement controls scope. Compare Ich kaufe kein Buch with Ich kaufe das Buch nicht.

Why: Negation with nicht and kein. [[German#^de-Q0366|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ihr%20wisst%20es%20eigentlich%20gar%20nicht%2C%20oder%3F)
^de-Q0366-answer

**de-Q0367** — Bist du sicher, dass du kein Übersetzungsprogramm verwendest?

Are you sure you don't use machine translations?

Expected form: **kein**

Why: Negation with nicht and kein. [[German#^de-Q0367|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Bist%20du%20sicher%2C%20dass%20du%20kein%20%C3%9Cbersetzungsprogramm%20verwendest%3F)
^de-Q0367-answer

**de-Q0368** — Bist du sicher, dass du kein Übersetzungsprogramm verwendest?

Are you sure you don't use machine translations?

Expected form: **kein**

Why: Negation with nicht and kein. [[German#^de-Q0368|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Bist%20du%20sicher%2C%20dass%20du%20kein%20%C3%9Cbersetzungsprogramm%20verwendest%3F)
^de-Q0368-answer

**de-Q0369** — Tom sagte, er fand es nicht lustig.

Tom said he didn't find it funny.

Expected form: **nicht**

Why: Negation with nicht and kein. [[German#^de-Q0369|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20sagte%2C%20er%20fand%20es%20nicht%20lustig.)
^de-Q0369-answer

**de-Q0370** — Tom sagte, er fand es nicht lustig.

Tom said he didn't find it funny.

Why: Negation with nicht and kein. [[German#^de-Q0370|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20sagte%2C%20er%20fand%20es%20nicht%20lustig.)
^de-Q0370-answer

**de-Q0371** — Schade, dass du nicht kommen kannst!

What a pity it is that you can't come!

Why: Negation with nicht and kein. [[German#^de-Q0371|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Schade%2C%20dass%20du%20nicht%20kommen%20kannst%21)
^de-Q0371-answer

**de-Q0372** — Schade, dass du nicht kommen kannst!

What a pity it is that you can't come!

Kein negates many indefinite noun phrases; nicht negates a predicate or another constituent. Placement controls scope. Compare Ich kaufe kein Buch with Ich kaufe das Buch nicht.

Why: Negation with nicht and kein. [[German#^de-Q0372|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Schade%2C%20dass%20du%20nicht%20kommen%20kannst%21)
^de-Q0372-answer

**de-Q0373** — Es ist nicht immer so leicht, das Richtige zu tun.

It's not always so easy to do the right thing.

Expected form: **nicht**

Why: Negation with nicht and kein. [[German#^de-Q0373|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20ist%20nicht%20immer%20so%20leicht%2C%20das%20Richtige%20zu%20tun.)
^de-Q0373-answer

**de-Q0374** — Es ist nicht immer so leicht, das Richtige zu tun.

It's not always so easy to do the right thing.

Expected form: **nicht**

Why: Negation with nicht and kein. [[German#^de-Q0374|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20ist%20nicht%20immer%20so%20leicht%2C%20das%20Richtige%20zu%20tun.)
^de-Q0374-answer

**de-Q0375** — Dieser Zug hält hier nicht.

That train doesn't stop here.

Expected form: **nicht**

Why: Negation with nicht and kein. [[German#^de-Q0375|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Dieser%20Zug%20h%C3%A4lt%20hier%20nicht.)
^de-Q0375-answer

**de-Q0376** — Dieser Zug hält hier nicht.

That train doesn't stop here.

Why: Negation with nicht and kein. [[German#^de-Q0376|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Dieser%20Zug%20h%C3%A4lt%20hier%20nicht.)
^de-Q0376-answer

**de-Q0377** — Ich sehe kein Problem dabei.

I don't see a problem with it.

Why: Negation with nicht and kein. [[German#^de-Q0377|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20sehe%20kein%20Problem%20dabei.)
^de-Q0377-answer

**de-Q0378** — Ich sehe kein Problem dabei.

I don't see a problem with it.

Kein negates many indefinite noun phrases; nicht negates a predicate or another constituent. Placement controls scope. Compare Ich kaufe kein Buch with Ich kaufe das Buch nicht.

Why: Negation with nicht and kein. [[German#^de-Q0378|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20sehe%20kein%20Problem%20dabei.)
^de-Q0378-answer

**de-Q0379** — Ihr braucht nicht zu warten.

You don't need to wait.

Expected form: **nicht**

Why: Negation with nicht and kein. [[German#^de-Q0379|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ihr%20braucht%20nicht%20zu%20warten.)
^de-Q0379-answer

**de-Q0380** — Ihr braucht nicht zu warten.

You don't need to wait.

Expected form: **nicht**

Why: Negation with nicht and kein. [[German#^de-Q0380|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ihr%20braucht%20nicht%20zu%20warten.)
^de-Q0380-answer

**de-Q0381** — Tom sagte, er macht es nicht.

Tom said he's not doing it.

Expected form: **nicht**

Why: Negation with nicht and kein. [[German#^de-Q0381|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20sagte%2C%20er%20macht%20es%20nicht.)
^de-Q0381-answer

**de-Q0382** — Tom sagte, er macht es nicht.

Tom said he's not doing it.

Why: Negation with nicht and kein. [[German#^de-Q0382|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20sagte%2C%20er%20macht%20es%20nicht.)
^de-Q0382-answer

**de-Q0383** — Du kannst alle anderen, nicht aber dich selbst belügen.

You can lie to everyone else, but you can't lie to yourself.

Why: Negation with nicht and kein. [[German#^de-Q0383|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Du%20kannst%20alle%20anderen%2C%20nicht%20aber%20dich%20selbst%20bel%C3%BCgen.)
^de-Q0383-answer

**de-Q0384** — Du kannst alle anderen, nicht aber dich selbst belügen.

You can lie to everyone else, but you can't lie to yourself.

Kein negates many indefinite noun phrases; nicht negates a predicate or another constituent. Placement controls scope. Compare Ich kaufe kein Buch with Ich kaufe das Buch nicht.

Why: Negation with nicht and kein. [[German#^de-Q0384|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Du%20kannst%20alle%20anderen%2C%20nicht%20aber%20dich%20selbst%20bel%C3%BCgen.)
^de-Q0384-answer

**de-Q0385** — Entweder gehen wir alle, oder es geht keiner.

Either we all go or nobody goes.

Expected form: **keiner**

Why: Negation with nicht and kein. [[German#^de-Q0385|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Entweder%20gehen%20wir%20alle%2C%20oder%20es%20geht%20keiner.)
^de-Q0385-answer

**de-Q0386** — Entweder gehen wir alle, oder es geht keiner.

Either we all go or nobody goes.

Expected form: **keiner**

Why: Negation with nicht and kein. [[German#^de-Q0386|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Entweder%20gehen%20wir%20alle%2C%20oder%20es%20geht%20keiner.)
^de-Q0386-answer

**de-Q0387** — Ich verstehe nicht immer, was du schreibst.

I can't always understand what you write.

Expected form: **nicht**

Why: Negation with nicht and kein. [[German#^de-Q0387|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20verstehe%20nicht%20immer%2C%20was%20du%20schreibst.)
^de-Q0387-answer

**de-Q0388** — Ich verstehe nicht immer, was du schreibst.

I can't always understand what you write.

Why: Negation with nicht and kein. [[German#^de-Q0388|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20verstehe%20nicht%20immer%2C%20was%20du%20schreibst.)
^de-Q0388-answer

**de-Q0389** — Ehrlich gesprochen, glaube ich nicht, dass Sie das Zeug zur Lehrerin haben.

Frankly speaking, I don't think you have what it takes to become a teacher.

Why: Negation with nicht and kein. [[German#^de-Q0389|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ehrlich%20gesprochen%2C%20glaube%20ich%20nicht%2C%20dass%20Sie%20das%20Zeug%20zur%20Lehrerin%20haben.)
^de-Q0389-answer

**de-Q0390** — Ehrlich gesprochen, glaube ich nicht, dass Sie das Zeug zur Lehrerin haben.

Frankly speaking, I don't think you have what it takes to become a teacher.

Kein negates many indefinite noun phrases; nicht negates a predicate or another constituent. Placement controls scope. Compare Ich kaufe kein Buch with Ich kaufe das Buch nicht.

Why: Negation with nicht and kein. [[German#^de-Q0390|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ehrlich%20gesprochen%2C%20glaube%20ich%20nicht%2C%20dass%20Sie%20das%20Zeug%20zur%20Lehrerin%20haben.)
^de-Q0390-answer

**de-Q0391** — Sie brauchen nicht sarkastisch zu werden.

You don't have to be sarcastic.

Expected form: **nicht**

Why: Negation with nicht and kein. [[German#^de-Q0391|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20brauchen%20nicht%20sarkastisch%20zu%20werden.)
^de-Q0391-answer

**de-Q0392** — Sie brauchen nicht sarkastisch zu werden.

You don't have to be sarcastic.

Expected form: **nicht**

Why: Negation with nicht and kein. [[German#^de-Q0392|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20brauchen%20nicht%20sarkastisch%20zu%20werden.)
^de-Q0392-answer

**de-Q0393** — Sie haben Herrn Schmidt bereits getroffen, nicht wahr?

You've met Mr. Smith already, haven't you?

Expected form: **nicht**

Why: Negation with nicht and kein. [[German#^de-Q0393|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20haben%20Herrn%20Schmidt%20bereits%20getroffen%2C%20nicht%20wahr%3F)
^de-Q0393-answer

**de-Q0394** — Sie haben Herrn Schmidt bereits getroffen, nicht wahr?

You've met Mr. Smith already, haven't you?

Why: Negation with nicht and kein. [[German#^de-Q0394|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20haben%20Herrn%20Schmidt%20bereits%20getroffen%2C%20nicht%20wahr%3F)
^de-Q0394-answer

**de-Q0395** — Wenn es nicht so läuft, wie er sich das vorgestellt hat, so schmollt er.

When he doesn't get his way, he sulks.

Why: Negation with nicht and kein. [[German#^de-Q0395|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wenn%20es%20nicht%20so%20l%C3%A4uft%2C%20wie%20er%20sich%20das%20vorgestellt%20hat%2C%20so%20schmollt%20er.)
^de-Q0395-answer

**de-Q0396** — Wenn es nicht so läuft, wie er sich das vorgestellt hat, so schmollt er.

When he doesn't get his way, he sulks.

Kein negates many indefinite noun phrases; nicht negates a predicate or another constituent. Placement controls scope. Compare Ich kaufe kein Buch with Ich kaufe das Buch nicht.

Why: Negation with nicht and kein. [[German#^de-Q0396|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wenn%20es%20nicht%20so%20l%C3%A4uft%2C%20wie%20er%20sich%20das%20vorgestellt%20hat%2C%20so%20schmollt%20er.)
^de-Q0396-answer

**de-Q0397** — Seid nicht so bescheiden!

Don't be so modest.

Expected form: **nicht**

Why: Negation with nicht and kein. [[German#^de-Q0397|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Seid%20nicht%20so%20bescheiden%21)
^de-Q0397-answer

**de-Q0398** — Seid nicht so bescheiden!

Don't be so modest.

Expected form: **nicht**

Why: Negation with nicht and kein. [[German#^de-Q0398|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Seid%20nicht%20so%20bescheiden%21)
^de-Q0398-answer

**de-Q0399** — Elke hatte keine Ahnung, dass Tom bereits mit Elke verheiratet war.

Alice had no idea that Tom was already married to Mary.

Expected form: **keine**

Why: Negation with nicht and kein. [[German#^de-Q0399|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Elke%20hatte%20keine%20Ahnung%2C%20dass%20Tom%20bereits%20mit%20Elke%20verheiratet%20war.)
^de-Q0399-answer

**de-Q0400** — Elke hatte keine Ahnung, dass Tom bereits mit Elke verheiratet war.

Alice had no idea that Tom was already married to Mary.

Why: Negation with nicht and kein. [[German#^de-Q0400|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Elke%20hatte%20keine%20Ahnung%2C%20dass%20Tom%20bereits%20mit%20Elke%20verheiratet%20war.)
^de-Q0400-answer


### Answers 401–450

**de-Q0401** — Du wusstest, dass da passieren wird, stimmt's?

You knew this was going to happen, right?

Why: Subordinate clause connectors. [[German#^de-Q0401|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Du%20wusstest%2C%20dass%20da%20passieren%20wird%2C%20stimmt%27s%3F)
^de-Q0401-answer

**de-Q0402** — Du wusstest, dass da passieren wird, stimmt's?

You knew this was going to happen, right?

A subordinating connector introduces a clause whose finite verb normally comes at the end. Ob introduces an indirect yes/no question. Wenn and als differ in temporal uses; als normally locates a single past occasion.

Why: Subordinate clause connectors. [[German#^de-Q0402|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Du%20wusstest%2C%20dass%20da%20passieren%20wird%2C%20stimmt%27s%3F)
^de-Q0402-answer

**de-Q0403** — Tom kam gerade, als ich ging.

Tom came just as I was leaving.

Expected form: **als**

Why: Subordinate clause connectors. [[German#^de-Q0403|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20kam%20gerade%2C%20als%20ich%20ging.)
^de-Q0403-answer

**de-Q0404** — Tom kam gerade, als ich ging.

Tom came just as I was leaving.

Expected form: **als**

Why: Subordinate clause connectors. [[German#^de-Q0404|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20kam%20gerade%2C%20als%20ich%20ging.)
^de-Q0404-answer

**de-Q0405** — Die Nachricht erwies sich als falsch.

The news turned out false.

Expected form: **als**

Why: Subordinate clause connectors. [[German#^de-Q0405|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Nachricht%20erwies%20sich%20als%20falsch.)
^de-Q0405-answer

**de-Q0406** — Die Nachricht erwies sich als falsch.

The news turned out false.

Why: Subordinate clause connectors. [[German#^de-Q0406|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Nachricht%20erwies%20sich%20als%20falsch.)
^de-Q0406-answer

**de-Q0407** — Sie waren so beschäftigt, dass sie vergaßen, wie spät es war.

They were so busy they didn't realize what time it was.

Why: Subordinate clause connectors. [[German#^de-Q0407|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20waren%20so%20besch%C3%A4ftigt%2C%20dass%20sie%20verga%C3%9Fen%2C%20wie%20sp%C3%A4t%20es%20war.)
^de-Q0407-answer

**de-Q0408** — Sie waren so beschäftigt, dass sie vergaßen, wie spät es war.

They were so busy they didn't realize what time it was.

A subordinating connector introduces a clause whose finite verb normally comes at the end. Ob introduces an indirect yes/no question. Wenn and als differ in temporal uses; als normally locates a single past occasion.

Why: Subordinate clause connectors. [[German#^de-Q0408|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20waren%20so%20besch%C3%A4ftigt%2C%20dass%20sie%20verga%C3%9Fen%2C%20wie%20sp%C3%A4t%20es%20war.)
^de-Q0408-answer

**de-Q0409** — Tom bemerkte, dass Maria schlief.

Tom noticed that Mary was asleep.

Expected form: **dass**

Why: Subordinate clause connectors. [[German#^de-Q0409|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20bemerkte%2C%20dass%20Maria%20schlief.)
^de-Q0409-answer

**de-Q0410** — Tom bemerkte, dass Maria schlief.

Tom noticed that Mary was asleep.

Expected form: **dass**

Why: Subordinate clause connectors. [[German#^de-Q0410|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20bemerkte%2C%20dass%20Maria%20schlief.)
^de-Q0410-answer

**de-Q0411** — Tom sagte Maria, dass er glaube, was John sagte.

Tom told Mary that he believed what John said.

Expected form: **dass**

Why: Subordinate clause connectors. [[German#^de-Q0411|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20sagte%20Maria%2C%20dass%20er%20glaube%2C%20was%20John%20sagte.)
^de-Q0411-answer

**de-Q0412** — Tom sagte Maria, dass er glaube, was John sagte.

Tom told Mary that he believed what John said.

Why: Subordinate clause connectors. [[German#^de-Q0412|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20sagte%20Maria%2C%20dass%20er%20glaube%2C%20was%20John%20sagte.)
^de-Q0412-answer

**de-Q0413** — Ihr wurde bewusst, dass ihre Eltern sie beobachteten.

She became aware that her parents were watching her.

Why: Subordinate clause connectors. [[German#^de-Q0413|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ihr%20wurde%20bewusst%2C%20dass%20ihre%20Eltern%20sie%20beobachteten.)
^de-Q0413-answer

**de-Q0414** — Ihr wurde bewusst, dass ihre Eltern sie beobachteten.

She became aware that her parents were watching her.

A subordinating connector introduces a clause whose finite verb normally comes at the end. Ob introduces an indirect yes/no question. Wenn and als differ in temporal uses; als normally locates a single past occasion.

Why: Subordinate clause connectors. [[German#^de-Q0414|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ihr%20wurde%20bewusst%2C%20dass%20ihre%20Eltern%20sie%20beobachteten.)
^de-Q0414-answer

**de-Q0415** — Als sie das Klopfen hörte, dachte sie schon, ihre Eltern seien angekommen.

As she heard the knocking she thought her parents were coming home.

Expected form: **Als**

Why: Subordinate clause connectors. [[German#^de-Q0415|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Als%20sie%20das%20Klopfen%20h%C3%B6rte%2C%20dachte%20sie%20schon%2C%20ihre%20Eltern%20seien%20angekommen.)
^de-Q0415-answer

**de-Q0416** — Als sie das Klopfen hörte, dachte sie schon, ihre Eltern seien angekommen.

As she heard the knocking she thought her parents were coming home.

Expected form: **Als**

Why: Subordinate clause connectors. [[German#^de-Q0416|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Als%20sie%20das%20Klopfen%20h%C3%B6rte%2C%20dachte%20sie%20schon%2C%20ihre%20Eltern%20seien%20angekommen.)
^de-Q0416-answer

**de-Q0417** — Das ist das erste Mal, dass ich mein Auto im Wald parke.

This is the first time I've ever parked my car in the woods.

Expected form: **dass**

Why: Subordinate clause connectors. [[German#^de-Q0417|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20ist%20das%20erste%20Mal%2C%20dass%20ich%20mein%20Auto%20im%20Wald%20parke.)
^de-Q0417-answer

**de-Q0418** — Das ist das erste Mal, dass ich mein Auto im Wald parke.

This is the first time I've ever parked my car in the woods.

Why: Subordinate clause connectors. [[German#^de-Q0418|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20ist%20das%20erste%20Mal%2C%20dass%20ich%20mein%20Auto%20im%20Wald%20parke.)
^de-Q0418-answer

**de-Q0419** — Stimmt es, dass in dieser Gegend niemand wohnt?

Is it true that nobody lives around here?

Why: Subordinate clause connectors. [[German#^de-Q0419|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Stimmt%20es%2C%20dass%20in%20dieser%20Gegend%20niemand%20wohnt%3F)
^de-Q0419-answer

**de-Q0420** — Stimmt es, dass in dieser Gegend niemand wohnt?

Is it true that nobody lives around here?

A subordinating connector introduces a clause whose finite verb normally comes at the end. Ob introduces an indirect yes/no question. Wenn and als differ in temporal uses; als normally locates a single past occasion.

Why: Subordinate clause connectors. [[German#^de-Q0420|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Stimmt%20es%2C%20dass%20in%20dieser%20Gegend%20niemand%20wohnt%3F)
^de-Q0420-answer

**de-Q0421** — Tom weiß, dass wir hier sind.

Tom knows we're here.

Expected form: **dass**

Why: Subordinate clause connectors. [[German#^de-Q0421|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20wei%C3%9F%2C%20dass%20wir%20hier%20sind.)
^de-Q0421-answer

**de-Q0422** — Tom weiß, dass wir hier sind.

Tom knows we're here.

Expected form: **dass**

Why: Subordinate clause connectors. [[German#^de-Q0422|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20wei%C3%9F%2C%20dass%20wir%20hier%20sind.)
^de-Q0422-answer

**de-Q0423** — Wenn ihr wissen wollt, woher der Wind weht, braucht ihr nur nach der Windhose zu schauen.

If you want to know which direction the wind is blowing, just look at the windsock.

Expected form: **Wenn**

Why: Subordinate clause connectors. [[German#^de-Q0423|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wenn%20ihr%20wissen%20wollt%2C%20woher%20der%20Wind%20weht%2C%20braucht%20ihr%20nur%20nach%20der%20Windhose%20zu%20schauen.)
^de-Q0423-answer

**de-Q0424** — Wenn ihr wissen wollt, woher der Wind weht, braucht ihr nur nach der Windhose zu schauen.

If you want to know which direction the wind is blowing, just look at the windsock.

Why: Subordinate clause connectors. [[German#^de-Q0424|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wenn%20ihr%20wissen%20wollt%2C%20woher%20der%20Wind%20weht%2C%20braucht%20ihr%20nur%20nach%20der%20Windhose%20zu%20schauen.)
^de-Q0424-answer

**de-Q0425** — Ihr werdet mir sehr fehlen, wenn ihr geht.

I'll miss you very much if you go.

Why: Subordinate clause connectors. [[German#^de-Q0425|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ihr%20werdet%20mir%20sehr%20fehlen%2C%20wenn%20ihr%20geht.)
^de-Q0425-answer

**de-Q0426** — Ihr werdet mir sehr fehlen, wenn ihr geht.

I'll miss you very much if you go.

A subordinating connector introduces a clause whose finite verb normally comes at the end. Ob introduces an indirect yes/no question. Wenn and als differ in temporal uses; als normally locates a single past occasion.

Why: Subordinate clause connectors. [[German#^de-Q0426|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ihr%20werdet%20mir%20sehr%20fehlen%2C%20wenn%20ihr%20geht.)
^de-Q0426-answer

**de-Q0427** — Du darfst erst gehen, wenn wir dir das sagen.

You can't leave until we say you can leave.

Expected form: **wenn**

Why: Subordinate clause connectors. [[German#^de-Q0427|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Du%20darfst%20erst%20gehen%2C%20wenn%20wir%20dir%20das%20sagen.)
^de-Q0427-answer

**de-Q0428** — Du darfst erst gehen, wenn wir dir das sagen.

You can't leave until we say you can leave.

Expected form: **wenn**

Why: Subordinate clause connectors. [[German#^de-Q0428|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Du%20darfst%20erst%20gehen%2C%20wenn%20wir%20dir%20das%20sagen.)
^de-Q0428-answer

**de-Q0429** — Es ist gut, dass ich hierher gekommen bin.

It's a good thing I came here.

Expected form: **dass**

Why: Subordinate clause connectors. [[German#^de-Q0429|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20ist%20gut%2C%20dass%20ich%20hierher%20gekommen%20bin.)
^de-Q0429-answer

**de-Q0430** — Es ist gut, dass ich hierher gekommen bin.

It's a good thing I came here.

Why: Subordinate clause connectors. [[German#^de-Q0430|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20ist%20gut%2C%20dass%20ich%20hierher%20gekommen%20bin.)
^de-Q0430-answer

**de-Q0431** — Tom fragte Maria, ob sie das allein tun wolle.

Tom asked Mary if she wanted to do that by herself.

Why: Subordinate clause connectors. [[German#^de-Q0431|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20fragte%20Maria%2C%20ob%20sie%20das%20allein%20tun%20wolle.)
^de-Q0431-answer

**de-Q0432** — Tom fragte Maria, ob sie das allein tun wolle.

Tom asked Mary if she wanted to do that by herself.

A subordinating connector introduces a clause whose finite verb normally comes at the end. Ob introduces an indirect yes/no question. Wenn and als differ in temporal uses; als normally locates a single past occasion.

Why: Subordinate clause connectors. [[German#^de-Q0432|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20fragte%20Maria%2C%20ob%20sie%20das%20allein%20tun%20wolle.)
^de-Q0432-answer

**de-Q0433** — Das war das letzte Mal, dass einer von uns Tom je gesehen hat.

That was the last time any of us ever saw Tom.

Expected form: **dass**

Why: Subordinate clause connectors. [[German#^de-Q0433|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20war%20das%20letzte%20Mal%2C%20dass%20einer%20von%20uns%20Tom%20je%20gesehen%20hat.)
^de-Q0433-answer

**de-Q0434** — Das war das letzte Mal, dass einer von uns Tom je gesehen hat.

That was the last time any of us ever saw Tom.

Expected form: **dass**

Why: Subordinate clause connectors. [[German#^de-Q0434|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20war%20das%20letzte%20Mal%2C%20dass%20einer%20von%20uns%20Tom%20je%20gesehen%20hat.)
^de-Q0434-answer

**de-Q0435** — Sie sprach, als ob sie meine Mutter wäre.

She talked as if she were my mother.

Expected form: **als**

Why: Subordinate clause connectors. [[German#^de-Q0435|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20sprach%2C%20als%20ob%20sie%20meine%20Mutter%20w%C3%A4re.)
^de-Q0435-answer

**de-Q0436** — Sie sprach, als ob sie meine Mutter wäre.

She talked as if she were my mother.

Why: Subordinate clause connectors. [[German#^de-Q0436|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20sprach%2C%20als%20ob%20sie%20meine%20Mutter%20w%C3%A4re.)
^de-Q0436-answer

**de-Q0437** — Ich gehe davon aus, dass Tom gewinnen wird.

I expect Tom will win.

Why: Subordinate clause connectors. [[German#^de-Q0437|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20gehe%20davon%20aus%2C%20dass%20Tom%20gewinnen%20wird.)
^de-Q0437-answer

**de-Q0438** — Ich gehe davon aus, dass Tom gewinnen wird.

I expect Tom will win.

A subordinating connector introduces a clause whose finite verb normally comes at the end. Ob introduces an indirect yes/no question. Wenn and als differ in temporal uses; als normally locates a single past occasion.

Why: Subordinate clause connectors. [[German#^de-Q0438|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20gehe%20davon%20aus%2C%20dass%20Tom%20gewinnen%20wird.)
^de-Q0438-answer

**de-Q0439** — Ich bin froh, dass Tom und Maria sich dazu bereit erklärt haben.

I'm glad Tom and Mary have agreed to do that.

Expected form: **dass**

Why: Subordinate clause connectors. [[German#^de-Q0439|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20bin%20froh%2C%20dass%20Tom%20und%20Maria%20sich%20dazu%20bereit%20erkl%C3%A4rt%20haben.)
^de-Q0439-answer

**de-Q0440** — Ich bin froh, dass Tom und Maria sich dazu bereit erklärt haben.

I'm glad Tom and Mary have agreed to do that.

Expected form: **dass**

Why: Subordinate clause connectors. [[German#^de-Q0440|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20bin%20froh%2C%20dass%20Tom%20und%20Maria%20sich%20dazu%20bereit%20erkl%C3%A4rt%20haben.)
^de-Q0440-answer

**de-Q0441** — Es gibt nichts Schöneres als die Liebe.

There is nothing more beautiful than love.

Expected form: **als**

Why: Subordinate clause connectors. [[German#^de-Q0441|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20gibt%20nichts%20Sch%C3%B6neres%20als%20die%20Liebe.)
^de-Q0441-answer

**de-Q0442** — Es gibt nichts Schöneres als die Liebe.

There is nothing more beautiful than love.

Why: Subordinate clause connectors. [[German#^de-Q0442|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20gibt%20nichts%20Sch%C3%B6neres%20als%20die%20Liebe.)
^de-Q0442-answer

**de-Q0443** — Ich weiß, dass das schwer hinzunehmen ist.

I know this is difficult to accept.

Why: Subordinate clause connectors. [[German#^de-Q0443|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20wei%C3%9F%2C%20dass%20das%20schwer%20hinzunehmen%20ist.)
^de-Q0443-answer

**de-Q0444** — Ich weiß, dass das schwer hinzunehmen ist.

I know this is difficult to accept.

A subordinating connector introduces a clause whose finite verb normally comes at the end. Ob introduces an indirect yes/no question. Wenn and als differ in temporal uses; als normally locates a single past occasion.

Why: Subordinate clause connectors. [[German#^de-Q0444|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20wei%C3%9F%2C%20dass%20das%20schwer%20hinzunehmen%20ist.)
^de-Q0444-answer

**de-Q0445** — Er verdient sich seinen Lebensunterhalt als Lehrer.

He earns his living by teaching.

Expected form: **als**

Why: Subordinate clause connectors. [[German#^de-Q0445|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20verdient%20sich%20seinen%20Lebensunterhalt%20als%20Lehrer.)
^de-Q0445-answer

**de-Q0446** — Er verdient sich seinen Lebensunterhalt als Lehrer.

He earns his living by teaching.

Expected form: **als**

Why: Subordinate clause connectors. [[German#^de-Q0446|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20verdient%20sich%20seinen%20Lebensunterhalt%20als%20Lehrer.)
^de-Q0446-answer

**de-Q0447** — Wenn ihr in Narita landet, wird es bereits dunkel sein.

By the time you land at Narita, it will be dark.

Expected form: **Wenn**

Why: Subordinate clause connectors. [[German#^de-Q0447|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wenn%20ihr%20in%20Narita%20landet%2C%20wird%20es%20bereits%20dunkel%20sein.)
^de-Q0447-answer

**de-Q0448** — Wenn ihr in Narita landet, wird es bereits dunkel sein.

By the time you land at Narita, it will be dark.

Why: Subordinate clause connectors. [[German#^de-Q0448|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wenn%20ihr%20in%20Narita%20landet%2C%20wird%20es%20bereits%20dunkel%20sein.)
^de-Q0448-answer

**de-Q0449** — Ich mache oft Sachen kaputt, wenn ich wütend bin.

I often break things when I'm angry.

Why: Subordinate clause connectors. [[German#^de-Q0449|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20mache%20oft%20Sachen%20kaputt%2C%20wenn%20ich%20w%C3%BCtend%20bin.)
^de-Q0449-answer

**de-Q0450** — Ich mache oft Sachen kaputt, wenn ich wütend bin.

I often break things when I'm angry.

A subordinating connector introduces a clause whose finite verb normally comes at the end. Ob introduces an indirect yes/no question. Wenn and als differ in temporal uses; als normally locates a single past occasion.

Why: Subordinate clause connectors. [[German#^de-Q0450|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20mache%20oft%20Sachen%20kaputt%2C%20wenn%20ich%20w%C3%BCtend%20bin.)
^de-Q0450-answer


### Answers 451–500

**de-Q0451** — Tom und Maria liefen ins Wasser.

Tom and Mary ran into the water.

Expected form: **und**

Why: Coordinating connectors. [[German#^de-Q0451|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20und%20Maria%20liefen%20ins%20Wasser.)
^de-Q0451-answer

**de-Q0452** — Tom und Maria liefen ins Wasser.

Tom and Mary ran into the water.

Expected form: **und**

Why: Coordinating connectors. [[German#^de-Q0452|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20und%20Maria%20liefen%20ins%20Wasser.)
^de-Q0452-answer

**de-Q0453** — Das Mädchen wurde abgelenkt und verlor ihre Eltern aus den Augen.

The girl got distracted and lost sight of her parents.

Expected form: **und**

Why: Coordinating connectors. [[German#^de-Q0453|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20M%C3%A4dchen%20wurde%20abgelenkt%20und%20verlor%20ihre%20Eltern%20aus%20den%20Augen.)
^de-Q0453-answer

**de-Q0454** — Das Mädchen wurde abgelenkt und verlor ihre Eltern aus den Augen.

The girl got distracted and lost sight of her parents.

Why: Coordinating connectors. [[German#^de-Q0454|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20M%C3%A4dchen%20wurde%20abgelenkt%20und%20verlor%20ihre%20Eltern%20aus%20den%20Augen.)
^de-Q0454-answer

**de-Q0455** — Dann sprach der Geist erneut, und seine Stimme klang wie das Seufzen des Windes.

Then the ghost spoke again, and his voice sounded like the sighing of the wind.

Why: Coordinating connectors. [[German#^de-Q0455|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Dann%20sprach%20der%20Geist%20erneut%2C%20und%20seine%20Stimme%20klang%20wie%20das%20Seufzen%20des%20Windes.)
^de-Q0455-answer

**de-Q0456** — Dann sprach der Geist erneut, und seine Stimme klang wie das Seufzen des Windes.

Then the ghost spoke again, and his voice sounded like the sighing of the wind.

Coordinating connectors do not impose subordinate verb-final order. Sondern corrects a preceding negated alternative. Denn gives a reason with main-clause order.

Why: Coordinating connectors. [[German#^de-Q0456|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Dann%20sprach%20der%20Geist%20erneut%2C%20und%20seine%20Stimme%20klang%20wie%20das%20Seufzen%20des%20Windes.)
^de-Q0456-answer

**de-Q0457** — Tom und ich waren abwechselnd am Steuer.

Tom and I took turns driving.

Expected form: **und**

Why: Coordinating connectors. [[German#^de-Q0457|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20und%20ich%20waren%20abwechselnd%20am%20Steuer.)
^de-Q0457-answer

**de-Q0458** — Tom und ich waren abwechselnd am Steuer.

Tom and I took turns driving.

Expected form: **und**

Why: Coordinating connectors. [[German#^de-Q0458|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20und%20ich%20waren%20abwechselnd%20am%20Steuer.)
^de-Q0458-answer

**de-Q0459** — Was backen Sie denn da?

What're you baking?

Expected form: **denn**

Why: Coordinating connectors. [[German#^de-Q0459|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Was%20backen%20Sie%20denn%20da%3F)
^de-Q0459-answer

**de-Q0460** — Was backen Sie denn da?

What're you baking?

Why: Coordinating connectors. [[German#^de-Q0460|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Was%20backen%20Sie%20denn%20da%3F)
^de-Q0460-answer

**de-Q0461** — Ich habe das Haus noch nie gesehen, aber ich habe es mir schon Tausende Male vorgestellt.

I've never seen that house, but I've imagined it thousands of times.

Why: Coordinating connectors. [[German#^de-Q0461|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20das%20Haus%20noch%20nie%20gesehen%2C%20aber%20ich%20habe%20es%20mir%20schon%20Tausende%20Male%20vorgestellt.)
^de-Q0461-answer

**de-Q0462** — Ich habe das Haus noch nie gesehen, aber ich habe es mir schon Tausende Male vorgestellt.

I've never seen that house, but I've imagined it thousands of times.

Coordinating connectors do not impose subordinate verb-final order. Sondern corrects a preceding negated alternative. Denn gives a reason with main-clause order.

Why: Coordinating connectors. [[German#^de-Q0462|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20das%20Haus%20noch%20nie%20gesehen%2C%20aber%20ich%20habe%20es%20mir%20schon%20Tausende%20Male%20vorgestellt.)
^de-Q0462-answer

**de-Q0463** — Tom und Maria arbeiten beide im selben Supermarkt.

Tom and Mary both work at the same supermarket.

Expected form: **und**

Why: Coordinating connectors. [[German#^de-Q0463|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20und%20Maria%20arbeiten%20beide%20im%20selben%20Supermarkt.)
^de-Q0463-answer

**de-Q0464** — Tom und Maria arbeiten beide im selben Supermarkt.

Tom and Mary both work at the same supermarket.

Expected form: **und**

Why: Coordinating connectors. [[German#^de-Q0464|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20und%20Maria%20arbeiten%20beide%20im%20selben%20Supermarkt.)
^de-Q0464-answer

**de-Q0465** — Was glauben Sie, wie Tom und Maria das hinkriegen?

How do you think Tom and Mary do that?

Expected form: **und**

Why: Coordinating connectors. [[German#^de-Q0465|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Was%20glauben%20Sie%2C%20wie%20Tom%20und%20Maria%20das%20hinkriegen%3F)
^de-Q0465-answer

**de-Q0466** — Was glauben Sie, wie Tom und Maria das hinkriegen?

How do you think Tom and Mary do that?

Why: Coordinating connectors. [[German#^de-Q0466|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Was%20glauben%20Sie%2C%20wie%20Tom%20und%20Maria%20das%20hinkriegen%3F)
^de-Q0466-answer

**de-Q0467** — Sieht aus wie Latein, ist es aber nicht.

Looks like Latin, but it is not.

Why: Coordinating connectors. [[German#^de-Q0467|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sieht%20aus%20wie%20Latein%2C%20ist%20es%20aber%20nicht.)
^de-Q0467-answer

**de-Q0468** — Sieht aus wie Latein, ist es aber nicht.

Looks like Latin, but it is not.

Coordinating connectors do not impose subordinate verb-final order. Sondern corrects a preceding negated alternative. Denn gives a reason with main-clause order.

Why: Coordinating connectors. [[German#^de-Q0468|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sieht%20aus%20wie%20Latein%2C%20ist%20es%20aber%20nicht.)
^de-Q0468-answer

**de-Q0469** — Maria liebt mich, und ich liebe sie auch.

Mary loves me and I love her, too.

Expected form: **und**

Why: Coordinating connectors. [[German#^de-Q0469|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Maria%20liebt%20mich%2C%20und%20ich%20liebe%20sie%20auch.)
^de-Q0469-answer

**de-Q0470** — Maria liebt mich, und ich liebe sie auch.

Mary loves me and I love her, too.

Expected form: **und**

Why: Coordinating connectors. [[German#^de-Q0470|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Maria%20liebt%20mich%2C%20und%20ich%20liebe%20sie%20auch.)
^de-Q0470-answer

**de-Q0471** — Komm her und hilf mit.

Come over and help out.

Expected form: **und**

Why: Coordinating connectors. [[German#^de-Q0471|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Komm%20her%20und%20hilf%20mit.)
^de-Q0471-answer

**de-Q0472** — Komm her und hilf mit.

Come over and help out.

Why: Coordinating connectors. [[German#^de-Q0472|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Komm%20her%20und%20hilf%20mit.)
^de-Q0472-answer

**de-Q0473** — Das Billet gilt bis und mit Montag.

The ticket is good through Monday.

Why: Coordinating connectors. [[German#^de-Q0473|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20Billet%20gilt%20bis%20und%20mit%20Montag.)
^de-Q0473-answer

**de-Q0474** — Das Billet gilt bis und mit Montag.

The ticket is good through Monday.

Coordinating connectors do not impose subordinate verb-final order. Sondern corrects a preceding negated alternative. Denn gives a reason with main-clause order.

Why: Coordinating connectors. [[German#^de-Q0474|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20Billet%20gilt%20bis%20und%20mit%20Montag.)
^de-Q0474-answer

**de-Q0475** — Ich habe nicht ihn geküsst, sondern er mich.

I didn't kiss him. He kissed me.

Expected form: **sondern**

Why: Coordinating connectors. [[German#^de-Q0475|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20nicht%20ihn%20gek%C3%BCsst%2C%20sondern%20er%20mich.)
^de-Q0475-answer

**de-Q0476** — Ich habe nicht ihn geküsst, sondern er mich.

I didn't kiss him. He kissed me.

Expected form: **sondern**

Why: Coordinating connectors. [[German#^de-Q0476|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20nicht%20ihn%20gek%C3%BCsst%2C%20sondern%20er%20mich.)
^de-Q0476-answer

**de-Q0477** — Wir standen früh auf und machten uns dran, das Haus zu putzen.

We got up early and set about cleaning our house.

Expected form: **und**

Why: Coordinating connectors. [[German#^de-Q0477|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20standen%20fr%C3%BCh%20auf%20und%20machten%20uns%20dran%2C%20das%20Haus%20zu%20putzen.)
^de-Q0477-answer

**de-Q0478** — Wir standen früh auf und machten uns dran, das Haus zu putzen.

We got up early and set about cleaning our house.

Why: Coordinating connectors. [[German#^de-Q0478|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20standen%20fr%C3%BCh%20auf%20und%20machten%20uns%20dran%2C%20das%20Haus%20zu%20putzen.)
^de-Q0478-answer

**de-Q0479** — Ich bin kein Geisterschreiber, sondern der Geist eines verblichenen Schreibers.

I'm not a ghost-writer, I'm the ghost of a deceased writer.

Why: Coordinating connectors. [[German#^de-Q0479|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20bin%20kein%20Geisterschreiber%2C%20sondern%20der%20Geist%20eines%20verblichenen%20Schreibers.)
^de-Q0479-answer

**de-Q0480** — Ich bin kein Geisterschreiber, sondern der Geist eines verblichenen Schreibers.

I'm not a ghost-writer, I'm the ghost of a deceased writer.

Coordinating connectors do not impose subordinate verb-final order. Sondern corrects a preceding negated alternative. Denn gives a reason with main-clause order.

Why: Coordinating connectors. [[German#^de-Q0480|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20bin%20kein%20Geisterschreiber%2C%20sondern%20der%20Geist%20eines%20verblichenen%20Schreibers.)
^de-Q0480-answer

**de-Q0481** — Toms Flug wurde verschoben und dann gestrichen.

Tom's flight was delayed and then cancelled.

Expected form: **und**

Why: Coordinating connectors. [[German#^de-Q0481|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Toms%20Flug%20wurde%20verschoben%20und%20dann%20gestrichen.)
^de-Q0481-answer

**de-Q0482** — Toms Flug wurde verschoben und dann gestrichen.

Tom's flight was delayed and then cancelled.

Expected form: **und**

Why: Coordinating connectors. [[German#^de-Q0482|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Toms%20Flug%20wurde%20verschoben%20und%20dann%20gestrichen.)
^de-Q0482-answer

**de-Q0483** — Ihr wollt Tom doch nicht wütend machen, oder?

You don't want to make Tom mad, do you?

Expected form: **oder**

Why: Coordinating connectors. [[German#^de-Q0483|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ihr%20wollt%20Tom%20doch%20nicht%20w%C3%BCtend%20machen%2C%20oder%3F)
^de-Q0483-answer

**de-Q0484** — Ihr wollt Tom doch nicht wütend machen, oder?

You don't want to make Tom mad, do you?

Why: Coordinating connectors. [[German#^de-Q0484|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ihr%20wollt%20Tom%20doch%20nicht%20w%C3%BCtend%20machen%2C%20oder%3F)
^de-Q0484-answer

**de-Q0485** — Tom fährt nicht mit uns Schi, oder?

Tom won't be skiing with us, will he?

Why: Coordinating connectors. [[German#^de-Q0485|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20f%C3%A4hrt%20nicht%20mit%20uns%20Schi%2C%20oder%3F)
^de-Q0485-answer

**de-Q0486** — Tom fährt nicht mit uns Schi, oder?

Tom won't be skiing with us, will he?

Coordinating connectors do not impose subordinate verb-final order. Sondern corrects a preceding negated alternative. Denn gives a reason with main-clause order.

Why: Coordinating connectors. [[German#^de-Q0486|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20f%C3%A4hrt%20nicht%20mit%20uns%20Schi%2C%20oder%3F)
^de-Q0486-answer

**de-Q0487** — Ich bin so schnell gerannt, wie ich konnte, aber ich habe den letzten Zug nicht mehr erreicht.

I ran as fast as possible, but I was not in time for the last train.

Expected form: **aber**

Why: Coordinating connectors. [[German#^de-Q0487|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20bin%20so%20schnell%20gerannt%2C%20wie%20ich%20konnte%2C%20aber%20ich%20habe%20den%20letzten%20Zug%20nicht%20mehr%20erreicht.)
^de-Q0487-answer

**de-Q0488** — Ich bin so schnell gerannt, wie ich konnte, aber ich habe den letzten Zug nicht mehr erreicht.

I ran as fast as possible, but I was not in time for the last train.

Expected form: **aber**

Why: Coordinating connectors. [[German#^de-Q0488|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20bin%20so%20schnell%20gerannt%2C%20wie%20ich%20konnte%2C%20aber%20ich%20habe%20den%20letzten%20Zug%20nicht%20mehr%20erreicht.)
^de-Q0488-answer

**de-Q0489** — Das seid ihr gewohnt, oder?

You're used to that, aren't you?

Expected form: **oder**

Why: Coordinating connectors. [[German#^de-Q0489|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20seid%20ihr%20gewohnt%2C%20oder%3F)
^de-Q0489-answer

**de-Q0490** — Das seid ihr gewohnt, oder?

You're used to that, aren't you?

Why: Coordinating connectors. [[German#^de-Q0490|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20seid%20ihr%20gewohnt%2C%20oder%3F)
^de-Q0490-answer

**de-Q0491** — Die Brücke zwischen Dänemark und Schweden ist fast acht Kilometer lang.

The bridge between Denmark and Sweden is almost five miles long.

Why: Coordinating connectors. [[German#^de-Q0491|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Br%C3%BCcke%20zwischen%20D%C3%A4nemark%20und%20Schweden%20ist%20fast%20acht%20Kilometer%20lang.)
^de-Q0491-answer

**de-Q0492** — Die Brücke zwischen Dänemark und Schweden ist fast acht Kilometer lang.

The bridge between Denmark and Sweden is almost five miles long.

Coordinating connectors do not impose subordinate verb-final order. Sondern corrects a preceding negated alternative. Denn gives a reason with main-clause order.

Why: Coordinating connectors. [[German#^de-Q0492|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Br%C3%BCcke%20zwischen%20D%C3%A4nemark%20und%20Schweden%20ist%20fast%20acht%20Kilometer%20lang.)
^de-Q0492-answer

**de-Q0493** — Ich verstehe kein Englisch und Deutsch noch weniger.

I understand no English and German even less.

Expected form: **und**

Why: Coordinating connectors. [[German#^de-Q0493|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20verstehe%20kein%20Englisch%20und%20Deutsch%20noch%20weniger.)
^de-Q0493-answer

**de-Q0494** — Ich verstehe kein Englisch und Deutsch noch weniger.

I understand no English and German even less.

Expected form: **und**

Why: Coordinating connectors. [[German#^de-Q0494|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20verstehe%20kein%20Englisch%20und%20Deutsch%20noch%20weniger.)
^de-Q0494-answer

**de-Q0495** — Ein Gentleman ist einer, der weiß, wie man ein Banjo spielt und es nicht tut.

A gentleman is someone who knows how to play the banjo and doesn't.

Expected form: **und**

Why: Coordinating connectors. [[German#^de-Q0495|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ein%20Gentleman%20ist%20einer%2C%20der%20wei%C3%9F%2C%20wie%20man%20ein%20Banjo%20spielt%20und%20es%20nicht%20tut.)
^de-Q0495-answer

**de-Q0496** — Ein Gentleman ist einer, der weiß, wie man ein Banjo spielt und es nicht tut.

A gentleman is someone who knows how to play the banjo and doesn't.

Why: Coordinating connectors. [[German#^de-Q0496|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ein%20Gentleman%20ist%20einer%2C%20der%20wei%C3%9F%2C%20wie%20man%20ein%20Banjo%20spielt%20und%20es%20nicht%20tut.)
^de-Q0496-answer

**de-Q0497** — 2008 fusionierten Delta und Northwest Airlines zur weltgrößten Fluggesellschaft.

In 2008, Delta and Northwest airlines united to form the world's largest airline.

Why: Coordinating connectors. [[German#^de-Q0497|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=2008%20fusionierten%20Delta%20und%20Northwest%20Airlines%20zur%20weltgr%C3%B6%C3%9Ften%20Fluggesellschaft.)
^de-Q0497-answer

**de-Q0498** — 2008 fusionierten Delta und Northwest Airlines zur weltgrößten Fluggesellschaft.

In 2008, Delta and Northwest airlines united to form the world's largest airline.

Coordinating connectors do not impose subordinate verb-final order. Sondern corrects a preceding negated alternative. Denn gives a reason with main-clause order.

Why: Coordinating connectors. [[German#^de-Q0498|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=2008%20fusionierten%20Delta%20und%20Northwest%20Airlines%20zur%20weltgr%C3%B6%C3%9Ften%20Fluggesellschaft.)
^de-Q0498-answer

**de-Q0499** — Tom und Maria küssten sich im Treppenhaus.

Tom and Mary kissed in the stairwell.

Expected form: **und**

Why: Coordinating connectors. [[German#^de-Q0499|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20und%20Maria%20k%C3%BCssten%20sich%20im%20Treppenhaus.)
^de-Q0499-answer

**de-Q0500** — Tom und Maria küssten sich im Treppenhaus.

Tom and Mary kissed in the stairwell.

Expected form: **und**

Why: Coordinating connectors. [[German#^de-Q0500|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20und%20Maria%20k%C3%BCssten%20sich%20im%20Treppenhaus.)
^de-Q0500-answer


### Answers 501–550

**de-Q0501** — Tom wusste von nichts.

Tom knew nothing.

Expected form: **von**

Why: Prepositions with case. [[German#^de-Q0501|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20wusste%20von%20nichts.)
^de-Q0501-answer

**de-Q0502** — Tom wusste von nichts.

Tom knew nothing.

Why: Prepositions with case. [[German#^de-Q0502|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20wusste%20von%20nichts.)
^de-Q0502-answer

**de-Q0503** — Ich verspreche, von nun an nett zu euch zu sein.

I promise I'll be nice to you from now on.

Why: Prepositions with case. [[German#^de-Q0503|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20verspreche%2C%20von%20nun%20an%20nett%20zu%20euch%20zu%20sein.)
^de-Q0503-answer

**de-Q0504** — Ich verspreche, von nun an nett zu euch zu sein.

I promise I'll be nice to you from now on.

Mit, bei, nach, seit, von, zu and aus normally govern dative. Für, ohne and durch normally govern accusative. A preposition selects the case of its complement, not the case of every noun nearby.

Why: Prepositions with case. [[German#^de-Q0504|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20verspreche%2C%20von%20nun%20an%20nett%20zu%20euch%20zu%20sein.)
^de-Q0504-answer

**de-Q0505** — Ich wurde zu Unrecht angeklagt.

I was falsely accused.

Expected form: **zu**

Why: Prepositions with case. [[German#^de-Q0505|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20wurde%20zu%20Unrecht%20angeklagt.)
^de-Q0505-answer

**de-Q0506** — Ich wurde zu Unrecht angeklagt.

I was falsely accused.

Expected form: **zu**

Why: Prepositions with case. [[German#^de-Q0506|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20wurde%20zu%20Unrecht%20angeklagt.)
^de-Q0506-answer

**de-Q0507** — Am nächsten Sonntag fahren wir aus.

We'll go for a drive next Sunday.

Expected form: **aus**

Why: Prepositions with case. [[German#^de-Q0507|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Am%20n%C3%A4chsten%20Sonntag%20fahren%20wir%20aus.)
^de-Q0507-answer

**de-Q0508** — Am nächsten Sonntag fahren wir aus.

We'll go for a drive next Sunday.

Why: Prepositions with case. [[German#^de-Q0508|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Am%20n%C3%A4chsten%20Sonntag%20fahren%20wir%20aus.)
^de-Q0508-answer

**de-Q0509** — Ich fahre nächsten Monat nach Australien.

I will be leaving for Australia next month.

Why: Prepositions with case. [[German#^de-Q0509|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20fahre%20n%C3%A4chsten%20Monat%20nach%20Australien.)
^de-Q0509-answer

**de-Q0510** — Ich fahre nächsten Monat nach Australien.

I will be leaving for Australia next month.

Mit, bei, nach, seit, von, zu and aus normally govern dative. Für, ohne and durch normally govern accusative. A preposition selects the case of its complement, not the case of every noun nearby.

Why: Prepositions with case. [[German#^de-Q0510|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20fahre%20n%C3%A4chsten%20Monat%20nach%20Australien.)
^de-Q0510-answer

**de-Q0511** — Tom vergaß, sich die Hände zu waschen.

Tom forgot to wash his hands.

Expected form: **zu**

Why: Prepositions with case. [[German#^de-Q0511|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20verga%C3%9F%2C%20sich%20die%20H%C3%A4nde%20zu%20waschen.)
^de-Q0511-answer

**de-Q0512** — Tom vergaß, sich die Hände zu waschen.

Tom forgot to wash his hands.

Expected form: **zu**

Why: Prepositions with case. [[German#^de-Q0512|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20verga%C3%9F%2C%20sich%20die%20H%C3%A4nde%20zu%20waschen.)
^de-Q0512-answer

**de-Q0513** — Doch, ich war zu Hause!

No, I was at home!

Expected form: **zu**

Why: Prepositions with case. [[German#^de-Q0513|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Doch%2C%20ich%20war%20zu%20Hause%21)
^de-Q0513-answer

**de-Q0514** — Doch, ich war zu Hause!

No, I was at home!

Why: Prepositions with case. [[German#^de-Q0514|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Doch%2C%20ich%20war%20zu%20Hause%21)
^de-Q0514-answer

**de-Q0515** — Ich versuche noch etwas Platz für den Nachtisch lassen.

I'm trying to leave a little space for dessert.

Why: Prepositions with case. [[German#^de-Q0515|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20versuche%20noch%20etwas%20Platz%20f%C3%BCr%20den%20Nachtisch%20lassen.)
^de-Q0515-answer

**de-Q0516** — Ich versuche noch etwas Platz für den Nachtisch lassen.

I'm trying to leave a little space for dessert.

Mit, bei, nach, seit, von, zu and aus normally govern dative. Für, ohne and durch normally govern accusative. A preposition selects the case of its complement, not the case of every noun nearby.

Why: Prepositions with case. [[German#^de-Q0516|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20versuche%20noch%20etwas%20Platz%20f%C3%BCr%20den%20Nachtisch%20lassen.)
^de-Q0516-answer

**de-Q0517** — Das Kind spielt gerne mit den Katzen.

The child likes to play with the cats.

Expected form: **mit**

Why: Prepositions with case. [[German#^de-Q0517|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20Kind%20spielt%20gerne%20mit%20den%20Katzen.)
^de-Q0517-answer

**de-Q0518** — Das Kind spielt gerne mit den Katzen.

The child likes to play with the cats.

Expected form: **mit**

Why: Prepositions with case. [[German#^de-Q0518|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20Kind%20spielt%20gerne%20mit%20den%20Katzen.)
^de-Q0518-answer

**de-Q0519** — Bei meinem ersten Besuch in Spanien war alles ganz aufregend für mich.

Everything was exciting to me when I visited Spain for the first time.

Expected form: **Bei**

Why: Prepositions with case. [[German#^de-Q0519|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Bei%20meinem%20ersten%20Besuch%20in%20Spanien%20war%20alles%20ganz%20aufregend%20f%C3%BCr%20mich.)
^de-Q0519-answer

**de-Q0520** — Bei meinem ersten Besuch in Spanien war alles ganz aufregend für mich.

Everything was exciting to me when I visited Spain for the first time.

Why: Prepositions with case. [[German#^de-Q0520|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Bei%20meinem%20ersten%20Besuch%20in%20Spanien%20war%20alles%20ganz%20aufregend%20f%C3%BCr%20mich.)
^de-Q0520-answer

**de-Q0521** — Alles hängt von eurer Entscheidung ab.

Everything depends upon your decision.

Why: Prepositions with case. [[German#^de-Q0521|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Alles%20h%C3%A4ngt%20von%20eurer%20Entscheidung%20ab.)
^de-Q0521-answer

**de-Q0522** — Alles hängt von eurer Entscheidung ab.

Everything depends upon your decision.

Mit, bei, nach, seit, von, zu and aus normally govern dative. Für, ohne and durch normally govern accusative. A preposition selects the case of its complement, not the case of every noun nearby.

Why: Prepositions with case. [[German#^de-Q0522|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Alles%20h%C3%A4ngt%20von%20eurer%20Entscheidung%20ab.)
^de-Q0522-answer

**de-Q0523** — Er war berühmt für seine Marathonreden im Parlament.

He was famous for his marathon speeches in parliament.

Expected form: **für**

Why: Prepositions with case. [[German#^de-Q0523|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20war%20ber%C3%BChmt%20f%C3%BCr%20seine%20Marathonreden%20im%20Parlament.)
^de-Q0523-answer

**de-Q0524** — Er war berühmt für seine Marathonreden im Parlament.

He was famous for his marathon speeches in parliament.

Expected form: **für**

Why: Prepositions with case. [[German#^de-Q0524|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20war%20ber%C3%BChmt%20f%C3%BCr%20seine%20Marathonreden%20im%20Parlament.)
^de-Q0524-answer

**de-Q0525** — Ich hasse es, meine Zeit zu verschwenden.

I hate to waste my time.

Expected form: **zu**

Why: Prepositions with case. [[German#^de-Q0525|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20hasse%20es%2C%20meine%20Zeit%20zu%20verschwenden.)
^de-Q0525-answer

**de-Q0526** — Ich hasse es, meine Zeit zu verschwenden.

I hate to waste my time.

Why: Prepositions with case. [[German#^de-Q0526|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20hasse%20es%2C%20meine%20Zeit%20zu%20verschwenden.)
^de-Q0526-answer

**de-Q0527** — Hört auf, euch zu streiten! Wir stehen hier alle auf der gleichen Seite.

Stop fighting. We're all on the same team here.

Why: Prepositions with case. [[German#^de-Q0527|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=H%C3%B6rt%20auf%2C%20euch%20zu%20streiten%21%20Wir%20stehen%20hier%20alle%20auf%20der%20gleichen%20Seite.)
^de-Q0527-answer

**de-Q0528** — Hört auf, euch zu streiten! Wir stehen hier alle auf der gleichen Seite.

Stop fighting. We're all on the same team here.

Mit, bei, nach, seit, von, zu and aus normally govern dative. Für, ohne and durch normally govern accusative. A preposition selects the case of its complement, not the case of every noun nearby.

Why: Prepositions with case. [[German#^de-Q0528|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=H%C3%B6rt%20auf%2C%20euch%20zu%20streiten%21%20Wir%20stehen%20hier%20alle%20auf%20der%20gleichen%20Seite.)
^de-Q0528-answer

**de-Q0529** — Übersetze, statt zu quatschen!

Translate instead of chattering!

Expected form: **zu**

Why: Prepositions with case. [[German#^de-Q0529|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=%C3%9Cbersetze%2C%20statt%20zu%20quatschen%21)
^de-Q0529-answer

**de-Q0530** — Übersetze, statt zu quatschen!

Translate instead of chattering!

Expected form: **zu**

Why: Prepositions with case. [[German#^de-Q0530|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=%C3%9Cbersetze%2C%20statt%20zu%20quatschen%21)
^de-Q0530-answer

**de-Q0531** — Tom ist mit seinem Hubschrauber auf dem Dach gelandet.

Tom landed his helicopter on the roof.

Expected form: **mit**

Why: Prepositions with case. [[German#^de-Q0531|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20ist%20mit%20seinem%20Hubschrauber%20auf%20dem%20Dach%20gelandet.)
^de-Q0531-answer

**de-Q0532** — Tom ist mit seinem Hubschrauber auf dem Dach gelandet.

Tom landed his helicopter on the roof.

Why: Prepositions with case. [[German#^de-Q0532|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20ist%20mit%20seinem%20Hubschrauber%20auf%20dem%20Dach%20gelandet.)
^de-Q0532-answer

**de-Q0533** — Ich werde dir aus der Hand lesen.

I'll read your fortune.

Why: Prepositions with case. [[German#^de-Q0533|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20werde%20dir%20aus%20der%20Hand%20lesen.)
^de-Q0533-answer

**de-Q0534** — Ich werde dir aus der Hand lesen.

I'll read your fortune.

Mit, bei, nach, seit, von, zu and aus normally govern dative. Für, ohne and durch normally govern accusative. A preposition selects the case of its complement, not the case of every noun nearby.

Why: Prepositions with case. [[German#^de-Q0534|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20werde%20dir%20aus%20der%20Hand%20lesen.)
^de-Q0534-answer

**de-Q0535** — Mir ging der Sprit aus.

I ran out of gas.

Expected form: **aus**

Why: Prepositions with case. [[German#^de-Q0535|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Mir%20ging%20der%20Sprit%20aus.)
^de-Q0535-answer

**de-Q0536** — Mir ging der Sprit aus.

I ran out of gas.

Expected form: **aus**

Why: Prepositions with case. [[German#^de-Q0536|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Mir%20ging%20der%20Sprit%20aus.)
^de-Q0536-answer

**de-Q0537** — Mit wem ist Tom beisammen?

Who's Tom with?

Expected form: **Mit**

Why: Prepositions with case. [[German#^de-Q0537|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Mit%20wem%20ist%20Tom%20beisammen%3F)
^de-Q0537-answer

**de-Q0538** — Mit wem ist Tom beisammen?

Who's Tom with?

Why: Prepositions with case. [[German#^de-Q0538|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Mit%20wem%20ist%20Tom%20beisammen%3F)
^de-Q0538-answer

**de-Q0539** — Heutzutage ist es schwer, ein renovierungsbedürftiges Haus zu verkaufen.

It's hard to sell a fixer-upper nowadays.

Why: Prepositions with case. [[German#^de-Q0539|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Heutzutage%20ist%20es%20schwer%2C%20ein%20renovierungsbed%C3%BCrftiges%20Haus%20zu%20verkaufen.)
^de-Q0539-answer

**de-Q0540** — Heutzutage ist es schwer, ein renovierungsbedürftiges Haus zu verkaufen.

It's hard to sell a fixer-upper nowadays.

Mit, bei, nach, seit, von, zu and aus normally govern dative. Für, ohne and durch normally govern accusative. A preposition selects the case of its complement, not the case of every noun nearby.

Why: Prepositions with case. [[German#^de-Q0540|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Heutzutage%20ist%20es%20schwer%2C%20ein%20renovierungsbed%C3%BCrftiges%20Haus%20zu%20verkaufen.)
^de-Q0540-answer

**de-Q0541** — Tom verdient kaum genug, um davon zu leben.

Tom just barely earns enough to live on.

Expected form: **zu**

Why: Prepositions with case. [[German#^de-Q0541|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20verdient%20kaum%20genug%2C%20um%20davon%20zu%20leben.)
^de-Q0541-answer

**de-Q0542** — Tom verdient kaum genug, um davon zu leben.

Tom just barely earns enough to live on.

Expected form: **zu**

Why: Prepositions with case. [[German#^de-Q0542|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20verdient%20kaum%20genug%2C%20um%20davon%20zu%20leben.)
^de-Q0542-answer

**de-Q0543** — Tom kommt bei mir vorbei.

Tom is coming to see me.

Expected form: **bei**

Why: Prepositions with case. [[German#^de-Q0543|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20kommt%20bei%20mir%20vorbei.)
^de-Q0543-answer

**de-Q0544** — Tom kommt bei mir vorbei.

Tom is coming to see me.

Why: Prepositions with case. [[German#^de-Q0544|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20kommt%20bei%20mir%20vorbei.)
^de-Q0544-answer

**de-Q0545** — Es ist sehr schwer, ein Taxi in dieser Stadt zu bekommen.

It's very hard getting a taxi in this city.

Why: Prepositions with case. [[German#^de-Q0545|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20ist%20sehr%20schwer%2C%20ein%20Taxi%20in%20dieser%20Stadt%20zu%20bekommen.)
^de-Q0545-answer

**de-Q0546** — Es ist sehr schwer, ein Taxi in dieser Stadt zu bekommen.

It's very hard getting a taxi in this city.

Mit, bei, nach, seit, von, zu and aus normally govern dative. Für, ohne and durch normally govern accusative. A preposition selects the case of its complement, not the case of every noun nearby.

Why: Prepositions with case. [[German#^de-Q0546|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20ist%20sehr%20schwer%2C%20ein%20Taxi%20in%20dieser%20Stadt%20zu%20bekommen.)
^de-Q0546-answer

**de-Q0547** — Alle auf der Feier waren von ihrer Anmut bezaubert.

Everybody at the party was charmed by her grace.

Expected form: **von**

Why: Prepositions with case. [[German#^de-Q0547|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Alle%20auf%20der%20Feier%20waren%20von%20ihrer%20Anmut%20bezaubert.)
^de-Q0547-answer

**de-Q0548** — Alle auf der Feier waren von ihrer Anmut bezaubert.

Everybody at the party was charmed by her grace.

Expected form: **von**

Why: Prepositions with case. [[German#^de-Q0548|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Alle%20auf%20der%20Feier%20waren%20von%20ihrer%20Anmut%20bezaubert.)
^de-Q0548-answer

**de-Q0549** — Habt ihr mit Tom darüber gesprochen?

Have you talked to Tom about this?

Expected form: **mit**

Why: Prepositions with case. [[German#^de-Q0549|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Habt%20ihr%20mit%20Tom%20dar%C3%BCber%20gesprochen%3F)
^de-Q0549-answer

**de-Q0550** — Habt ihr mit Tom darüber gesprochen?

Have you talked to Tom about this?

Why: Prepositions with case. [[German#^de-Q0550|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Habt%20ihr%20mit%20Tom%20dar%C3%BCber%20gesprochen%3F)
^de-Q0550-answer


### Answers 551–600

**de-Q0551** — Schauen Sie sich diese Fische im Teich an.

Look at those fish in the pond.

Why: Two-way prepositions. [[German#^de-Q0551|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Schauen%20Sie%20sich%20diese%20Fische%20im%20Teich%20an.)
^de-Q0551-answer

**de-Q0552** — Schauen Sie sich diese Fische im Teich an.

Look at those fish in the pond.

Many spatial uses take dative for location and accusative for a destination or change of spatial relation. The distinction is not simply movement versus no movement. A movement within a location can still take dative.

Why: Two-way prepositions. [[German#^de-Q0552|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Schauen%20Sie%20sich%20diese%20Fische%20im%20Teich%20an.)
^de-Q0552-answer

**de-Q0553** — Tom sollte in Kürze hier sein.

Tom should be here shortly.

Expected form: **in**

Why: Two-way prepositions. [[German#^de-Q0553|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20sollte%20in%20K%C3%BCrze%20hier%20sein.)
^de-Q0553-answer

**de-Q0554** — Tom sollte in Kürze hier sein.

Tom should be here shortly.

Expected form: **in**

Why: Two-way prepositions. [[German#^de-Q0554|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20sollte%20in%20K%C3%BCrze%20hier%20sein.)
^de-Q0554-answer

**de-Q0555** — Die Jungen unterhielten sich über Videospiele.

The boys talked about video games.

Expected form: **über**

Why: Two-way prepositions. [[German#^de-Q0555|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Jungen%20unterhielten%20sich%20%C3%BCber%20Videospiele.)
^de-Q0555-answer

**de-Q0556** — Die Jungen unterhielten sich über Videospiele.

The boys talked about video games.

Why: Two-way prepositions. [[German#^de-Q0556|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Jungen%20unterhielten%20sich%20%C3%BCber%20Videospiele.)
^de-Q0556-answer

**de-Q0557** — Halten Sie mal den Atem an.

Hold your breath, please.

Why: Two-way prepositions. [[German#^de-Q0557|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Halten%20Sie%20mal%20den%20Atem%20an.)
^de-Q0557-answer

**de-Q0558** — Halten Sie mal den Atem an.

Hold your breath, please.

Many spatial uses take dative for location and accusative for a destination or change of spatial relation. The distinction is not simply movement versus no movement. A movement within a location can still take dative.

Why: Two-way prepositions. [[German#^de-Q0558|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Halten%20Sie%20mal%20den%20Atem%20an.)
^de-Q0558-answer

**de-Q0559** — Tom gewann zehntausend Dollar in der Lotterie.

Tom won $10,000 in the lottery.

Expected form: **in**

Why: Two-way prepositions. [[German#^de-Q0559|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20gewann%20zehntausend%20Dollar%20in%20der%20Lotterie.)
^de-Q0559-answer

**de-Q0560** — Tom gewann zehntausend Dollar in der Lotterie.

Tom won $10,000 in the lottery.

Expected form: **in**

Why: Two-way prepositions. [[German#^de-Q0560|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20gewann%20zehntausend%20Dollar%20in%20der%20Lotterie.)
^de-Q0560-answer

**de-Q0561** — Ich wollte niemanden in die Irre führen.

I didn't want to mislead anyone.

Expected form: **in**

Why: Two-way prepositions. [[German#^de-Q0561|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20wollte%20niemanden%20in%20die%20Irre%20f%C3%BChren.)
^de-Q0561-answer

**de-Q0562** — Ich wollte niemanden in die Irre führen.

I didn't want to mislead anyone.

Why: Two-way prepositions. [[German#^de-Q0562|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20wollte%20niemanden%20in%20die%20Irre%20f%C3%BChren.)
^de-Q0562-answer

**de-Q0563** — Ihr solltet zwischen den Zeilen lesen.

You should read between the lines.

Why: Two-way prepositions. [[German#^de-Q0563|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ihr%20solltet%20zwischen%20den%20Zeilen%20lesen.)
^de-Q0563-answer

**de-Q0564** — Ihr solltet zwischen den Zeilen lesen.

You should read between the lines.

Many spatial uses take dative for location and accusative for a destination or change of spatial relation. The distinction is not simply movement versus no movement. A movement within a location can still take dative.

Why: Two-way prepositions. [[German#^de-Q0564|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ihr%20solltet%20zwischen%20den%20Zeilen%20lesen.)
^de-Q0564-answer

**de-Q0565** — Setz ihn auf.

Put it on.

Expected form: **auf**

Why: Two-way prepositions. [[German#^de-Q0565|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Setz%20ihn%20auf.)
^de-Q0565-answer

**de-Q0566** — Setz ihn auf.

Put it on.

Expected form: **auf**

Why: Two-way prepositions. [[German#^de-Q0566|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Setz%20ihn%20auf.)
^de-Q0566-answer

**de-Q0567** — Tom ist vor Mary davongerannt.

Tom ran away from Mary.

Expected form: **vor**

Why: Two-way prepositions. [[German#^de-Q0567|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20ist%20vor%20Mary%20davongerannt.)
^de-Q0567-answer

**de-Q0568** — Tom ist vor Mary davongerannt.

Tom ran away from Mary.

Why: Two-way prepositions. [[German#^de-Q0568|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20ist%20vor%20Mary%20davongerannt.)
^de-Q0568-answer

**de-Q0569** — In der Bibliothek war niemand.

There was no one in the library.

Why: Two-way prepositions. [[German#^de-Q0569|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=In%20der%20Bibliothek%20war%20niemand.)
^de-Q0569-answer

**de-Q0570** — In der Bibliothek war niemand.

There was no one in the library.

Many spatial uses take dative for location and accusative for a destination or change of spatial relation. The distinction is not simply movement versus no movement. A movement within a location can still take dative.

Why: Two-way prepositions. [[German#^de-Q0570|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=In%20der%20Bibliothek%20war%20niemand.)
^de-Q0570-answer

**de-Q0571** — Sie fesselten den Dieb an den Baum.

They tied the thief to the tree.

Expected form: **an**

Why: Two-way prepositions. [[German#^de-Q0571|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20fesselten%20den%20Dieb%20an%20den%20Baum.)
^de-Q0571-answer

**de-Q0572** — Sie fesselten den Dieb an den Baum.

They tied the thief to the tree.

Expected form: **an**

Why: Two-way prepositions. [[German#^de-Q0572|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20fesselten%20den%20Dieb%20an%20den%20Baum.)
^de-Q0572-answer

**de-Q0573** — Er legte mir die Hand auf meine Schulter.

He placed his hand on my shoulder.

Expected form: **auf**

Why: Two-way prepositions. [[German#^de-Q0573|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20legte%20mir%20die%20Hand%20auf%20meine%20Schulter.)
^de-Q0573-answer

**de-Q0574** — Er legte mir die Hand auf meine Schulter.

He placed his hand on my shoulder.

Why: Two-way prepositions. [[German#^de-Q0574|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20legte%20mir%20die%20Hand%20auf%20meine%20Schulter.)
^de-Q0574-answer

**de-Q0575** — Ich bin ein bisschen sauer auf dich.

I'm a little angry with you.

Why: Two-way prepositions. [[German#^de-Q0575|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20bin%20ein%20bisschen%20sauer%20auf%20dich.)
^de-Q0575-answer

**de-Q0576** — Ich bin ein bisschen sauer auf dich.

I'm a little angry with you.

Many spatial uses take dative for location and accusative for a destination or change of spatial relation. The distinction is not simply movement versus no movement. A movement within a location can still take dative.

Why: Two-way prepositions. [[German#^de-Q0576|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20bin%20ein%20bisschen%20sauer%20auf%20dich.)
^de-Q0576-answer

**de-Q0577** — In der Spüle ist schmutziges Geschirr.

There are dirty dishes in the sink­.

Expected form: **In**

Why: Two-way prepositions. [[German#^de-Q0577|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=In%20der%20Sp%C3%BCle%20ist%20schmutziges%20Geschirr.)
^de-Q0577-answer

**de-Q0578** — In der Spüle ist schmutziges Geschirr.

There are dirty dishes in the sink­.

Expected form: **In**

Why: Two-way prepositions. [[German#^de-Q0578|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=In%20der%20Sp%C3%BCle%20ist%20schmutziges%20Geschirr.)
^de-Q0578-answer

**de-Q0579** — Er wollte alles über Sie erfahren.

He wanted to know everything about you.

Expected form: **über**

Why: Two-way prepositions. [[German#^de-Q0579|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20wollte%20alles%20%C3%BCber%20Sie%20erfahren.)
^de-Q0579-answer

**de-Q0580** — Er wollte alles über Sie erfahren.

He wanted to know everything about you.

Why: Two-way prepositions. [[German#^de-Q0580|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20wollte%20alles%20%C3%BCber%20Sie%20erfahren.)
^de-Q0580-answer

**de-Q0581** — Wir treffen uns draußen vor dem Eingang.

We'll meet you out front.

Why: Two-way prepositions. [[German#^de-Q0581|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20treffen%20uns%20drau%C3%9Fen%20vor%20dem%20Eingang.)
^de-Q0581-answer

**de-Q0582** — Wir treffen uns draußen vor dem Eingang.

We'll meet you out front.

Many spatial uses take dative for location and accusative for a destination or change of spatial relation. The distinction is not simply movement versus no movement. A movement within a location can still take dative.

Why: Two-way prepositions. [[German#^de-Q0582|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20treffen%20uns%20drau%C3%9Fen%20vor%20dem%20Eingang.)
^de-Q0582-answer

**de-Q0583** — Hat Tom sich mit Ihnen in Verbindung gesetzt?

Did Tom contact you?

Expected form: **in**

Why: Two-way prepositions. [[German#^de-Q0583|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Hat%20Tom%20sich%20mit%20Ihnen%20in%20Verbindung%20gesetzt%3F)
^de-Q0583-answer

**de-Q0584** — Hat Tom sich mit Ihnen in Verbindung gesetzt?

Did Tom contact you?

Expected form: **in**

Why: Two-way prepositions. [[German#^de-Q0584|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Hat%20Tom%20sich%20mit%20Ihnen%20in%20Verbindung%20gesetzt%3F)
^de-Q0584-answer

**de-Q0585** — Er legte mir die Hand auf die Schulter.

He placed his hand on my shoulder.

Expected form: **auf**

Why: Two-way prepositions. [[German#^de-Q0585|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20legte%20mir%20die%20Hand%20auf%20die%20Schulter.)
^de-Q0585-answer

**de-Q0586** — Er legte mir die Hand auf die Schulter.

He placed his hand on my shoulder.

Why: Two-way prepositions. [[German#^de-Q0586|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20legte%20mir%20die%20Hand%20auf%20die%20Schulter.)
^de-Q0586-answer

**de-Q0587** — Glück liegt in Zufriedenheit.

Happiness lies in contentment.

Why: Two-way prepositions. [[German#^de-Q0587|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Gl%C3%BCck%20liegt%20in%20Zufriedenheit.)
^de-Q0587-answer

**de-Q0588** — Glück liegt in Zufriedenheit.

Happiness lies in contentment.

Many spatial uses take dative for location and accusative for a destination or change of spatial relation. The distinction is not simply movement versus no movement. A movement within a location can still take dative.

Why: Two-way prepositions. [[German#^de-Q0588|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Gl%C3%BCck%20liegt%20in%20Zufriedenheit.)
^de-Q0588-answer

**de-Q0589** — Wie heißt das auf Italienisch?

How do you say that in Italian?

Expected form: **auf**

Why: Two-way prepositions. [[German#^de-Q0589|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20hei%C3%9Ft%20das%20auf%20Italienisch%3F)
^de-Q0589-answer

**de-Q0590** — Wie heißt das auf Italienisch?

How do you say that in Italian?

Expected form: **auf**

Why: Two-way prepositions. [[German#^de-Q0590|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20hei%C3%9Ft%20das%20auf%20Italienisch%3F)
^de-Q0590-answer

**de-Q0591** — Der Inhalt der Schachtel ist auf dem Etikett verzeichnet.

The contents of the box are indicated on the label.

Expected form: **auf**

Why: Two-way prepositions. [[German#^de-Q0591|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Inhalt%20der%20Schachtel%20ist%20auf%20dem%20Etikett%20verzeichnet.)
^de-Q0591-answer

**de-Q0592** — Der Inhalt der Schachtel ist auf dem Etikett verzeichnet.

The contents of the box are indicated on the label.

Why: Two-way prepositions. [[German#^de-Q0592|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Inhalt%20der%20Schachtel%20ist%20auf%20dem%20Etikett%20verzeichnet.)
^de-Q0592-answer

**de-Q0593** — Vergiss nicht, das Buch in der Bibliothek zurückzugeben.

Don't forget to return the book to the library.

Why: Two-way prepositions. [[German#^de-Q0593|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Vergiss%20nicht%2C%20das%20Buch%20in%20der%20Bibliothek%20zur%C3%BCckzugeben.)
^de-Q0593-answer

**de-Q0594** — Vergiss nicht, das Buch in der Bibliothek zurückzugeben.

Don't forget to return the book to the library.

Many spatial uses take dative for location and accusative for a destination or change of spatial relation. The distinction is not simply movement versus no movement. A movement within a location can still take dative.

Why: Two-way prepositions. [[German#^de-Q0594|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Vergiss%20nicht%2C%20das%20Buch%20in%20der%20Bibliothek%20zur%C3%BCckzugeben.)
^de-Q0594-answer

**de-Q0595** — Ich lernte fleißig, um in die Schule aufgenommen zu werden.

I studied hard to enter the school.

Expected form: **in**

Why: Two-way prepositions. [[German#^de-Q0595|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20lernte%20flei%C3%9Fig%2C%20um%20in%20die%20Schule%20aufgenommen%20zu%20werden.)
^de-Q0595-answer

**de-Q0596** — Ich lernte fleißig, um in die Schule aufgenommen zu werden.

I studied hard to enter the school.

Expected form: **in**

Why: Two-way prepositions. [[German#^de-Q0596|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20lernte%20flei%C3%9Fig%2C%20um%20in%20die%20Schule%20aufgenommen%20zu%20werden.)
^de-Q0596-answer

**de-Q0597** — Er drückte seine Gefühle in Form eines Bildes aus.

He expressed his feelings in the form of a painting.

Expected form: **in**

Why: Two-way prepositions. [[German#^de-Q0597|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20dr%C3%BCckte%20seine%20Gef%C3%BChle%20in%20Form%20eines%20Bildes%20aus.)
^de-Q0597-answer

**de-Q0598** — Er drückte seine Gefühle in Form eines Bildes aus.

He expressed his feelings in the form of a painting.

Why: Two-way prepositions. [[German#^de-Q0598|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20dr%C3%BCckte%20seine%20Gef%C3%BChle%20in%20Form%20eines%20Bildes%20aus.)
^de-Q0598-answer

**de-Q0599** — Ist das nicht skurril? Ein Ausländer, der einem Einheimischen das Feilschen auf dem Basar beibringt!

Isn't it strange?--A foreigner showing a local how to bargain at the bazaar.

Why: Two-way prepositions. [[German#^de-Q0599|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ist%20das%20nicht%20skurril%3F%20Ein%20Ausl%C3%A4nder%2C%20der%20einem%20Einheimischen%20das%20Feilschen%20auf%20dem%20Basar%20beibringt%21)
^de-Q0599-answer

**de-Q0600** — Ist das nicht skurril? Ein Ausländer, der einem Einheimischen das Feilschen auf dem Basar beibringt!

Isn't it strange?--A foreigner showing a local how to bargain at the bazaar.

Many spatial uses take dative for location and accusative for a destination or change of spatial relation. The distinction is not simply movement versus no movement. A movement within a location can still take dative.

Why: Two-way prepositions. [[German#^de-Q0600|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ist%20das%20nicht%20skurril%3F%20Ein%20Ausl%C3%A4nder%2C%20der%20einem%20Einheimischen%20das%20Feilschen%20auf%20dem%20Basar%20beibringt%21)
^de-Q0600-answer


### Answers 601–650

**de-Q0601** — Wie waren eure letzten Prüfungen?

How were your last exams?

Expected form: **waren**

Why: Past forms of sein and haben. [[German#^de-Q0601|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20waren%20eure%20letzten%20Pr%C3%BCfungen%3F)
^de-Q0601-answer

**de-Q0602** — Wie waren eure letzten Prüfungen?

How were your last exams?

Expected form: **waren**

Why: Past forms of sein and haben. [[German#^de-Q0602|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20waren%20eure%20letzten%20Pr%C3%BCfungen%3F)
^de-Q0602-answer

**de-Q0603** — Das war äußerst lustig.

It was extremely funny.

Expected form: **war**

Why: Past forms of sein and haben. [[German#^de-Q0603|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20war%20%C3%A4u%C3%9Ferst%20lustig.)
^de-Q0603-answer

**de-Q0604** — Das war äußerst lustig.

It was extremely funny.

Why: Past forms of sein and haben. [[German#^de-Q0604|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20war%20%C3%A4u%C3%9Ferst%20lustig.)
^de-Q0604-answer

**de-Q0605** — Das war ein schwerwiegender Fehler.

That was a serious mistake.

Why: Past forms of sein and haben. [[German#^de-Q0605|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20war%20ein%20schwerwiegender%20Fehler.)
^de-Q0605-answer

**de-Q0606** — Das war ein schwerwiegender Fehler.

That was a serious mistake.

War and hatte are past forms of sein and haben. They occur frequently in spoken as well as written German. They also help construct pluperfect forms when a past participle follows.

Why: Past forms of sein and haben. [[German#^de-Q0606|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20war%20ein%20schwerwiegender%20Fehler.)
^de-Q0606-answer

**de-Q0607** — Maria war eine außergewöhnliche Frau.

Mary was an extraordinary woman.

Expected form: **war**

Why: Past forms of sein and haben. [[German#^de-Q0607|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Maria%20war%20eine%20au%C3%9Fergew%C3%B6hnliche%20Frau.)
^de-Q0607-answer

**de-Q0608** — Maria war eine außergewöhnliche Frau.

Mary was an extraordinary woman.

Expected form: **war**

Why: Past forms of sein and haben. [[German#^de-Q0608|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Maria%20war%20eine%20au%C3%9Fergew%C3%B6hnliche%20Frau.)
^de-Q0608-answer

**de-Q0609** — Das ist, wie es damals war.

That's how things were back then.

Expected form: **war**

Why: Past forms of sein and haben. [[German#^de-Q0609|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20ist%2C%20wie%20es%20damals%20war.)
^de-Q0609-answer

**de-Q0610** — Das ist, wie es damals war.

That's how things were back then.

Why: Past forms of sein and haben. [[German#^de-Q0610|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20ist%2C%20wie%20es%20damals%20war.)
^de-Q0610-answer

**de-Q0611** — Tom war schon weg, als ich ankam.

Tom had already left when I arrived.

Why: Past forms of sein and haben. [[German#^de-Q0611|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20war%20schon%20weg%2C%20als%20ich%20ankam.)
^de-Q0611-answer

**de-Q0612** — Tom war schon weg, als ich ankam.

Tom had already left when I arrived.

War and hatte are past forms of sein and haben. They occur frequently in spoken as well as written German. They also help construct pluperfect forms when a past participle follows.

Why: Past forms of sein and haben. [[German#^de-Q0612|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20war%20schon%20weg%2C%20als%20ich%20ankam.)
^de-Q0612-answer

**de-Q0613** — Was ihr getan habt, war sehr tapfer.

What you did was very brave.

Expected form: **war**

Why: Past forms of sein and haben. [[German#^de-Q0613|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Was%20ihr%20getan%20habt%2C%20war%20sehr%20tapfer.)
^de-Q0613-answer

**de-Q0614** — Was ihr getan habt, war sehr tapfer.

What you did was very brave.

Expected form: **war**

Why: Past forms of sein and haben. [[German#^de-Q0614|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Was%20ihr%20getan%20habt%2C%20war%20sehr%20tapfer.)
^de-Q0614-answer

**de-Q0615** — Tom erklärte im Detail, was er gesehen hatte.

Tom explained in detail what he had seen.

Expected form: **hatte**

Why: Past forms of sein and haben. [[German#^de-Q0615|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20erkl%C3%A4rte%20im%20Detail%2C%20was%20er%20gesehen%20hatte.)
^de-Q0615-answer

**de-Q0616** — Tom erklärte im Detail, was er gesehen hatte.

Tom explained in detail what he had seen.

Why: Past forms of sein and haben. [[German#^de-Q0616|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20erkl%C3%A4rte%20im%20Detail%2C%20was%20er%20gesehen%20hatte.)
^de-Q0616-answer

**de-Q0617** — Der bekannte Dichter hatte in seinem Arbeitszimmer einen Selbstmordversuch unternommen.

The prominent poet attempted to commit suicide in his study.

Why: Past forms of sein and haben. [[German#^de-Q0617|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20bekannte%20Dichter%20hatte%20in%20seinem%20Arbeitszimmer%20einen%20Selbstmordversuch%20unternommen.)
^de-Q0617-answer

**de-Q0618** — Der bekannte Dichter hatte in seinem Arbeitszimmer einen Selbstmordversuch unternommen.

The prominent poet attempted to commit suicide in his study.

War and hatte are past forms of sein and haben. They occur frequently in spoken as well as written German. They also help construct pluperfect forms when a past participle follows.

Why: Past forms of sein and haben. [[German#^de-Q0618|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20bekannte%20Dichter%20hatte%20in%20seinem%20Arbeitszimmer%20einen%20Selbstmordversuch%20unternommen.)
^de-Q0618-answer

**de-Q0619** — Maria war eifersüchtig.

Mary was jealous.

Expected form: **war**

Why: Past forms of sein and haben. [[German#^de-Q0619|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Maria%20war%20eifers%C3%BCchtig.)
^de-Q0619-answer

**de-Q0620** — Maria war eifersüchtig.

Mary was jealous.

Expected form: **war**

Why: Past forms of sein and haben. [[German#^de-Q0620|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Maria%20war%20eifers%C3%BCchtig.)
^de-Q0620-answer

**de-Q0621** — Toms Mutter war eine fromme Katholikin.

Tom's mother was a devout Catholic.

Expected form: **war**

Why: Past forms of sein and haben. [[German#^de-Q0621|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Toms%20Mutter%20war%20eine%20fromme%20Katholikin.)
^de-Q0621-answer

**de-Q0622** — Toms Mutter war eine fromme Katholikin.

Tom's mother was a devout Catholic.

Why: Past forms of sein and haben. [[German#^de-Q0622|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Toms%20Mutter%20war%20eine%20fromme%20Katholikin.)
^de-Q0622-answer

**de-Q0623** — Er war wie gelähmt.

He was stunned.

Why: Past forms of sein and haben. [[German#^de-Q0623|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20war%20wie%20gel%C3%A4hmt.)
^de-Q0623-answer

**de-Q0624** — Er war wie gelähmt.

He was stunned.

War and hatte are past forms of sein and haben. They occur frequently in spoken as well as written German. They also help construct pluperfect forms when a past participle follows.

Why: Past forms of sein and haben. [[German#^de-Q0624|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20war%20wie%20gel%C3%A4hmt.)
^de-Q0624-answer

**de-Q0625** — Maria war ein schüchternes Kind.

Mary was a timid child.

Expected form: **war**

Why: Past forms of sein and haben. [[German#^de-Q0625|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Maria%20war%20ein%20sch%C3%BCchternes%20Kind.)
^de-Q0625-answer

**de-Q0626** — Maria war ein schüchternes Kind.

Mary was a timid child.

Expected form: **war**

Why: Past forms of sein and haben. [[German#^de-Q0626|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Maria%20war%20ein%20sch%C3%BCchternes%20Kind.)
^de-Q0626-answer

**de-Q0627** — Eines Nachts hatte er einen Traum.

One night, he had a dream.

Expected form: **hatte**

Why: Past forms of sein and haben. [[German#^de-Q0627|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Eines%20Nachts%20hatte%20er%20einen%20Traum.)
^de-Q0627-answer

**de-Q0628** — Eines Nachts hatte er einen Traum.

One night, he had a dream.

Why: Past forms of sein and haben. [[German#^de-Q0628|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Eines%20Nachts%20hatte%20er%20einen%20Traum.)
^de-Q0628-answer

**de-Q0629** — Ich war froh, als ich erwachte und feststellte, dass alles nur ein böser Traum gewesen war.

I was glad when I woke up and realised that it had all been just a bad dream.

Why: Past forms of sein and haben. [[German#^de-Q0629|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20war%20froh%2C%20als%20ich%20erwachte%20und%20feststellte%2C%20dass%20alles%20nur%20ein%20b%C3%B6ser%20Traum%20gewesen%20war.)
^de-Q0629-answer

**de-Q0630** — Ich war froh, als ich erwachte und feststellte, dass alles nur ein böser Traum gewesen war.

I was glad when I woke up and realised that it had all been just a bad dream.

War and hatte are past forms of sein and haben. They occur frequently in spoken as well as written German. They also help construct pluperfect forms when a past participle follows.

Why: Past forms of sein and haben. [[German#^de-Q0630|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20war%20froh%2C%20als%20ich%20erwachte%20und%20feststellte%2C%20dass%20alles%20nur%20ein%20b%C3%B6ser%20Traum%20gewesen%20war.)
^de-Q0630-answer

**de-Q0631** — Ich hatte ein Gespräch mit Tom.

I had a talk with Tom.

Expected form: **hatte**

Why: Past forms of sein and haben. [[German#^de-Q0631|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20hatte%20ein%20Gespr%C3%A4ch%20mit%20Tom.)
^de-Q0631-answer

**de-Q0632** — Ich hatte ein Gespräch mit Tom.

I had a talk with Tom.

Expected form: **hatte**

Why: Past forms of sein and haben. [[German#^de-Q0632|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20hatte%20ein%20Gespr%C3%A4ch%20mit%20Tom.)
^de-Q0632-answer

**de-Q0633** — Die Frau benutzte ein Nasenspray, weil sie eine schwere Erkältung hatte.

The woman used a nasal spray because she had a severe cold.

Expected form: **hatte**

Why: Past forms of sein and haben. [[German#^de-Q0633|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Frau%20benutzte%20ein%20Nasenspray%2C%20weil%20sie%20eine%20schwere%20Erk%C3%A4ltung%20hatte.)
^de-Q0633-answer

**de-Q0634** — Die Frau benutzte ein Nasenspray, weil sie eine schwere Erkältung hatte.

The woman used a nasal spray because she had a severe cold.

Why: Past forms of sein and haben. [[German#^de-Q0634|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Frau%20benutzte%20ein%20Nasenspray%2C%20weil%20sie%20eine%20schwere%20Erk%C3%A4ltung%20hatte.)
^de-Q0634-answer

**de-Q0635** — Als Tom aufwachte, war Maria weg.

When Tom woke up, Mary was gone.

Why: Past forms of sein and haben. [[German#^de-Q0635|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Als%20Tom%20aufwachte%2C%20war%20Maria%20weg.)
^de-Q0635-answer

**de-Q0636** — Als Tom aufwachte, war Maria weg.

When Tom woke up, Mary was gone.

War and hatte are past forms of sein and haben. They occur frequently in spoken as well as written German. They also help construct pluperfect forms when a past participle follows.

Why: Past forms of sein and haben. [[German#^de-Q0636|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Als%20Tom%20aufwachte%2C%20war%20Maria%20weg.)
^de-Q0636-answer

**de-Q0637** — Zuerst: Marley war tot.

Marley was dead: to begin with.

Expected form: **war**

Why: Past forms of sein and haben. [[German#^de-Q0637|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Zuerst%3A%20Marley%20war%20tot.)
^de-Q0637-answer

**de-Q0638** — Zuerst: Marley war tot.

Marley was dead: to begin with.

Expected form: **war**

Why: Past forms of sein and haben. [[German#^de-Q0638|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Zuerst%3A%20Marley%20war%20tot.)
^de-Q0638-answer

**de-Q0639** — Tom hatte nichts zu tun; deswegen ist er nach Hause gegangen.

Tom had nothing to do, so he went home.

Expected form: **hatte**

Why: Past forms of sein and haben. [[German#^de-Q0639|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20hatte%20nichts%20zu%20tun%3B%20deswegen%20ist%20er%20nach%20Hause%20gegangen.)
^de-Q0639-answer

**de-Q0640** — Tom hatte nichts zu tun; deswegen ist er nach Hause gegangen.

Tom had nothing to do, so he went home.

Why: Past forms of sein and haben. [[German#^de-Q0640|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20hatte%20nichts%20zu%20tun%3B%20deswegen%20ist%20er%20nach%20Hause%20gegangen.)
^de-Q0640-answer

**de-Q0641** — Seien wir ehrlich! Das war ein Witz über mich.

Let's be honest. That joke was about me.

Why: Past forms of sein and haben. [[German#^de-Q0641|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Seien%20wir%20ehrlich%21%20Das%20war%20ein%20Witz%20%C3%BCber%20mich.)
^de-Q0641-answer

**de-Q0642** — Seien wir ehrlich! Das war ein Witz über mich.

Let's be honest. That joke was about me.

War and hatte are past forms of sein and haben. They occur frequently in spoken as well as written German. They also help construct pluperfect forms when a past participle follows.

Why: Past forms of sein and haben. [[German#^de-Q0642|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Seien%20wir%20ehrlich%21%20Das%20war%20ein%20Witz%20%C3%BCber%20mich.)
^de-Q0642-answer

**de-Q0643** — Sie hatten viel Spaß auf meine Kosten.

They had great fun at my expense.

Expected form: **hatten**

Why: Past forms of sein and haben. [[German#^de-Q0643|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20hatten%20viel%20Spa%C3%9F%20auf%20meine%20Kosten.)
^de-Q0643-answer

**de-Q0644** — Sie hatten viel Spaß auf meine Kosten.

They had great fun at my expense.

Expected form: **hatten**

Why: Past forms of sein and haben. [[German#^de-Q0644|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20hatten%20viel%20Spa%C3%9F%20auf%20meine%20Kosten.)
^de-Q0644-answer

**de-Q0645** — Sie hatten nicht mehr das Bedürfnis zu protestieren.

They no longer felt a need to protest.

Expected form: **hatten**

Why: Past forms of sein and haben. [[German#^de-Q0645|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20hatten%20nicht%20mehr%20das%20Bed%C3%BCrfnis%20zu%20protestieren.)
^de-Q0645-answer

**de-Q0646** — Sie hatten nicht mehr das Bedürfnis zu protestieren.

They no longer felt a need to protest.

Why: Past forms of sein and haben. [[German#^de-Q0646|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20hatten%20nicht%20mehr%20das%20Bed%C3%BCrfnis%20zu%20protestieren.)
^de-Q0646-answer

**de-Q0647** — Ich kam zu spät zu der Besprechung mit dem Ergebnis, dass ich das Wichtigste verpasst hatte.

I was late for the meeting with the result that I missed the most important part.

Why: Past forms of sein and haben. [[German#^de-Q0647|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20kam%20zu%20sp%C3%A4t%20zu%20der%20Besprechung%20mit%20dem%20Ergebnis%2C%20dass%20ich%20das%20Wichtigste%20verpasst%20hatte.)
^de-Q0647-answer

**de-Q0648** — Ich kam zu spät zu der Besprechung mit dem Ergebnis, dass ich das Wichtigste verpasst hatte.

I was late for the meeting with the result that I missed the most important part.

War and hatte are past forms of sein and haben. They occur frequently in spoken as well as written German. They also help construct pluperfect forms when a past participle follows.

Why: Past forms of sein and haben. [[German#^de-Q0648|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20kam%20zu%20sp%C3%A4t%20zu%20der%20Besprechung%20mit%20dem%20Ergebnis%2C%20dass%20ich%20das%20Wichtigste%20verpasst%20hatte.)
^de-Q0648-answer

**de-Q0649** — Ich hatte keine andere Wahl, als anzunehmen.

I had no choice but to accept.

Expected form: **hatte**

Why: Past forms of sein and haben. [[German#^de-Q0649|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20hatte%20keine%20andere%20Wahl%2C%20als%20anzunehmen.)
^de-Q0649-answer

**de-Q0650** — Ich hatte keine andere Wahl, als anzunehmen.

I had no choice but to accept.

Expected form: **hatte**

Why: Past forms of sein and haben. [[German#^de-Q0650|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20hatte%20keine%20andere%20Wahl%2C%20als%20anzunehmen.)
^de-Q0650-answer


### Answers 651–700

**de-Q0651** — Weißt du, wie beschäftigt ich gewesen bin?

Do you know how busy I've been?

Expected form: **gewesen**

Why: Participles in context. [[German#^de-Q0651|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wei%C3%9Ft%20du%2C%20wie%20besch%C3%A4ftigt%20ich%20gewesen%20bin%3F)
^de-Q0651-answer

**de-Q0652** — Weißt du, wie beschäftigt ich gewesen bin?

Do you know how busy I've been?

Why: Participles in context. [[German#^de-Q0652|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wei%C3%9Ft%20du%2C%20wie%20besch%C3%A4ftigt%20ich%20gewesen%20bin%3F)
^de-Q0652-answer

**de-Q0653** — Wer hat es ihm gesagt? Nicht vielleicht du?

Who told him? Not you, perhaps?

Why: Participles in context. [[German#^de-Q0653|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wer%20hat%20es%20ihm%20gesagt%3F%20Nicht%20vielleicht%20du%3F)
^de-Q0653-answer

**de-Q0654** — Wer hat es ihm gesagt? Nicht vielleicht du?

Who told him? Not you, perhaps?

A past participle can occur in a perfect, passive or adjective phrase. The auxiliary and context determine the construction. Gehen often forms its perfect with sein; many transitive verbs use haben.

Why: Participles in context. [[German#^de-Q0654|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wer%20hat%20es%20ihm%20gesagt%3F%20Nicht%20vielleicht%20du%3F)
^de-Q0654-answer

**de-Q0655** — Tom ist schon lange nicht mehr hier gewesen.

Tom hasn't been here in a long time.

Expected form: **gewesen**

Why: Participles in context. [[German#^de-Q0655|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20ist%20schon%20lange%20nicht%20mehr%20hier%20gewesen.)
^de-Q0655-answer

**de-Q0656** — Tom ist schon lange nicht mehr hier gewesen.

Tom hasn't been here in a long time.

Expected form: **gewesen**

Why: Participles in context. [[German#^de-Q0656|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20ist%20schon%20lange%20nicht%20mehr%20hier%20gewesen.)
^de-Q0656-answer

**de-Q0657** — Hast du gesehen, was Tom Maria angetan hat?

Did you see what Tom did to Mary?

Expected form: **gesehen**

Why: Participles in context. [[German#^de-Q0657|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Hast%20du%20gesehen%2C%20was%20Tom%20Maria%20angetan%20hat%3F)
^de-Q0657-answer

**de-Q0658** — Hast du gesehen, was Tom Maria angetan hat?

Did you see what Tom did to Mary?

Why: Participles in context. [[German#^de-Q0658|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Hast%20du%20gesehen%2C%20was%20Tom%20Maria%20angetan%20hat%3F)
^de-Q0658-answer

**de-Q0659** — Tom hat bisher alles richtig gemacht.

Tom has done everything right so far.

Why: Participles in context. [[German#^de-Q0659|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20hat%20bisher%20alles%20richtig%20gemacht.)
^de-Q0659-answer

**de-Q0660** — Tom hat bisher alles richtig gemacht.

Tom has done everything right so far.

A past participle can occur in a perfect, passive or adjective phrase. The auxiliary and context determine the construction. Gehen often forms its perfect with sein; many transitive verbs use haben.

Why: Participles in context. [[German#^de-Q0660|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20hat%20bisher%20alles%20richtig%20gemacht.)
^de-Q0660-answer

**de-Q0661** — Ich bin noch nie in einem Flugzeug gewesen.

I've never gotten on a plane yet.

Expected form: **gewesen**

Why: Participles in context. [[German#^de-Q0661|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20bin%20noch%20nie%20in%20einem%20Flugzeug%20gewesen.)
^de-Q0661-answer

**de-Q0662** — Ich bin noch nie in einem Flugzeug gewesen.

I've never gotten on a plane yet.

Expected form: **gewesen**

Why: Participles in context. [[German#^de-Q0662|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20bin%20noch%20nie%20in%20einem%20Flugzeug%20gewesen.)
^de-Q0662-answer

**de-Q0663** — A propos Schweiz, sind Sie dort schon mal im Winter gewesen?

Speaking of Switzerland, have you ever been there in winter?

Expected form: **gewesen**

Why: Participles in context. [[German#^de-Q0663|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=A%20propos%20Schweiz%2C%20sind%20Sie%20dort%20schon%20mal%20im%20Winter%20gewesen%3F)
^de-Q0663-answer

**de-Q0664** — A propos Schweiz, sind Sie dort schon mal im Winter gewesen?

Speaking of Switzerland, have you ever been there in winter?

Why: Participles in context. [[German#^de-Q0664|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=A%20propos%20Schweiz%2C%20sind%20Sie%20dort%20schon%20mal%20im%20Winter%20gewesen%3F)
^de-Q0664-answer

**de-Q0665** — Er ist gekommen!

He has come!

Why: Participles in context. [[German#^de-Q0665|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20ist%20gekommen%21)
^de-Q0665-answer

**de-Q0666** — Er ist gekommen!

He has come!

A past participle can occur in a perfect, passive or adjective phrase. The auxiliary and context determine the construction. Gehen often forms its perfect with sein; many transitive verbs use haben.

Why: Participles in context. [[German#^de-Q0666|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20ist%20gekommen%21)
^de-Q0666-answer

**de-Q0667** — Ich habe wohl etwas falsch gemacht.

I seem to have done something wrong.

Expected form: **gemacht**

Why: Participles in context. [[German#^de-Q0667|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20wohl%20etwas%20falsch%20gemacht.)
^de-Q0667-answer

**de-Q0668** — Ich habe wohl etwas falsch gemacht.

I seem to have done something wrong.

Expected form: **gemacht**

Why: Participles in context. [[German#^de-Q0668|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20wohl%20etwas%20falsch%20gemacht.)
^de-Q0668-answer

**de-Q0669** — Ich kann mich nicht erinnern, dass ich das schon mal gesehen hätte.

I don't remember seeing it before.

Expected form: **gesehen**

Why: Participles in context. [[German#^de-Q0669|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20kann%20mich%20nicht%20erinnern%2C%20dass%20ich%20das%20schon%20mal%20gesehen%20h%C3%A4tte.)
^de-Q0669-answer

**de-Q0670** — Ich kann mich nicht erinnern, dass ich das schon mal gesehen hätte.

I don't remember seeing it before.

Why: Participles in context. [[German#^de-Q0670|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20kann%20mich%20nicht%20erinnern%2C%20dass%20ich%20das%20schon%20mal%20gesehen%20h%C3%A4tte.)
^de-Q0670-answer

**de-Q0671** — Ich habe noch nicht gefunden, was ich suche.

I still haven't found what I'm looking for.

Why: Participles in context. [[German#^de-Q0671|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20noch%20nicht%20gefunden%2C%20was%20ich%20suche.)
^de-Q0671-answer

**de-Q0672** — Ich habe noch nicht gefunden, was ich suche.

I still haven't found what I'm looking for.

A past participle can occur in a perfect, passive or adjective phrase. The auxiliary and context determine the construction. Gehen often forms its perfect with sein; many transitive verbs use haben.

Why: Participles in context. [[German#^de-Q0672|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20noch%20nicht%20gefunden%2C%20was%20ich%20suche.)
^de-Q0672-answer

**de-Q0673** — Wenn ich die Wahrheit gewusst hätte, hätte ich sie dir gesagt.

If I'd known the truth, I would've told it to you.

Expected form: **gesagt**

Why: Participles in context. [[German#^de-Q0673|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wenn%20ich%20die%20Wahrheit%20gewusst%20h%C3%A4tte%2C%20h%C3%A4tte%20ich%20sie%20dir%20gesagt.)
^de-Q0673-answer

**de-Q0674** — Wenn ich die Wahrheit gewusst hätte, hätte ich sie dir gesagt.

If I'd known the truth, I would've told it to you.

Expected form: **gesagt**

Why: Participles in context. [[German#^de-Q0674|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wenn%20ich%20die%20Wahrheit%20gewusst%20h%C3%A4tte%2C%20h%C3%A4tte%20ich%20sie%20dir%20gesagt.)
^de-Q0674-answer

**de-Q0675** — Tom bestritt, in die Affäre verwickelt gewesen zu sein.

Tom denied having been involved in the affair.

Expected form: **gewesen**

Why: Participles in context. [[German#^de-Q0675|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20bestritt%2C%20in%20die%20Aff%C3%A4re%20verwickelt%20gewesen%20zu%20sein.)
^de-Q0675-answer

**de-Q0676** — Tom bestritt, in die Affäre verwickelt gewesen zu sein.

Tom denied having been involved in the affair.

Why: Participles in context. [[German#^de-Q0676|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20bestritt%2C%20in%20die%20Aff%C3%A4re%20verwickelt%20gewesen%20zu%20sein.)
^de-Q0676-answer

**de-Q0677** — Ich habe Tom vor drei Wochen gesehen.

I saw Tom three weeks ago.

Why: Participles in context. [[German#^de-Q0677|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20Tom%20vor%20drei%20Wochen%20gesehen.)
^de-Q0677-answer

**de-Q0678** — Ich habe Tom vor drei Wochen gesehen.

I saw Tom three weeks ago.

A past participle can occur in a perfect, passive or adjective phrase. The auxiliary and context determine the construction. Gehen often forms its perfect with sein; many transitive verbs use haben.

Why: Participles in context. [[German#^de-Q0678|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20Tom%20vor%20drei%20Wochen%20gesehen.)
^de-Q0678-answer

**de-Q0679** — Es wäre gemeint gewesen zu lachen.

It would've been mean to laugh.

Expected form: **gewesen**

Why: Participles in context. [[German#^de-Q0679|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20w%C3%A4re%20gemeint%20gewesen%20zu%20lachen.)
^de-Q0679-answer

**de-Q0680** — Es wäre gemeint gewesen zu lachen.

It would've been mean to laugh.

Expected form: **gewesen**

Why: Participles in context. [[German#^de-Q0680|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20w%C3%A4re%20gemeint%20gewesen%20zu%20lachen.)
^de-Q0680-answer

**de-Q0681** — Überleg mal, was ich dir gesagt habe.

Think about what I said to you.

Expected form: **gesagt**

Why: Participles in context. [[German#^de-Q0681|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=%C3%9Cberleg%20mal%2C%20was%20ich%20dir%20gesagt%20habe.)
^de-Q0681-answer

**de-Q0682** — Überleg mal, was ich dir gesagt habe.

Think about what I said to you.

Why: Participles in context. [[German#^de-Q0682|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=%C3%9Cberleg%20mal%2C%20was%20ich%20dir%20gesagt%20habe.)
^de-Q0682-answer

**de-Q0683** — Ich habe alle Briefe verbrannt, die du mir geschrieben hast.

I burned all the letters that you wrote me.

Why: Participles in context. [[German#^de-Q0683|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20alle%20Briefe%20verbrannt%2C%20die%20du%20mir%20geschrieben%20hast.)
^de-Q0683-answer

**de-Q0684** — Ich habe alle Briefe verbrannt, die du mir geschrieben hast.

I burned all the letters that you wrote me.

A past participle can occur in a perfect, passive or adjective phrase. The auxiliary and context determine the construction. Gehen often forms its perfect with sein; many transitive verbs use haben.

Why: Participles in context. [[German#^de-Q0684|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20alle%20Briefe%20verbrannt%2C%20die%20du%20mir%20geschrieben%20hast.)
^de-Q0684-answer

**de-Q0685** — Ich bin gekommen, um dich zu warnen.

I came to warn you.

Expected form: **gekommen**

Why: Participles in context. [[German#^de-Q0685|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20bin%20gekommen%2C%20um%20dich%20zu%20warnen.)
^de-Q0685-answer

**de-Q0686** — Ich bin gekommen, um dich zu warnen.

I came to warn you.

Expected form: **gekommen**

Why: Participles in context. [[German#^de-Q0686|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20bin%20gekommen%2C%20um%20dich%20zu%20warnen.)
^de-Q0686-answer

**de-Q0687** — Sie hat ihr Zimmer noch nicht sauber gemacht.

She hasn't cleaned her room yet.

Expected form: **gemacht**

Why: Participles in context. [[German#^de-Q0687|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20hat%20ihr%20Zimmer%20noch%20nicht%20sauber%20gemacht.)
^de-Q0687-answer

**de-Q0688** — Sie hat ihr Zimmer noch nicht sauber gemacht.

She hasn't cleaned her room yet.

Why: Participles in context. [[German#^de-Q0688|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20hat%20ihr%20Zimmer%20noch%20nicht%20sauber%20gemacht.)
^de-Q0688-answer

**de-Q0689** — Hallo, Liebes, ich habe zwei Bilder gemacht und wüsste gerne, was du von ihnen hältst.

Hello, my dear, I made two pictures and I want your opinion on them.

Why: Participles in context. [[German#^de-Q0689|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Hallo%2C%20Liebes%2C%20ich%20habe%20zwei%20Bilder%20gemacht%20und%20w%C3%BCsste%20gerne%2C%20was%20du%20von%20ihnen%20h%C3%A4ltst.)
^de-Q0689-answer

**de-Q0690** — Hallo, Liebes, ich habe zwei Bilder gemacht und wüsste gerne, was du von ihnen hältst.

Hello, my dear, I made two pictures and I want your opinion on them.

A past participle can occur in a perfect, passive or adjective phrase. The auxiliary and context determine the construction. Gehen often forms its perfect with sein; many transitive verbs use haben.

Why: Participles in context. [[German#^de-Q0690|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Hallo%2C%20Liebes%2C%20ich%20habe%20zwei%20Bilder%20gemacht%20und%20w%C3%BCsste%20gerne%2C%20was%20du%20von%20ihnen%20h%C3%A4ltst.)
^de-Q0690-answer

**de-Q0691** — Tom ist bei einem Unfall ums Leben gekommen.

Tom died in an accident.

Expected form: **gekommen**

Why: Participles in context. [[German#^de-Q0691|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20ist%20bei%20einem%20Unfall%20ums%20Leben%20gekommen.)
^de-Q0691-answer

**de-Q0692** — Tom ist bei einem Unfall ums Leben gekommen.

Tom died in an accident.

Expected form: **gekommen**

Why: Participles in context. [[German#^de-Q0692|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20ist%20bei%20einem%20Unfall%20ums%20Leben%20gekommen.)
^de-Q0692-answer

**de-Q0693** — Wer hat mich gesehen?

Who saw me?

Expected form: **gesehen**

Why: Participles in context. [[German#^de-Q0693|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wer%20hat%20mich%20gesehen%3F)
^de-Q0693-answer

**de-Q0694** — Wer hat mich gesehen?

Who saw me?

Why: Participles in context. [[German#^de-Q0694|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wer%20hat%20mich%20gesehen%3F)
^de-Q0694-answer

**de-Q0695** — Ich habe kein einziges Wort gesagt.

I didn't say a single word.

Why: Participles in context. [[German#^de-Q0695|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20kein%20einziges%20Wort%20gesagt.)
^de-Q0695-answer

**de-Q0696** — Ich habe kein einziges Wort gesagt.

I didn't say a single word.

A past participle can occur in a perfect, passive or adjective phrase. The auxiliary and context determine the construction. Gehen often forms its perfect with sein; many transitive verbs use haben.

Why: Participles in context. [[German#^de-Q0696|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20kein%20einziges%20Wort%20gesagt.)
^de-Q0696-answer

**de-Q0697** — Während meine Frau in der Stadt einkaufen war, habe ich in der Küche klar Schiff gemacht.

While my wife was shopping in town, I tidied up in the kitchen.

Expected form: **gemacht**

Why: Participles in context. [[German#^de-Q0697|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=W%C3%A4hrend%20meine%20Frau%20in%20der%20Stadt%20einkaufen%20war%2C%20habe%20ich%20in%20der%20K%C3%BCche%20klar%20Schiff%20gemacht.)
^de-Q0697-answer

**de-Q0698** — Während meine Frau in der Stadt einkaufen war, habe ich in der Küche klar Schiff gemacht.

While my wife was shopping in town, I tidied up in the kitchen.

Expected form: **gemacht**

Why: Participles in context. [[German#^de-Q0698|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=W%C3%A4hrend%20meine%20Frau%20in%20der%20Stadt%20einkaufen%20war%2C%20habe%20ich%20in%20der%20K%C3%BCche%20klar%20Schiff%20gemacht.)
^de-Q0698-answer

**de-Q0699** — Wir hören oft, dass gesagt wird, die Japaner seien gute Arbeiter.

We often hear it said that the Japanese are good workers.

Expected form: **gesagt**

Why: Participles in context. [[German#^de-Q0699|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20h%C3%B6ren%20oft%2C%20dass%20gesagt%20wird%2C%20die%20Japaner%20seien%20gute%20Arbeiter.)
^de-Q0699-answer

**de-Q0700** — Wir hören oft, dass gesagt wird, die Japaner seien gute Arbeiter.

We often hear it said that the Japanese are good workers.

Why: Participles in context. [[German#^de-Q0700|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20h%C3%B6ren%20oft%2C%20dass%20gesagt%20wird%2C%20die%20Japaner%20seien%20gute%20Arbeiter.)
^de-Q0700-answer


### Answers 701–750

**de-Q0701** — Langsam werde ich neidisch.

I'm beginning to get jealous.

Why: Werden: future and passive. [[German#^de-Q0701|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Langsam%20werde%20ich%20neidisch.)
^de-Q0701-answer

**de-Q0702** — Langsam werde ich neidisch.

I'm beginning to get jealous.

Werden plus infinitive can mark future or prediction; werden plus past participle can mark an event passive. The form alone is not enough: inspect the later verb and the whole meaning.

Why: Werden: future and passive. [[German#^de-Q0702|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Langsam%20werde%20ich%20neidisch.)
^de-Q0702-answer

**de-Q0703** — Tom wird Vater sein.

Tom is going to be a father.

Expected form: **wird**

Why: Werden: future and passive. [[German#^de-Q0703|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20wird%20Vater%20sein.)
^de-Q0703-answer

**de-Q0704** — Tom wird Vater sein.

Tom is going to be a father.

Expected form: **wird**

Why: Werden: future and passive. [[German#^de-Q0704|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20wird%20Vater%20sein.)
^de-Q0704-answer

**de-Q0705** — Ich werde im Krankenhaus behandelt.

I am receiving treatment at the hospital.

Expected form: **werde**

Why: Werden: future and passive. [[German#^de-Q0705|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20werde%20im%20Krankenhaus%20behandelt.)
^de-Q0705-answer

**de-Q0706** — Ich werde im Krankenhaus behandelt.

I am receiving treatment at the hospital.

Why: Werden: future and passive. [[German#^de-Q0706|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20werde%20im%20Krankenhaus%20behandelt.)
^de-Q0706-answer

**de-Q0707** — Tom wird das morgen auch tun.

Tom will do that tomorrow, too.

Why: Werden: future and passive. [[German#^de-Q0707|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20wird%20das%20morgen%20auch%20tun.)
^de-Q0707-answer

**de-Q0708** — Tom wird das morgen auch tun.

Tom will do that tomorrow, too.

Werden plus infinitive can mark future or prediction; werden plus past participle can mark an event passive. The form alone is not enough: inspect the later verb and the whole meaning.

Why: Werden: future and passive. [[German#^de-Q0708|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20wird%20das%20morgen%20auch%20tun.)
^de-Q0708-answer

**de-Q0709** — Ich werde ihnen Bescheid geben.

I'll let them know.

Expected form: **werde**

Why: Werden: future and passive. [[German#^de-Q0709|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20werde%20ihnen%20Bescheid%20geben.)
^de-Q0709-answer

**de-Q0710** — Ich werde ihnen Bescheid geben.

I'll let them know.

Expected form: **werde**

Why: Werden: future and passive. [[German#^de-Q0710|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20werde%20ihnen%20Bescheid%20geben.)
^de-Q0710-answer

**de-Q0711** — Die Tür wird jeden Morgen geöffnet.

The door is opened every morning.

Expected form: **wird**

Why: Werden: future and passive. [[German#^de-Q0711|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20T%C3%BCr%20wird%20jeden%20Morgen%20ge%C3%B6ffnet.)
^de-Q0711-answer

**de-Q0712** — Die Tür wird jeden Morgen geöffnet.

The door is opened every morning.

Why: Werden: future and passive. [[German#^de-Q0712|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20T%C3%BCr%20wird%20jeden%20Morgen%20ge%C3%B6ffnet.)
^de-Q0712-answer

**de-Q0713** — Dieses Diagram wird zeigen, was ich meine.

This diagram will illustrate what I mean.

Why: Werden: future and passive. [[German#^de-Q0713|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Dieses%20Diagram%20wird%20zeigen%2C%20was%20ich%20meine.)
^de-Q0713-answer

**de-Q0714** — Dieses Diagram wird zeigen, was ich meine.

This diagram will illustrate what I mean.

Werden plus infinitive can mark future or prediction; werden plus past participle can mark an event passive. The form alone is not enough: inspect the later verb and the whole meaning.

Why: Werden: future and passive. [[German#^de-Q0714|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Dieses%20Diagram%20wird%20zeigen%2C%20was%20ich%20meine.)
^de-Q0714-answer

**de-Q0715** — Tom wurde 2008 in den Senat gewählt.

Tom was elected to the Senate in 2008.

Expected form: **wurde**

Why: Werden: future and passive. [[German#^de-Q0715|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20wurde%202008%20in%20den%20Senat%20gew%C3%A4hlt.)
^de-Q0715-answer

**de-Q0716** — Tom wurde 2008 in den Senat gewählt.

Tom was elected to the Senate in 2008.

Expected form: **wurde**

Why: Werden: future and passive. [[German#^de-Q0716|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20wurde%202008%20in%20den%20Senat%20gew%C3%A4hlt.)
^de-Q0716-answer

**de-Q0717** — Der Himmel wurde immer dunkler.

The sky grew darker and darker.

Expected form: **wurde**

Why: Werden: future and passive. [[German#^de-Q0717|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Himmel%20wurde%20immer%20dunkler.)
^de-Q0717-answer

**de-Q0718** — Der Himmel wurde immer dunkler.

The sky grew darker and darker.

Why: Werden: future and passive. [[German#^de-Q0718|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Himmel%20wurde%20immer%20dunkler.)
^de-Q0718-answer

**de-Q0719** — Ich werde morgen Rache an ihm nehmen, egal was es koste.

I'll take my revenge on him at all costs tomorrow.

Why: Werden: future and passive. [[German#^de-Q0719|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20werde%20morgen%20Rache%20an%20ihm%20nehmen%2C%20egal%20was%20es%20koste.)
^de-Q0719-answer

**de-Q0720** — Ich werde morgen Rache an ihm nehmen, egal was es koste.

I'll take my revenge on him at all costs tomorrow.

Werden plus infinitive can mark future or prediction; werden plus past participle can mark an event passive. The form alone is not enough: inspect the later verb and the whole meaning.

Why: Werden: future and passive. [[German#^de-Q0720|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20werde%20morgen%20Rache%20an%20ihm%20nehmen%2C%20egal%20was%20es%20koste.)
^de-Q0720-answer

**de-Q0721** — Dennoch wird Japan vom Ausland immer noch nicht genügend verstanden, und die Japaner finden es ihrerseits schwierig, Ausländer zu verstehen.

Yet Japan is still not sufficiently understood by other countries, and the Japanese, likewise, find foreigners difficult to understand.

Expected form: **wird**

Why: Werden: future and passive. [[German#^de-Q0721|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Dennoch%20wird%20Japan%20vom%20Ausland%20immer%20noch%20nicht%20gen%C3%BCgend%20verstanden%2C%20und%20die%20Japaner%20finden%20es%20ihrerseits%20schwierig%2C%20Ausl%C3%A4nder%20zu%20verstehen.)
^de-Q0721-answer

**de-Q0722** — Dennoch wird Japan vom Ausland immer noch nicht genügend verstanden, und die Japaner finden es ihrerseits schwierig, Ausländer zu verstehen.

Yet Japan is still not sufficiently understood by other countries, and the Japanese, likewise, find foreigners difficult to understand.

Expected form: **wird**

Why: Werden: future and passive. [[German#^de-Q0722|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Dennoch%20wird%20Japan%20vom%20Ausland%20immer%20noch%20nicht%20gen%C3%BCgend%20verstanden%2C%20und%20die%20Japaner%20finden%20es%20ihrerseits%20schwierig%2C%20Ausl%C3%A4nder%20zu%20verstehen.)
^de-Q0722-answer

**de-Q0723** — Ich werde zu Mittag zurückrufen.

I'll ring back at midday.

Expected form: **werde**

Why: Werden: future and passive. [[German#^de-Q0723|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20werde%20zu%20Mittag%20zur%C3%BCckrufen.)
^de-Q0723-answer

**de-Q0724** — Ich werde zu Mittag zurückrufen.

I'll ring back at midday.

Why: Werden: future and passive. [[German#^de-Q0724|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20werde%20zu%20Mittag%20zur%C3%BCckrufen.)
^de-Q0724-answer

**de-Q0725** — Kein Kind sollte zurückgelassen werden.

No child should be left behind.

Why: Werden: future and passive. [[German#^de-Q0725|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Kein%20Kind%20sollte%20zur%C3%BCckgelassen%20werden.)
^de-Q0725-answer

**de-Q0726** — Kein Kind sollte zurückgelassen werden.

No child should be left behind.

Werden plus infinitive can mark future or prediction; werden plus past participle can mark an event passive. The form alone is not enough: inspect the later verb and the whole meaning.

Why: Werden: future and passive. [[German#^de-Q0726|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Kein%20Kind%20sollte%20zur%C3%BCckgelassen%20werden.)
^de-Q0726-answer

**de-Q0727** — Es wird bald alles vorbei sein.

It will all be over soon.

Expected form: **wird**

Why: Werden: future and passive. [[German#^de-Q0727|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20wird%20bald%20alles%20vorbei%20sein.)
^de-Q0727-answer

**de-Q0728** — Es wird bald alles vorbei sein.

It will all be over soon.

Expected form: **wird**

Why: Werden: future and passive. [[German#^de-Q0728|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20wird%20bald%20alles%20vorbei%20sein.)
^de-Q0728-answer

**de-Q0729** — Sie werden sich erinnern.

They'll remember.

Expected form: **werden**

Why: Werden: future and passive. [[German#^de-Q0729|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20werden%20sich%20erinnern.)
^de-Q0729-answer

**de-Q0730** — Sie werden sich erinnern.

They'll remember.

Why: Werden: future and passive. [[German#^de-Q0730|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20werden%20sich%20erinnern.)
^de-Q0730-answer

**de-Q0731** — Tom sagte, er werde helfen.

Tom said that he was going to help.

Why: Werden: future and passive. [[German#^de-Q0731|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20sagte%2C%20er%20werde%20helfen.)
^de-Q0731-answer

**de-Q0732** — Tom sagte, er werde helfen.

Tom said that he was going to help.

Werden plus infinitive can mark future or prediction; werden plus past participle can mark an event passive. The form alone is not enough: inspect the later verb and the whole meaning.

Why: Werden: future and passive. [[German#^de-Q0732|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20sagte%2C%20er%20werde%20helfen.)
^de-Q0732-answer

**de-Q0733** — Ich werde morgen nach Hokkaidō fahren.

I will go to Hokkaido tomorrow.

Expected form: **werde**

Why: Werden: future and passive. [[German#^de-Q0733|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20werde%20morgen%20nach%20Hokkaid%C5%8D%20fahren.)
^de-Q0733-answer

**de-Q0734** — Ich werde morgen nach Hokkaidō fahren.

I will go to Hokkaido tomorrow.

Expected form: **werde**

Why: Werden: future and passive. [[German#^de-Q0734|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20werde%20morgen%20nach%20Hokkaid%C5%8D%20fahren.)
^de-Q0734-answer

**de-Q0735** — Das Klonen von Übermenschen wurde zum militärischen Standard.

Cloning of supermen in the military became the norm.

Expected form: **wurde**

Why: Werden: future and passive. [[German#^de-Q0735|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20Klonen%20von%20%C3%9Cbermenschen%20wurde%20zum%20milit%C3%A4rischen%20Standard.)
^de-Q0735-answer

**de-Q0736** — Das Klonen von Übermenschen wurde zum militärischen Standard.

Cloning of supermen in the military became the norm.

Why: Werden: future and passive. [[German#^de-Q0736|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20Klonen%20von%20%C3%9Cbermenschen%20wurde%20zum%20milit%C3%A4rischen%20Standard.)
^de-Q0736-answer

**de-Q0737** — Ich werde Weihnachten mit meiner Familie zusammen verbringen.

I'll spend Christmas with my family.

Why: Werden: future and passive. [[German#^de-Q0737|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20werde%20Weihnachten%20mit%20meiner%20Familie%20zusammen%20verbringen.)
^de-Q0737-answer

**de-Q0738** — Ich werde Weihnachten mit meiner Familie zusammen verbringen.

I'll spend Christmas with my family.

Werden plus infinitive can mark future or prediction; werden plus past participle can mark an event passive. The form alone is not enough: inspect the later verb and the whole meaning.

Why: Werden: future and passive. [[German#^de-Q0738|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20werde%20Weihnachten%20mit%20meiner%20Familie%20zusammen%20verbringen.)
^de-Q0738-answer

**de-Q0739** — Ich werde dich verklagen.

I will sue you.

Expected form: **werde**

Why: Werden: future and passive. [[German#^de-Q0739|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20werde%20dich%20verklagen.)
^de-Q0739-answer

**de-Q0740** — Ich werde dich verklagen.

I will sue you.

Expected form: **werde**

Why: Werden: future and passive. [[German#^de-Q0740|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20werde%20dich%20verklagen.)
^de-Q0740-answer

**de-Q0741** — Er wird sich bald an das Klima hier gewöhnen.

He will soon get used to the climate here.

Expected form: **wird**

Why: Werden: future and passive. [[German#^de-Q0741|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20wird%20sich%20bald%20an%20das%20Klima%20hier%20gew%C3%B6hnen.)
^de-Q0741-answer

**de-Q0742** — Er wird sich bald an das Klima hier gewöhnen.

He will soon get used to the climate here.

Why: Werden: future and passive. [[German#^de-Q0742|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20wird%20sich%20bald%20an%20das%20Klima%20hier%20gew%C3%B6hnen.)
^de-Q0742-answer

**de-Q0743** — Wie können wir besser werden?

How can we do better than this?

Why: Werden: future and passive. [[German#^de-Q0743|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20k%C3%B6nnen%20wir%20besser%20werden%3F)
^de-Q0743-answer

**de-Q0744** — Wie können wir besser werden?

How can we do better than this?

Werden plus infinitive can mark future or prediction; werden plus past participle can mark an event passive. The form alone is not enough: inspect the later verb and the whole meaning.

Why: Werden: future and passive. [[German#^de-Q0744|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20k%C3%B6nnen%20wir%20besser%20werden%3F)
^de-Q0744-answer

**de-Q0745** — Die Hochzeit wurde verschoben.

The wedding was moved.

Expected form: **wurde**

Why: Werden: future and passive. [[German#^de-Q0745|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Hochzeit%20wurde%20verschoben.)
^de-Q0745-answer

**de-Q0746** — Die Hochzeit wurde verschoben.

The wedding was moved.

Expected form: **wurde**

Why: Werden: future and passive. [[German#^de-Q0746|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Hochzeit%20wurde%20verschoben.)
^de-Q0746-answer

**de-Q0747** — Wir werden um 12.30 Uhr gemeinsam zu Mittag essen.

We will have lunch together at twelve-thirty.

Expected form: **werden**

Why: Werden: future and passive. [[German#^de-Q0747|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20werden%20um%2012.30%20Uhr%20gemeinsam%20zu%20Mittag%20essen.)
^de-Q0747-answer

**de-Q0748** — Wir werden um 12.30 Uhr gemeinsam zu Mittag essen.

We will have lunch together at twelve-thirty.

Why: Werden: future and passive. [[German#^de-Q0748|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20werden%20um%2012.30%20Uhr%20gemeinsam%20zu%20Mittag%20essen.)
^de-Q0748-answer

**de-Q0749** — Ich werde versuchen, deine Wünsche zu erfüllen.

I'll try to meet your wishes.

Why: Werden: future and passive. [[German#^de-Q0749|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20werde%20versuchen%2C%20deine%20W%C3%BCnsche%20zu%20erf%C3%BCllen.)
^de-Q0749-answer

**de-Q0750** — Ich werde versuchen, deine Wünsche zu erfüllen.

I'll try to meet your wishes.

Werden plus infinitive can mark future or prediction; werden plus past participle can mark an event passive. The form alone is not enough: inspect the later verb and the whole meaning.

Why: Werden: future and passive. [[German#^de-Q0750|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20werde%20versuchen%2C%20deine%20W%C3%BCnsche%20zu%20erf%C3%BCllen.)
^de-Q0750-answer


### Answers 751–800

**de-Q0751** — Sie sagte, sie würde im nächsten Monat sechzehn.

She said she would be sixteen next month.

Expected form: **würde**

Why: Conditional and polite forms. [[German#^de-Q0751|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20sagte%2C%20sie%20w%C3%BCrde%20im%20n%C3%A4chsten%20Monat%20sechzehn.)
^de-Q0751-answer

**de-Q0752** — Sie sagte, sie würde im nächsten Monat sechzehn.

She said she would be sixteen next month.

Expected form: **würde**

Why: Conditional and polite forms. [[German#^de-Q0752|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20sagte%2C%20sie%20w%C3%BCrde%20im%20n%C3%A4chsten%20Monat%20sechzehn.)
^de-Q0752-answer

**de-Q0753** — Könnten Sie das noch einmal erklären?

Would you explain it again?

Expected form: **Könnten**

Why: Conditional and polite forms. [[German#^de-Q0753|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=K%C3%B6nnten%20Sie%20das%20noch%20einmal%20erkl%C3%A4ren%3F)
^de-Q0753-answer

**de-Q0754** — Könnten Sie das noch einmal erklären?

Would you explain it again?

Why: Conditional and polite forms. [[German#^de-Q0754|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=K%C3%B6nnten%20Sie%20das%20noch%20einmal%20erkl%C3%A4ren%3F)
^de-Q0754-answer

**de-Q0755** — Ich würde das gelbe nehmen.

I'll take the yellow one.

Why: Conditional and polite forms. [[German#^de-Q0755|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20w%C3%BCrde%20das%20gelbe%20nehmen.)
^de-Q0755-answer

**de-Q0756** — Ich würde das gelbe nehmen.

I'll take the yellow one.

Konjunktiv II marks hypothetical meaning and polite distance. Würde often combines with an infinitive; wäre and hätte are common direct forms. A hypothetical past uses hätte/wäre plus participle.

Why: Conditional and polite forms. [[German#^de-Q0756|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20w%C3%BCrde%20das%20gelbe%20nehmen.)
^de-Q0756-answer

**de-Q0757** — Mit dem Fahrrad könnte ich in 20 Minuten bei dir zu Hause sein.

With a bicycle, I could reach your house in 20 minutes.

Expected form: **könnte**

Why: Conditional and polite forms. [[German#^de-Q0757|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Mit%20dem%20Fahrrad%20k%C3%B6nnte%20ich%20in%2020%20Minuten%20bei%20dir%20zu%20Hause%20sein.)
^de-Q0757-answer

**de-Q0758** — Mit dem Fahrrad könnte ich in 20 Minuten bei dir zu Hause sein.

With a bicycle, I could reach your house in 20 minutes.

Expected form: **könnte**

Why: Conditional and polite forms. [[German#^de-Q0758|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Mit%20dem%20Fahrrad%20k%C3%B6nnte%20ich%20in%2020%20Minuten%20bei%20dir%20zu%20Hause%20sein.)
^de-Q0758-answer

**de-Q0759** — Ich wünschte ich könnte zaubern.

I wish I could use magic.

Expected form: **könnte**

Why: Conditional and polite forms. [[German#^de-Q0759|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20w%C3%BCnschte%20ich%20k%C3%B6nnte%20zaubern.)
^de-Q0759-answer

**de-Q0760** — Ich wünschte ich könnte zaubern.

I wish I could use magic.

Why: Conditional and polite forms. [[German#^de-Q0760|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20w%C3%BCnschte%20ich%20k%C3%B6nnte%20zaubern.)
^de-Q0760-answer

**de-Q0761** — Hättet ihr etwas dagegen, wenn ich eine Pause machen würde?

Would you mind if I took a break?

Why: Conditional and polite forms. [[German#^de-Q0761|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=H%C3%A4ttet%20ihr%20etwas%20dagegen%2C%20wenn%20ich%20eine%20Pause%20machen%20w%C3%BCrde%3F)
^de-Q0761-answer

**de-Q0762** — Hättet ihr etwas dagegen, wenn ich eine Pause machen würde?

Would you mind if I took a break?

Konjunktiv II marks hypothetical meaning and polite distance. Würde often combines with an infinitive; wäre and hätte are common direct forms. A hypothetical past uses hätte/wäre plus participle.

Why: Conditional and polite forms. [[German#^de-Q0762|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=H%C3%A4ttet%20ihr%20etwas%20dagegen%2C%20wenn%20ich%20eine%20Pause%20machen%20w%C3%BCrde%3F)
^de-Q0762-answer

**de-Q0763** — Würde es dir etwas ausmachen, mir das Zeug hier aus dem Weg zu räumen?

Would you mind moving this stuff out of my way?

Expected form: **Würde**

Why: Conditional and polite forms. [[German#^de-Q0763|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=W%C3%BCrde%20es%20dir%20etwas%20ausmachen%2C%20mir%20das%20Zeug%20hier%20aus%20dem%20Weg%20zu%20r%C3%A4umen%3F)
^de-Q0763-answer

**de-Q0764** — Würde es dir etwas ausmachen, mir das Zeug hier aus dem Weg zu räumen?

Would you mind moving this stuff out of my way?

Expected form: **Würde**

Why: Conditional and polite forms. [[German#^de-Q0764|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=W%C3%BCrde%20es%20dir%20etwas%20ausmachen%2C%20mir%20das%20Zeug%20hier%20aus%20dem%20Weg%20zu%20r%C3%A4umen%3F)
^de-Q0764-answer

**de-Q0765** — Könnte mir bitte jemand helfen?

Could someone please help me?

Expected form: **Könnte**

Why: Conditional and polite forms. [[German#^de-Q0765|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=K%C3%B6nnte%20mir%20bitte%20jemand%20helfen%3F)
^de-Q0765-answer

**de-Q0766** — Könnte mir bitte jemand helfen?

Could someone please help me?

Why: Conditional and polite forms. [[German#^de-Q0766|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=K%C3%B6nnte%20mir%20bitte%20jemand%20helfen%3F)
^de-Q0766-answer

**de-Q0767** — An deiner Stelle würde ich mich für den Job bewerben.

Were I you, I would apply for the job.

Why: Conditional and polite forms. [[German#^de-Q0767|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=An%20deiner%20Stelle%20w%C3%BCrde%20ich%20mich%20f%C3%BCr%20den%20Job%20bewerben.)
^de-Q0767-answer

**de-Q0768** — An deiner Stelle würde ich mich für den Job bewerben.

Were I you, I would apply for the job.

Konjunktiv II marks hypothetical meaning and polite distance. Würde often combines with an infinitive; wäre and hätte are common direct forms. A hypothetical past uses hätte/wäre plus participle.

Why: Conditional and polite forms. [[German#^de-Q0768|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=An%20deiner%20Stelle%20w%C3%BCrde%20ich%20mich%20f%C3%BCr%20den%20Job%20bewerben.)
^de-Q0768-answer

**de-Q0769** — Wenn er mich nur heiraten würde!

If only he would marry me!

Expected form: **würde**

Why: Conditional and polite forms. [[German#^de-Q0769|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wenn%20er%20mich%20nur%20heiraten%20w%C3%BCrde%21)
^de-Q0769-answer

**de-Q0770** — Wenn er mich nur heiraten würde!

If only he would marry me!

Expected form: **würde**

Why: Conditional and polite forms. [[German#^de-Q0770|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wenn%20er%20mich%20nur%20heiraten%20w%C3%BCrde%21)
^de-Q0770-answer

**de-Q0771** — Tom sagte, dass er und Maria gestritten hätten.

Tom said that he and Mary had had a fight.

Expected form: **hätten**

Why: Conditional and polite forms. [[German#^de-Q0771|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20sagte%2C%20dass%20er%20und%20Maria%20gestritten%20h%C3%A4tten.)
^de-Q0771-answer

**de-Q0772** — Tom sagte, dass er und Maria gestritten hätten.

Tom said that he and Mary had had a fight.

Why: Conditional and polite forms. [[German#^de-Q0772|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20sagte%2C%20dass%20er%20und%20Maria%20gestritten%20h%C3%A4tten.)
^de-Q0772-answer

**de-Q0773** — Was hätte ich Ihrer Meinung nach tun sollen?

What do you think I should've done?

Why: Conditional and polite forms. [[German#^de-Q0773|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Was%20h%C3%A4tte%20ich%20Ihrer%20Meinung%20nach%20tun%20sollen%3F)
^de-Q0773-answer

**de-Q0774** — Was hätte ich Ihrer Meinung nach tun sollen?

What do you think I should've done?

Konjunktiv II marks hypothetical meaning and polite distance. Würde often combines with an infinitive; wäre and hätte are common direct forms. A hypothetical past uses hätte/wäre plus participle.

Why: Conditional and polite forms. [[German#^de-Q0774|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Was%20h%C3%A4tte%20ich%20Ihrer%20Meinung%20nach%20tun%20sollen%3F)
^de-Q0774-answer

**de-Q0775** — Tom ist die Art Junge, in den sich ein Mädchen verlieben könnte.

Tom is the kind of guy that a girl could fall in love with.

Expected form: **könnte**

Why: Conditional and polite forms. [[German#^de-Q0775|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20ist%20die%20Art%20Junge%2C%20in%20den%20sich%20ein%20M%C3%A4dchen%20verlieben%20k%C3%B6nnte.)
^de-Q0775-answer

**de-Q0776** — Tom ist die Art Junge, in den sich ein Mädchen verlieben könnte.

Tom is the kind of guy that a girl could fall in love with.

Expected form: **könnte**

Why: Conditional and polite forms. [[German#^de-Q0776|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20ist%20die%20Art%20Junge%2C%20in%20den%20sich%20ein%20M%C3%A4dchen%20verlieben%20k%C3%B6nnte.)
^de-Q0776-answer

**de-Q0777** — Ich hätte dich am Flughafen treffen können.

I could've met you at the airport.

Expected form: **hätte**

Why: Conditional and polite forms. [[German#^de-Q0777|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20h%C3%A4tte%20dich%20am%20Flughafen%20treffen%20k%C3%B6nnen.)
^de-Q0777-answer

**de-Q0778** — Ich hätte dich am Flughafen treffen können.

I could've met you at the airport.

Why: Conditional and polite forms. [[German#^de-Q0778|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20h%C3%A4tte%20dich%20am%20Flughafen%20treffen%20k%C3%B6nnen.)
^de-Q0778-answer

**de-Q0779** — Es würde uns gefallen, wenn Sie sich uns anschließen.

We would like you to join our company.

Why: Conditional and polite forms. [[German#^de-Q0779|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20w%C3%BCrde%20uns%20gefallen%2C%20wenn%20Sie%20sich%20uns%20anschlie%C3%9Fen.)
^de-Q0779-answer

**de-Q0780** — Es würde uns gefallen, wenn Sie sich uns anschließen.

We would like you to join our company.

Konjunktiv II marks hypothetical meaning and polite distance. Würde often combines with an infinitive; wäre and hätte are common direct forms. A hypothetical past uses hätte/wäre plus participle.

Why: Conditional and polite forms. [[German#^de-Q0780|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20w%C3%BCrde%20uns%20gefallen%2C%20wenn%20Sie%20sich%20uns%20anschlie%C3%9Fen.)
^de-Q0780-answer

**de-Q0781** — Ich würde laut schreien, wenn ich einen Skorpion in meinem Zimmer fände.

I would scream very loudly if I saw a scorpion in my room.

Expected form: **würde**

Why: Conditional and polite forms. [[German#^de-Q0781|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20w%C3%BCrde%20laut%20schreien%2C%20wenn%20ich%20einen%20Skorpion%20in%20meinem%20Zimmer%20f%C3%A4nde.)
^de-Q0781-answer

**de-Q0782** — Ich würde laut schreien, wenn ich einen Skorpion in meinem Zimmer fände.

I would scream very loudly if I saw a scorpion in my room.

Expected form: **würde**

Why: Conditional and polite forms. [[German#^de-Q0782|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20w%C3%BCrde%20laut%20schreien%2C%20wenn%20ich%20einen%20Skorpion%20in%20meinem%20Zimmer%20f%C3%A4nde.)
^de-Q0782-answer

**de-Q0783** — Wir hätten bis zum Ende der Party bleiben sollen.

We should've stayed till the end of the party.

Expected form: **hätten**

Why: Conditional and polite forms. [[German#^de-Q0783|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20h%C3%A4tten%20bis%20zum%20Ende%20der%20Party%20bleiben%20sollen.)
^de-Q0783-answer

**de-Q0784** — Wir hätten bis zum Ende der Party bleiben sollen.

We should've stayed till the end of the party.

Why: Conditional and polite forms. [[German#^de-Q0784|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20h%C3%A4tten%20bis%20zum%20Ende%20der%20Party%20bleiben%20sollen.)
^de-Q0784-answer

**de-Q0785** — Könnten Sie mir bitte ein sauberes Messer bringen?

Could you please bring me a clean knife?

Why: Conditional and polite forms. [[German#^de-Q0785|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=K%C3%B6nnten%20Sie%20mir%20bitte%20ein%20sauberes%20Messer%20bringen%3F)
^de-Q0785-answer

**de-Q0786** — Könnten Sie mir bitte ein sauberes Messer bringen?

Could you please bring me a clean knife?

Konjunktiv II marks hypothetical meaning and polite distance. Würde often combines with an infinitive; wäre and hätte are common direct forms. A hypothetical past uses hätte/wäre plus participle.

Why: Conditional and polite forms. [[German#^de-Q0786|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=K%C3%B6nnten%20Sie%20mir%20bitte%20ein%20sauberes%20Messer%20bringen%3F)
^de-Q0786-answer

**de-Q0787** — Das könnte sich als nützlich erweisen.

This might prove useful.

Expected form: **könnte**

Why: Conditional and polite forms. [[German#^de-Q0787|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20k%C3%B6nnte%20sich%20als%20n%C3%BCtzlich%20erweisen.)
^de-Q0787-answer

**de-Q0788** — Das könnte sich als nützlich erweisen.

This might prove useful.

Expected form: **könnte**

Why: Conditional and polite forms. [[German#^de-Q0788|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20k%C3%B6nnte%20sich%20als%20n%C3%BCtzlich%20erweisen.)
^de-Q0788-answer

**de-Q0789** — Ich könnte Sie niemals hassen.

I could never hate you.

Expected form: **könnte**

Why: Conditional and polite forms. [[German#^de-Q0789|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20k%C3%B6nnte%20Sie%20niemals%20hassen.)
^de-Q0789-answer

**de-Q0790** — Ich könnte Sie niemals hassen.

I could never hate you.

Why: Conditional and polite forms. [[German#^de-Q0790|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20k%C3%B6nnte%20Sie%20niemals%20hassen.)
^de-Q0790-answer

**de-Q0791** — Ich wusste, dass Tom das nicht alleine hätte tun können.

I knew Tom couldn't have done this by himself.

Why: Conditional and polite forms. [[German#^de-Q0791|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20wusste%2C%20dass%20Tom%20das%20nicht%20alleine%20h%C3%A4tte%20tun%20k%C3%B6nnen.)
^de-Q0791-answer

**de-Q0792** — Ich wusste, dass Tom das nicht alleine hätte tun können.

I knew Tom couldn't have done this by himself.

Konjunktiv II marks hypothetical meaning and polite distance. Würde often combines with an infinitive; wäre and hätte are common direct forms. A hypothetical past uses hätte/wäre plus participle.

Why: Conditional and polite forms. [[German#^de-Q0792|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20wusste%2C%20dass%20Tom%20das%20nicht%20alleine%20h%C3%A4tte%20tun%20k%C3%B6nnen.)
^de-Q0792-answer

**de-Q0793** — Ich würde gerne hören, was ihr dazu meinst.

I'd like to hear what your opinion is.

Expected form: **würde**

Why: Conditional and polite forms. [[German#^de-Q0793|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20w%C3%BCrde%20gerne%20h%C3%B6ren%2C%20was%20ihr%20dazu%20meinst.)
^de-Q0793-answer

**de-Q0794** — Ich würde gerne hören, was ihr dazu meinst.

I'd like to hear what your opinion is.

Expected form: **würde**

Why: Conditional and polite forms. [[German#^de-Q0794|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20w%C3%BCrde%20gerne%20h%C3%B6ren%2C%20was%20ihr%20dazu%20meinst.)
^de-Q0794-answer

**de-Q0795** — Wir hätten sterben können.

We could've died.

Expected form: **hätten**

Why: Conditional and polite forms. [[German#^de-Q0795|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20h%C3%A4tten%20sterben%20k%C3%B6nnen.)
^de-Q0795-answer

**de-Q0796** — Wir hätten sterben können.

We could've died.

Why: Conditional and polite forms. [[German#^de-Q0796|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20h%C3%A4tten%20sterben%20k%C3%B6nnen.)
^de-Q0796-answer

**de-Q0797** — Ich würde gerne mit dir mitkommen, aber ich kann wirklich nicht.

I'd like to go with you, but I really can't.

Why: Conditional and polite forms. [[German#^de-Q0797|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20w%C3%BCrde%20gerne%20mit%20dir%20mitkommen%2C%20aber%20ich%20kann%20wirklich%20nicht.)
^de-Q0797-answer

**de-Q0798** — Ich würde gerne mit dir mitkommen, aber ich kann wirklich nicht.

I'd like to go with you, but I really can't.

Konjunktiv II marks hypothetical meaning and polite distance. Würde often combines with an infinitive; wäre and hätte are common direct forms. A hypothetical past uses hätte/wäre plus participle.

Why: Conditional and polite forms. [[German#^de-Q0798|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20w%C3%BCrde%20gerne%20mit%20dir%20mitkommen%2C%20aber%20ich%20kann%20wirklich%20nicht.)
^de-Q0798-answer

**de-Q0799** — Ich würde alles für sie tun.

I'd do anything for her.

Expected form: **würde**

Why: Conditional and polite forms. [[German#^de-Q0799|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20w%C3%BCrde%20alles%20f%C3%BCr%20sie%20tun.)
^de-Q0799-answer

**de-Q0800** — Ich würde alles für sie tun.

I'd do anything for her.

Expected form: **würde**

Why: Conditional and polite forms. [[German#^de-Q0800|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20w%C3%BCrde%20alles%20f%C3%BCr%20sie%20tun.)
^de-Q0800-answer


### Answers 801–850

**de-Q0801** — Es lebe die Republik!

Long live the Republic!

Expected form: **die**

Why: Relative words. [[German#^de-Q0801|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20lebe%20die%20Republik%21)
^de-Q0801-answer

**de-Q0802** — Es lebe die Republik!

Long live the Republic!

Why: Relative words. [[German#^de-Q0802|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20lebe%20die%20Republik%21)
^de-Q0802-answer

**de-Q0803** — Du solltest die Menschen respektvoller behandeln.

You should treat people with more respect.

Why: Relative words. [[German#^de-Q0803|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Du%20solltest%20die%20Menschen%20respektvoller%20behandeln.)
^de-Q0803-answer

**de-Q0804** — Du solltest die Menschen respektvoller behandeln.

You should treat people with more respect.

A relative pronoun relates a clause to an antecedent. Its gender and number follow the antecedent, but its case follows its role inside the relative clause. The relative clause normally has verb-final order.

Why: Relative words. [[German#^de-Q0804|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Du%20solltest%20die%20Menschen%20respektvoller%20behandeln.)
^de-Q0804-answer

**de-Q0805** — Dem Mann droht die Todesstrafe.

The man is liable to the death penalty.

Expected form: **Dem**

Why: Relative words. [[German#^de-Q0805|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Dem%20Mann%20droht%20die%20Todesstrafe.)
^de-Q0805-answer

**de-Q0806** — Dem Mann droht die Todesstrafe.

The man is liable to the death penalty.

Expected form: **Dem**

Why: Relative words. [[German#^de-Q0806|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Dem%20Mann%20droht%20die%20Todesstrafe.)
^de-Q0806-answer

**de-Q0807** — Woher wusstest du das alles?

How did you know all that?

Expected form: **das**

Why: Relative words. [[German#^de-Q0807|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Woher%20wusstest%20du%20das%20alles%3F)
^de-Q0807-answer

**de-Q0808** — Woher wusstest du das alles?

How did you know all that?

Why: Relative words. [[German#^de-Q0808|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Woher%20wusstest%20du%20das%20alles%3F)
^de-Q0808-answer

**de-Q0809** — Die Ausgaben betrugen insgesamt 200.000 Yen.

The expenditure totaled 200,000 yen.

Why: Relative words. [[German#^de-Q0809|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Ausgaben%20betrugen%20insgesamt%20200.000%20Yen.)
^de-Q0809-answer

**de-Q0810** — Die Ausgaben betrugen insgesamt 200.000 Yen.

The expenditure totaled 200,000 yen.

A relative pronoun relates a clause to an antecedent. Its gender and number follow the antecedent, but its case follows its role inside the relative clause. The relative clause normally has verb-final order.

Why: Relative words. [[German#^de-Q0810|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Ausgaben%20betrugen%20insgesamt%20200.000%20Yen.)
^de-Q0810-answer

**de-Q0811** — Der Mann ging um die Ecke.

The man walked round the corner.

Expected form: **Der**

Why: Relative words. [[German#^de-Q0811|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Mann%20ging%20um%20die%20Ecke.)
^de-Q0811-answer

**de-Q0812** — Der Mann ging um die Ecke.

The man walked round the corner.

Expected form: **Der**

Why: Relative words. [[German#^de-Q0812|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Mann%20ging%20um%20die%20Ecke.)
^de-Q0812-answer

**de-Q0813** — Die Rechnungen stapeln sich immer mehr.

The bills keep piling up.

Expected form: **Die**

Why: Relative words. [[German#^de-Q0813|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Rechnungen%20stapeln%20sich%20immer%20mehr.)
^de-Q0813-answer

**de-Q0814** — Die Rechnungen stapeln sich immer mehr.

The bills keep piling up.

Why: Relative words. [[German#^de-Q0814|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Rechnungen%20stapeln%20sich%20immer%20mehr.)
^de-Q0814-answer

**de-Q0815** — Der Fuji ist wegen seiner schönen Form bekannt.

Mt. Fuji is noted for its beautiful shape.

Why: Relative words. [[German#^de-Q0815|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Fuji%20ist%20wegen%20seiner%20sch%C3%B6nen%20Form%20bekannt.)
^de-Q0815-answer

**de-Q0816** — Der Fuji ist wegen seiner schönen Form bekannt.

Mt. Fuji is noted for its beautiful shape.

A relative pronoun relates a clause to an antecedent. Its gender and number follow the antecedent, but its case follows its role inside the relative clause. The relative clause normally has verb-final order.

Why: Relative words. [[German#^de-Q0816|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Fuji%20ist%20wegen%20seiner%20sch%C3%B6nen%20Form%20bekannt.)
^de-Q0816-answer

**de-Q0817** — Ich sah Tom die Treppe heraufkommen.

I saw Tom coming up the stairs.

Expected form: **die**

Why: Relative words. [[German#^de-Q0817|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20sah%20Tom%20die%20Treppe%20heraufkommen.)
^de-Q0817-answer

**de-Q0818** — Ich sah Tom die Treppe heraufkommen.

I saw Tom coming up the stairs.

Expected form: **die**

Why: Relative words. [[German#^de-Q0818|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20sah%20Tom%20die%20Treppe%20heraufkommen.)
^de-Q0818-answer

**de-Q0819** — Ich verschob die Veranstaltung.

I postponed the event.

Expected form: **die**

Why: Relative words. [[German#^de-Q0819|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20verschob%20die%20Veranstaltung.)
^de-Q0819-answer

**de-Q0820** — Ich verschob die Veranstaltung.

I postponed the event.

Why: Relative words. [[German#^de-Q0820|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20verschob%20die%20Veranstaltung.)
^de-Q0820-answer

**de-Q0821** — Was ist die Geheimzutat?

What's the secret ingredient?

Why: Relative words. [[German#^de-Q0821|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Was%20ist%20die%20Geheimzutat%3F)
^de-Q0821-answer

**de-Q0822** — Was ist die Geheimzutat?

What's the secret ingredient?

A relative pronoun relates a clause to an antecedent. Its gender and number follow the antecedent, but its case follows its role inside the relative clause. The relative clause normally has verb-final order.

Why: Relative words. [[German#^de-Q0822|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Was%20ist%20die%20Geheimzutat%3F)
^de-Q0822-answer

**de-Q0823** — Das Ticket ist bis zum 29. April gültig.

The ticket is valid to April 29.

Expected form: **Das**

Why: Relative words. [[German#^de-Q0823|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20Ticket%20ist%20bis%20zum%2029.%20April%20g%C3%BCltig.)
^de-Q0823-answer

**de-Q0824** — Das Ticket ist bis zum 29. April gültig.

The ticket is valid to April 29.

Expected form: **Das**

Why: Relative words. [[German#^de-Q0824|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20Ticket%20ist%20bis%20zum%2029.%20April%20g%C3%BCltig.)
^de-Q0824-answer

**de-Q0825** — Das sind sehr gierige Leute.

They are very greedy people.

Expected form: **Das**

Why: Relative words. [[German#^de-Q0825|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20sind%20sehr%20gierige%20Leute.)
^de-Q0825-answer

**de-Q0826** — Das sind sehr gierige Leute.

They are very greedy people.

Why: Relative words. [[German#^de-Q0826|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20sind%20sehr%20gierige%20Leute.)
^de-Q0826-answer

**de-Q0827** — Ich möchte das tun.

I want to do this.

Why: Relative words. [[German#^de-Q0827|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20m%C3%B6chte%20das%20tun.)
^de-Q0827-answer

**de-Q0828** — Ich möchte das tun.

I want to do this.

A relative pronoun relates a clause to an antecedent. Its gender and number follow the antecedent, but its case follows its role inside the relative clause. The relative clause normally has verb-final order.

Why: Relative words. [[German#^de-Q0828|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20m%C3%B6chte%20das%20tun.)
^de-Q0828-answer

**de-Q0829** — Die Kinder beschuldigten sich gegenseitig.

The children blamed each other.

Expected form: **Die**

Why: Relative words. [[German#^de-Q0829|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Kinder%20beschuldigten%20sich%20gegenseitig.)
^de-Q0829-answer

**de-Q0830** — Die Kinder beschuldigten sich gegenseitig.

The children blamed each other.

Expected form: **Die**

Why: Relative words. [[German#^de-Q0830|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Kinder%20beschuldigten%20sich%20gegenseitig.)
^de-Q0830-answer

**de-Q0831** — Die Klitoris ist das empfindlichste Organ einer Frau.

The clitoris is the most sensitive organ of a woman.

Expected form: **Die**

Why: Relative words. [[German#^de-Q0831|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Klitoris%20ist%20das%20empfindlichste%20Organ%20einer%20Frau.)
^de-Q0831-answer

**de-Q0832** — Die Klitoris ist das empfindlichste Organ einer Frau.

The clitoris is the most sensitive organ of a woman.

Why: Relative words. [[German#^de-Q0832|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Die%20Klitoris%20ist%20das%20empfindlichste%20Organ%20einer%20Frau.)
^de-Q0832-answer

**de-Q0833** — Tom sah von der schwindelnden Höhe des Wolkenkratzers auf die Stadt hinab.

Tom looked down upon the city from the dizzying height of the skyscraper.

Why: Relative words. [[German#^de-Q0833|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20sah%20von%20der%20schwindelnden%20H%C3%B6he%20des%20Wolkenkratzers%20auf%20die%20Stadt%20hinab.)
^de-Q0833-answer

**de-Q0834** — Tom sah von der schwindelnden Höhe des Wolkenkratzers auf die Stadt hinab.

Tom looked down upon the city from the dizzying height of the skyscraper.

A relative pronoun relates a clause to an antecedent. Its gender and number follow the antecedent, but its case follows its role inside the relative clause. The relative clause normally has verb-final order.

Why: Relative words. [[German#^de-Q0834|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20sah%20von%20der%20schwindelnden%20H%C3%B6he%20des%20Wolkenkratzers%20auf%20die%20Stadt%20hinab.)
^de-Q0834-answer

**de-Q0835** — Das ist Toms Terminkalender.

This is Tom's diary.

Expected form: **Das**

Why: Relative words. [[German#^de-Q0835|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20ist%20Toms%20Terminkalender.)
^de-Q0835-answer

**de-Q0836** — Das ist Toms Terminkalender.

This is Tom's diary.

Expected form: **Das**

Why: Relative words. [[German#^de-Q0836|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20ist%20Toms%20Terminkalender.)
^de-Q0836-answer

**de-Q0837** — Er füllte die Gläser mit Wein.

He filled the glasses with wine.

Expected form: **die**

Why: Relative words. [[German#^de-Q0837|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20f%C3%BCllte%20die%20Gl%C3%A4ser%20mit%20Wein.)
^de-Q0837-answer

**de-Q0838** — Er füllte die Gläser mit Wein.

He filled the glasses with wine.

Why: Relative words. [[German#^de-Q0838|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20f%C3%BCllte%20die%20Gl%C3%A4ser%20mit%20Wein.)
^de-Q0838-answer

**de-Q0839** — Tom bestieg das Flugzeug.

Tom got on the airplane.

Why: Relative words. [[German#^de-Q0839|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20bestieg%20das%20Flugzeug.)
^de-Q0839-answer

**de-Q0840** — Tom bestieg das Flugzeug.

Tom got on the airplane.

A relative pronoun relates a clause to an antecedent. Its gender and number follow the antecedent, but its case follows its role inside the relative clause. The relative clause normally has verb-final order.

Why: Relative words. [[German#^de-Q0840|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20bestieg%20das%20Flugzeug.)
^de-Q0840-answer

**de-Q0841** — Portugal hat zum ersten Mal einen Sieg beim Liederwettbewerb der Eurovision davongetragen.

Portugal won the Eurovision Song Contest for the first time.

Expected form: **der**

Why: Relative words. [[German#^de-Q0841|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Portugal%20hat%20zum%20ersten%20Mal%20einen%20Sieg%20beim%20Liederwettbewerb%20der%20Eurovision%20davongetragen.)
^de-Q0841-answer

**de-Q0842** — Portugal hat zum ersten Mal einen Sieg beim Liederwettbewerb der Eurovision davongetragen.

Portugal won the Eurovision Song Contest for the first time.

Expected form: **der**

Why: Relative words. [[German#^de-Q0842|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Portugal%20hat%20zum%20ersten%20Mal%20einen%20Sieg%20beim%20Liederwettbewerb%20der%20Eurovision%20davongetragen.)
^de-Q0842-answer

**de-Q0843** — Wo haben Sie das her?

Where did you get this?

Expected form: **das**

Why: Relative words. [[German#^de-Q0843|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wo%20haben%20Sie%20das%20her%3F)
^de-Q0843-answer

**de-Q0844** — Wo haben Sie das her?

Where did you get this?

Why: Relative words. [[German#^de-Q0844|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wo%20haben%20Sie%20das%20her%3F)
^de-Q0844-answer

**de-Q0845** — Das stört wirklich.

It's really annoying.

Why: Relative words. [[German#^de-Q0845|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20st%C3%B6rt%20wirklich.)
^de-Q0845-answer

**de-Q0846** — Das stört wirklich.

It's really annoying.

A relative pronoun relates a clause to an antecedent. Its gender and number follow the antecedent, but its case follows its role inside the relative clause. The relative clause normally has verb-final order.

Why: Relative words. [[German#^de-Q0846|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20st%C3%B6rt%20wirklich.)
^de-Q0846-answer

**de-Q0847** — Das geht mich nichts an.

This matter does not concern me.

Expected form: **Das**

Why: Relative words. [[German#^de-Q0847|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20geht%20mich%20nichts%20an.)
^de-Q0847-answer

**de-Q0848** — Das geht mich nichts an.

This matter does not concern me.

Expected form: **Das**

Why: Relative words. [[German#^de-Q0848|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20geht%20mich%20nichts%20an.)
^de-Q0848-answer

**de-Q0849** — Früher durften Frauen das nicht.

Women didn't use to be allowed to do that.

Expected form: **das**

Why: Relative words. [[German#^de-Q0849|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Fr%C3%BCher%20durften%20Frauen%20das%20nicht.)
^de-Q0849-answer

**de-Q0850** — Früher durften Frauen das nicht.

Women didn't use to be allowed to do that.

Why: Relative words. [[German#^de-Q0850|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Fr%C3%BCher%20durften%20Frauen%20das%20nicht.)
^de-Q0850-answer


### Answers 851–900

**de-Q0851** — John ist zu dick, um schnell zu rennen.

John is too fat to run fast.

Why: Infinitives with zu. [[German#^de-Q0851|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=John%20ist%20zu%20dick%2C%20um%20schnell%20zu%20rennen.)
^de-Q0851-answer

**de-Q0852** — John ist zu dick, um schnell zu rennen.

John is too fat to run fast.

Many infinitive complements use zu. Um ... zu expresses purpose when the understood subject fits. Zu can also be a preposition, so check whether a verb infinitive is present before analysing it as an infinitive marker.

Why: Infinitives with zu. [[German#^de-Q0852|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=John%20ist%20zu%20dick%2C%20um%20schnell%20zu%20rennen.)
^de-Q0852-answer

**de-Q0853** — Wir haben unser Leben zu leben.

We have our lives to live.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0853|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20haben%20unser%20Leben%20zu%20leben.)
^de-Q0853-answer

**de-Q0854** — Wir haben unser Leben zu leben.

We have our lives to live.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0854|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20haben%20unser%20Leben%20zu%20leben.)
^de-Q0854-answer

**de-Q0855** — Es bringt nichts, mit ihm zu streiten.

It is vain to argue with him.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0855|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20bringt%20nichts%2C%20mit%20ihm%20zu%20streiten.)
^de-Q0855-answer

**de-Q0856** — Es bringt nichts, mit ihm zu streiten.

It is vain to argue with him.

Why: Infinitives with zu. [[German#^de-Q0856|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20bringt%20nichts%2C%20mit%20ihm%20zu%20streiten.)
^de-Q0856-answer

**de-Q0857** — Ich tatoebaisiere zu viel.

I spend too much time on Tatoeba.

Why: Infinitives with zu. [[German#^de-Q0857|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20tatoebaisiere%20zu%20viel.)
^de-Q0857-answer

**de-Q0858** — Ich tatoebaisiere zu viel.

I spend too much time on Tatoeba.

Many infinitive complements use zu. Um ... zu expresses purpose when the understood subject fits. Zu can also be a preposition, so check whether a verb infinitive is present before analysing it as an infinitive marker.

Why: Infinitives with zu. [[German#^de-Q0858|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20tatoebaisiere%20zu%20viel.)
^de-Q0858-answer

**de-Q0859** — Anscheinend ist Tom nicht willens, seine Fehler zu berichtigen.

Tom seems to be unwilling to correct his mistakes.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0859|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Anscheinend%20ist%20Tom%20nicht%20willens%2C%20seine%20Fehler%20zu%20berichtigen.)
^de-Q0859-answer

**de-Q0860** — Anscheinend ist Tom nicht willens, seine Fehler zu berichtigen.

Tom seems to be unwilling to correct his mistakes.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0860|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Anscheinend%20ist%20Tom%20nicht%20willens%2C%20seine%20Fehler%20zu%20berichtigen.)
^de-Q0860-answer

**de-Q0861** — Warum hast du eingewilligt, ihr zu helfen?

Why did you agree to help her?

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0861|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Warum%20hast%20du%20eingewilligt%2C%20ihr%20zu%20helfen%3F)
^de-Q0861-answer

**de-Q0862** — Warum hast du eingewilligt, ihr zu helfen?

Why did you agree to help her?

Why: Infinitives with zu. [[German#^de-Q0862|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Warum%20hast%20du%20eingewilligt%2C%20ihr%20zu%20helfen%3F)
^de-Q0862-answer

**de-Q0863** — Dann stellte die Hexe ihren Kessel auf das Feuer, um den Zaubertrunk zu bereiten.

Then the witch placed her cauldron on the fire, to prepare the magic draught.

Why: Infinitives with zu. [[German#^de-Q0863|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Dann%20stellte%20die%20Hexe%20ihren%20Kessel%20auf%20das%20Feuer%2C%20um%20den%20Zaubertrunk%20zu%20bereiten.)
^de-Q0863-answer

**de-Q0864** — Dann stellte die Hexe ihren Kessel auf das Feuer, um den Zaubertrunk zu bereiten.

Then the witch placed her cauldron on the fire, to prepare the magic draught.

Many infinitive complements use zu. Um ... zu expresses purpose when the understood subject fits. Zu can also be a preposition, so check whether a verb infinitive is present before analysing it as an infinitive marker.

Why: Infinitives with zu. [[German#^de-Q0864|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Dann%20stellte%20die%20Hexe%20ihren%20Kessel%20auf%20das%20Feuer%2C%20um%20den%20Zaubertrunk%20zu%20bereiten.)
^de-Q0864-answer

**de-Q0865** — Ich habe mit der Sache nichts zu schaffen.

I have nothing to do with the affair.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0865|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20mit%20der%20Sache%20nichts%20zu%20schaffen.)
^de-Q0865-answer

**de-Q0866** — Ich habe mit der Sache nichts zu schaffen.

I have nothing to do with the affair.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0866|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20mit%20der%20Sache%20nichts%20zu%20schaffen.)
^de-Q0866-answer

**de-Q0867** — Versuch wenigstens, vorsichtig zu sein.

At least try and be careful.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0867|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Versuch%20wenigstens%2C%20vorsichtig%20zu%20sein.)
^de-Q0867-answer

**de-Q0868** — Versuch wenigstens, vorsichtig zu sein.

At least try and be careful.

Why: Infinitives with zu. [[German#^de-Q0868|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Versuch%20wenigstens%2C%20vorsichtig%20zu%20sein.)
^de-Q0868-answer

**de-Q0869** — Wir sind dabei zu gewinnen.

We're winning.

Why: Infinitives with zu. [[German#^de-Q0869|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20sind%20dabei%20zu%20gewinnen.)
^de-Q0869-answer

**de-Q0870** — Wir sind dabei zu gewinnen.

We're winning.

Many infinitive complements use zu. Um ... zu expresses purpose when the understood subject fits. Zu can also be a preposition, so check whether a verb infinitive is present before analysing it as an infinitive marker.

Why: Infinitives with zu. [[German#^de-Q0870|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20sind%20dabei%20zu%20gewinnen.)
^de-Q0870-answer

**de-Q0871** — Ich nehme mir ein Taxi, um zum Bahnhof zu fahren.

I take a taxi to the train station.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0871|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20nehme%20mir%20ein%20Taxi%2C%20um%20zum%20Bahnhof%20zu%20fahren.)
^de-Q0871-answer

**de-Q0872** — Ich nehme mir ein Taxi, um zum Bahnhof zu fahren.

I take a taxi to the train station.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0872|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20nehme%20mir%20ein%20Taxi%2C%20um%20zum%20Bahnhof%20zu%20fahren.)
^de-Q0872-answer

**de-Q0873** — Diese Anordnung ist buchstabengetreu zu befolgen.

This order is to be obeyed to the letter.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0873|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Diese%20Anordnung%20ist%20buchstabengetreu%20zu%20befolgen.)
^de-Q0873-answer

**de-Q0874** — Diese Anordnung ist buchstabengetreu zu befolgen.

This order is to be obeyed to the letter.

Why: Infinitives with zu. [[German#^de-Q0874|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Diese%20Anordnung%20ist%20buchstabengetreu%20zu%20befolgen.)
^de-Q0874-answer

**de-Q0875** — Zu meiner Überraschung konnte sie die Frage nicht beantworten.

To my surprise, she could not answer the question.

Why: Infinitives with zu. [[German#^de-Q0875|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Zu%20meiner%20%C3%9Cberraschung%20konnte%20sie%20die%20Frage%20nicht%20beantworten.)
^de-Q0875-answer

**de-Q0876** — Zu meiner Überraschung konnte sie die Frage nicht beantworten.

To my surprise, she could not answer the question.

Many infinitive complements use zu. Um ... zu expresses purpose when the understood subject fits. Zu can also be a preposition, so check whether a verb infinitive is present before analysing it as an infinitive marker.

Why: Infinitives with zu. [[German#^de-Q0876|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Zu%20meiner%20%C3%9Cberraschung%20konnte%20sie%20die%20Frage%20nicht%20beantworten.)
^de-Q0876-answer

**de-Q0877** — Tom machte schnell die Tür zu.

Tom quickly closed the door.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0877|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20machte%20schnell%20die%20T%C3%BCr%20zu.)
^de-Q0877-answer

**de-Q0878** — Tom machte schnell die Tür zu.

Tom quickly closed the door.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0878|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20machte%20schnell%20die%20T%C3%BCr%20zu.)
^de-Q0878-answer

**de-Q0879** — Ich bat Tom zu gehen.

I asked Tom to leave.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0879|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20bat%20Tom%20zu%20gehen.)
^de-Q0879-answer

**de-Q0880** — Ich bat Tom zu gehen.

I asked Tom to leave.

Why: Infinitives with zu. [[German#^de-Q0880|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20bat%20Tom%20zu%20gehen.)
^de-Q0880-answer

**de-Q0881** — Mir kam ein interessantes Gerücht zu Ohren.

I heard an interesting rumor.

Why: Infinitives with zu. [[German#^de-Q0881|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Mir%20kam%20ein%20interessantes%20Ger%C3%BCcht%20zu%20Ohren.)
^de-Q0881-answer

**de-Q0882** — Mir kam ein interessantes Gerücht zu Ohren.

I heard an interesting rumor.

Many infinitive complements use zu. Um ... zu expresses purpose when the understood subject fits. Zu can also be a preposition, so check whether a verb infinitive is present before analysing it as an infinitive marker.

Why: Infinitives with zu. [[German#^de-Q0882|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Mir%20kam%20ein%20interessantes%20Ger%C3%BCcht%20zu%20Ohren.)
^de-Q0882-answer

**de-Q0883** — Es muss angenehm sein, höher gestellte Freunde zu haben.

It must be nice to have friends in high places.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0883|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20muss%20angenehm%20sein%2C%20h%C3%B6her%20gestellte%20Freunde%20zu%20haben.)
^de-Q0883-answer

**de-Q0884** — Es muss angenehm sein, höher gestellte Freunde zu haben.

It must be nice to have friends in high places.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0884|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20muss%20angenehm%20sein%2C%20h%C3%B6her%20gestellte%20Freunde%20zu%20haben.)
^de-Q0884-answer

**de-Q0885** — Versuch doch nicht, mich zu verarschen! Sag mir die Wahrheit!

Don't try to bullshit me, tell me the truth.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0885|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Versuch%20doch%20nicht%2C%20mich%20zu%20verarschen%21%20Sag%20mir%20die%20Wahrheit%21)
^de-Q0885-answer

**de-Q0886** — Versuch doch nicht, mich zu verarschen! Sag mir die Wahrheit!

Don't try to bullshit me, tell me the truth.

Why: Infinitives with zu. [[German#^de-Q0886|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Versuch%20doch%20nicht%2C%20mich%20zu%20verarschen%21%20Sag%20mir%20die%20Wahrheit%21)
^de-Q0886-answer

**de-Q0887** — Hört auf zu zanken.

Stop squabbling.

Why: Infinitives with zu. [[German#^de-Q0887|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=H%C3%B6rt%20auf%20zu%20zanken.)
^de-Q0887-answer

**de-Q0888** — Hört auf zu zanken.

Stop squabbling.

Many infinitive complements use zu. Um ... zu expresses purpose when the understood subject fits. Zu can also be a preposition, so check whether a verb infinitive is present before analysing it as an infinitive marker.

Why: Infinitives with zu. [[German#^de-Q0888|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=H%C3%B6rt%20auf%20zu%20zanken.)
^de-Q0888-answer

**de-Q0889** — Es ist gewiss nicht leicht, das zu verstehen.

It is far from easy to understand it.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0889|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20ist%20gewiss%20nicht%20leicht%2C%20das%20zu%20verstehen.)
^de-Q0889-answer

**de-Q0890** — Es ist gewiss nicht leicht, das zu verstehen.

It is far from easy to understand it.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0890|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20ist%20gewiss%20nicht%20leicht%2C%20das%20zu%20verstehen.)
^de-Q0890-answer

**de-Q0891** — Ihre Erklärung ist mir zu abstrakt.

Your explanation is too abstract for me.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0891|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ihre%20Erkl%C3%A4rung%20ist%20mir%20zu%20abstrakt.)
^de-Q0891-answer

**de-Q0892** — Ihre Erklärung ist mir zu abstrakt.

Your explanation is too abstract for me.

Why: Infinitives with zu. [[German#^de-Q0892|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ihre%20Erkl%C3%A4rung%20ist%20mir%20zu%20abstrakt.)
^de-Q0892-answer

**de-Q0893** — Sie rief ihre beste Freundin an, um ihrem Ärger Luft zu machen.

She telephoned her best friend to vent her frustration.

Why: Infinitives with zu. [[German#^de-Q0893|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20rief%20ihre%20beste%20Freundin%20an%2C%20um%20ihrem%20%C3%84rger%20Luft%20zu%20machen.)
^de-Q0893-answer

**de-Q0894** — Sie rief ihre beste Freundin an, um ihrem Ärger Luft zu machen.

She telephoned her best friend to vent her frustration.

Many infinitive complements use zu. Um ... zu expresses purpose when the understood subject fits. Zu can also be a preposition, so check whether a verb infinitive is present before analysing it as an infinitive marker.

Why: Infinitives with zu. [[German#^de-Q0894|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20rief%20ihre%20beste%20Freundin%20an%2C%20um%20ihrem%20%C3%84rger%20Luft%20zu%20machen.)
^de-Q0894-answer

**de-Q0895** — Wenn Sie rechts abbiegen, sehen Sie das Krankenhaus zu Ihrer Linken.

Turning right, you'll find the hospital on your left.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0895|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wenn%20Sie%20rechts%20abbiegen%2C%20sehen%20Sie%20das%20Krankenhaus%20zu%20Ihrer%20Linken.)
^de-Q0895-answer

**de-Q0896** — Wenn Sie rechts abbiegen, sehen Sie das Krankenhaus zu Ihrer Linken.

Turning right, you'll find the hospital on your left.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0896|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wenn%20Sie%20rechts%20abbiegen%2C%20sehen%20Sie%20das%20Krankenhaus%20zu%20Ihrer%20Linken.)
^de-Q0896-answer

**de-Q0897** — Mathe zu machen ist die einzige gesellschaftlich akzeptable Art, sich in der Öffentlichkeit selbstzubefriedigen.

Doing math is the only socially acceptable way to masturbate in public.

Expected form: **zu**

Why: Infinitives with zu. [[German#^de-Q0897|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Mathe%20zu%20machen%20ist%20die%20einzige%20gesellschaftlich%20akzeptable%20Art%2C%20sich%20in%20der%20%C3%96ffentlichkeit%20selbstzubefriedigen.)
^de-Q0897-answer

**de-Q0898** — Mathe zu machen ist die einzige gesellschaftlich akzeptable Art, sich in der Öffentlichkeit selbstzubefriedigen.

Doing math is the only socially acceptable way to masturbate in public.

Why: Infinitives with zu. [[German#^de-Q0898|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Mathe%20zu%20machen%20ist%20die%20einzige%20gesellschaftlich%20akzeptable%20Art%2C%20sich%20in%20der%20%C3%96ffentlichkeit%20selbstzubefriedigen.)
^de-Q0898-answer

**de-Q0899** — Du hast das Zeug dazu, diese Arbeit zu meistern.

You've got what it takes to do well in this job.

Why: Infinitives with zu. [[German#^de-Q0899|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Du%20hast%20das%20Zeug%20dazu%2C%20diese%20Arbeit%20zu%20meistern.)
^de-Q0899-answer

**de-Q0900** — Du hast das Zeug dazu, diese Arbeit zu meistern.

You've got what it takes to do well in this job.

Many infinitive complements use zu. Um ... zu expresses purpose when the understood subject fits. Zu can also be a preposition, so check whether a verb infinitive is present before analysing it as an infinitive marker.

Why: Infinitives with zu. [[German#^de-Q0900|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Du%20hast%20das%20Zeug%20dazu%2C%20diese%20Arbeit%20zu%20meistern.)
^de-Q0900-answer


### Answers 901–950

**de-Q0901** — Wie viele Instrumente kannst du spielen?

How many instruments do you know how to play?

Expected form: **viele**

Why: Comparison and quantity. [[German#^de-Q0901|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20viele%20Instrumente%20kannst%20du%20spielen%3F)
^de-Q0901-answer

**de-Q0902** — Wie viele Instrumente kannst du spielen?

How many instruments do you know how to play?

Expected form: **viele**

Why: Comparison and quantity. [[German#^de-Q0902|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20viele%20Instrumente%20kannst%20du%20spielen%3F)
^de-Q0902-answer

**de-Q0903** — Tom hat nicht sehr viel geholfen.

Tom didn't help much.

Expected form: **viel**

Why: Comparison and quantity. [[German#^de-Q0903|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20hat%20nicht%20sehr%20viel%20geholfen.)
^de-Q0903-answer

**de-Q0904** — Tom hat nicht sehr viel geholfen.

Tom didn't help much.

Why: Comparison and quantity. [[German#^de-Q0904|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20hat%20nicht%20sehr%20viel%20geholfen.)
^de-Q0904-answer

**de-Q0905** — Wie viel ist das insgesamt?

What is the total amount?

Why: Comparison and quantity. [[German#^de-Q0905|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20viel%20ist%20das%20insgesamt%3F)
^de-Q0905-answer

**de-Q0906** — Wie viel ist das insgesamt?

What is the total amount?

Comparatives normally use als, while equal comparison uses so ... wie. Mehr and weniger do not take the ordinary attributive adjective endings. Viel/viele distinguish some uncountable and countable uses.

Why: Comparison and quantity. [[German#^de-Q0906|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20viel%20ist%20das%20insgesamt%3F)
^de-Q0906-answer

**de-Q0907** — Wie viele Stockwerke hat dieses Gebäude?

How many floors does this building have?

Expected form: **viele**

Why: Comparison and quantity. [[German#^de-Q0907|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20viele%20Stockwerke%20hat%20dieses%20Geb%C3%A4ude%3F)
^de-Q0907-answer

**de-Q0908** — Wie viele Stockwerke hat dieses Gebäude?

How many floors does this building have?

Expected form: **viele**

Why: Comparison and quantity. [[German#^de-Q0908|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20viele%20Stockwerke%20hat%20dieses%20Geb%C3%A4ude%3F)
^de-Q0908-answer

**de-Q0909** — Tom tut so etwas nicht mehr.

Tom doesn't do that kind of thing anymore.

Expected form: **mehr**

Why: Comparison and quantity. [[German#^de-Q0909|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20tut%20so%20etwas%20nicht%20mehr.)
^de-Q0909-answer

**de-Q0910** — Tom tut so etwas nicht mehr.

Tom doesn't do that kind of thing anymore.

Why: Comparison and quantity. [[German#^de-Q0910|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20tut%20so%20etwas%20nicht%20mehr.)
^de-Q0910-answer

**de-Q0911** — Ken lernte viele japanische Lieder auswendig.

Ken learned many Japanese songs by heart.

Why: Comparison and quantity. [[German#^de-Q0911|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ken%20lernte%20viele%20japanische%20Lieder%20auswendig.)
^de-Q0911-answer

**de-Q0912** — Ken lernte viele japanische Lieder auswendig.

Ken learned many Japanese songs by heart.

Comparatives normally use als, while equal comparison uses so ... wie. Mehr and weniger do not take the ordinary attributive adjective endings. Viel/viele distinguish some uncountable and countable uses.

Why: Comparison and quantity. [[German#^de-Q0912|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ken%20lernte%20viele%20japanische%20Lieder%20auswendig.)
^de-Q0912-answer

**de-Q0913** — Es gibt so viele Fehler, die man machen kann!

There are so many mistakes to be made.

Expected form: **viele**

Why: Comparison and quantity. [[German#^de-Q0913|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20gibt%20so%20viele%20Fehler%2C%20die%20man%20machen%20kann%21)
^de-Q0913-answer

**de-Q0914** — Es gibt so viele Fehler, die man machen kann!

There are so many mistakes to be made.

Expected form: **viele**

Why: Comparison and quantity. [[German#^de-Q0914|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20gibt%20so%20viele%20Fehler%2C%20die%20man%20machen%20kann%21)
^de-Q0914-answer

**de-Q0915** — Er gab mir nicht weniger als fünftausend Yen.

He gave me no less than five thousand yen.

Expected form: **weniger**

Why: Comparison and quantity. [[German#^de-Q0915|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20gab%20mir%20nicht%20weniger%20als%20f%C3%BCnftausend%20Yen.)
^de-Q0915-answer

**de-Q0916** — Er gab mir nicht weniger als fünftausend Yen.

He gave me no less than five thousand yen.

Why: Comparison and quantity. [[German#^de-Q0916|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Er%20gab%20mir%20nicht%20weniger%20als%20f%C3%BCnftausend%20Yen.)
^de-Q0916-answer

**de-Q0917** — Desto mehr du arbeitest, desto mehr verdienst du.

The more you work, the more you gain.

Why: Comparison and quantity. [[German#^de-Q0917|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Desto%20mehr%20du%20arbeitest%2C%20desto%20mehr%20verdienst%20du.)
^de-Q0917-answer

**de-Q0918** — Desto mehr du arbeitest, desto mehr verdienst du.

The more you work, the more you gain.

Comparatives normally use als, while equal comparison uses so ... wie. Mehr and weniger do not take the ordinary attributive adjective endings. Viel/viele distinguish some uncountable and countable uses.

Why: Comparison and quantity. [[German#^de-Q0918|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Desto%20mehr%20du%20arbeitest%2C%20desto%20mehr%20verdienst%20du.)
^de-Q0918-answer

**de-Q0919** — Viele Männer haben größere Brüste als Frauen.

Many men have larger breasts than women.

Expected form: **Viele**

Why: Comparison and quantity. [[German#^de-Q0919|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Viele%20M%C3%A4nner%20haben%20gr%C3%B6%C3%9Fere%20Br%C3%BCste%20als%20Frauen.)
^de-Q0919-answer

**de-Q0920** — Viele Männer haben größere Brüste als Frauen.

Many men have larger breasts than women.

Expected form: **Viele**

Why: Comparison and quantity. [[German#^de-Q0920|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Viele%20M%C3%A4nner%20haben%20gr%C3%B6%C3%9Fere%20Br%C3%BCste%20als%20Frauen.)
^de-Q0920-answer

**de-Q0921** — Der Tag hat einfach zu wenige Stunden.

There's just too few hours in the day.

Expected form: **wenige**

Why: Comparison and quantity. [[German#^de-Q0921|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Tag%20hat%20einfach%20zu%20wenige%20Stunden.)
^de-Q0921-answer

**de-Q0922** — Der Tag hat einfach zu wenige Stunden.

There's just too few hours in the day.

Why: Comparison and quantity. [[German#^de-Q0922|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Der%20Tag%20hat%20einfach%20zu%20wenige%20Stunden.)
^de-Q0922-answer

**de-Q0923** — Es gibt im Internet wenige Seiten auf Tatarisch.

There are few sites in the Tatar language on the Internet.

Why: Comparison and quantity. [[German#^de-Q0923|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20gibt%20im%20Internet%20wenige%20Seiten%20auf%20Tatarisch.)
^de-Q0923-answer

**de-Q0924** — Es gibt im Internet wenige Seiten auf Tatarisch.

There are few sites in the Tatar language on the Internet.

Comparatives normally use als, while equal comparison uses so ... wie. Mehr and weniger do not take the ordinary attributive adjective endings. Viel/viele distinguish some uncountable and countable uses.

Why: Comparison and quantity. [[German#^de-Q0924|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Es%20gibt%20im%20Internet%20wenige%20Seiten%20auf%20Tatarisch.)
^de-Q0924-answer

**de-Q0925** — Ich habe weniger Geld als du.

I have less money than you.

Expected form: **weniger**

Why: Comparison and quantity. [[German#^de-Q0925|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20weniger%20Geld%20als%20du.)
^de-Q0925-answer

**de-Q0926** — Ich habe weniger Geld als du.

I have less money than you.

Expected form: **weniger**

Why: Comparison and quantity. [[German#^de-Q0926|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20weniger%20Geld%20als%20du.)
^de-Q0926-answer

**de-Q0927** — Menschen, die Überstunden machen, bringen nicht immer mehr Arbeit zustande.

People who work longer hours don't always get more work done.

Expected form: **mehr**

Why: Comparison and quantity. [[German#^de-Q0927|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Menschen%2C%20die%20%C3%9Cberstunden%20machen%2C%20bringen%20nicht%20immer%20mehr%20Arbeit%20zustande.)
^de-Q0927-answer

**de-Q0928** — Menschen, die Überstunden machen, bringen nicht immer mehr Arbeit zustande.

People who work longer hours don't always get more work done.

Why: Comparison and quantity. [[German#^de-Q0928|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Menschen%2C%20die%20%C3%9Cberstunden%20machen%2C%20bringen%20nicht%20immer%20mehr%20Arbeit%20zustande.)
^de-Q0928-answer

**de-Q0929** — Übernimm nicht mehr, als du bewältigen kannst!

Don't take on more than you can handle!

Why: Comparison and quantity. [[German#^de-Q0929|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=%C3%9Cbernimm%20nicht%20mehr%2C%20als%20du%20bew%C3%A4ltigen%20kannst%21)
^de-Q0929-answer

**de-Q0930** — Übernimm nicht mehr, als du bewältigen kannst!

Don't take on more than you can handle!

Comparatives normally use als, while equal comparison uses so ... wie. Mehr and weniger do not take the ordinary attributive adjective endings. Viel/viele distinguish some uncountable and countable uses.

Why: Comparison and quantity. [[German#^de-Q0930|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=%C3%9Cbernimm%20nicht%20mehr%2C%20als%20du%20bew%C3%A4ltigen%20kannst%21)
^de-Q0930-answer

**de-Q0931** — Tom wünschte mir viel Erfolg.

Tom wished me success.

Expected form: **viel**

Why: Comparison and quantity. [[German#^de-Q0931|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20w%C3%BCnschte%20mir%20viel%20Erfolg.)
^de-Q0931-answer

**de-Q0932** — Tom wünschte mir viel Erfolg.

Tom wished me success.

Expected form: **viel**

Why: Comparison and quantity. [[German#^de-Q0932|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20w%C3%BCnschte%20mir%20viel%20Erfolg.)
^de-Q0932-answer

**de-Q0933** — Bist du tatsächlich gewillt, so viel zu bezahen?

Are you really willing to pay that much?

Expected form: **viel**

Why: Comparison and quantity. [[German#^de-Q0933|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Bist%20du%20tats%C3%A4chlich%20gewillt%2C%20so%20viel%20zu%20bezahen%3F)
^de-Q0933-answer

**de-Q0934** — Bist du tatsächlich gewillt, so viel zu bezahen?

Are you really willing to pay that much?

Why: Comparison and quantity. [[German#^de-Q0934|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Bist%20du%20tats%C3%A4chlich%20gewillt%2C%20so%20viel%20zu%20bezahen%3F)
^de-Q0934-answer

**de-Q0935** — Mädchen sollen sich mehr um ihr Aussehen sorgen als Jungen.

They say that girls spend more time worrying about how they look than boys do.

Why: Comparison and quantity. [[German#^de-Q0935|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=M%C3%A4dchen%20sollen%20sich%20mehr%20um%20ihr%20Aussehen%20sorgen%20als%20Jungen.)
^de-Q0935-answer

**de-Q0936** — Mädchen sollen sich mehr um ihr Aussehen sorgen als Jungen.

They say that girls spend more time worrying about how they look than boys do.

Comparatives normally use als, while equal comparison uses so ... wie. Mehr and weniger do not take the ordinary attributive adjective endings. Viel/viele distinguish some uncountable and countable uses.

Why: Comparison and quantity. [[German#^de-Q0936|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=M%C3%A4dchen%20sollen%20sich%20mehr%20um%20ihr%20Aussehen%20sorgen%20als%20Jungen.)
^de-Q0936-answer

**de-Q0937** — Wie viel gebt ihr mir dafür?

How much will you give me for this?

Expected form: **viel**

Why: Comparison and quantity. [[German#^de-Q0937|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20viel%20gebt%20ihr%20mir%20daf%C3%BCr%3F)
^de-Q0937-answer

**de-Q0938** — Wie viel gebt ihr mir dafür?

How much will you give me for this?

Expected form: **viel**

Why: Comparison and quantity. [[German#^de-Q0938|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20viel%20gebt%20ihr%20mir%20daf%C3%BCr%3F)
^de-Q0938-answer

**de-Q0939** — Mit ein bisschen mehr Anstrengung.

With a little more effort.

Expected form: **mehr**

Why: Comparison and quantity. [[German#^de-Q0939|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Mit%20ein%20bisschen%20mehr%20Anstrengung.)
^de-Q0939-answer

**de-Q0940** — Mit ein bisschen mehr Anstrengung.

With a little more effort.

Why: Comparison and quantity. [[German#^de-Q0940|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Mit%20ein%20bisschen%20mehr%20Anstrengung.)
^de-Q0940-answer

**de-Q0941** — Ich habe schon lange kein Radio mehr gehört.

I haven't listened to the radio in a long time.

Why: Comparison and quantity. [[German#^de-Q0941|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20schon%20lange%20kein%20Radio%20mehr%20geh%C3%B6rt.)
^de-Q0941-answer

**de-Q0942** — Ich habe schon lange kein Radio mehr gehört.

I haven't listened to the radio in a long time.

Comparatives normally use als, while equal comparison uses so ... wie. Mehr and weniger do not take the ordinary attributive adjective endings. Viel/viele distinguish some uncountable and countable uses.

Why: Comparison and quantity. [[German#^de-Q0942|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20habe%20schon%20lange%20kein%20Radio%20mehr%20geh%C3%B6rt.)
^de-Q0942-answer

**de-Q0943** — Das Gesetz ist nicht mehr in Kraft.

The law is no longer in force.

Expected form: **mehr**

Why: Comparison and quantity. [[German#^de-Q0943|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20Gesetz%20ist%20nicht%20mehr%20in%20Kraft.)
^de-Q0943-answer

**de-Q0944** — Das Gesetz ist nicht mehr in Kraft.

The law is no longer in force.

Expected form: **mehr**

Why: Comparison and quantity. [[German#^de-Q0944|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20Gesetz%20ist%20nicht%20mehr%20in%20Kraft.)
^de-Q0944-answer

**de-Q0945** — Wir haben weitaus mehr Gemeinsamkeiten, als du wahrscheinlich denkst.

We have a lot more in common than you probably think we do.

Expected form: **mehr**

Why: Comparison and quantity. [[German#^de-Q0945|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20haben%20weitaus%20mehr%20Gemeinsamkeiten%2C%20als%20du%20wahrscheinlich%20denkst.)
^de-Q0945-answer

**de-Q0946** — Wir haben weitaus mehr Gemeinsamkeiten, als du wahrscheinlich denkst.

We have a lot more in common than you probably think we do.

Why: Comparison and quantity. [[German#^de-Q0946|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wir%20haben%20weitaus%20mehr%20Gemeinsamkeiten%2C%20als%20du%20wahrscheinlich%20denkst.)
^de-Q0946-answer

**de-Q0947** — Das hätte besser laufen können.

That could've gone better.

Why: Comparison and quantity. [[German#^de-Q0947|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20h%C3%A4tte%20besser%20laufen%20k%C3%B6nnen.)
^de-Q0947-answer

**de-Q0948** — Das hätte besser laufen können.

That could've gone better.

Comparatives normally use als, while equal comparison uses so ... wie. Mehr and weniger do not take the ordinary attributive adjective endings. Viel/viele distinguish some uncountable and countable uses.

Why: Comparison and quantity. [[German#^de-Q0948|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20h%C3%A4tte%20besser%20laufen%20k%C3%B6nnen.)
^de-Q0948-answer

**de-Q0949** — Tom fand nicht mehr nach Hause.

Tom couldn't find his way back home.

Expected form: **mehr**

Why: Comparison and quantity. [[German#^de-Q0949|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20fand%20nicht%20mehr%20nach%20Hause.)
^de-Q0949-answer

**de-Q0950** — Tom fand nicht mehr nach Hause.

Tom couldn't find his way back home.

Expected form: **mehr**

Why: Comparison and quantity. [[German#^de-Q0950|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20fand%20nicht%20mehr%20nach%20Hause.)
^de-Q0950-answer


### Answers 951–1000

**de-Q0951** — Du bist ein Hornochse, aber ich liebe dich trotzdem.

You're an idiot, but I still love you.

Expected form: **trotzdem**

Why: Concession and argument. [[German#^de-Q0951|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Du%20bist%20ein%20Hornochse%2C%20aber%20ich%20liebe%20dich%20trotzdem.)
^de-Q0951-answer

**de-Q0952** — Du bist ein Hornochse, aber ich liebe dich trotzdem.

You're an idiot, but I still love you.

Why: Concession and argument. [[German#^de-Q0952|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Du%20bist%20ein%20Hornochse%2C%20aber%20ich%20liebe%20dich%20trotzdem.)
^de-Q0952-answer

**de-Q0953** — Ich besitze keinen CD-Spieler, aber ich habe die CD trotzdem gekauft.

I don't have a CD player, but I bought the CD anyway.

Why: Concession and argument. [[German#^de-Q0953|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20besitze%20keinen%20CD-Spieler%2C%20aber%20ich%20habe%20die%20CD%20trotzdem%20gekauft.)
^de-Q0953-answer

**de-Q0954** — Ich besitze keinen CD-Spieler, aber ich habe die CD trotzdem gekauft.

I don't have a CD player, but I bought the CD anyway.

Obwohl introduces a subordinate concession. Trotzdem, deshalb and jedoch can link main clauses as adverbials, so they interact with verb-second order. Distinguish concession from consequence in the translation.

Why: Concession and argument. [[German#^de-Q0954|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20besitze%20keinen%20CD-Spieler%2C%20aber%20ich%20habe%20die%20CD%20trotzdem%20gekauft.)
^de-Q0954-answer

**de-Q0955** — Obwohl sie alle anderen feige nennt, fehlt ihr selbst dennoch jeglicher Mut.

Although she calls all the others cowardly, she nonetheless lacks any courage herself.

Expected form: **Obwohl**

Why: Concession and argument. [[German#^de-Q0955|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Obwohl%20sie%20alle%20anderen%20feige%20nennt%2C%20fehlt%20ihr%20selbst%20dennoch%20jeglicher%20Mut.)
^de-Q0955-answer

**de-Q0956** — Obwohl sie alle anderen feige nennt, fehlt ihr selbst dennoch jeglicher Mut.

Although she calls all the others cowardly, she nonetheless lacks any courage herself.

Expected form: **Obwohl**

Why: Concession and argument. [[German#^de-Q0956|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Obwohl%20sie%20alle%20anderen%20feige%20nennt%2C%20fehlt%20ihr%20selbst%20dennoch%20jeglicher%20Mut.)
^de-Q0956-answer

**de-Q0957** — Ist mein Freund nicht schrecklich? Er nimmt mich immer zu Horrorfilmen mit, obwohl er weiß, dass ich sie nicht mag. Ich hasse es.

Isn't my boyfriend terrible? He always takes me to see horror movies, even though he knows I don't like them. I hate it.

Expected form: **obwohl**

Why: Concession and argument. [[German#^de-Q0957|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ist%20mein%20Freund%20nicht%20schrecklich%3F%20Er%20nimmt%20mich%20immer%20zu%20Horrorfilmen%20mit%2C%20obwohl%20er%20wei%C3%9F%2C%20dass%20ich%20sie%20nicht%20mag.%20Ich%20hasse%20es.)
^de-Q0957-answer

**de-Q0958** — Ist mein Freund nicht schrecklich? Er nimmt mich immer zu Horrorfilmen mit, obwohl er weiß, dass ich sie nicht mag. Ich hasse es.

Isn't my boyfriend terrible? He always takes me to see horror movies, even though he knows I don't like them. I hate it.

Why: Concession and argument. [[German#^de-Q0958|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ist%20mein%20Freund%20nicht%20schrecklich%3F%20Er%20nimmt%20mich%20immer%20zu%20Horrorfilmen%20mit%2C%20obwohl%20er%20wei%C3%9F%2C%20dass%20ich%20sie%20nicht%20mag.%20Ich%20hasse%20es.)
^de-Q0958-answer

**de-Q0959** — Trotzdem ist es wahr.

It is none the less true.

Why: Concession and argument. [[German#^de-Q0959|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Trotzdem%20ist%20es%20wahr.)
^de-Q0959-answer

**de-Q0960** — Trotzdem ist es wahr.

It is none the less true.

Obwohl introduces a subordinate concession. Trotzdem, deshalb and jedoch can link main clauses as adverbials, so they interact with verb-second order. Distinguish concession from consequence in the translation.

Why: Concession and argument. [[German#^de-Q0960|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Trotzdem%20ist%20es%20wahr.)
^de-Q0960-answer

**de-Q0961** — Tom sagte Maria, dass ihm ihre Schuhe sehr gefielen, obwohl er sie eigentlich hässlich fand.

Tom told Mary that he loved her shoes even though he thought they were ugly.

Expected form: **obwohl**

Why: Concession and argument. [[German#^de-Q0961|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20sagte%20Maria%2C%20dass%20ihm%20ihre%20Schuhe%20sehr%20gefielen%2C%20obwohl%20er%20sie%20eigentlich%20h%C3%A4sslich%20fand.)
^de-Q0961-answer

**de-Q0962** — Tom sagte Maria, dass ihm ihre Schuhe sehr gefielen, obwohl er sie eigentlich hässlich fand.

Tom told Mary that he loved her shoes even though he thought they were ugly.

Expected form: **obwohl**

Why: Concession and argument. [[German#^de-Q0962|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Tom%20sagte%20Maria%2C%20dass%20ihm%20ihre%20Schuhe%20sehr%20gefielen%2C%20obwohl%20er%20sie%20eigentlich%20h%C3%A4sslich%20fand.)
^de-Q0962-answer

**de-Q0963** — Starke Behaarung ist für mich ein Symbol für Männlichkeit, deshalb mag ich das sehr.

I think hairiness is a symbol of masculinity, so I really like it.

Expected form: **deshalb**

Why: Concession and argument. [[German#^de-Q0963|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Starke%20Behaarung%20ist%20f%C3%BCr%20mich%20ein%20Symbol%20f%C3%BCr%20M%C3%A4nnlichkeit%2C%20deshalb%20mag%20ich%20das%20sehr.)
^de-Q0963-answer

**de-Q0964** — Starke Behaarung ist für mich ein Symbol für Männlichkeit, deshalb mag ich das sehr.

I think hairiness is a symbol of masculinity, so I really like it.

Why: Concession and argument. [[German#^de-Q0964|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Starke%20Behaarung%20ist%20f%C3%BCr%20mich%20ein%20Symbol%20f%C3%BCr%20M%C3%A4nnlichkeit%2C%20deshalb%20mag%20ich%20das%20sehr.)
^de-Q0964-answer

**de-Q0965** — Ich bin nicht Tom, allerdings sehe ich ihm ein bisschen ähnlich.

I'm not Tom, though I do resemble him somewhat.

Why: Concession and argument. [[German#^de-Q0965|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20bin%20nicht%20Tom%2C%20allerdings%20sehe%20ich%20ihm%20ein%20bisschen%20%C3%A4hnlich.)
^de-Q0965-answer

**de-Q0966** — Ich bin nicht Tom, allerdings sehe ich ihm ein bisschen ähnlich.

I'm not Tom, though I do resemble him somewhat.

Obwohl introduces a subordinate concession. Trotzdem, deshalb and jedoch can link main clauses as adverbials, so they interact with verb-second order. Distinguish concession from consequence in the translation.

Why: Concession and argument. [[German#^de-Q0966|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20bin%20nicht%20Tom%2C%20allerdings%20sehe%20ich%20ihm%20ein%20bisschen%20%C3%A4hnlich.)
^de-Q0966-answer

**de-Q0967** — Obwohl es ein umfangreiches Buch mit über eintausend Seiten ist, werde ich es bis nächste Woche um diese Zeit gelesen haben.

Though this is a bulky book with over 1000 pages, I will have read it all by this time next week.

Expected form: **Obwohl**

Why: Concession and argument. [[German#^de-Q0967|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Obwohl%20es%20ein%20umfangreiches%20Buch%20mit%20%C3%BCber%20eintausend%20Seiten%20ist%2C%20werde%20ich%20es%20bis%20n%C3%A4chste%20Woche%20um%20diese%20Zeit%20gelesen%20haben.)
^de-Q0967-answer

**de-Q0968** — Obwohl es ein umfangreiches Buch mit über eintausend Seiten ist, werde ich es bis nächste Woche um diese Zeit gelesen haben.

Though this is a bulky book with over 1000 pages, I will have read it all by this time next week.

Expected form: **Obwohl**

Why: Concession and argument. [[German#^de-Q0968|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Obwohl%20es%20ein%20umfangreiches%20Buch%20mit%20%C3%BCber%20eintausend%20Seiten%20ist%2C%20werde%20ich%20es%20bis%20n%C3%A4chste%20Woche%20um%20diese%20Zeit%20gelesen%20haben.)
^de-Q0968-answer

**de-Q0969** — Und trotzdem schaffte er das Examen.

And yet he could pass the exam.

Expected form: **trotzdem**

Why: Concession and argument. [[German#^de-Q0969|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Und%20trotzdem%20schaffte%20er%20das%20Examen.)
^de-Q0969-answer

**de-Q0970** — Und trotzdem schaffte er das Examen.

And yet he could pass the exam.

Why: Concession and argument. [[German#^de-Q0970|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Und%20trotzdem%20schaffte%20er%20das%20Examen.)
^de-Q0970-answer

**de-Q0971** — Das Küchenmesser war zum Schneiden des Fleischs nicht scharf genug; daher nahm ich mein Taschenmesser.

The kitchen knife wasn't sharp enough to cut the meat, so I used my pocket knife.

Why: Concession and argument. [[German#^de-Q0971|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20K%C3%BCchenmesser%20war%20zum%20Schneiden%20des%20Fleischs%20nicht%20scharf%20genug%3B%20daher%20nahm%20ich%20mein%20Taschenmesser.)
^de-Q0971-answer

**de-Q0972** — Das Küchenmesser war zum Schneiden des Fleischs nicht scharf genug; daher nahm ich mein Taschenmesser.

The kitchen knife wasn't sharp enough to cut the meat, so I used my pocket knife.

Obwohl introduces a subordinate concession. Trotzdem, deshalb and jedoch can link main clauses as adverbials, so they interact with verb-second order. Distinguish concession from consequence in the translation.

Why: Concession and argument. [[German#^de-Q0972|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20K%C3%BCchenmesser%20war%20zum%20Schneiden%20des%20Fleischs%20nicht%20scharf%20genug%3B%20daher%20nahm%20ich%20mein%20Taschenmesser.)
^de-Q0972-answer

**de-Q0973** — Ich spreche nicht gut Englisch, obwohl ich es sechs Jahre in der Schule gelernt habe.

I don't speak English well even though I took it for six years at school.

Expected form: **obwohl**

Why: Concession and argument. [[German#^de-Q0973|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20spreche%20nicht%20gut%20Englisch%2C%20obwohl%20ich%20es%20sechs%20Jahre%20in%20der%20Schule%20gelernt%20habe.)
^de-Q0973-answer

**de-Q0974** — Ich spreche nicht gut Englisch, obwohl ich es sechs Jahre in der Schule gelernt habe.

I don't speak English well even though I took it for six years at school.

Expected form: **obwohl**

Why: Concession and argument. [[German#^de-Q0974|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20spreche%20nicht%20gut%20Englisch%2C%20obwohl%20ich%20es%20sechs%20Jahre%20in%20der%20Schule%20gelernt%20habe.)
^de-Q0974-answer

**de-Q0975** — Deshalb ist er wütend geworden.

That's why he got angry.

Expected form: **Deshalb**

Why: Concession and argument. [[German#^de-Q0975|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Deshalb%20ist%20er%20w%C3%BCtend%20geworden.)
^de-Q0975-answer

**de-Q0976** — Deshalb ist er wütend geworden.

That's why he got angry.

Why: Concession and argument. [[German#^de-Q0976|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Deshalb%20ist%20er%20w%C3%BCtend%20geworden.)
^de-Q0976-answer

**de-Q0977** — Ich hatte genug Zeit; daher brauchte ich mich nicht zu beeilen.

I had enough time, so I didn't need to hurry.

Why: Concession and argument. [[German#^de-Q0977|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20hatte%20genug%20Zeit%3B%20daher%20brauchte%20ich%20mich%20nicht%20zu%20beeilen.)
^de-Q0977-answer

**de-Q0978** — Ich hatte genug Zeit; daher brauchte ich mich nicht zu beeilen.

I had enough time, so I didn't need to hurry.

Obwohl introduces a subordinate concession. Trotzdem, deshalb and jedoch can link main clauses as adverbials, so they interact with verb-second order. Distinguish concession from consequence in the translation.

Why: Concession and argument. [[German#^de-Q0978|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20hatte%20genug%20Zeit%3B%20daher%20brauchte%20ich%20mich%20nicht%20zu%20beeilen.)
^de-Q0978-answer

**de-Q0979** — Das ist zwar viel, aber trotzdem nicht genug.

It is a lot, but still it's not enough.

Expected form: **trotzdem**

Why: Concession and argument. [[German#^de-Q0979|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20ist%20zwar%20viel%2C%20aber%20trotzdem%20nicht%20genug.)
^de-Q0979-answer

**de-Q0980** — Das ist zwar viel, aber trotzdem nicht genug.

It is a lot, but still it's not enough.

Expected form: **trotzdem**

Why: Concession and argument. [[German#^de-Q0980|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Das%20ist%20zwar%20viel%2C%20aber%20trotzdem%20nicht%20genug.)
^de-Q0980-answer

**de-Q0981** — Obwohl er so groß ist, finden Frauen ihn recht attraktiv.

Despite his being so tall, women find him quite attractive.

Expected form: **Obwohl**

Why: Concession and argument. [[German#^de-Q0981|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Obwohl%20er%20so%20gro%C3%9F%20ist%2C%20finden%20Frauen%20ihn%20recht%20attraktiv.)
^de-Q0981-answer

**de-Q0982** — Obwohl er so groß ist, finden Frauen ihn recht attraktiv.

Despite his being so tall, women find him quite attractive.

Why: Concession and argument. [[German#^de-Q0982|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Obwohl%20er%20so%20gro%C3%9F%20ist%2C%20finden%20Frauen%20ihn%20recht%20attraktiv.)
^de-Q0982-answer

**de-Q0983** — Ich bin erschöpft, deshalb werde ich es ruhig angehen lassen und ins Teetassenkarussel einsteigen.

I'm tired. I just want to go on the teacup ride and take it easy.

Why: Concession and argument. [[German#^de-Q0983|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20bin%20ersch%C3%B6pft%2C%20deshalb%20werde%20ich%20es%20ruhig%20angehen%20lassen%20und%20ins%20Teetassenkarussel%20einsteigen.)
^de-Q0983-answer

**de-Q0984** — Ich bin erschöpft, deshalb werde ich es ruhig angehen lassen und ins Teetassenkarussel einsteigen.

I'm tired. I just want to go on the teacup ride and take it easy.

Obwohl introduces a subordinate concession. Trotzdem, deshalb and jedoch can link main clauses as adverbials, so they interact with verb-second order. Distinguish concession from consequence in the translation.

Why: Concession and argument. [[German#^de-Q0984|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Ich%20bin%20ersch%C3%B6pft%2C%20deshalb%20werde%20ich%20es%20ruhig%20angehen%20lassen%20und%20ins%20Teetassenkarussel%20einsteigen.)
^de-Q0984-answer

**de-Q0985** — Obwohl er in England geboren wurde, spricht er sehr schlecht Englisch.

Although he was born in England, he speaks English very badly.

Expected form: **Obwohl**

Why: Concession and argument. [[German#^de-Q0985|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Obwohl%20er%20in%20England%20geboren%20wurde%2C%20spricht%20er%20sehr%20schlecht%20Englisch.)
^de-Q0985-answer

**de-Q0986** — Obwohl er in England geboren wurde, spricht er sehr schlecht Englisch.

Although he was born in England, he speaks English very badly.

Expected form: **Obwohl**

Why: Concession and argument. [[German#^de-Q0986|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Obwohl%20er%20in%20England%20geboren%20wurde%2C%20spricht%20er%20sehr%20schlecht%20Englisch.)
^de-Q0986-answer

**de-Q0987** — Wie ihr bereits wisst, spreche ich nicht allzu gut Französisch. Daher zöge ich es vor, keine Rede auf Französisch zu halten.

As you already know, I don't speak French very well, so I'd rather not give a speech in French.

Expected form: **Daher**

Why: Concession and argument. [[German#^de-Q0987|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20ihr%20bereits%20wisst%2C%20spreche%20ich%20nicht%20allzu%20gut%20Franz%C3%B6sisch.%20Daher%20z%C3%B6ge%20ich%20es%20vor%2C%20keine%20Rede%20auf%20Franz%C3%B6sisch%20zu%20halten.)
^de-Q0987-answer

**de-Q0988** — Wie ihr bereits wisst, spreche ich nicht allzu gut Französisch. Daher zöge ich es vor, keine Rede auf Französisch zu halten.

As you already know, I don't speak French very well, so I'd rather not give a speech in French.

Why: Concession and argument. [[German#^de-Q0988|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Wie%20ihr%20bereits%20wisst%2C%20spreche%20ich%20nicht%20allzu%20gut%20Franz%C3%B6sisch.%20Daher%20z%C3%B6ge%20ich%20es%20vor%2C%20keine%20Rede%20auf%20Franz%C3%B6sisch%20zu%20halten.)
^de-Q0988-answer

**de-Q0989** — Obwohl er schon 38 ist, ist er noch immer von seinen Eltern abhängig.

In spite of the fact that he's 38, he's still dependent on his parents.

Why: Concession and argument. [[German#^de-Q0989|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Obwohl%20er%20schon%2038%20ist%2C%20ist%20er%20noch%20immer%20von%20seinen%20Eltern%20abh%C3%A4ngig.)
^de-Q0989-answer

**de-Q0990** — Obwohl er schon 38 ist, ist er noch immer von seinen Eltern abhängig.

In spite of the fact that he's 38, he's still dependent on his parents.

Obwohl introduces a subordinate concession. Trotzdem, deshalb and jedoch can link main clauses as adverbials, so they interact with verb-second order. Distinguish concession from consequence in the translation.

Why: Concession and argument. [[German#^de-Q0990|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Obwohl%20er%20schon%2038%20ist%2C%20ist%20er%20noch%20immer%20von%20seinen%20Eltern%20abh%C3%A4ngig.)
^de-Q0990-answer

**de-Q0991** — Deshalb bin ich nicht gekommen.

That's not why I came.

Expected form: **Deshalb**

Why: Concession and argument. [[German#^de-Q0991|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Deshalb%20bin%20ich%20nicht%20gekommen.)
^de-Q0991-answer

**de-Q0992** — Deshalb bin ich nicht gekommen.

That's not why I came.

Expected form: **Deshalb**

Why: Concession and argument. [[German#^de-Q0992|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Deshalb%20bin%20ich%20nicht%20gekommen.)
^de-Q0992-answer

**de-Q0993** — Obwohl Tom mein Nachbar ist, kenne ich ihn nicht allzu gut.

Even though Tom is my neighbor, I don't know him very well.

Expected form: **Obwohl**

Why: Concession and argument. [[German#^de-Q0993|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Obwohl%20Tom%20mein%20Nachbar%20ist%2C%20kenne%20ich%20ihn%20nicht%20allzu%20gut.)
^de-Q0993-answer

**de-Q0994** — Obwohl Tom mein Nachbar ist, kenne ich ihn nicht allzu gut.

Even though Tom is my neighbor, I don't know him very well.

Why: Concession and argument. [[German#^de-Q0994|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Obwohl%20Tom%20mein%20Nachbar%20ist%2C%20kenne%20ich%20ihn%20nicht%20allzu%20gut.)
^de-Q0994-answer

**de-Q0995** — Sie können die Behandlung jederzeit ablehnen; allerdings muss ich Sie in diesem Fall über die möglichen Auswirkungen aufklären.

You always have the right to refuse treatment, however, I must explain the potential consequences if that will be your choice.

Why: Concession and argument. [[German#^de-Q0995|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20k%C3%B6nnen%20die%20Behandlung%20jederzeit%20ablehnen%3B%20allerdings%20muss%20ich%20Sie%20in%20diesem%20Fall%20%C3%BCber%20die%20m%C3%B6glichen%20Auswirkungen%20aufkl%C3%A4ren.)
^de-Q0995-answer

**de-Q0996** — Sie können die Behandlung jederzeit ablehnen; allerdings muss ich Sie in diesem Fall über die möglichen Auswirkungen aufklären.

You always have the right to refuse treatment, however, I must explain the potential consequences if that will be your choice.

Obwohl introduces a subordinate concession. Trotzdem, deshalb and jedoch can link main clauses as adverbials, so they interact with verb-second order. Distinguish concession from consequence in the translation.

Why: Concession and argument. [[German#^de-Q0996|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Sie%20k%C3%B6nnen%20die%20Behandlung%20jederzeit%20ablehnen%3B%20allerdings%20muss%20ich%20Sie%20in%20diesem%20Fall%20%C3%BCber%20die%20m%C3%B6glichen%20Auswirkungen%20aufkl%C3%A4ren.)
^de-Q0996-answer

**de-Q0997** — Ärgerst du dich deshalb?

Is that why you're upset?

Expected form: **deshalb**

Why: Concession and argument. [[German#^de-Q0997|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=%C3%84rgerst%20du%20dich%20deshalb%3F)
^de-Q0997-answer

**de-Q0998** — Ärgerst du dich deshalb?

Is that why you're upset?

Expected form: **deshalb**

Why: Concession and argument. [[German#^de-Q0998|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=%C3%84rgerst%20du%20dich%20deshalb%3F)
^de-Q0998-answer

**de-Q0999** — Obwohl sie Zwillinge sind, teilen sie nicht viele Interessen.

Though they're twins, they don't have many interests in common.

Expected form: **Obwohl**

Why: Concession and argument. [[German#^de-Q0999|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Obwohl%20sie%20Zwillinge%20sind%2C%20teilen%20sie%20nicht%20viele%20Interessen.)
^de-Q0999-answer

**de-Q1000** — Obwohl sie Zwillinge sind, teilen sie nicht viele Interessen.

Though they're twins, they don't have many interests in common.

Why: Concession and argument. [[German#^de-Q1000|Return to question]] · [Source](https://tatoeba.org/en/sentences/search?from=deu&query=Obwohl%20sie%20Zwillinge%20sind%2C%20teilen%20sie%20nicht%20viele%20Interessen.)
^de-Q1000-answer


## Read and speak

Read the native sentence first, identify its predicate and one grammar form, then check the translation. Say it aloud and change one detail.

### Learning with a clear purpose

Ich lerne eine neue Sprache. Jeden Tag lese ich einen kurzen Text und höre mir klare Beispiele an. Ich schreibe nützliche Wörter in ein Heft. Wenn ich einen Fehler mache, überprüfe ich die Regel und versuche es noch einmal. Mein Ziel ist es, Menschen zu verstehen und meine Gedanken klar auszudrücken.

I am learning a new language. Each day, I read a short text and listen to clear examples. I write useful words in a notebook. When I make a mistake, I check the rule and try again. My goal is to understand people and express my ideas clearly.

### Economics: opportunity cost

Wer sich für eine Möglichkeit entscheidet, verzichtet zugleich auf andere Möglichkeiten. Die Kosten einer Entscheidung bestehen daher nicht nur aus dem Geld, das ausgegeben wird. Auch Zeit, Aufmerksamkeit und entgangene Chancen können relevant sein. Ein günstiger Kurs ist beispielsweise nicht unbedingt die beste Wahl, wenn er kaum zu den eigenen Zielen passt. Um Alternativen sinnvoll zu vergleichen, muss man zunächst klären, welche Ergebnisse wichtig sind. Dabei bleiben manche Werte schwer messbar. Eine sorgfältige Entscheidung kann diese Unsicherheit berücksichtigen, ohne so zu tun, als ließe sich jedes Ziel in einer einzigen Zahl ausdrücken.

Choosing one possibility also means forgoing others. A decision's costs therefore consist not only of money spent, but also time, attention and forgone opportunities. A cheap course may not be the best choice if it poorly fits one's goals. Comparing alternatives requires clarifying the desired outcomes. Some values are hard to measure; careful decisions can acknowledge uncertainty without pretending every goal fits one number.

![[Resources/Audio/de/Reading passage.mp3]]

**Hast du Vorsätze fürs neue Jahr?**

Have you made any New Year's resolutions?

**Tom gab seinen Freunden gegenüber damit an, mit wie vielen Mädchen er schon geschlafen habe.**

Tom bragged to his friends about all the girls he had slept with.

**Zwingen Sie mich nicht, das zu essen!**

Don't make me eat this.

**Ich werde Tom nicht erlauben zu gehen.**

I won't allow Tom to go.

**Japaner und Briten warten an Bushaltestellen normalerweise in einer Schlange.**

Japanese and British people usually wait at a bus stop in a queue.

**Der Vater geht im Park spazieren.**

My father is taking a walk in the park.

**Du wirst von jedem respektiert.**

You're respected by everybody.

**Ich habe es nicht bemerkt.**

I didn't notice it.

**Bring mir meine Kleidung.**

Bring me my clothes.

**Ich weiß genau, wie ihr euch fühlt.**

I know precisely what you are feeling.

**Ich bin es gewohnt, einen Lastwagen zu fahren.**

I am used to driving a truck.

**Ich will nicht zur Arbeit.**

I don't want to go to work.

**Am Ende ist sie wieder zurück nach England gezogen.**

In the end, she moved back to England.

**Tom konnte sich nicht vorstellen, jemanden zu erschießen.**

Tom couldn't imagine himself shooting anyone.

**Er war der einzige Betrunkene auf der Feier.**

He was the only one drunk at the party.

## Professional writing

Write an introduction, a polite request, an explanation of a finding, a summary of a passage and a tactful disagreement. Use the professional/advanced lessons for models.

## PDF edition

[[Resources/PDFs/German.pdf|Open the complete printable book]]
